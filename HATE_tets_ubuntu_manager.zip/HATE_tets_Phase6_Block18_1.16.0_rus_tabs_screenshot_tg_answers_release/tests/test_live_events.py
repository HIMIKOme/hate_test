from __future__ import annotations

import time
import unittest

from services.event_bus import EventBus, EventType
from services.live_events import LiveEventServer, connect_client, read_endpoint


class _Logger:
    def warning(self, *_args, **_kwargs):
        pass


class LiveEventsTests(unittest.TestCase):
    def test_push_transport_delivers_event_without_journal_polling(self):
        bus = EventBus(_Logger())
        server = LiveEventServer(_Logger())
        server.start()
        token = bus.subscribe_all(server.publish)
        try:
            client = connect_client(timeout=1.5)
            self.assertIsNotNone(client)
            assert client is not None
            hello = client.recv(timeout=2)
            self.assertEqual(hello["type"], "LiveConnected")
            bus.publish(EventType.JOB_PROGRESS, source="worker", job_id="job-live", progress=42, stage="testing")
            event = client.recv(timeout=2)
            self.assertEqual(event["type"], "JobProgress")
            self.assertEqual(event["job_id"], "job-live")
            self.assertEqual(event["progress"], 42)
            client.close()
        finally:
            bus.unsubscribe(token)
            server.stop()

    def test_endpoint_is_published_and_removed(self):
        server = LiveEventServer(_Logger())
        server.start()
        try:
            endpoint = read_endpoint()
            self.assertEqual(endpoint["protocol"], "hate-live-events-v1")
            self.assertEqual(int(endpoint["port"]), server.port)
        finally:
            server.stop()
        self.assertNotEqual(read_endpoint().get("pid"), server.pid)


if __name__ == "__main__":
    unittest.main()
