from __future__ import annotations

import json
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

from services.event_bus import EventBus, EventType
from services.job import JobState
from services.job_manager import JobManager
from services.job_timeout import evaluate_job_timeout
from services.watchdog_service import Watchdog
import services.watchdog_service as ws


class _Logger:
    def info(self, *args, **kwargs): pass
    def warning(self, *args, **kwargs): pass
    def error(self, *args, **kwargs): pass
    def debug(self, *args, **kwargs): pass


class _Resource:
    def __init__(self):
        self.closed = False
    def close(self):
        self.closed = True


class _Context:
    def __init__(self):
        self.worker_id = "worker-1"
        self.restarted = False
        self.released = False
        self.resources = {"chrome": _Resource()}
    def restart_browser(self, logger=None):
        self.restarted = True
        return True
    def release_job_resources(self):
        self.released = True


class JobTimeoutPolicyTests(unittest.TestCase):
    def test_per_job_timeout_overrides_global(self):
        job = {"id": "job-1", "state": "TESTING", "started_at": 90, "metadata": {"max_runtime_sec": 5}}
        result = evaluate_job_timeout(job, now=100, default_timeout=60)
        self.assertIsNotNone(result)
        self.assertEqual(result["timeout_sec"], 5.0)
        self.assertTrue(result["intervention_required"])

    def test_allowed_overrun_is_reported_but_not_intervention(self):
        job = {"id": "job-2", "state": "TESTING", "started_at": 0}
        job["started_at"] = 90
        job["metadata"] = {"max_runtime_sec": 5, "stuck_policy": "allow"}
        result = evaluate_job_timeout(job, now=100, default_timeout=60)
        self.assertTrue(result["allow_overrun"])
        self.assertFalse(result["intervention_required"])

    def test_terminal_job_is_never_stuck(self):
        for state in ("QUEUED", "COMPLETED", "FAILED", "CANCELLED"):
            job = {"id": "job-terminal", "state": state, "started_at": 1, "metadata": {"max_runtime_sec": 1}}
            self.assertIsNone(evaluate_job_timeout(job, now=100, default_timeout=1))


class JobManagerStuckTests(unittest.TestCase):
    def test_mark_stuck_writes_diagnostics_and_event(self):
        bus = EventBus(_Logger())
        seen = []
        bus.subscribe(EventType.JOB_STUCK, seen.append)
        manager = JobManager(_Logger(), event_bus=bus, worker_count=1)
        job = manager.create_job("https://example.test", metadata={"max_runtime_sec": 30})
        job.transition(JobState.STARTING, stage="starting")
        manager._active[job.id] = job
        manager.mark_job_stuck(job.id, runtime_sec=31, timeout_sec=30)
        self.assertTrue(job.stuck)
        self.assertTrue(job.intervention_required)
        self.assertEqual(job.diagnostics["timeout"]["reason"], "watchdog_timeout")
        self.assertEqual(seen[-1]["job_id"], job.id)

    def test_recover_stuck_job_restarts_worker_browser(self):
        bus = EventBus(_Logger())
        events = []
        bus.subscribe(EventType.JOB_RECOVERY_SUCCEEDED, events.append)
        manager = JobManager(_Logger(), event_bus=bus, worker_count=1)
        job = manager.create_job("https://example.test", metadata={"max_runtime_sec": 1})
        job.transition(JobState.STARTING, stage="starting")
        manager._active[job.id] = job
        job.worker_id = "worker-1"
        context = _Context()
        manager._contexts["worker-1"] = context
        manager.mark_job_stuck(job.id, runtime_sec=2, timeout_sec=1)
        self.assertTrue(manager.recover_stuck_job(job.id))
        self.assertTrue(context.restarted)
        self.assertEqual(job.recovery_attempts, 1)
        self.assertEqual(job.recovery_status, "recovered")
        self.assertEqual(events[-1]["job_id"], job.id)

    def test_terminate_stuck_job_fails_job_and_releases_resources(self):
        bus = EventBus(_Logger())
        failed = []
        bus.subscribe(EventType.JOB_FAILED, failed.append)
        manager = JobManager(_Logger(), event_bus=bus, worker_count=1)
        job = manager.create_job("https://example.test", metadata={"max_runtime_sec": 1})
        job.transition(JobState.STARTING, stage="starting")
        manager._active[job.id] = job
        job.worker_id = "worker-1"
        context = _Context()
        manager._contexts["worker-1"] = context
        manager.mark_job_stuck(job.id, runtime_sec=2, timeout_sec=1)
        self.assertTrue(manager.terminate_stuck_job(job.id))
        self.assertEqual(job.state, JobState.FAILED)
        self.assertTrue(context.released)
        self.assertEqual(job.recovery_status, "terminated")
        self.assertEqual(failed[-1]["job_id"], job.id)

    def test_allow_overrun_does_not_trigger_recovery(self):
        manager = JobManager(_Logger(), event_bus=EventBus(_Logger()), worker_count=1)
        job = manager.create_job("https://example.test", metadata={"max_runtime_sec": 1, "allow_overrun": True})
        job.transition(JobState.STARTING, stage="starting")
        manager._active[job.id] = job
        self.assertFalse(manager.mark_job_stuck(job.id, runtime_sec=2, timeout_sec=1) is False)
        manager._active.pop(job.id, None)
        self.assertFalse(job.intervention_required)


class JobSnapshotTests(unittest.TestCase):
    def test_job_snapshot_contains_timeout_fields_and_policy(self):
        manager = JobManager(_Logger(), event_bus=EventBus(_Logger()), worker_count=1)
        job = manager.create_job("https://example.test", metadata={"max_runtime_sec": 12, "stuck_policy": "allow"})
        data = job.to_dict()
        self.assertEqual(data["max_runtime_sec"], 12.0)
        self.assertEqual(data["timeout_policy"], "allow")
        self.assertTrue(data["allow_overrun"])
        self.assertFalse(data["stuck"])



class WatchdogEscalationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        base = Path(self.tmp.name)
        self.old = {k: getattr(ws, k) for k in ["HEARTBEATS", "STATUS_PATH", "LOCK_PATH", "LOG_PATH", "SHUTDOWN_MARKER", "web_alive", "read_state", "load_settings", "send_command"]}
        ws.HEARTBEATS = base / "heartbeats"; ws.HEARTBEATS.mkdir(parents=True, exist_ok=True)
        ws.STATUS_PATH = base / "watchdog.json"
        ws.LOCK_PATH = base / "watchdog.lock"
        ws.LOG_PATH = base / "watchdog.log"
        ws.SHUTDOWN_MARKER = base / "shutdown.json"
        ws.web_alive = lambda _cfg: True
        ws.load_settings = lambda: {"telegram_token": ""}
    def tearDown(self):
        for k,v in self.old.items(): setattr(ws,k,v)
        self.tmp.cleanup()
    def _hb(self, name, age=0, **payload):
        body={"timestamp": time.time()-age, "pid": 9999, **payload}
        (ws.HEARTBEATS/name).write_text(json.dumps(body),encoding="utf-8")
    def test_watchdog_detects_per_job_limit_and_records_mark_command(self):
        self._hb("app.json")
        self._hb("worker-1.json", job_id="job-7", queue_type="TEST_QUEUE", age=0)
        commands=[]
        ws.send_command=lambda name,payload=None: commands.append((name,payload or {})) or "cmd"
        now=time.time()
        ws.read_state=lambda:{"jobs":{"active":[{"id":"job-7","state":"TESTING","started_at":now-31,"metadata":{"max_runtime_sec":30},"worker_id":"worker-1"}],"queued":[],"worker_count":1},"workers":[]}
        cfg={**ws.DEFAULT_CONFIG,"auto_recover":False,"job_timeout_sec":3600}
        snap=Watchdog(config=cfg).run_once()
        self.assertEqual(snap["queue"]["stuck_jobs"][0]["timeout_sec"],30.0)
        self.assertIn(("mark_job_stuck", "job-7"), [(name,p.get("job_id")) for name,p in commands])
        self.assertIn("stuck jobs", snap["issues"])
    def test_allowed_overrun_is_not_added_to_stuck_jobs(self):
        self._hb("app.json")
        self._hb("worker-1.json", job_id="job-8", queue_type="TEST_QUEUE")
        now=time.time()
        ws.read_state=lambda:{"jobs":{"active":[{"id":"job-8","state":"TESTING","started_at":now-120,"metadata":{"max_runtime_sec":30,"allow_overrun":True}}],"queued":[],"worker_count":1},"workers":[]}
        snap=Watchdog(config={**ws.DEFAULT_CONFIG,"auto_recover":False,"job_timeout_sec":3600}).inspect_once()
        self.assertEqual(snap["queue"]["stuck_jobs"], [])
        self.assertEqual(snap["queue"]["allowed_overrun_jobs"][0]["job_id"], "job-8")
    def test_watchdog_escalates_to_terminate_after_grace(self):
        self._hb("app.json")
        self._hb("worker-1.json", job_id="job-9", queue_type="TEST_QUEUE")
        commands=[]
        ws.send_command=lambda name,payload=None: commands.append((name,payload or {})) or "cmd"
        now=time.time()
        ws.read_state=lambda:{"jobs":{"active":[{"id":"job-9","state":"TESTING","started_at":now-120,"stuck_since":now-60,"recovery_attempts":1,"recovery_status":"recovery_failed","metadata":{"max_runtime_sec":30},"worker_id":"worker-1"}],"queued":[],"worker_count":1},"workers":[],"components":{"hub":{"status":"online"}}}
        cfg={**ws.DEFAULT_CONFIG,"auto_recover":True,"stuck_recovery_grace_sec":10,"stuck_max_recovery_attempts":1,"terminate_stuck_jobs":True,"job_timeout_sec":30}
        snap=Watchdog(config=cfg).run_once()
        self.assertIn(("terminate_job","job-9"), [(n,p.get("job_id")) for n,p in commands])
        self.assertEqual(snap["queue"]["stuck_jobs"][0]["recovery_status"], "recovery_failed")


if __name__ == "__main__":
    unittest.main()

class Block13ReleaseSurfaceTests(unittest.TestCase):
    def test_web_exposes_stuck_controls_and_runtime_fields(self):
        from pathlib import Path
        page = (Path(__file__).resolve().parents[1] / "src" / "services" / "web_page.html").read_text(encoding="utf-8")
        server = (Path(__file__).resolve().parents[1] / "src" / "services" / "web_server.py").read_text(encoding="utf-8")
        self.assertIn('id="create-timeout"', page)
        self.assertIn('recoverJob', page)
        self.assertIn('terminateJob', page)
        self.assertIn('/api/jobs/recover', server)
        self.assertIn('/api/jobs/terminate', server)

    def test_watchdog_config_contains_block13_controls(self):
        cfg = json.loads((Path(__file__).resolve().parents[1] / "data" / "watchdog_config.json").read_text(encoding="utf-8"))
        self.assertEqual(cfg["job_timeout_sec"], 3600)
        self.assertEqual(cfg["stuck_recovery_grace_sec"], 20)
        self.assertEqual(cfg["stuck_max_recovery_attempts"], 1)
        self.assertTrue(cfg["terminate_stuck_jobs"])

    def test_new_event_types_and_timeout_module_are_built(self):
        from services.event_bus import EventType
        self.assertEqual(EventType.JOB_STUCK.value, "JobStuck")
        self.assertEqual(EventType.JOB_RECOVERY_STARTED.value, "JobRecoveryStarted")
        self.assertEqual(EventType.JOB_STUCK_TERMINATED.value, "JobStuckTerminated")
        source = (Path(__file__).resolve().parents[1] / "src" / "services" / "job_timeout.py").read_text(encoding="utf-8")
        self.assertIn("def evaluate_job_timeout", source)

