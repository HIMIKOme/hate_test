from __future__ import annotations

import threading
import time
import unittest

from services.event_bus import EventBus
from services.job import Job, JobPriority, QueueType
from services.job_manager import JobManager
from services.job_queue import AGING_INTERVAL_SECONDS, PriorityJobQueue


class _Logger:
    def info(self, *args, **kwargs):
        pass

    def warning(self, *args, **kwargs):
        pass

    def error(self, *args, **kwargs):
        pass


class PriorityJobQueueTests(unittest.TestCase):
    def make_job(self, job_id: str, priority: JobPriority, created_at: float) -> Job:
        return Job(
            url="https://example.test/" + job_id,
            id=job_id,
            priority=priority,
            created_at=created_at,
            queued_at=created_at,
        )

    def test_priority_then_creation_then_job_id(self):
        queue = PriorityJobQueue(QueueType.TEST_QUEUE)
        queue.put(self.make_job("job-b", JobPriority.HIGH, 2.0))
        queue.put(self.make_job("job-a", JobPriority.HIGH, 2.0))
        queue.put(self.make_job("job-c", JobPriority.NORMAL, 1.0))
        ordered = [item.job.id for item in queue.peek_all(now=2.0)]
        self.assertEqual(ordered, ["job-a", "job-b", "job-c"])

    def test_aging_changes_effective_priority(self):
        queue = PriorityJobQueue(QueueType.TEST_QUEUE)
        old_low = self.make_job("old-low", JobPriority.LOW, 0.0)
        recent_high = self.make_job("recent-high", JobPriority.HIGH, 21 * AGING_INTERVAL_SECONDS)
        old_low.queued_at = 0.0
        recent_high.queued_at = 21 * AGING_INTERVAL_SECONDS
        queue.put(old_low)
        queue.put(recent_high)
        # Через 22 интервала LOW получила +22, а HIGH — только +1.
        now = 22 * AGING_INTERVAL_SECONDS
        self.assertEqual(queue.peek(now=now).id, "old-low")
        self.assertGreater(old_low.effective_priority(now), recent_high.effective_priority(now))

    def test_positions_update_after_priority_change(self):
        queue = PriorityJobQueue(QueueType.TEST_QUEUE)
        a = self.make_job("a", JobPriority.NORMAL, 1.0)
        b = self.make_job("b", JobPriority.NORMAL, 2.0)
        queue.put(a)
        queue.put(b)
        self.assertEqual(queue.position("a", now=2.0), 1)
        b.priority = JobPriority.VERY_HIGH
        self.assertEqual(queue.position("b", now=2.0), 1)
        self.assertEqual(queue.position("a", now=2.0), 2)

    def test_queues_are_strictly_separated(self):
        queue = PriorityJobQueue(QueueType.CACHE_QUEUE)
        with self.assertRaises(ValueError):
            queue.put(Job("", queue_type=QueueType.TEST_QUEUE))


class JobManagerQueueTests(unittest.TestCase):
    def test_four_queues_are_exposed_in_snapshot(self):
        manager = JobManager(_Logger(), event_bus=EventBus(_Logger()), worker_count=1)
        manager.set_handler(lambda job, context: None)
        manager.submit_operation(QueueType.CACHE_QUEUE, "cache_refresh")
        manager.submit_operation(QueueType.NOTIFICATION_QUEUE, "notify")
        manager.submit_operation(QueueType.DIAGNOSTIC_QUEUE, "diagnostics")
        snapshot = manager.snapshot()
        self.assertEqual(
            set(snapshot["queue_sizes"]),
            {"TEST_QUEUE", "CACHE_QUEUE", "NOTIFICATION_QUEUE", "DIAGNOSTIC_QUEUE"},
        )
        self.assertEqual(snapshot["queue_sizes"]["TEST_QUEUE"], 0)
        self.assertEqual(snapshot["queue_sizes"]["CACHE_QUEUE"], 1)
        self.assertEqual(snapshot["queue_sizes"]["NOTIFICATION_QUEUE"], 1)
        self.assertEqual(snapshot["queue_sizes"]["DIAGNOSTIC_QUEUE"], 1)

    def test_auxiliary_work_does_not_block_test_worker(self):
        manager = JobManager(_Logger(), event_bus=EventBus(_Logger()), worker_count=1, auxiliary_worker_count=1)
        test_done = threading.Event()
        aux_started = threading.Event()
        aux_release = threading.Event()

        def test_handler(job, _context):
            test_done.set()

        def cache_handler(job, _context):
            aux_started.set()
            aux_release.wait(2.0)

        manager.set_handler(test_handler)
        manager.set_queue_handler(QueueType.CACHE_QUEUE, cache_handler)
        manager.start()
        try:
            cache_job = manager.submit_operation(QueueType.CACHE_QUEUE, "cache_refresh")
            test_job = manager.create_job("https://example.test", priority=JobPriority.NORMAL)
            self.assertTrue(aux_started.wait(2.0))
            self.assertTrue(test_done.wait(2.0), "TEST_QUEUE заблокирована вспомогательной Job")
            deadline = time.time() + 2
            while time.time() < deadline and test_job.state.value != "COMPLETED":
                time.sleep(0.01)
            self.assertEqual(test_job.state.value, "COMPLETED")
            self.assertEqual(cache_job.queue_type, QueueType.CACHE_QUEUE)
        finally:
            aux_release.set()
            manager.stop(cancel_pending=True)

    def test_priority_and_position_are_available_through_manager(self):
        manager = JobManager(_Logger(), event_bus=EventBus(_Logger()), worker_count=1)
        manager.set_handler(lambda job, context: None)
        # Не запускаем worker, чтобы Job гарантированно осталась в очереди.
        first = manager.create_job("https://example.test/1", priority=JobPriority.NORMAL)
        second = manager.create_job("https://example.test/2", priority=JobPriority.NORMAL)
        self.assertEqual(manager.get_queue_position(first.id), 1)
        self.assertEqual(manager.get_queue_position(second.id), 2)
        self.assertTrue(manager.set_priority(second.id, JobPriority.VERY_HIGH))
        self.assertEqual(manager.get_queue_position(second.id), 1)
        self.assertEqual(manager.get_queue_position(first.id), 2)


if __name__ == "__main__":
    unittest.main()
