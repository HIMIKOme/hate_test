import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import patch

from services.event_bus import EventBus, EventType
from services.telegram_notifications import TelegramJobNotifier
from services.version import APP_VERSION


class _Logger:
    def __init__(self):
        self.messages = []

    def warning(self, message):
        self.messages.append(("warning", str(message)))

    def debug(self, message):
        self.messages.append(("debug", str(message)))


class TelegramNotifierTests(unittest.TestCase):
    def test_completed_event_updates_service_and_sends_artifact(self):
        bus = EventBus()
        sent = []
        edited = []
        documents = []
        gate = threading.Event()
        logger = _Logger()

        def fake_send(token, chat_id, text):
            sent.append((chat_id, text))
            gate.set()
            return len(sent)

        def fake_edit(token, chat_id, message_id, text):
            edited.append((chat_id, message_id, text))
            return True

        with tempfile.TemporaryDirectory() as tmp:
            artifact = Path(tmp) / "answers.txt"
            artifact.write_text("answers", encoding="utf-8")
            notifier = None
            try:
                notifier = TelegramJobNotifier(lambda: "TOKEN", logger=logger, hub=type("H", (), {"events": bus})())
                job = {
                    "id": "job-tg-1",
                    "job_id": "job-tg-1",
                    "url": "https://onlinetestpad.com/test",
                    "state": "COMPLETED",
                    "telegram_chat_id": "100",
                    "started_at": time.time() - 3,
                    "finished_at": time.time(),
                    "progress_context": {
                        "stage": "completed", "percent": 100, "current_question": 10, "total_questions": 10,
                    },
                    "result": {
                        "test_title": "Контрольная",
                        "total_questions": 10,
                        "answer_count": 10,
                        "result_status": "success",
                        "score": {"percent": 100, "correct": 10, "total": 10},
                        "telegram_text": "1. А\n2. Б\n3. В",
                        "cheatsheet_path": str(artifact),
                    },
                    "artifact_paths": [str(artifact)],
                    "metadata": {"telegram_chat_ids": ["100"]},
                }
                with patch("services.telegram_notifications.send_text", side_effect=fake_send), \
                     patch("services.telegram_notifications.edit_text", side_effect=fake_edit):
                    notifier.register_job(job["id"], ["100"], "✅ Принято", job_snapshot=job)
                    bus.publish(EventType.JOB_COMPLETED, source="worker", job=job)
                    self.assertTrue(gate.wait(2.0))
                    time.sleep(0.2)
                self.assertTrue(any("✅ Принято" in text for _, text in sent))
                self.assertTrue(any("Контрольная" in text and "100%" in text for _, _, text in edited))
                self.assertTrue(any("1. А" in text and "2. Б" in text for _, text in sent))
                self.assertEqual(documents, [])
            finally:
                if notifier is not None:
                    notifier.stop()

    def test_fast_completed_job_is_not_lost_before_notifier_registration(self):
        bus = EventBus()
        notifier = TelegramJobNotifier(lambda: "TOKEN", logger=_Logger(), hub=type("H", (), {"events": bus})())
        sent = []
        try:
            job = {
                "id": "job-fast", "job_id": "job-fast",
                "url": "https://onlinetestpad.com/fast", "state": "COMPLETED",
                "telegram_chat_id": "501",
                "result": {"test_title": "Быстрый тест", "telegram_text": "Ответ 1: А"},
                "metadata": {"telegram_chat_ids": ["501"]},
            }
            with patch("services.telegram_notifications.send_text", side_effect=lambda t, c, x: sent.append((c, x)) or len(sent)), \
                 patch("services.telegram_notifications.edit_text", return_value=True):
                notifier.register_job(job["id"], ["501"], "Принято", job_snapshot=job)
                time.sleep(0.25)
            self.assertTrue(any("Ответ 1: А" in text for _, text in sent))
        finally:
            notifier.stop()

    def test_cached_answers_are_message_not_document(self):
        import services.telegram_bot as tg

        bot = tg.TelegramBot.__new__(tg.TelegramBot)
        bot.token = "TOKEN"
        bot.logger = _Logger()
        cached = {"telegram_text": "1. А\n2. Б", "cheatsheet_path": "/tmp/answers.txt"}
        with patch("services.telegram_bot.send_text", return_value=1) as send, \
             patch("services.telegram_bot.send_document") as document:
            bot._send_cached("777", cached)
        self.assertEqual(send.call_count, 1)
        document.assert_not_called()

    def test_progress_events_are_non_blocking_and_coalesced(self):
        bus = EventBus()
        notifier = TelegramJobNotifier(lambda: "TOKEN", logger=_Logger(), hub=type("H", (), {"events": bus})(), min_edit_interval=10.0)
        try:
            with patch("services.telegram_notifications.send_text", return_value=1), \
                 patch("services.telegram_notifications.edit_text", return_value=True) as edit:
                job = {
                    "id": "job-progress",
                    "url": "https://onlinetestpad.com/x",
                    "state": "TESTING",
                    "telegram_chat_id": "101",
                    "progress_context": {"stage": "testing", "percent": 10, "current_question": 1, "total_questions": 20},
                    "metadata": {"telegram_chat_ids": ["101"]},
                }
                notifier.register_job(job["id"], ["101"], "accepted")
                start = time.time()
                for n in range(1, 30):
                    payload = dict(job)
                    payload["progress_context"] = {"stage": "testing", "percent": n, "current_question": n, "total_questions": 20}
                    bus.publish(EventType.JOB_PROGRESS, source="worker", job=payload)
                elapsed = time.time() - start
                self.assertLess(elapsed, 0.1)
                time.sleep(0.2)
                # Initial progress may be skipped due to coalescing, but the event callback itself never blocks.
                self.assertLessEqual(edit.call_count, 2)
        finally:
            notifier.stop()

    def test_only_job_recipients_receive_events(self):
        bus = EventBus()
        notifier = TelegramJobNotifier(lambda: "TOKEN", logger=_Logger(), hub=type("H", (), {"events": bus})())
        try:
            sent = []
            with patch("services.telegram_notifications.send_text", side_effect=lambda t, c, x: sent.append(c) or len(sent)):
                job = {
                    "id": "job-recipient",
                    "url": "https://onlinetestpad.com/a",
                    "state": "QUEUED",
                    "telegram_chat_id": "222",
                    "metadata": {"telegram_chat_ids": ["222"]},
                }
                bus.publish(EventType.JOB_CREATED, source="hub", job=job)
                time.sleep(0.2)
            self.assertTrue(sent)
            self.assertTrue(all(chat_id == "222" for chat_id in sent))
            self.assertNotIn("111", sent)
        finally:
            notifier.stop()

    def test_test_runner_does_not_send_telegram_directly(self):
        runner_source = Path("src/automation/runner.py").read_text(encoding="utf-8")
        self.assertNotIn("from services.telegram import send_to_all", runner_source)
        self.assertNotIn("send_to_all(\n", runner_source)
        self.assertNotIn("self._send_to_telegram(", runner_source)
        self.assertIn("result[\"test_title\"]", runner_source)

    def test_telegram_heartbeat_stays_fresh_during_long_polling(self):
        import json
        import services.telegram_bot as tg

        with tempfile.TemporaryDirectory() as tmp:
            heartbeat_root = Path(tmp)

            class Logger:
                def info(self, _message):
                    pass

                def warning(self, _message):
                    pass

                def debug(self, _message):
                    pass

            def slow_get_updates(*_args, **_kwargs):
                time.sleep(0.45)
                return []

            with patch.object(tg, 'get_data_dir', return_value=heartbeat_root), \
                 patch.object(tg, 'get_updates', side_effect=slow_get_updates), \
                 patch.object(tg, 'TELEGRAM_HEARTBEAT_INTERVAL', 0.05):
                bot = tg.TelegramBot('TOKEN', Logger())
                bot.start()
                try:
                    hb = heartbeat_root / 'heartbeats' / 'telegram.json'
                    deadline = time.time() + 1.0
                    while time.time() < deadline and not hb.exists():
                        time.sleep(0.02)
                    self.assertTrue(hb.exists())
                    first = json.loads(hb.read_text(encoding='utf-8'))['timestamp']
                    time.sleep(0.16)
                    second = json.loads(hb.read_text(encoding='utf-8'))['timestamp']
                    self.assertGreater(second, first)
                    self.assertTrue(json.loads(hb.read_text(encoding='utf-8')).get('running'))
                finally:
                    bot.stop()

    def test_send_photo_uses_telegram_send_photo(self):
        from services.telegram import send_photo

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "result.png"
            path.write_bytes(b"PNG")
            with patch("services.telegram._api_call_multipart", return_value={"ok": True, "result": {"message_id": 7}}) as api:
                self.assertTrue(send_photo("TOKEN", "100", path, caption="Итог"))
            fields = api.call_args.args[2]
            files = api.call_args.args[3]
            self.assertEqual(fields["chat_id"], "100")
            self.assertEqual(fields["caption"], "Итог")
            self.assertIn("photo", files)
            self.assertEqual(files["photo"][0], "result.png")
            self.assertEqual(files["photo"][2], "image/png")

    def test_page_screenshot_helper_captures_png(self):
        import base64
        from services.screenshots import capture_page_screenshot

        class Logger:
            def debug(self, _message):
                pass

            def warning(self, _message):
                pass

        class Driver:
            def execute_cdp_cmd(self, method, _params):
                self.method = method
                return {"data": base64.b64encode(b"fake-png").decode("ascii")}

            def save_screenshot(self, path):
                Path(path).write_bytes(b"fallback")
                return True

        with tempfile.TemporaryDirectory() as tmp:
            shot = Path(tmp) / "result.png"
            self.assertTrue(capture_page_screenshot(Driver(), shot, logger=Logger()))
            self.assertTrue(shot.exists())
            self.assertEqual(shot.read_bytes(), b"fake-png")

    def test_r_screenshot_is_sent_before_worker_release(self):
        import services.telegram_bot as tg

        class Logger:
            def warning(self, _message):
                pass

            def info(self, _message):
                pass

        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "shot.png"
            path.write_bytes(b"PNG")
            bot = tg.TelegramBot.__new__(tg.TelegramBot)
            bot.token = "TOKEN"
            bot.logger = Logger()
            with patch("services.telegram_bot.send_photo", return_value=True) as photo:
                start = time.time()
                bot._send_r_screenshot(["100"], str(path), "https://onlinetestpad.com/test", delay=0)
                elapsed = time.time() - start
            photo.assert_called_once_with("TOKEN", "100", path, caption="📸 Скриншот итоговой страницы теста")
            self.assertFalse(path.exists())
            self.assertLess(elapsed, 1.0)


    def test_r_only_sends_final_attempt_screenshot(self):
        import services.telegram_bot as tg

        class Cache:
            def get(self, _url):
                return {"answers": [{"q": "Q1", "answer": "A"}]}

        class Hub:
            def __init__(self):
                self.results = []

            def set_result(self, job_id, **values):
                self.results.append((job_id, values))

        class Job:
            id = "job-shot-flow"
            cancel_event = threading.Event()

        with tempfile.TemporaryDirectory() as tmp:
            first = Path(tmp) / "first.png"
            second = Path(tmp) / "second.png"
            first.write_bytes(b"first")
            second.write_bytes(b"second")

            bot = tg.TelegramBot.__new__(tg.TelegramBot)
            bot.logger = type("L", (), {"info": lambda *_: None, "warning": lambda *_: None})()
            bot.cache = Cache()
            bot.hub = Hub()
            bot._restart_browser = lambda _ctx: None
            bot._process_collect = lambda *_args, **_kwargs: None
            bot._attempt_100 = unittest.mock.Mock(side_effect=[
                ("partial", {"percent": 70}, str(first)),
                ("success", {"percent": 100}, str(second)),
            ])
            with patch.object(tg, "is_stop_requested", return_value=False), \
                 patch.object(bot, "_send_r_screenshot") as send_shot:
                bot._process_100("https://onlinetestpad.com/test", ["100"], "", Job(), None)

            bot._attempt_100.assert_called_once if False else None
            self.assertEqual(send_shot.call_count, 1)
            self.assertEqual(send_shot.call_args.args[1], str(second))
            self.assertFalse(first.exists())
            self.assertTrue(second.exists())
            self.assertTrue(any(v.get("screenshot_path") == "" for _, v in bot.hub.results))


    def test_clean_ipc_state_uses_current_release_version(self):
        from services import ipc
        from unittest.mock import patch
        with patch.object(ipc, "state_path", return_value=Path("/definitely/missing/state.json")):
            state = ipc.read_state()
        self.assertEqual(state.get("version"), APP_VERSION)

    def test_block10_event_types_are_available(self):
        self.assertEqual(EventType.JOB_RESULT_UPDATED.value, "JobResultUpdated")
        self.assertEqual(EventType.JOB_CANCELLED.value, "JobCancelled")
        self.assertEqual(EventType.JOB_COMPLETED.value, "JobCompleted")


if __name__ == "__main__":
    unittest.main()
