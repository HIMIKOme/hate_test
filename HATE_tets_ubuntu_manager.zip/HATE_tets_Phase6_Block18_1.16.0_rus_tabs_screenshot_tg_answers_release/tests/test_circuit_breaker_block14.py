import json
import tempfile
import time
import unittest
from pathlib import Path

from services.circuit_breaker import CircuitBreaker, CircuitOpenError, CircuitState
from services.event_bus import EventBus, EventType
from services.job import JobPriority, QueueType
from services.job_manager import JobManager
from services.hub import Hub


class CircuitBreakerBlock14Tests(unittest.TestCase):
    def setUp(self):
        self.events = EventBus()
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "circuit.json"
        self.cb = CircuitBreaker(
            self.events,
            data_path=self.path,
            failure_threshold=3,
            window_sec=60,
            cooldown_sec=10,
        )

    def tearDown(self):
        self.cb.close()
        self.tmp.cleanup()

    def test_site_key_normalizes_scheme_port_and_case(self):
        self.assertEqual(self.cb.site_key("HTTPS://Example.COM:443/path"), "example.com")
        self.assertEqual(self.cb.site_key("https://example.com/path"), "example.com")
        self.assertEqual(self.cb.site_key("https://EXAMPLE.com."), "example.com")

    def test_failures_make_site_problematic(self):
        self.cb.record_failure("example.com", error="e1")
        status = self.cb.status("https://example.com/test")
        self.assertEqual(status["state"], CircuitState.PROBLEMATIC.value)
        self.assertEqual(status["failure_count"], 1)

    def test_threshold_blocks_new_admission(self):
        for i in range(3):
            self.cb.record_failure("example.com", error=f"e{i}")
        status = self.cb.status("example.com")
        self.assertEqual(status["state"], CircuitState.TEMPORARILY_BLOCKED.value)
        with self.assertRaises(CircuitOpenError):
            self.cb.admit("https://example.com/test")

    def test_only_one_probe_after_cooldown(self):
        for i in range(3):
            self.cb.record_failure("example.com", error=f"e{i}")
        with self.cb._lock:
            item = self.cb._sites["example.com"]
            item.blocked_until = time.time() - 1
        meta = self.cb.admit("https://example.com/test")
        self.assertTrue(meta["probe"])
        with self.assertRaises(CircuitOpenError):
            self.cb.admit("https://example.com/test-2")

    def test_probe_success_returns_to_normal(self):
        for i in range(3):
            self.cb.record_failure("example.com", error=f"e{i}")
        with self.cb._lock:
            self.cb._sites["example.com"].blocked_until = time.time() - 1
        self.assertTrue(self.cb.admit("https://example.com/test")["probe"])
        self.cb.record_success("example.com", job_id="job-probe", probe=True)
        status = self.cb.status("example.com")
        self.assertEqual(status["state"], CircuitState.NORMAL.value)
        self.assertFalse(status["probe_in_flight"])
        self.assertTrue(self.cb.admit("https://example.com/next")["probe"] is False)

    def test_normal_success_clears_problematic_failures(self):
        self.cb.record_failure("example.com", error="e1")
        self.cb.record_failure("example.com", error="e2")
        self.cb.record_success("example.com", job_id="ok")
        status = self.cb.status("example.com")
        self.assertEqual(status["state"], CircuitState.NORMAL.value)
        self.assertEqual(status["failure_count"], 0)

    def test_event_bus_terminal_events_drive_breaker(self):
        job = {"id": "j1", "url": "https://example.org/t", "queue_type": QueueType.TEST_QUEUE.value, "metadata": {}}
        for n in range(3):
            self.events.publish(EventType.JOB_FAILED, source="worker", job={**job, "id": f"j{n}"}, error="site error")
        self.assertEqual(self.cb.status("example.org")["state"], CircuitState.TEMPORARILY_BLOCKED.value)

    def test_event_success_resets_circuit(self):
        job = {"id": "j1", "url": "https://example.org/t", "queue_type": QueueType.TEST_QUEUE.value, "metadata": {}}
        self.events.publish(EventType.JOB_FAILED, source="worker", job=job, error="site error")
        self.events.publish(EventType.JOB_COMPLETED, source="worker", job={**job, "id": "j2"})
        self.assertEqual(self.cb.status("example.org")["state"], CircuitState.NORMAL.value)

    def test_circuit_does_not_affect_auxiliary_queue(self):
        for i in range(3):
            self.cb.record_failure("example.com", error=f"e{i}")
        manager = JobManager(logger=None, event_bus=self.events, circuit_breaker=self.cb)
        job = manager.create_job(url="", mode="diagnostic", queue_type=QueueType.DIAGNOSTIC_QUEUE)
        self.assertEqual(job.queue_type, QueueType.DIAGNOSTIC_QUEUE)

    def test_job_manager_blocks_test_creation(self):
        manager = JobManager(logger=None, event_bus=self.events, circuit_breaker=self.cb)
        for i in range(3):
            self.cb.record_failure("example.com", error=f"e{i}")
        with self.assertRaises(CircuitOpenError):
            manager.create_job("https://example.com/test")

    def test_cooldown_probe_is_attached_to_new_job(self):
        manager = JobManager(logger=None, event_bus=self.events, circuit_breaker=self.cb)
        for i in range(3):
            self.cb.record_failure("example.probe", error=f"e{i}")
        with self.cb._lock:
            self.cb._sites["example.probe"].blocked_until = time.time() - 1
        job = manager.create_job("https://example.probe/test")
        self.assertTrue(job.metadata.get("circuit_probe"))
        self.assertEqual(job.metadata.get("circuit_site"), "example.probe")
        with self.assertRaises(CircuitOpenError):
            manager.create_job("https://example.probe/another")

    def test_retry_respects_circuit_breaker(self):
        manager = JobManager(logger=None, event_bus=self.events, circuit_breaker=self.cb)
        old = manager.create_job("https://retry.example/test")
        old.transition("STARTING")
        old.transition("FAILED", stage="failed", error="site down")
        manager.circuit_breaker.record_failure("retry.example", error="site down", job_id=old.id)
        manager.circuit_breaker.record_failure("retry.example", error="site down", job_id=old.id)
        manager.circuit_breaker.record_failure("retry.example", error="site down", job_id=old.id)
        with self.assertRaises(CircuitOpenError):
            manager.retry(old.id)

    def test_hub_snapshot_contains_circuit_breakers(self):
        hub = Hub(logger=None, worker_count=1, auxiliary_worker_count=1, version="1.12.0")
        try:
            snap = hub.snapshot()
            self.assertIn("circuit_breakers", snap)
            self.assertIn("failure_threshold", snap["circuit_breakers"])
        finally:
            try:
                hub.circuit_breaker.close()
            except Exception:
                pass


    def test_web_exposes_circuit_breaker_surface(self):
        from services.web_server import _decorate_state
        state = _decorate_state({"version": "1.12.0", "jobs": {"queued": [], "active": [], "history": []}})
        self.assertIn("circuit_breakers", state)
        from pathlib import Path
        html = Path("src/services/web_page.html").read_text(encoding="utf-8")
        self.assertIn("api/circuit-breakers", html)
        self.assertIn("resetCircuit", html)

    def test_persistence_restores_blocked_state(self):
        for i in range(3):
            self.cb.record_failure("example.net", error=f"e{i}")
        self.assertTrue(self.path.exists())
        self.cb.close()
        events2 = EventBus()
        cb2 = CircuitBreaker(events2, data_path=self.path, failure_threshold=3, window_sec=60, cooldown_sec=10)
        try:
            status = cb2.status("example.net")
            self.assertEqual(status["state"], CircuitState.TEMPORARILY_BLOCKED.value)
        finally:
            cb2.close()

    def test_reset_restores_admission(self):
        for i in range(3):
            self.cb.record_failure("example.io", error=f"e{i}")
        self.assertTrue(self.cb.reset("example.io"))
        self.assertEqual(self.cb.status("example.io")["state"], CircuitState.NORMAL.value)
        self.assertFalse(self.cb.admit("https://example.io/x")["probe"])


if __name__ == "__main__":
    unittest.main()
