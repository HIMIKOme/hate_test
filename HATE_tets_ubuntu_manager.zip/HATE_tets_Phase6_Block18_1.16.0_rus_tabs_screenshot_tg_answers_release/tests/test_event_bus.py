from __future__ import annotations

import unittest

from services.event_bus import EventBus, EventType
from services.hub import Hub
from services.job import JobState
from services.worker_context import WorkerContext


class _Logger:
    def info(self, *args, **kwargs):
        pass

    def warning(self, *args, **kwargs):
        pass

    def error(self, *args, **kwargs):
        pass

    def debug(self, *args, **kwargs):
        pass


class EventBusTests(unittest.TestCase):
    def test_typed_event_metadata_and_job_id_are_emitted(self):
        bus = EventBus(_Logger())
        received = []
        bus.subscribe(EventType.JOB_PROGRESS, received.append)
        event = bus.publish(
            EventType.JOB_PROGRESS,
            source="worker",
            correlation_id="corr-1",
            job={"id": "job-1", "state": "TESTING"},
            progress=42,
        )
        self.assertEqual(event["type"], "JobProgress")
        self.assertEqual(event["source"], "worker")
        self.assertEqual(event["correlation_id"], "corr-1")
        self.assertEqual(event["job_id"], "job-1")
        self.assertTrue(event["event_id"].startswith("evt-"))
        self.assertEqual(received[0]["job_id"], "job-1")

    def test_wildcard_and_unsubscribe(self):
        bus = EventBus(_Logger())
        seen = []
        specific_token = bus.subscribe(EventType.JOB_CREATED, lambda e: seen.append(("specific", e["type"])))
        bus.subscribe_all(lambda e: seen.append(("all", e["type"])))
        bus.publish(EventType.JOB_CREATED)
        self.assertEqual(seen, [("specific", "JobCreated"), ("all", "JobCreated")])
        self.assertTrue(bus.unsubscribe(specific_token))
        bus.publish(EventType.JOB_CREATED)
        self.assertEqual(seen[-1], ("all", "JobCreated"))
        self.assertFalse(bus.unsubscribe(specific_token))

    def test_failing_subscriber_does_not_break_other_subscriber(self):
        bus = EventBus(_Logger())
        received = []
        bus.subscribe(EventType.JOB_FAILED, lambda e: (_ for _ in ()).throw(RuntimeError("boom")))
        bus.subscribe(EventType.JOB_FAILED, lambda e: received.append(e["type"]))
        bus.publish(EventType.JOB_FAILED)
        self.assertEqual(received, ["JobFailed"])


class WorkerToHubEventFlowTests(unittest.TestCase):
    def test_worker_progress_reaches_hub_and_state_manager(self):
        logger = _Logger()
        hub = Hub(logger, worker_count=1)
        job = hub.create_job(
            "https://example.test",
            telegram_chat_id="chat-42",
        )
        canonical_events = []
        hub.events.subscribe(EventType.JOB_STATE_CHANGED, canonical_events.append)
        hub.events.subscribe(EventType.JOB_PROGRESS, canonical_events.append)

        hub.events.publish(
            EventType.JOB_STARTED,
            source="worker",
            worker_id="worker-1",
            job_id=job.id,
            state=JobState.STARTING.value,
        )
        self.assertEqual(job.state, JobState.STARTING)
        self.assertEqual(job.worker_id, "worker-1")

        hub.events.publish(
            EventType.JOB_STATE_REQUESTED,
            source="worker",
            worker_id="worker-1",
            job_id=job.id,
            state=JobState.TESTING.value,
            stage="testing",
        )
        self.assertEqual(job.state, JobState.TESTING)
        self.assertEqual(job.stage, "testing")

        hub.events.publish(
            EventType.JOB_PROGRESS_REQUESTED,
            source="worker",
            worker_id="worker-1",
            job_id=job.id,
            progress=50,
            current_question=2,
            total_questions=4,
            stage="testing",
        )
        self.assertEqual(job.progress, 50.0)
        self.assertEqual(job.current_question, 2)
        self.assertEqual(job.total_questions, 4)

        state_snapshot = hub.state.snapshot(hub.job_manager.snapshot())
        current = next(item for item in state_snapshot["jobs"]["active"] if item["id"] == job.id)
        self.assertEqual(current["state"], "TESTING")
        self.assertEqual(current["progress"], 50.0)
        self.assertTrue(any(e["type"] == "JobStateChanged" for e in canonical_events))
        self.assertTrue(any(e["type"] == "JobProgress" and e["source"] == "hub" for e in canonical_events))

    def test_browser_crash_is_translated_to_job_failed(self):
        logger = _Logger()
        hub = Hub(logger, worker_count=1)
        job = hub.create_job("https://example.test")
        hub.events.publish(
            EventType.JOB_STARTED,
            source="worker",
            worker_id="worker-1",
            job_id=job.id,
        )
        hub.events.publish(
            EventType.BROWSER_CRASHED,
            source="worker",
            worker_id="worker-1",
            job_id=job.id,
            error="Chrome crashed",
        )
        self.assertEqual(job.state, JobState.FAILED)
        self.assertEqual(job.error, "Chrome crashed")

    def test_worker_context_emits_worker_source_events(self):
        logger = _Logger()
        from services.event_bus import EventBus
        bus = EventBus(logger)
        seen = []
        bus.subscribe(EventType.JOB_PROGRESS_REQUESTED, seen.append)
        bus.subscribe(EventType.JOB_STATE_REQUESTED, seen.append)
        context = WorkerContext("worker-9", bus, logger)
        context.emit_job_progress("job-9", 25, current_question=1, total_questions=4, stage="testing")
        context.emit_job_state("job-9", JobState.TESTING, stage="testing")
        self.assertEqual([event["source"] for event in seen], ["worker", "worker"])
        self.assertEqual([event["worker_id"] for event in seen], ["worker-9", "worker-9"])
        self.assertEqual([event["job_id"] for event in seen], ["job-9", "job-9"])


if __name__ == "__main__":
    unittest.main()
