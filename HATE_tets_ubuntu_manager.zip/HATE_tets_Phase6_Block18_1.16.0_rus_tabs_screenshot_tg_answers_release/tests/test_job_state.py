from __future__ import annotations

import threading
import time
import unittest

from services.event_bus import EventBus
from services.job import (
    ALLOWED_TRANSITIONS,
    Job,
    JobProgress,
    JobState,
    JobStateMachine,
)
from services.job_manager import JobManager


class _Logger:
    def info(self, *args, **kwargs):
        pass

    def warning(self, *args, **kwargs):
        pass

    def error(self, *args, **kwargs):
        pass


class JobStateMachineTests(unittest.TestCase):
    def test_all_required_states_exist(self):
        self.assertEqual(
            {state.value for state in JobState},
            {
                "QUEUED", "STARTING", "BROWSER_STARTING", "OPENING", "TESTING",
                "COLLECTING", "SAVING", "NOTIFYING", "RETRY_WAIT", "COMPLETED", "FAILED",
                "CANCELLING", "CANCELLED",
            },
        )

    def test_normal_path_is_valid(self):
        job = Job("https://example.test")
        path = [
            JobState.STARTING,
            JobState.BROWSER_STARTING,
            JobState.OPENING,
            JobState.TESTING,
            JobState.COLLECTING,
            JobState.SAVING,
            JobState.NOTIFYING,
            JobState.COMPLETED,
        ]
        for state in path:
            job.transition(state)
        self.assertEqual(job.state, JobState.COMPLETED)
        self.assertEqual(job.progress, 100.0)
        self.assertIsNotNone(job.started_at)
        self.assertIsNotNone(job.finished_at)

    def test_invalid_transition_is_rejected(self):
        job = Job("https://example.test")
        job.transition(JobState.STARTING)
        with self.assertRaises(ValueError):
            job.transition(JobState.NOTIFYING)
        self.assertEqual(job.state, JobState.STARTING)

        job.transition(JobState.BROWSER_STARTING)
        # Повторное назначение того же state разрешено как idempotent-операция.
        job.transition(JobState.BROWSER_STARTING)
        self.assertEqual(job.state, JobState.BROWSER_STARTING)
        with self.assertRaises(ValueError):
            job.transition(JobState.CANCELLED)

    def test_terminal_state_cannot_be_reopened(self):
        job = Job("https://example.test")
        for state in (
            JobState.STARTING,
            JobState.BROWSER_STARTING,
            JobState.OPENING,
            JobState.COMPLETED,
        ):
            job.transition(state)
        self.assertFalse(JobStateMachine.can_transition(JobState.COMPLETED, JobState.TESTING))
        with self.assertRaises(ValueError):
            job.transition(JobState.TESTING)

    def test_state_and_progress_are_separate(self):
        job = Job("https://example.test")
        self.assertIsInstance(job.progress_context, JobProgress)
        job.transition(JobState.STARTING, stage="starting")
        job.update_progress(25, stage="testing", current_question=2, total_questions=8)
        self.assertEqual(job.state, JobState.STARTING)
        self.assertEqual(job.progress_context.stage, "testing")
        self.assertEqual(job.progress_context.current_question, 2)
        self.assertEqual(job.progress_context.total_questions, 8)
        payload = job.to_dict()
        self.assertEqual(payload["state"], "STARTING")
        self.assertEqual(payload["progress_context"]["percent"], 25.0)
        self.assertIn("allowed_next_states", payload)

    def test_cancellation_uses_cancelling_state(self):
        job = Job("https://example.test")
        job.transition(JobState.STARTING)
        self.assertTrue(job.request_cancel())
        self.assertEqual(job.state, JobState.CANCELLING)
        job.transition(JobState.CANCELLED, stage="cancelled")
        self.assertEqual(job.state, JobState.CANCELLED)


class JobManagerCancellationTests(unittest.TestCase):
    def test_running_job_never_jumps_directly_to_cancelled(self):
        logger = _Logger()
        bus = EventBus(logger)
        started = threading.Event()

        def handler(job, _context):
            started.set()
            while not job.cancel_event.is_set():
                time.sleep(0.01)

        manager = JobManager(logger, event_bus=bus, worker_count=1)
        manager.set_handler(handler)
        manager.start()
        try:
            job = manager.create_job("https://example.test")
            self.assertTrue(started.wait(2.0))
            self.assertTrue(manager.cancel(job.id))

            deadline = time.time() + 2.0
            while time.time() < deadline:
                if job.state == JobState.CANCELLED:
                    break
                time.sleep(0.01)

            self.assertEqual(job.state, JobState.CANCELLED)
            self.assertTrue(job.cancel_event.is_set())
        finally:
            manager.stop(cancel_pending=True)


if __name__ == "__main__":
    unittest.main()
