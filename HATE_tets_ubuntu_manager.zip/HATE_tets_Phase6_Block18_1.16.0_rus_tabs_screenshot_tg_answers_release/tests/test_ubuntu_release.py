from pathlib import Path
import ast
import unittest

ROOT = Path(__file__).resolve().parents[1]


class UbuntuReleaseTests(unittest.TestCase):
    def test_linux_entrypoint(self):
        source = (ROOT / "src" / "main.py").read_text(encoding="utf-8")
        self.assertIn("sys.platform.startswith(\"linux\")", source)
        self.assertNotIn("tkinter", source)

    def test_no_windows_launchers(self):
        forbidden = list(ROOT.glob("**/*.bat")) + list(ROOT.glob("**/*.exe"))
        self.assertEqual([], forbidden)

    def test_runtime_requirements_are_linux_only(self):
        req = (ROOT / "config" / "requirements.txt").read_text(encoding="utf-8")
        self.assertNotIn("pyinstaller", req.lower())
        self.assertNotIn("pystray", req.lower())
        self.assertNotIn("webdriver-manager", req.lower())
        self.assertIn("selenium", req)

    def test_default_telegram_token_is_configured(self):
        source = (ROOT / "src" / "services" / "config.py").read_text(encoding="utf-8")
        self.assertIn("8626056286:AAFw2VzItYY7Ms5dvEpemzJX7UDXT37CkJc", source)

    def test_installer_and_service_scripts_exist(self):
        for name in ("install.sh", "start.sh", "stop.sh", "status.sh"):
            self.assertTrue((ROOT / name).is_file(), name)


if __name__ == "__main__":
    unittest.main()
