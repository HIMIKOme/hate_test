from __future__ import annotations

import json
import shutil
import tempfile
import time
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

from services.diagnostics import DiagnosticsManager
from services.event_bus import EventBus, EventType
from services.event_journal import append_event, read_events
from services.idempotency import IdempotencyConflict, IdempotencyStore
from services.job import Job, JobState
from services.job_manager import JobManager
from services.metrics import record_event as record_metric_event, snapshot as metrics_snapshot
from services.resource_manager import ResourceManager
from services.retry_policy import RetryPolicy
from services.worker_context import WorkerContext
from services.worker_lifecycle import WorkerLifecycle, WorkerState


class _Logger:
    def debug(self, *_a, **_k): pass
    def warning(self, *_a, **_k): pass
    def error(self, *_a, **_k): pass
    def info(self, *_a, **_k): pass


class _FakePsutil:
    cpu = 10.0
    mem = 20.0

    @classmethod
    def cpu_percent(cls, interval=0.0):
        return cls.cpu

    @classmethod
    def virtual_memory(cls):
        class Mem:
            percent = _FakePsutil.mem
        return Mem()


class Block18OperationalTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="hate-block18-"))

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_retry_policy_backoff_and_max_attempts(self):
        job = Job("https://example.test", metadata={
            "retry_max_attempts": 3,
            "retry_backoff_sec": 2,
            "retry_backoff_max_sec": 5,
        })
        job.attempts = 1
        d1 = RetryPolicy.decide(job, RuntimeError("boom"))
        self.assertTrue(d1.retry)
        self.assertEqual(d1.delay_sec, 2.0)
        job.attempts = 2
        d2 = RetryPolicy.decide(job, RuntimeError("boom"))
        self.assertTrue(d2.retry)
        self.assertEqual(d2.delay_sec, 4.0)
        job.attempts = 3
        self.assertFalse(RetryPolicy.decide(job, RuntimeError("boom")).retry)

    def test_retry_policy_rejects_non_retryable(self):
        job = Job("https://example.test", metadata={"retry_max_attempts": 3})
        job.attempts = 1
        self.assertFalse(RetryPolicy.decide(job, ValueError("bad input")).retry)
        job.metadata["retry_policy"] = "never"
        self.assertFalse(RetryPolicy.decide(job, RuntimeError("bad")).retry)

    def test_job_manager_retries_then_completes(self):
        bus = EventBus(_Logger())
        events = []
        bus.subscribe_all(lambda e: events.append(e))
        manager = JobManager(_Logger(), event_bus=bus, worker_count=1)
        calls = {"count": 0}
        done = False

        def handler(job, context):
            calls["count"] += 1
            if calls["count"] < 3:
                raise RuntimeError(f"attempt {calls['count']}")

        manager.set_handler(handler)
        manager.start()
        try:
            job = manager.create_job(
                "https://example.test",
                metadata={"retry_max_attempts": 3, "retry_backoff_sec": 0, "retry_backoff_max_sec": 0},
            )
            deadline = time.time() + 5
            while time.time() < deadline:
                current = manager.get(job.id)
                if current and current.state == JobState.COMPLETED:
                    done = True
                    break
                time.sleep(0.05)
            self.assertTrue(done, manager.get(job.id).to_dict())
            current = manager.get(job.id)
            self.assertEqual(calls["count"], 3)
            self.assertEqual(current.attempts, 3)
            self.assertEqual(len(current.retry_history), 2)
            self.assertGreaterEqual(sum(1 for e in events if e["type"] == EventType.JOB_RETRY_SCHEDULED.value), 2)
            self.assertGreaterEqual(sum(1 for e in events if e["type"] == EventType.JOB_COMPLETED.value), 1)
        finally:
            manager.stop()

    def test_cancel_retry_wait_cancels_timer_and_terminalizes(self):
        bus = EventBus(_Logger())
        manager = JobManager(_Logger(), event_bus=bus, worker_count=1)
        entered = []
        manager.set_handler(lambda job, ctx: (_ for _ in ()).throw(RuntimeError("fail")))
        manager.start()
        try:
            job = manager.create_job(
                "https://example.test",
                metadata={"retry_max_attempts": 3, "retry_backoff_sec": 2},
            )
            deadline = time.time() + 2
            while time.time() < deadline and manager.get(job.id).state != JobState.RETRY_WAIT:
                time.sleep(0.03)
            self.assertEqual(manager.get(job.id).state, JobState.RETRY_WAIT)
            self.assertTrue(manager.cancel(job.id))
            self.assertEqual(manager.get(job.id).state, JobState.CANCELLED)
            time.sleep(0.1)
            self.assertNotIn(job.id, manager._retry_waiting)
        finally:
            manager.stop()

    def test_idempotency_persists_and_conflicts(self):
        store = IdempotencyStore(self.tmp / "idempotency.json", ttl_sec=3600)
        manager = JobManager(_Logger(), event_bus=EventBus(_Logger()), worker_count=1, idempotency_store=store)
        first = manager.create_job("https://example.test", idempotency_key="req-1")
        again = manager.create_job("https://example.test", idempotency_key="req-1")
        self.assertIs(first, again)
        with self.assertRaises(IdempotencyConflict):
            manager.create_job("https://other.test", idempotency_key="req-1")
        self.assertEqual(store.lookup("req-1")["job_id"], first.id)

    def test_idempotency_fingerprint_ignores_circuit_metadata(self):
        store = IdempotencyStore(self.tmp / "idempotency.json")
        bus = EventBus(_Logger())
        manager = JobManager(_Logger(), event_bus=bus, worker_count=1, idempotency_store=store)
        job = manager.create_job("https://example.test", idempotency_key="req-2", metadata={"circuit_site": "example.test"})
        restarted = JobManager(_Logger(), event_bus=EventBus(_Logger()), worker_count=1, idempotency_store=store)
        restarted._jobs[job.id] = Job.from_dict(job.to_dict())
        restored = restarted.create_job("https://example.test", idempotency_key="req-2")
        self.assertEqual(restored.id, job.id)

    def test_idempotency_expiry(self):
        store = IdempotencyStore(self.tmp / "idempotency.json", ttl_sec=60)
        store.bind("old", "job-old", "fp")
        payload = json.loads(store.path.read_text(encoding="utf-8"))
        payload["items"]["old"]["last_seen_at"] = time.time() - 120
        store.path.write_text(json.dumps(payload), encoding="utf-8")
        fresh = IdempotencyStore(store.path, ttl_sec=60)
        self.assertIsNone(fresh.lookup("old"))

    def test_diagnostics_keep_separate_attempt_directories_and_zip(self):
        manager = DiagnosticsManager(self.tmp / "diagnostics", logger=_Logger())
        job = Job("https://example.test")
        job.attempts = 1
        job.transition(JobState.STARTING)
        manager.capture_failure(job, RuntimeError("first"))
        job.attempts = 2
        manager.capture_failure(job, RuntimeError("second"))
        archive = manager.get_archive(job.id)
        self.assertIsNotNone(archive)
        with zipfile.ZipFile(archive) as zf:
            names = set(zf.namelist())
        self.assertIn("attempt-001/traceback.txt", names)
        self.assertIn("attempt-002/traceback.txt", names)
        self.assertIn("latest.json", names)
        self.assertIn("attempt-002/events.json", names)

    def test_metrics_use_worker_lifecycle_not_double_counting_job_events(self):
        with patch("services.metrics._PATH", self.tmp / "metrics.json"):
            now = time.time()
            record_metric_event({"type": "WorkerStarted", "worker_id": "w1", "timestamp": now})
            record_metric_event({"type": "WorkerStateChanged", "worker_id": "w1", "worker_state": "IDLE", "timestamp": now})
            record_metric_event({"type": "WorkerStateChanged", "worker_id": "w1", "worker_state": "BUSY", "timestamp": now + 1})
            record_metric_event({"type": "JobStarted", "worker_id": "w1", "job_id": "j1", "timestamp": now + 1.1})
            record_metric_event({"type": "JobCompleted", "worker_id": "w1", "job_id": "j1", "timestamp": now + 4.1, "job": {"queue_type": "TEST_QUEUE", "started_at": now + 1.1, "finished_at": now + 4.1}})
            record_metric_event({"type": "WorkerStateChanged", "worker_id": "w1", "worker_state": "IDLE", "timestamp": now + 5})
            snap = metrics_snapshot()
            self.assertEqual(snap["jobs_started"], 1)
            self.assertEqual(snap["jobs_completed"], 1)
            self.assertGreater(snap["worker_utilization_percent"], 0)
            self.assertEqual(snap["worker_count_observed"], 1)

    def test_resource_manager_does_not_check_disk_and_throttles_cpu_memory(self):
        with patch("services.resource_manager.psutil", _FakePsutil):
            manager = ResourceManager(_Logger(), cpu_limit_percent=50, memory_limit_percent=50)
            _FakePsutil.cpu = 90
            _FakePsutil.mem = 20
            blocked = manager.check(force=True)
            self.assertFalse(blocked.allowed)
            self.assertIn("cpu", blocked.reason)
            self.assertFalse(manager.snapshot()["disk_limit_enabled"])
            _FakePsutil.cpu = 10
            _FakePsutil.mem = 20
            allowed = manager.check(force=True)
            self.assertTrue(allowed.allowed)

    def test_worker_lifecycle_and_drain(self):
        lc = WorkerLifecycle()
        self.assertEqual(lc.transition(WorkerState.STARTING), WorkerState.STARTING)
        self.assertEqual(lc.transition(WorkerState.IDLE), WorkerState.IDLE)
        self.assertEqual(lc.transition(WorkerState.DRAINING), WorkerState.DRAINING)
        self.assertEqual(lc.transition(WorkerState.IDLE), WorkerState.IDLE)
        self.assertEqual(lc.transition(WorkerState.BUSY), WorkerState.BUSY)
        self.assertEqual(lc.transition(WorkerState.CRASHED), WorkerState.CRASHED)
        self.assertEqual(lc.transition(WorkerState.IDLE), WorkerState.IDLE)

    def test_worker_context_exposes_drain_state(self):
        bus = EventBus(_Logger())
        ctx = WorkerContext("worker-test-18", event_bus=bus, logger=_Logger(), heartbeat_interval=60)
        seen = []
        bus.subscribe(EventType.WORKER_STATE_CHANGED, lambda e: seen.append(e["worker_state"]))
        try:
            ctx.start()
            ctx.drain()
            snap = ctx.snapshot()
            self.assertEqual(snap["worker_state"], WorkerState.DRAINING.value)
            self.assertFalse(snap["accepting_jobs"])
            ctx.undrain()
            self.assertTrue(ctx.accepting_jobs)
        finally:
            ctx.stop()
        self.assertIn("DRAINING", seen)

    def test_event_journal_roundtrip(self):
        import services.event_journal as ej
        old_base = ej.base_dir
        try:
            ej.base_dir = lambda: self.tmp
            append_event({"type": "JobCompleted", "job_id": "j-1", "timestamp": time.time()})
            values = read_events(limit=10)
            self.assertTrue(any(item.get("job_id") == "j-1" for item in values))
        finally:
            ej.base_dir = old_base

    def test_web_and_build_declare_new_operational_features(self):
        root = Path(__file__).resolve().parents[1]
        web = (root / "src" / "services" / "web_server.py").read_text(encoding="utf-8")
        page = (root / "src" / "services" / "web_page.html").read_text(encoding="utf-8")
        requirements = (root / "config" / "requirements.txt").read_text(encoding="utf-8")
        for needle in ("/api/metrics", "/api/event-log", "/api/jobs/diagnostics", "/api/resource", "/api/workers/drain", "/api/workers/undrain"):
            self.assertIn(needle, web)
        for needle in ("Рабочие метрики", "Диагностика", "Вывести из очереди", "Ключ идемпотентности", "retry-max", "resource-cpu"):
            self.assertIn(needle, page)
        for needle in ("selenium", "psutil"):
            self.assertIn(needle, requirements)


if __name__ == "__main__":
    unittest.main()
