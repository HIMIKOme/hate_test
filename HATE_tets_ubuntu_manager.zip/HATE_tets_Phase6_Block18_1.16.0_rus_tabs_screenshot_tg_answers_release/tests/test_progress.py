from __future__ import annotations

import unittest

from services.event_bus import EventBus, EventType
from services.hub import Hub
from services.job import Job, JobProgress, JobState
from services.worker_context import WorkerContext


class _Logger:
    def info(self, *args, **kwargs): pass
    def warning(self, *args, **kwargs): pass
    def error(self, *args, **kwargs): pass
    def debug(self, *args, **kwargs): pass


class ProgressBlock7Tests(unittest.TestCase):
    def test_progress_revision_is_monotonic_and_stale_update_is_ignored(self):
        progress = JobProgress()
        self.assertTrue(progress.update(percent=10, stage="testing", current_question=1, total_questions=10, revision=1))
        self.assertTrue(progress.update(percent=40, stage="testing", current_question=4, total_questions=10, revision=2))
        self.assertFalse(progress.update(percent=20, stage="testing", current_question=2, total_questions=10, revision=1))
        self.assertEqual(progress.percent, 40.0)
        self.assertEqual(progress.current_question, 4)
        self.assertEqual(progress.revision, 2)

    def test_worker_emits_full_progress_context_with_revision(self):
        bus = EventBus(_Logger())
        seen = []
        bus.subscribe(EventType.JOB_PROGRESS_REQUESTED, seen.append)
        ctx = WorkerContext("worker-7", bus, _Logger())
        ctx.set_job("job-7")
        ctx.emit_job_progress("job-7", 25, current_question=2, total_questions=8, stage="testing")
        ctx.emit_job_progress("job-7", 37.5, current_question=3, total_questions=8, stage="testing")
        self.assertEqual([e["progress_revision"] for e in seen], [1, 2])
        self.assertEqual(seen[-1]["progress_context"], {
            "stage": "testing", "percent": 37.5,
            "current_question": 3, "total_questions": 8, "revision": 2,
        })
        ctx.stop()

    def test_hub_rejects_stale_progress_event(self):
        hub = Hub(_Logger(), worker_count=1, version="1.5.0")
        job = hub.create_job("https://example.test")
        hub.events.publish(EventType.JOB_STARTED, source="worker", worker_id="worker-1", job_id=job.id)
        hub.events.publish(EventType.JOB_PROGRESS_REQUESTED, source="worker", worker_id="worker-1", job_id=job.id,
                           progress=60, current_question=6, total_questions=10, stage="testing", progress_revision=6)
        self.assertEqual(job.progress, 60.0)
        self.assertEqual(job.progress_context.revision, 6)
        hub.events.publish(EventType.JOB_PROGRESS_REQUESTED, source="worker", worker_id="worker-1", job_id=job.id,
                           progress=20, current_question=2, total_questions=10, stage="testing", progress_revision=5)
        self.assertEqual(job.progress, 60.0)
        self.assertEqual(job.current_question, 6)
        self.assertEqual(job.progress_context.revision, 6)

    def test_state_manager_exposes_dedicated_job_progress_snapshot(self):
        hub = Hub(_Logger(), worker_count=1, version="1.5.0")
        job = hub.create_job("https://example.test")
        hub.events.publish(EventType.JOB_PROGRESS_REQUESTED, source="worker", worker_id="worker-2", job_id=job.id,
                           progress=50, current_question=5, total_questions=10, stage="testing", progress_revision=3)
        snapshot = hub.snapshot()
        current = snapshot["job_progress"][job.id]
        self.assertEqual(current["percent"], 50.0)
        self.assertEqual(current["current_question"], 5)
        self.assertEqual(current["total_questions"], 10)
        self.assertEqual(current["revision"], 3)
        self.assertEqual(current["state"], "QUEUED")
        self.assertEqual(current["worker_id"], "worker-2")

    def test_real_worker_callback_updates_canonical_progress(self):
        import threading
        import time

        hub = Hub(_Logger(), worker_count=1, version="1.5.0")
        done = threading.Event()
        release = threading.Event()

        def handler(job, context):
            context.emit_job_progress(job.id, 10, current_question=1, total_questions=10, stage="testing")
            context.emit_job_progress(job.id, 70, current_question=7, total_questions=10, stage="testing")
            done.set()
            release.wait(2.0)

        hub.set_job_handler(handler)
        hub.start()
        try:
            job = hub.create_job("https://example.test")
            self.assertTrue(done.wait(2.0))
            deadline = time.time() + 2.0
            while time.time() < deadline and job.progress < 70:
                time.sleep(0.01)
            self.assertEqual(job.progress, 70.0)
            self.assertEqual(job.current_question, 7)
            self.assertEqual(job.total_questions, 10)
            self.assertEqual(job.stage, "testing")
            self.assertGreaterEqual(job.progress_context.revision, 2)
        finally:
            release.set()
            hub.stop(cancel_pending=True)

    def test_hub_progress_api_is_canonical(self):
        hub = Hub(_Logger(), worker_count=1, version="1.5.0")
        job = hub.create_job("https://example.test")
        hub.events.publish(EventType.JOB_PROGRESS_REQUESTED, source="worker", worker_id="worker-3", job_id=job.id,
                           progress=75, current_question=3, total_questions=4, stage="testing", progress_revision=1)
        progress = hub.get_job_progress(job.id)
        self.assertEqual(progress["job_id"], job.id)
        self.assertEqual(progress["percent"], 75.0)
        self.assertEqual(progress["current_question"], 3)
        self.assertEqual(hub.get_all_job_progress()[job.id]["revision"], 1)


if __name__ == "__main__":
    unittest.main()
