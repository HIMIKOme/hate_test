from __future__ import annotations

import json
import tempfile
import time
import unittest
from pathlib import Path

from services import statistics
from services.web_server import _component_status, _dashboard, _decorate_state


class WebDashboardTests(unittest.TestCase):
    def test_online_status_uses_application_and_worker_health(self):
        fresh = {
            "bot_running": True,
            "config": {"telegram_token": "token"},
            "jobs": {"active": [], "queued": [], "running": 0, "queue_size": 0},
            "workers": [
                {"worker_id": "worker-1", "queue_type": "TEST_QUEUE", "alive": True, "browser_status": "offline"},
            ],
            "watchdog": {"alive": True, "status": "Online"},
        }
        # Не привязываем тест к реальному heartbeat файловой системы.
        import services.web_server as ws
        old = ws._heartbeat_age
        ws._heartbeat_age = lambda: 1.0
        try:
            health = _component_status(fresh)
        finally:
            ws._heartbeat_age = old
        self.assertEqual(health["overall"], "Online")
        self.assertEqual(health["worker"], "Online")
        self.assertEqual(health["telegram"], "Online")

    def test_warning_when_telegram_configured_but_stopped(self):
        state = {
            "bot_running": False,
            "config": {"telegram_token": "configured"},
            "jobs": {"active": [], "queued": [], "running": 0, "queue_size": 0},
            "workers": [{"worker_id": "worker-1", "queue_type": "TEST_QUEUE", "alive": True}],
        }
        import services.web_server as ws
        old = ws._heartbeat_age
        ws._heartbeat_age = lambda: 1.0
        try:
            health = _component_status(state)
        finally:
            ws._heartbeat_age = old
        self.assertEqual(health["overall"], "Warning")
        self.assertEqual(health["telegram"], "Warning")

    def test_critical_when_active_jobs_have_no_live_worker(self):
        state = {
            "bot_running": True,
            "config": {"telegram_token": "configured"},
            "jobs": {"active": [{"id": "job-1"}], "queued": [], "running": 1, "queue_size": 0},
            "workers": [{"worker_id": "worker-1", "queue_type": "TEST_QUEUE", "alive": False}],
        }
        import services.web_server as ws
        old = ws._heartbeat_age
        ws._heartbeat_age = lambda: 1.0
        try:
            health = _component_status(state)
        finally:
            ws._heartbeat_age = old
        self.assertEqual(health["overall"], "Critical")

    def test_dashboard_contains_current_job_and_queue_counts(self):
        state = {
            "bot_running": True,
            "config": {"telegram_token": "configured"},
            "jobs": {
                "active": [{"id": "job-42", "started_at": time.time() - 7, "stage": "testing", "progress": 40}],
                "queued": [{"id": "job-43"}],
                "running": 1,
                "total_queue_size": 1,
            },
            "workers": [{"worker_id": "worker-1", "queue_type": "TEST_QUEUE", "alive": True}],
            "statistics": {"last_error": None, "last_success": None},
        }
        import services.web_server as ws
        old = ws._heartbeat_age
        ws._heartbeat_age = lambda: 1.0
        try:
            dashboard = _dashboard(state)
        finally:
            ws._heartbeat_age = old
        self.assertEqual(dashboard["current_job"]["id"], "job-42")
        self.assertEqual(dashboard["queue_count"], 1)
        self.assertEqual(dashboard["running_count"], 1)

    def test_statistics_persist_job_counts(self):
        with tempfile.TemporaryDirectory() as td:
            old_path = statistics._PATH
            statistics._PATH = Path(td) / "stats.json"
            try:
                base = {"id": "job-1", "queue_type": "TEST_QUEUE", "started_at": time.time() - 5}
                statistics.record_event({"type": "JobStarted", "timestamp": time.time(), "job_id": "job-1", "job": base})
                completed = dict(base, finished_at=time.time(), result={"answer_count": 12})
                statistics.record_event({"type": "JobCompleted", "timestamp": time.time(), "job_id": "job-1", "job": completed})
                snap = statistics.snapshot()
                self.assertEqual(snap["tests_total"], 1)
                self.assertEqual(snap["successful_total"], 1)
                self.assertEqual(snap["answers_saved"], 12)
                self.assertEqual(snap["errors_total"], 0)
                self.assertEqual(snap["messages_sent"], 0)
                self.assertTrue(statistics._PATH.exists())
                self.assertIsInstance(json.loads(statistics._PATH.read_text(encoding="utf-8")), dict)
            finally:
                statistics._PATH = old_path

    def test_web_page_is_a_full_dashboard_and_main_interface(self):
        page = Path(__file__).resolve().parents[1] / "src" / "services" / "web_page.html"
        html = page.read_text(encoding="utf-8")
        for needle in (
            'Главная',
            'Задания',
            'Данные',
            'Журнал',
            'Настройки',
            'Система',
            'Очереди и задания',
            'История событий',
            'Статистика',
            'Telegram',
            'Исполнители и браузеры',
            'Последняя ошибка',
            'Последний успех',
            'Добавить задание',
            'worker-count',
            "EventSource('/api/events')",
            'Онлайн-журнал',
            'StateSnapshot',
            'setInterval(refresh,60000)',
            'Завершить все процессы',
            'shutdownAll()',
            '/api/shutdown_all',
            'Настройки сохранены и отображаются актуально',
        ):
            self.assertIn(needle, html)

    def test_decorated_state_reports_health_and_statistics(self):
        import services.web_server as ws
        old = ws._heartbeat_age
        ws._heartbeat_age = lambda: 1.0
        try:
            with tempfile.TemporaryDirectory() as td:
                old_path = statistics._PATH
                statistics._PATH = Path(td) / "stats.json"
                try:
                    state = _decorate_state({
                        "bot_running": True,
                        "jobs": {"active": [], "queued": [], "history": [], "running": 0, "queue_size": 0},
                        "workers": [],
                        "config": {},
                    })
                finally:
                    statistics._PATH = old_path
            self.assertEqual(state["application_status"], "Warning")
            self.assertIn("health", state)
            self.assertIn("statistics", state)
            self.assertIn("history", state)
        finally:
            ws._heartbeat_age = old

    def test_saved_configuration_round_trips_without_visual_reset(self):
        import services.config as cfg
        with tempfile.TemporaryDirectory() as td:
            old_base = cfg._base_dir
            old_reload = cfg.request_reload
            cfg._base_dir = lambda: Path(td)
            cfg.request_reload = lambda: None
            try:
                cfg.save_settings({
                    "telegram_token": "123:ABC",
                    "telegram_chats": ["111", "222", ""],
                    "error_contact": "@admin",
                    "cleanup_days": 17,
                    "whitelist": ["user1"],
                    "worker_count": 6,
                    "auxiliary_worker_count": 2,
                    "circuit_failure_threshold": 4,
                    "circuit_window_sec": 600,
                    "circuit_cooldown_sec": 180,
                    "retry_max_attempts": 5,
                    "retry_backoff_sec": 7,
                    "retry_backoff_max_sec": 140,
                    "retry_policy": "auto",
                    "resource_cpu_limit_percent": 80,
                    "resource_memory_limit_percent": 75,
                })
                loaded = cfg.load_settings()
                self.assertEqual(loaded["telegram_token"], "123:ABC")
                self.assertEqual(loaded["telegram_chats"], ["111", "222", ""])
                self.assertEqual(loaded["error_contact"], "@admin")
                self.assertEqual(loaded["worker_count"], 6)
                self.assertEqual(loaded["retry_max_attempts"], 5)
            finally:
                cfg._base_dir = old_base
                cfg.request_reload = old_reload


if __name__ == "__main__":
    unittest.main()
