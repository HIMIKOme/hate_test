import tempfile
import unittest
from pathlib import Path

from manager.manager import github_download_url, validate_name, extract_archive


class ManagerTests(unittest.TestCase):
    def test_github_blob_zip(self):
        self.assertEqual(
            github_download_url("https://github.com/a/b/blob/main/file.zip"),
            "https://raw.githubusercontent.com/a/b/main/file.zip",
        )

    def test_repo_defaults_to_main_zip(self):
        self.assertEqual(
            github_download_url("https://github.com/a/b"),
            "https://github.com/a/b/archive/refs/heads/main.zip",
        )

    def test_project_name(self):
        self.assertEqual(validate_name("my-project_1"), "my-project_1")
        with self.assertRaises(ValueError):
            validate_name("../bad")

    def test_flatten_single_wrapper(self):
        import zipfile
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            archive = root / "a.zip"
            with zipfile.ZipFile(archive, "w") as z:
                z.writestr("wrapper/install.sh", "#!/bin/sh\n")
                z.writestr("wrapper/data/x.txt", "x")
            out = root / "out"
            extract_archive(archive, out)
            self.assertTrue((out / "install.sh").exists())
            self.assertTrue((out / "data/x.txt").exists())


if __name__ == "__main__":
    unittest.main()
