from __future__ import annotations

import threading
import time
import unittest

from services.event_bus import EventBus
from services.job_manager import JobManager
from services.worker_context import WorkerContext


class _Logger:
    def info(self, *args, **kwargs):
        pass

    def warning(self, *args, **kwargs):
        pass

    def error(self, *args, **kwargs):
        pass

    def debug(self, *args, **kwargs):
        pass


class _Resource:
    def __init__(self, closed: threading.Event):
        self.closed = closed

    def close(self):
        self.closed.set()


class WorkerPoolTests(unittest.TestCase):
    def test_two_jobs_run_concurrently_on_different_workers(self):
        logger = _Logger()
        manager = JobManager(logger, event_bus=EventBus(logger), worker_count=2)
        started = {"a": threading.Event(), "b": threading.Event()}
        release = threading.Event()
        worker_ids = {}

        def handler(job, context):
            worker_ids[job.id] = context.worker_id
            started[job.url.rsplit("/", 1)[-1]].set()
            release.wait(2.0)

        manager.set_handler(handler)
        manager.start()
        try:
            a = manager.create_job("https://example.test/a")
            b = manager.create_job("https://example.test/b")
            self.assertTrue(started["a"].wait(2.0))
            self.assertTrue(started["b"].wait(2.0))
            self.assertEqual(len(set(worker_ids.values())), 2)
            snap = manager.snapshot()
            self.assertEqual(snap["worker_count"], 2)
            self.assertEqual(snap["running"], 2)
        finally:
            release.set()
            manager.stop(cancel_pending=True)

    def test_worker_executes_only_one_job_at_a_time(self):
        logger = _Logger()
        manager = JobManager(logger, event_bus=EventBus(logger), worker_count=1)
        first_started = threading.Event()
        release = threading.Event()
        concurrent_counter = {"value": 0, "max": 0}
        lock = threading.Lock()

        def handler(job, _context):
            with lock:
                concurrent_counter["value"] += 1
                concurrent_counter["max"] = max(concurrent_counter["max"], concurrent_counter["value"])
            first_started.set()
            release.wait(1.0)
            with lock:
                concurrent_counter["value"] -= 1

        manager.set_handler(handler)
        manager.start()
        try:
            manager.create_job("https://example.test/a")
            manager.create_job("https://example.test/b")
            self.assertTrue(first_started.wait(2.0))
            time.sleep(0.1)
            self.assertEqual(concurrent_counter["max"], 1)
        finally:
            release.set()
            manager.stop(cancel_pending=True)

    def test_worker_job_resources_are_released_after_callback(self):
        logger = _Logger()
        manager = JobManager(logger, event_bus=EventBus(logger), worker_count=1)
        resource_closed = threading.Event()
        resource_seen = threading.Event()

        def handler(job, context):
            resource = context.get_resource("fake", lambda: _Resource(resource_closed))
            self.assertIsNotNone(resource)
            resource_seen.set()

        manager.set_handler(handler)
        manager.start()
        try:
            job = manager.create_job("https://example.test")
            self.assertTrue(resource_seen.wait(2.0))
            deadline = time.time() + 2
            while time.time() < deadline and not resource_closed.is_set():
                time.sleep(0.01)
            self.assertTrue(resource_closed.is_set())
            deadline = time.time() + 2
            while time.time() < deadline and job.state.value != "COMPLETED":
                time.sleep(0.01)
            self.assertEqual(job.state.value, "COMPLETED")
        finally:
            manager.stop(cancel_pending=True)

    def test_worker_context_has_no_shared_browser_state(self):
        a = WorkerContext("worker-1", EventBus(_Logger()), _Logger())
        b = WorkerContext("worker-2", EventBus(_Logger()), _Logger())
        try:
            self.assertIsNot(a.resources, b.resources)
            self.assertEqual(a.worker_id, "worker-1")
            self.assertEqual(b.worker_id, "worker-2")
            self.assertNotEqual(a.worker_id, b.worker_id)
        finally:
            a.stop()
            b.stop()

    def test_browser_module_contains_no_global_driver_state(self):
        from pathlib import Path
        source = (Path(__file__).resolve().parents[1] / "src" / "automation" / "browser.py").read_text(encoding="utf-8")
        self.assertNotIn("_driver =", source)
        self.assertNotIn("_current_profile_dir =", source)
        self.assertNotIn("global _driver", source)
        self.assertNotIn("global _current_profile_dir", source)


if __name__ == "__main__":
    unittest.main()
