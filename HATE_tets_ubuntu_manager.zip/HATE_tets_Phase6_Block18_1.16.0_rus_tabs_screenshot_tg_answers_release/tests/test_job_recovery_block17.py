import json
import shutil
import tempfile
import time
import unittest
from pathlib import Path

from services.event_bus import EventBus, EventType
from services.job import Job, JobState
from services.job_manager import JobManager
from services.job_store import JobStore


class _Logger:
    def debug(self, *_a, **_k): pass
    def warning(self, *_a, **_k): pass
    def error(self, *_a, **_k): pass
    def info(self, *_a, **_k): pass


class JobRecoveryBlock17Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="hate-recovery17-"))

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_store_roundtrip_is_atomic_and_versioned(self):
        store = JobStore(self.tmp / "jobs_state.json", logger=_Logger())
        job = Job("https://example.test")
        store.save([job.to_dict()], process_version="1.15.0")
        raw = json.loads((self.tmp / "jobs_state.json").read_text(encoding="utf-8"))
        self.assertEqual(raw["schema_version"], 1)
        self.assertEqual(raw["process_version"], "1.15.0")
        self.assertEqual(raw["jobs"][0]["id"], job.id)

    def test_active_job_is_requeued_after_process_restart(self):
        store = JobStore(self.tmp / "jobs_state.json", logger=_Logger())
        job = Job("https://example.test")
        job.transition(JobState.STARTING, stage="starting")
        job.transition(JobState.BROWSER_STARTING, stage="browser")
        job.worker_id = "worker-7"
        job.attempts = 2
        store.save([job.to_dict()], process_version="1.14.0")

        bus = EventBus(_Logger())
        seen = []
        bus.subscribe(EventType.JOBS_RECOVERED_AFTER_RESTART, lambda event: seen.append(event))
        manager = JobManager(_Logger(), event_bus=bus, worker_count=1, job_store=store)
        summary = manager.restore_persisted_jobs(current_version="1.15.0")
        restored = manager.get(job.id)

        self.assertEqual(summary["recovered"], 1)
        self.assertEqual(restored.state, JobState.QUEUED)
        self.assertIsNone(restored.worker_id)
        self.assertIsNone(restored.started_at)
        self.assertEqual(restored.progress_context.stage, "recovered_after_restart")
        self.assertEqual(restored.diagnostics["restart_recovery"]["previous_state"], "BROWSER_STARTING")
        self.assertEqual(restored.diagnostics["restart_recovery"]["target_version"], "1.15.0")
        self.assertEqual(seen[0]["recovered"], 1)

    def test_terminal_history_is_restored_without_requeue(self):
        store = JobStore(self.tmp / "jobs_state.json", logger=_Logger())
        job = Job("https://example.test")
        job.transition(JobState.STARTING, stage="starting")
        job.transition(JobState.COMPLETED, stage="completed")
        store.save([job.to_dict()], process_version="1.14.0")

        manager = JobManager(_Logger(), event_bus=EventBus(_Logger()), worker_count=1, job_store=store)
        summary = manager.restore_persisted_jobs(current_version="1.15.0")
        restored = manager.get(job.id)
        self.assertEqual(summary["history_restored"], 1)
        self.assertEqual(restored.state, JobState.COMPLETED)
        self.assertIsNone(manager.get_queue_position(job.id))

    def test_corrupt_store_does_not_break_startup(self):
        path = self.tmp / "jobs_state.json"
        path.write_text("{not-json", encoding="utf-8")
        store = JobStore(path, logger=_Logger())
        self.assertEqual(store.load()["jobs"], [])

    def test_hub_accepts_explicit_job_store_without_forcing_persistence_on_clients(self):
        from services.hub import Hub
        store = JobStore(self.tmp / "jobs_state.json", logger=_Logger())
        hub = Hub(_Logger(), worker_count=1, version="1.15.0", job_store=store)
        job = hub.create_job("https://example.test")
        self.assertTrue(job.id)
        self.assertIs(hub.job_store, store)
        hub.events.publish(EventType.JOB_PROGRESS_REQUESTED, source="worker", job_id=job.id, progress=10, stage="testing", progress_revision=1)
        self.assertTrue(store.path.exists())

    def test_web_exposes_recovery_api_and_build_includes_job_store(self):
        root = Path(__file__).resolve().parents[1]
        server = (root / "src" / "services" / "web_server.py").read_text(encoding="utf-8")
        main = (root / "src" / "main.py").read_text(encoding="utf-8")
        self.assertIn('route == "/api/recovery"', server)
        self.assertIn('jobs_state.json', server)
        self.assertIn("src/main.py", (root / "README.md").read_text(encoding="utf-8"))
        self.assertIn("server_main", main)

    def test_persistence_snapshot_contains_history_and_queue(self):
        store = JobStore(self.tmp / "jobs_state.json", logger=_Logger())
        manager = JobManager(_Logger(), event_bus=EventBus(_Logger()), worker_count=1, job_store=store)
        queued = manager.create_job("https://example.test")
        terminal = manager.create_job("https://example.test/2")
        terminal.transition(JobState.STARTING, stage="starting")
        terminal.transition(JobState.COMPLETED, stage="completed")
        jobs = manager.persistence_snapshot()
        ids = {item["id"] for item in jobs}
        self.assertEqual(ids, {queued.id, terminal.id})


if __name__ == "__main__":
    unittest.main()
