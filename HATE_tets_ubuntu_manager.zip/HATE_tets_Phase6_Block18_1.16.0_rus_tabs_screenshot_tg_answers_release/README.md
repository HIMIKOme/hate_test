# HATE_tets — Ubuntu Server

Это Linux/Ubuntu Server-версия проекта. Windows `.bat`, `.exe`, Tkinter GUI и системный tray не используются.

## Быстрая установка

```bash
unzip HATE_tets_ubuntu_server.zip
cd HATE_tets_ubuntu_server
./install.sh
./start.sh
```

Установщик автоматически ставит системные пакеты, Chromium, Python virtualenv и Python-зависимости, затем запускает тесты и регистрирует `systemd`-сервис.

## Запуск

```bash
./start.sh
```

Сервис будет автоматически стартовать после перезагрузки Ubuntu.

```bash
./status.sh
```

LAN-адрес Web-панели сохраняется в `data/web.json`. Открой его с телефона или ПК в той же локальной сети.

## Telegram

В проекте задан стандартный токен бота. Его можно изменить через раздел настроек Web-панели. После изменения бот автоматически перезапускается.

> Для безопасности после публикации токена рекомендуется перевыпустить его через BotFather.

## Остановка

```bash
./stop.sh
```

## Логи

```bash
journalctl -u hate-tets.service -f
```

или файлы в `data/logs/`.

## Ручной запуск без systemd

```bash
./venv/bin/python src/main.py
```
