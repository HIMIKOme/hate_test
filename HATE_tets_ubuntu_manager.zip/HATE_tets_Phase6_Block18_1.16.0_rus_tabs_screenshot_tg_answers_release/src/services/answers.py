"""Извлечение и сохранение правильных ответов.

Разделение файлов:
  • data/answers_program/*.json  — «программный» формат: чистый структурированный
    JSON. Именно эти файлы читает проект (cache, runner, telegram_bot).
  • data/answers/*.txt           — красиво отформатированная шпаргалка,
    отправляется в Telegram как файл.
  • data/answers/*_short.md      — компактный список для Telegram-сообщения.
  • data/reports/*.txt|json|csv  — внутренние отладочные отчёты.

Поддерживаемые типы вопросов:
  • radio / checkbox;
  • matching — соответствие через <select>;
  • open_text — открытый ответ (всегда "не знаю").

ВАЖНО для matching: в кэш сохраняется ТЕКСТ правого варианта (right_text),
а не только номер строки. onlinetestpad перемешивает варианты правого
столбца между прохождениями, поэтому номер нестабилен, а текст — стабилен.
"""
from __future__ import annotations

import csv
import json
import re
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from selenium.common.exceptions import (
    StaleElementReferenceException,
    WebDriverException,
)
from selenium.webdriver.common.by import By

import page_selectors as sel
from .config import get_data_dir, load_settings


HEADER_LINE_1 = "Ответы на тест HATE_tets"

_NAME_MARKERS = ("фио", "фамил", "имя", "surname", "lastname", "firstname")

# Значение, которое бот вводит в любой открытый ответ.
OPEN_TEXT_FALLBACK = "не знаю"


def _get_author() -> str:
    try:
        return (load_settings().get("error_contact") or "").strip()
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# Пути
# ---------------------------------------------------------------------------

def get_answers_dir() -> Path:
    """Папка с человекочитаемыми шпаргалками (Telegram)."""
    d = get_data_dir() / "answers"
    d.mkdir(parents=True, exist_ok=True)
    return d


def get_program_answers_dir() -> Path:
    """Папка с программным форматом (JSON). Читает проект."""
    d = get_data_dir() / "answers_program"
    d.mkdir(parents=True, exist_ok=True)
    return d


def get_reports_dir() -> Path:
    d = get_data_dir() / "reports"
    d.mkdir(parents=True, exist_ok=True)
    return d


# ---------------------------------------------------------------------------
# Публичная точка входа
# ---------------------------------------------------------------------------

def save_answers(answers: List[Dict], logger=None, job_id: Optional[str] = None) -> Optional[Dict]:
    if not answers:
        if logger:
            logger.warning("Список ответов пуст — результаты не созданы.")
        return None

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    # История Job хранится отдельно и однозначно привязана к Job ID.
    # Старые общие latest-файлы сохраняются для совместимости.
    job_prefix = f"{job_id}_" if job_id else ""
    job_dir = get_data_dir() / "jobs" / (job_id or "legacy")
    job_dir.mkdir(parents=True, exist_ok=True)
    reports = job_dir / "reports"
    reports.mkdir(parents=True, exist_ok=True)
    answers_dir = job_dir / "answers"
    answers_dir.mkdir(parents=True, exist_ok=True)
    program_dir = job_dir / "answers_program"
    program_dir.mkdir(parents=True, exist_ok=True)

    # --- Программный формат (JSON) ------------------------------- #
    program_latest = program_dir / "latest.json"
    program_hist = program_dir / f"{job_prefix}{timestamp}.json"
    _write_program_json(answers, program_latest, logger)
    _write_program_json(answers, program_hist, logger)

    # --- Telegram: файл-шпаргалка -------------------------------- #
    cheatsheet_text = _format_cheatsheet(answers)
    cheat_path = _next_cheatsheet_path(answers_dir)
    try:
        cheat_path.write_text(cheatsheet_text, encoding="utf-8")
        if logger:
            logger.info(f"Шпаргалка сохранена: {cheat_path.name}")
    except OSError as exc:
        if logger:
            logger.error(f"Не удалось записать шпаргалку {cheat_path}: {exc}")

    # --- Telegram: компактное сообщение -------------------------- #
    telegram_text = _build_telegram_message(answers)
    short_path = cheat_path.with_name(cheat_path.stem + "_short.md")
    try:
        short_path.write_text(telegram_text, encoding="utf-8")
        if logger:
            logger.info(f"Сокращённые ответы сохранены: {short_path.name}")
    except OSError as exc:
        if logger:
            logger.error(f"Не удалось записать {short_path}: {exc}")

    # --- Внутренние отладочные отчёты ---------------------------- #
    _write_txt(answers, reports / f"{job_prefix}correct_answers_{timestamp}.txt", logger)
    _write_txt(answers, reports / f"{job_prefix}latest.txt", logger)
    _write_json(answers, reports / f"{job_prefix}correct_answers_{timestamp}.json", logger)
    _write_json(answers, reports / f"{job_prefix}latest.json", logger)
    _write_csv(answers, reports / f"{job_prefix}correct_answers_{timestamp}.csv", logger)
    _write_csv(answers, reports / f"{job_prefix}latest.csv", logger)

    return {
        "telegram_text": telegram_text,
        "cheatsheet_path": cheat_path,
        "short_path": short_path,
        "answer_pairs": _build_answer_pairs(answers),
        "program_json_path": program_latest,
    }


# ---------------------------------------------------------------------------
# Программный формат (JSON)
# ---------------------------------------------------------------------------

def _write_program_json(items: List[Dict], path: Path, logger=None) -> None:
    """Пишет компактный, стабильный JSON для проекта.

    Схема записи (по вопросам):
      {number, type, question, corrects|matching|value}
    """
    data: List[Dict] = []
    for i, it in enumerate(items, 1):
        t = it.get("type") or "radio"
        entry: Dict = {
            "number": i,
            "type": t,
            "question": (it.get("question") or "").strip(),
        }

        if t == "matching":
            entry["matching"] = [
                {
                    "left": m.get("left") or "",
                    "right_text": m.get("right_text") or "",
                }
                for m in (it.get("matching") or [])
            ]
        elif t == "open_text":
            entry["value"] = OPEN_TEXT_FALLBACK
            entry["detected_as_name"] = bool(it.get("detected_as_name"))
        else:
            corrects: List[Dict[str, str]] = []
            raw_corrects = it.get("corrects") or []
            if raw_corrects:
                for c in raw_corrects:
                    letter, text = _split_letter_and_text(c)
                    corrects.append({"letter": letter, "text": text})
            elif it.get("correct"):
                letter, text = _split_letter_and_text(it["correct"])
                corrects.append({"letter": letter, "text": text})
            entry["corrects"] = corrects

        data.append(entry)

    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        if logger:
            logger.info(f"Программный JSON сохранён: {path.name}")
    except OSError as exc:
        if logger:
            logger.error(f"Не удалось записать {path}: {exc}")


# ---------------------------------------------------------------------------
# Telegram: компактное сообщение
# ---------------------------------------------------------------------------

def _build_telegram_message(items: List[Dict]) -> str:
    """Красиво отформатированное сообщение для Telegram.

    Формат:
        📋 Ответы на тест
        👤 Автор: @user
        ❓ Вопросов: 16

        1. Текст вопроса
           • Левая часть → Правая часть        (для matching)
           ✅ Б) Текст ответа                  (для radio/checkbox)
           ✏️ Ответ: не знаю                    (для open_text)
    """
    lines: List[str] = []

    lines.append("📋 Ответы на тест")
    author = _get_author()
    if author:
        lines.append(f"👤 Автор: {author}")
    lines.append(f"❓ Вопросов: {len(items)}")
    lines.append("")

    for i, it in enumerate(items, 1):
        t = it.get("type") or "radio"
        q = _shorten(it.get("question") or "", limit=160)
        lines.append(f"{i}. {q}" if q else f"{i}. —")

        # --- Соответствие (matching) --- #
        if t == "matching":
            matching = it.get("matching") or []
            if not matching:
                lines.append("   (соответствие не распознано)")
            else:
                for m in matching:
                    left = (m.get("left") or "?").strip()
                    right = (m.get("right_text") or m.get("right") or "?").strip()
                    lines.append(f"   • {left} → {right}")

        # --- Открытый ответ --- #
        elif t == "open_text":
            lines.append(f"   ✏️ Ответ: {OPEN_TEXT_FALLBACK}")

        # --- Radio / checkbox --- #
        else:
            corrects = it.get("corrects") or []
            if not corrects and it.get("correct"):
                corrects = [it["correct"]]

            parts: List[str] = []
            for c in corrects:
                c_norm = _normalize_ws(c)
                if not c_norm:
                    continue
                letter = _extract_option_letter_anywhere(c_norm)
                rest = _strip_letter_prefix(c_norm)
                if letter and rest:
                    parts.append(f"{letter}) {_shorten(rest, 100)}")
                elif letter:
                    parts.append(letter)
                else:
                    parts.append(_shorten(c_norm, 100))

            if parts:
                lines.append("   ✅ " + " | ".join(parts))
            else:
                lines.append("   (ответ не распознан)")

        lines.append("")

    while lines and lines[-1] == "":
        lines.pop()

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Telegram: файл-шпаргалка
# ---------------------------------------------------------------------------

def _format_cheatsheet(items: List[Dict]) -> str:
    """Полная, аккуратно оформленная локальная шпаргалка."""
    lines: List[str] = []
    lines.append(HEADER_LINE_1)
    author = _get_author()
    if author:
        lines.append(f"Автор: {author}")
    lines.append(f"Дата: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    lines.append(f"Всего вопросов: {len(items)}")
    lines.append("")
    lines.append("═" * 60)
    lines.append("")

    for i, it in enumerate(items, 1):
        q = (it.get("question") or "(вопрос не распознан)").strip()
        t = it.get("type") or "radio"

        lines.append(f"Вопрос {i}")
        lines.append(q)
        lines.append("")

        if t == "matching":
            lines.append("Соответствие:")
            for m in (it.get("matching") or []):
                left = (m.get("left") or "?").strip()
                right = (m.get("right_text") or m.get("right") or "?").strip()
                lines.append(f"  • {left} → {right}")
        elif t == "open_text":
            lines.append(f"Ответ: {OPEN_TEXT_FALLBACK}")
        else:
            corrects = it.get("corrects") or []
            if corrects:
                joined = " | ".join(corrects)
                lines.append(f"Ответ: {joined}")
            else:
                lines.append(f"Ответ: {it.get('correct') or '(не распознан)'}")

        lines.append("")
        lines.append("─" * 60)
        lines.append("")

    return "\n".join(lines).rstrip() + "\n"


def _next_cheatsheet_path(answers_dir: Path) -> Path:
    date_str = datetime.now().strftime("%Y-%m-%d")
    _CHEAT_RE = re.compile(r"^(\d{4}-\d{2}-\d{2})_тест_(\d+)\.txt$")
    max_n = 0
    try:
        for p in answers_dir.iterdir():
            m = _CHEAT_RE.match(p.name)
            if m and m.group(1) == date_str:
                max_n = max(max_n, int(m.group(2)))
    except OSError:
        pass
    return answers_dir / f"{date_str}_тест_{max_n + 1}.txt"


# ---------------------------------------------------------------------------
# Внутренние отладочные отчёты (reports/)
# ---------------------------------------------------------------------------

def _correct_joined(it: Dict) -> str:
    matching = it.get("matching") or []
    if matching:
        parts = []
        for m in matching:
            right = m.get("right_text") or m.get("right")
            parts.append(f"{m.get('left', '?')} → {right}")
        return " | ".join(parts)

    if it.get("type") == "open_text":
        return it.get("open_text_value") or OPEN_TEXT_FALLBACK

    corrects = it.get("corrects") or []
    if corrects:
        return " | ".join(corrects)
    return it.get("correct") or ""


def _format_report(items: List[Dict], title: str) -> str:
    total = len(items)
    correct = sum(1 for it in items if it.get("is_correct") is True)
    incorrect = sum(1 for it in items if it.get("is_correct") is False)
    unknown = total - correct - incorrect

    lines = [
        f"# {title}",
        f"# Дата: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"# Всего вопросов: {total}",
        f"# Отвечено правильно: {correct}",
        f"# Отвечено неправильно: {incorrect}",
    ]
    if unknown:
        lines.append(f"# Статус неизвестен: {unknown}")
    lines.append("")

    for i, item in enumerate(items, 1):
        q = item.get("question") or "(вопрос не распознан)"
        c = _correct_joined(item) or "(правильный ответ не распознан)"
        s = item.get("selected")
        ic = item.get("is_correct")
        t = item.get("type") or "radio"
        lines.append(f"[{i}] ({t}) {q}")
        if ic is True:
            lines.append(f"    ✓ Правильный ответ: {c}")
        elif ic is False:
            lines.append(f"    ✗ Правильный ответ: {c}")
            if s:
                lines.append(f"      (был выбран: {s})")
        else:
            lines.append(f"    ? Правильный ответ: {c}")
            if s:
                lines.append(f"      (был выбран: {s})")
        lines.append("")
    return "\n".join(lines)


def _write_txt(items, path: Path, logger) -> None:
    try:
        path.write_text(
            _format_report(items, "Правильные ответы (собрано автоматически)"),
            encoding="utf-8",
        )
    except OSError as exc:
        if logger:
            logger.error(f"Не удалось записать {path}: {exc}")


def _write_json(items, path: Path, logger) -> None:
    data = []
    for i, it in enumerate(items, 1):
        entry = {
            "number": i,
            "type": it.get("type") or "radio",
            "question": it.get("question"),
            "correct_answers": it.get("corrects") or (
                [it.get("correct")] if it.get("correct") else []
            ),
            "selected_answer": it.get("selected"),
            "is_correct": it.get("is_correct"),
        }
        if it.get("matching"):
            entry["matching"] = it.get("matching")
        if it.get("type") == "open_text":
            entry["open_text_value"] = it.get("open_text_value")
            entry["detected_as_name"] = bool(it.get("detected_as_name"))
        data.append(entry)
    try:
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except OSError as exc:
        if logger:
            logger.error(f"Не удалось записать {path}: {exc}")


def _write_csv(items, path: Path, logger) -> None:
    try:
        with path.open("w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(["№", "Тип", "Вопрос", "Правильные ответы", "Выбранный ответ", "Статус"])
            for i, it in enumerate(items, 1):
                ic = it.get("is_correct")
                status = "верно" if ic is True else "неверно" if ic is False else "?"
                w.writerow([
                    i,
                    it.get("type") or "radio",
                    it.get("question") or "",
                    _correct_joined(it),
                    it.get("selected") or "",
                    status,
                ])
    except OSError as exc:
        if logger:
            logger.error(f"Не удалось записать {path}: {exc}")


# ---------------------------------------------------------------------------
# Хелперы для парсинга ответов
# ---------------------------------------------------------------------------

_OPTION_LETTER_RE = re.compile(r"^\s*\(?([А-Яа-яЁёA-Za-z])[\s\)\.\:\-]\s*")
_ANY_LETTER_PREFIX_RE = re.compile(
    r"(?<![A-Za-zА-Яа-яЁё0-9])([A-Za-zА-Яа-яЁё])\s*[\)\.\:\-]\s*\S"
)
_STRIP_LETTER_PREFIX_RE = re.compile(r"^\s*\(?[А-Яа-яЁёA-Za-z]\s*[\)\.\:\-]\s*")


def _extract_option_letter_anywhere(text: str) -> Optional[str]:
    if not text:
        return None
    m = _ANY_LETTER_PREFIX_RE.search(text)
    return m.group(1).upper() if m else None


def _normalize_ws(s: str) -> str:
    if not s:
        return ""
    for ch in ("\xa0", "\u2007", "\u2008", "\u2009", "\u200a", "\u202f",
               "\u200b", "\u200c", "\u200d", "\u2060"):
        s = s.replace(ch, " ")
    return re.sub(r"\s+", " ", s).strip()


def _shorten(text: str, limit: int = 140) -> str:
    """Обрезает длинный текст по последнему пробелу, добавляет «…»."""
    text = _normalize_ws(text or "")
    if len(text) <= limit:
        return text
    cut = text[:limit]
    if " " in cut:
        cut = cut.rsplit(" ", 1)[0]
    return cut.rstrip(".,;:!? ") + "…"


def _strip_letter_prefix(text: str) -> str:
    """Убирает 'А)' / 'Б.' / 'B:' в начале, оставляя чистый текст ответа."""
    return _STRIP_LETTER_PREFIX_RE.sub("", text).strip()


def _split_letter_and_text(raw: str):
    s = _normalize_ws(raw)
    if not s:
        return "", ""
    m = _ANY_LETTER_PREFIX_RE.search(s)
    if m:
        return m.group(1).upper(), s[m.start():].strip()
    m2 = _OPTION_LETTER_RE.match(s)
    if m2:
        letter = m2.group(1).upper()
        text = _STRIP_LETTER_PREFIX_RE.sub("", s).strip() or s
        return letter, text
    return "", s


def _build_answer_pairs(items: List[Dict]) -> List[Dict]:
    result: List[Dict] = []
    for idx, it in enumerate(items, 1):
        q = _normalize_ws((it.get("question") or "").strip())
        if not q:
            q = f"#{idx}"

        t = it.get("type") or "radio"

        if t == "matching":
            matching = it.get("matching") or []
            if not matching:
                continue
            result.append({
                "q": q,
                "num": str(idx),
                "type": "matching",
                "matching": matching,
            })
            continue

        if t == "open_text":
            result.append({
                "q": q,
                "num": str(idx),
                "type": "open_text",
                "detected_as_name": bool(it.get("detected_as_name")),
            })
            continue

        corrects_raw: List[str] = []
        if it.get("corrects"):
            corrects_raw = list(it.get("corrects") or [])
        elif it.get("correct"):
            corrects_raw = [_normalize_ws(it["correct"])]

        corrects: List[Dict[str, str]] = []
        for c in corrects_raw:
            letter, text = _split_letter_and_text(c)
            if not (letter or text):
                continue
            corrects.append({"letter": letter, "text": text})
        if not corrects:
            continue

        result.append({
            "q": q,
            "num": str(idx),
            "type": "checkbox" if len(corrects) > 1 else "radio",
            "corrects": corrects,
        })
    return result


# ---------------------------------------------------------------------------
# Парсинг страницы "Показать мои ответы"
# ---------------------------------------------------------------------------

_OPTION_LINE_RE = re.compile(r"^\s*[А-ЯЁA-Z]\s*[\)\.\:\-]\s+\S", re.IGNORECASE)

_GARBAGE_RE = re.compile(
    r"(балл|сообщить\s+об\s+ошибке|правильный\s+ответ\s*:|"
    r"верный\s+ответ\s*:|ваш\s+ответ|ответ\s+на\s+вопрос)",
    re.IGNORECASE,
)


class AnswersExtractor:
    def __init__(self, driver, logger, stop_event=None):
        self.driver = driver
        self.logger = logger
        self.stop_event = stop_event
        self.answers: List[Dict] = []

    def collect(self) -> List[Dict]:
        if not self._click_show_answers():
            self.logger.warning(
                "Кнопка 'Показать мои ответы' не найдена. "
                "Возможно, автор теста скрыл правильные ответы."
            )
            return []
        if not self._wait_for_answers_block(timeout=10):
            self.logger.warning("Блок с ответами не появился. Пробую распарсить что есть.")
        self.answers = self._extract_all()
        if self.answers:
            correct = sum(1 for a in self.answers if a.get("is_correct") is True)
            self.logger.info(
                f"Извлечено вопросов: {len(self.answers)} (правильных у бота: {correct})"
            )
        else:
            self.logger.warning("Не удалось найти ни одного правильного ответа.")
        return self.answers

    def _click_show_answers(self) -> bool:
        self.driver.switch_to.default_content()
        el = self._find_clickable(sel.SHOW_ANSWERS_BUTTON_XPATHS, timeout=10)
        if el is None:
            el = self._find_in_frames(sel.SHOW_ANSWERS_BUTTON_XPATHS, timeout=5)
        if el is None:
            self._log_diagnostics()
            return False
        self.logger.info("Нажимаю 'Показать мои ответы'...")
        try:
            self.driver.execute_script(
                "arguments[0].scrollIntoView({block:'center'});", el
            )
            time.sleep(0.2)
        except WebDriverException:
            pass
        try:
            el.click()
            return True
        except WebDriverException:
            pass
        try:
            self.driver.execute_script("arguments[0].click();", el)
            return True
        except WebDriverException:
            return False

    def _find_clickable(self, xpaths, timeout):
        end = time.time() + timeout
        while time.time() < end:
            for xp in xpaths:
                try:
                    els = self.driver.find_elements(By.XPATH, xp)
                except WebDriverException:
                    continue
                for el in els:
                    try:
                        if el.is_displayed() and el.is_enabled():
                            return el
                    except StaleElementReferenceException:
                        continue
            time.sleep(0.15)
        return None

    def _find_in_frames(self, xpaths, timeout):
        self.driver.switch_to.default_content()
        try:
            frames = self.driver.find_elements(By.CSS_SELECTOR, "iframe, frame")
        except WebDriverException:
            return None
        end = time.time() + timeout
        while time.time() < end:
            for frame in frames:
                try:
                    self.driver.switch_to.default_content()
                    self.driver.switch_to.frame(frame)
                except (WebDriverException, StaleElementReferenceException):
                    continue
                el = self._find_clickable(xpaths, timeout=0.4)
                if el is not None:
                    return el
            time.sleep(0.15)
        self.driver.switch_to.default_content()
        return None

    def _log_diagnostics(self) -> None:
        try:
            buttons = self.driver.find_elements(
                By.CSS_SELECTOR,
                "button, a, [role='button'], input[type='button'], input[type='submit']",
            )
        except WebDriverException as exc:
            self.logger.error(f"Диагностика кнопок не удалась: {exc}")
            return
        seen = []
        for b in buttons:
            try:
                t = (b.text or "").strip()
            except (WebDriverException, StaleElementReferenceException):
                continue
            if not t:
                try:
                    t = (b.get_attribute("value") or "").strip()
                except (WebDriverException, StaleElementReferenceException):
                    t = ""
            if t and len(t) <= 120 and t not in seen:
                seen.append(t)
            if len(seen) >= 30:
                break
        try:
            url = self.driver.current_url
        except WebDriverException:
            url = "?"
        self.logger.warning(
            f"Кнопка 'Показать мои ответы' не найдена. URL: {url}. Кнопки/ссылки: {seen}"
        )

    def _wait_for_answers_block(self, timeout: float) -> bool:
        end = time.time() + timeout
        while time.time() < end:
            for xp in sel.QUESTION_BLOCK_XPATHS:
                try:
                    if self.driver.find_elements(By.XPATH, xp):
                        time.sleep(0.4)
                        return True
                except WebDriverException:
                    continue
            time.sleep(0.2)
        return False

    # ------------------------------------------------------------------ #
    def _extract_all(self) -> List[Dict]:
        blocks = self._find_question_blocks()
        if not blocks:
            return []
        self.logger.info(f"Найдено блоков вопросов: {len(blocks)}")
        result = []
        for idx, block in enumerate(blocks, 1):
            info = self._extract_from_block(block, idx)
            st = {True: "✓", False: "✗", None: "?"}[info.get("is_correct")]
            q = (info.get("question") or "")[:60]
            t = info.get("type") or "radio"
            a = _correct_joined(info)[:200]
            self.logger.info(f"  #{idx} [{st}] ({t}) Q: {q} | A: {a}")
            result.append(info)
        return result

    def _find_question_blocks(self):
        best: list = []
        for xp in sel.QUESTION_BLOCK_XPATHS:
            try:
                els = self.driver.find_elements(By.XPATH, xp)
            except WebDriverException:
                continue
            if len(els) > len(best):
                best = els
        if not best:
            return []
        return self._dedupe_nested(best)

    def _dedupe_nested(self, elements):
        if not elements:
            return []
        try:
            kept = self.driver.execute_script(
                """
                var els = arguments[0]; var out = [];
                for (var i = 0; i < els.length; i++) {
                    var nested = false;
                    for (var j = 0; j < els.length; j++) {
                        if (i !== j && els[j].contains(els[i])) { nested = true; break; }
                    }
                    if (!nested) out.push(els[i]);
                }
                return out;
                """,
                elements,
            )
            return kept or elements
        except WebDriverException:
            return elements

    def _get_question_root(self, block):
        try:
            roots = block.find_elements(
                By.XPATH,
                "ancestor-or-self::div[contains(@class,'otp-item-view-question')][1]",
            )
            if roots:
                return roots[0]
        except (WebDriverException, StaleElementReferenceException):
            pass
        return block

    def _extract_from_block(self, block, idx: int) -> Dict:
        info: Dict = {
            "type": "radio",
            "question": None,
            "selected": None,
            "correct": None,
            "corrects": [],
            "is_correct": None,
            "matching": [],
            "open_text_value": None,
            "detected_as_name": False,
        }
        try:
            raw_text = block.text or ""
        except (WebDriverException, StaleElementReferenceException):
            raw_text = ""
        text_norm = _normalize_ws(raw_text)

        tl = text_norm.lower()
        if any(m in tl for m in sel.INCORRECT_STATUS_MARKERS):
            info["is_correct"] = False
        elif any(m in tl for m in sel.CORRECT_STATUS_MARKERS):
            info["is_correct"] = True

        try:
            has_matching = bool(
                block.find_elements(By.CSS_SELECTOR, "div.matching-div")
            )
        except WebDriverException:
            has_matching = False

        try:
            has_open_text = bool(
                block.find_elements(By.CSS_SELECTOR, "input.otp-textbox")
            )
        except WebDriverException:
            has_open_text = False

        if has_matching:
            info["type"] = "matching"
            info["matching"] = self._extract_matching_from_block(block)
            info["correct"] = (
                " | ".join(
                    f"{m['left']}→{m.get('right_text') or m.get('right')}"
                    for m in info["matching"]
                )
                or None
            )

        elif has_open_text:
            info["type"] = "open_text"
            self._extract_open_text_from_block(block, info)

        else:
            corrects = self._extract_corrects_by_icon(block)
            if not corrects:
                single = self._find_leaf_text(block, sel.CORRECT_OPTION_XPATHS)
                if single:
                    corrects = [single]
            if not corrects:
                single = self._parse_correct_from_text(raw_text)
                if single:
                    corrects = [single]
            info["corrects"] = corrects
            info["correct"] = " | ".join(corrects) if corrects else None
            info["selected"] = self._find_leaf_text(block, sel.SELECTED_OPTION_XPATHS)
            if (info["correct"] and info["selected"]
                    and info["correct"] == info["selected"]
                    and info["is_correct"] is None):
                info["is_correct"] = True
            info["type"] = "checkbox" if len(corrects) > 1 else "radio"

        info["question"] = self._extract_question(block, raw_text, idx)
        return info

    # ------------------------------------------------------------------ #
    # Matching
    # ------------------------------------------------------------------ #

    def _extract_matching_from_block(self, block) -> List[Dict[str, object]]:
        root = self._get_question_root(block)

        right_map = self._read_right_column_map(root)

        pairs: Dict[str, Dict[str, object]] = {}

        rows = self._find_rightanswers_rows(block)
        if not rows and root is not block:
            rows = self._find_rightanswers_rows(root)
        for row in rows:
            try:
                tds = row.find_elements(By.XPATH, "./td")
            except (WebDriverException, StaleElementReferenceException):
                continue
            if len(tds) < 4:
                continue
            try:
                left_text = _normalize_ws(tds[0].text or "")
                right_num_text = _normalize_ws(tds[2].text or "")
            except (WebDriverException, StaleElementReferenceException):
                continue
            if not left_text or not right_num_text:
                continue
            m = re.search(r"\d+", right_num_text)
            if not m:
                continue
            try:
                right_num = int(m.group(0))
            except ValueError:
                continue
            right_text = right_map.get(str(right_num), "")
            pairs[left_text] = {"right": right_num, "right_text": right_text}

        n_rightanswers = len(pairs)

        container = self._find_matching_container(root)
        if container is not None:
            for left_text, num in self._read_correct_br_from_container(container):
                if left_text not in pairs:
                    right_text = right_map.get(str(num), "")
                    pairs[left_text] = {"right": num, "right_text": right_text}

        result = [
            {"left": k, "right": v["right"], "right_text": v.get("right_text", "")}
            for k, v in pairs.items()
        ]
        self.logger.info(
            f"Matching: собрал {len(result)} пар "
            f"(rightanswers={n_rightanswers}, "
            f"correct-br={len(result) - n_rightanswers})."
        )
        return result

    def _read_right_column_map(self, root) -> Dict[str, str]:
        container = self._find_matching_container(root)
        if container is None:
            return {}
        result: Dict[str, str] = {}

        try:
            lis = container.find_elements(By.CSS_SELECTOR, "div.lst2 li")
        except WebDriverException:
            lis = []
        for li in lis:
            try:
                num_el = li.find_element(By.CSS_SELECTOR, "div.num")
                txt_el = li.find_element(By.CSS_SELECTOR, "div.txt")
                num_str = _normalize_ws(num_el.text or "")
                text = _normalize_ws(txt_el.text or "")
            except (WebDriverException, StaleElementReferenceException):
                continue
            if num_str and text:
                result[num_str] = text
        if result:
            return result

        try:
            tables = container.find_elements(By.CSS_SELECTOR, "table.matching-tbl")
        except WebDriverException:
            tables = []
        for table in tables:
            try:
                trs = table.find_elements(By.CSS_SELECTOR, "tr")
            except WebDriverException:
                trs = []
            for tr in trs:
                try:
                    num_el = tr.find_element(By.CSS_SELECTOR, "td.td-number")
                    tds = tr.find_elements(By.TAG_NAME, "td")
                    text = ""
                    for td in tds:
                        cls = td.get_attribute("class") or ""
                        if "td-number" in cls:
                            continue
                        cand = _normalize_ws(td.text or "")
                        if cand:
                            text = cand
                            break
                    num_str = _normalize_ws(num_el.text or "")
                except (WebDriverException, StaleElementReferenceException):
                    continue
                if num_str and text:
                    result[num_str] = text
            if result:
                return result

        return result

    def _read_correct_br_from_container(self, container) -> List:
        pairs: List = []

        try:
            lis = container.find_elements(By.CSS_SELECTOR, "div.lst1 li")
        except WebDriverException:
            lis = []
        for li in lis:
            try:
                sel_el = li.find_element(By.CSS_SELECTOR, "select.otp-select")
                txt_el = li.find_element(By.CSS_SELECTOR, "div.txt")
                left = _normalize_ws(txt_el.text or "")
            except (WebDriverException, StaleElementReferenceException):
                continue
            cls = ""
            try:
                cls = sel_el.get_attribute("class") or ""
            except (WebDriverException, StaleElementReferenceException):
                pass
            if "otp-item-ans-correct-br" not in cls:
                continue
            num = self._read_selected_num(sel_el)
            if left and num is not None:
                pairs.append((left, num))
        if pairs:
            return pairs

        try:
            trs = container.find_elements(By.CSS_SELECTOR, "table.matching-tbl tr")
        except WebDriverException:
            trs = []
        for tr in trs:
            try:
                tds = tr.find_elements(By.XPATH, "./td")
                if len(tds) < 2:
                    continue
                left = _normalize_ws(tds[0].text or "")
                sel_el = tds[1].find_element(By.CSS_SELECTOR, "select.otp-select")
            except (WebDriverException, StaleElementReferenceException):
                continue
            cls = ""
            try:
                cls = sel_el.get_attribute("class") or ""
            except (WebDriverException, StaleElementReferenceException):
                pass
            if "otp-item-ans-correct-br" not in cls:
                continue
            num = self._read_selected_num(sel_el)
            if left and num is not None:
                pairs.append((left, num))
        return pairs

    def _find_rightanswers_rows(self, scope) -> list:
        candidates = [
            "div.rightanswers table.item tbody tr",
            "div.rightanswers table.item tr",
            "div.rightanswers table tbody tr",
            "div.rightanswers table tr",
            ".rightanswers table.item tbody tr",
            ".rightanswers table.item tr",
        ]
        for css in candidates:
            try:
                els = scope.find_elements(By.CSS_SELECTOR, css)
            except (WebDriverException, StaleElementReferenceException):
                continue
            if els:
                return els
        return []

    def _find_matching_container(self, scope):
        try:
            return scope.find_element(By.CSS_SELECTOR, "div.matching-div")
        except (WebDriverException, StaleElementReferenceException):
            return None

    def _read_selected_num(self, select_el) -> Optional[int]:
        try:
            selected = select_el.find_elements(
                By.CSS_SELECTOR, "option[selected='selected']"
            )
            if not selected:
                selected = select_el.find_elements(By.CSS_SELECTOR, "option:checked")
        except WebDriverException:
            selected = []

        if not selected:
            try:
                from selenium.webdriver.support.ui import Select
                val = Select(select_el).first_selected_option
                txt = (val.text or "").strip()
                m = re.search(r"\d+", txt)
                return int(m.group(0)) if m else None
            except Exception:
                return None

        txt = (selected[0].text or "").strip()
        m = re.search(r"\d+", txt)
        return int(m.group(0)) if m else None

    # ------------------------------------------------------------------ #
    # Open text
    # ------------------------------------------------------------------ #

    def _extract_open_text_from_block(self, block, info: Dict) -> None:
        try:
            inp = block.find_element(By.CSS_SELECTOR, "input.otp-textbox")
            info["open_text_value"] = (inp.get_attribute("value") or "").strip()
        except (WebDriverException, StaleElementReferenceException):
            info["open_text_value"] = None

        try:
            correct = block.find_element(
                By.CSS_SELECTOR,
                "div.rightanswers span.correctans.otp-item-ans-correct",
            )
            val = (correct.text or "").strip()
            if val:
                info["open_text_value"] = val
                info["is_correct"] = True
        except (WebDriverException, StaleElementReferenceException):
            pass

        try:
            inp = block.find_element(By.CSS_SELECTOR, "input.otp-textbox")
            cls = (inp.get_attribute("class") or "")
            if "otp-item-ans-correct-br" in cls and info["is_correct"] is None:
                info["is_correct"] = True
            elif "otp-item-ans-wrong-br" in cls and info["is_correct"] is None:
                info["is_correct"] = False
        except (WebDriverException, StaleElementReferenceException):
            pass

        q_text = ""
        try:
            q_el = block.find_element(By.CSS_SELECTOR, "span.qtext")
            q_text = (q_el.text or "").lower()
        except (WebDriverException, StaleElementReferenceException):
            pass
        info["detected_as_name"] = any(m in q_text for m in _NAME_MARKERS)

    # ------------------------------------------------------------------ #
    # Radio / checkbox helpers
    # ------------------------------------------------------------------ #

    def _extract_corrects_by_icon(self, block) -> List[str]:
        try:
            icons = block.find_elements(By.CSS_SELECTOR, ".otp-item-ans-correct")
        except WebDriverException:
            icons = []
        result: List[str] = []
        seen = set()
        for icon in icons:
            text = self._text_for_icon(icon)
            if text and text not in seen:
                seen.add(text)
                result.append(text)
        return result

    def _text_for_icon(self, icon) -> Optional[str]:
        for xp in ("following-sibling::span[1]", "following-sibling::*[1]"):
            try:
                els = icon.find_elements(By.XPATH, xp)
            except (WebDriverException, StaleElementReferenceException):
                continue
            for el in els:
                t = self._pick_meaningful_line(el.text or "")
                if t:
                    return t
        for xp in ("ancestor::label[1]", "ancestor::p[1]"):
            try:
                els = icon.find_elements(By.XPATH, xp)
            except (WebDriverException, StaleElementReferenceException):
                continue
            for el in els:
                t = self._pick_meaningful_line(el.text or "")
                if t:
                    return t
        return None

    def _pick_meaningful_line(self, raw: str) -> Optional[str]:
        lines = [l.strip() for l in (raw or "").split("\n") if l.strip()]
        if not lines:
            return None
        for line in reversed(lines):
            if _OPTION_LINE_RE.match(line):
                c = self._clean(line)
                if c and not _GARBAGE_RE.search(c):
                    return c
        for line in reversed(lines):
            c = self._clean(line)
            if c and not _GARBAGE_RE.search(c):
                return c
        return None

    def _find_leaf_text(self, block, xpaths) -> Optional[str]:
        best_text, best_len = None, 10_000
        for xp in xpaths:
            try:
                els = block.find_elements(By.XPATH, xp)
            except (WebDriverException, StaleElementReferenceException):
                continue
            for el in els:
                try:
                    t = el.text or ""
                except (WebDriverException, StaleElementReferenceException):
                    continue
                c = self._clean(t)
                if not c or len(c) > 250 or _GARBAGE_RE.search(c):
                    continue
                if len(c) < best_len:
                    best_len, best_text = len(c), c
        return best_text

    def _parse_correct_from_text(self, raw_text: str) -> Optional[str]:
        lines = [l.strip() for l in (raw_text or "").split("\n") if l.strip()]
        for i, line in enumerate(lines):
            low = line.lower()
            if "правильный ответ" not in low and "верный ответ" not in low:
                continue
            m = re.search(r"ответ\s*:?\s*(.+)$", line, re.IGNORECASE)
            if m:
                t = self._clean(m.group(1))
                if t and not _GARBAGE_RE.search(t):
                    return t
            for j in range(i + 1, min(i + 4, len(lines))):
                cand = self._clean(lines[j])
                if not cand or _GARBAGE_RE.search(cand):
                    continue
                return cand
        return None

    def _collect_strongs(self, block) -> List[str]:
        try:
            els = block.find_elements(
                By.XPATH, ".//span[contains(@class,'qtext')]//strong"
            )
        except (WebDriverException, StaleElementReferenceException):
            return []
        result: List[str] = []
        for el in els:
            try:
                if not el.is_displayed():
                    continue
            except (WebDriverException, StaleElementReferenceException):
                continue
            parts: List[str] = []
            try:
                prev_sibs = el.find_elements(By.XPATH, "preceding-sibling::strong")
            except (WebDriverException, StaleElementReferenceException):
                prev_sibs = []
            for p in prev_sibs:
                try:
                    pt = _normalize_ws(p.text or "")
                    if pt:
                        parts.append(pt)
                except (WebDriverException, StaleElementReferenceException):
                    continue
            try:
                own = _normalize_ws(el.text or "")
            except (WebDriverException, StaleElementReferenceException):
                own = ""
            if own:
                parts.append(own)
            combined = " ".join(parts).strip()
            if not combined or len(combined) < 3 or len(combined) > 500:
                continue
            if _GARBAGE_RE.search(combined):
                continue
            if _OPTION_LINE_RE.match(combined):
                continue
            if combined not in result:
                result.append(combined)
        return result

    def _strip_to_question(self, raw: str) -> str:
        raw = (raw or "").replace("\xa0", " ").strip()
        if not raw:
            return ""
        m = re.search(r"\n\s*[А-ЯA-Z]\s*[\)\.\:\-]\s*\S", raw)
        if m:
            raw = raw[:m.start()].strip()
        for line in [l.strip() for l in raw.split("\n") if l.strip()]:
            if _GARBAGE_RE.search(line):
                continue
            if _OPTION_LINE_RE.match(line):
                continue
            if len(line) < 3:
                continue
            if len(line) > 500:
                line = line[:500] + "…"
            return line
        return ""

    def _extract_question(self, block, raw_text: str, idx: int) -> Optional[str]:
        strongs = self._collect_strongs(block)
        if strongs:
            for t in reversed(strongs):
                if t.rstrip().endswith("?") or len(t) >= 20:
                    return t
            return strongs[-1]

        try:
            qtexts = block.find_elements(
                By.XPATH, ".//span[contains(@class,'qtext')]"
            )
        except (WebDriverException, StaleElementReferenceException):
            qtexts = []
        for qt in qtexts:
            try:
                raw = qt.text or ""
            except (WebDriverException, StaleElementReferenceException):
                continue
            cleaned = self._strip_to_question(raw)
            if cleaned:
                return cleaned

        for line in [l.strip() for l in raw_text.split("\n") if l.strip()]:
            if _GARBAGE_RE.search(line):
                continue
            if _OPTION_LINE_RE.match(line):
                continue
            if len(line) < 3:
                continue
            if len(line) > 500:
                line = line[:500] + "…"
            return line
        return f"#{idx}"

    @staticmethod
    def _clean(text: str) -> str:
        text = (text or "").replace("\xa0", " ")
        text = re.sub(r"\s+", " ", text).strip()
        text = re.sub(
            r"^(Правильный ответ|Верный ответ|Correct answer|Correct)\s*:?\s*",
            "", text, flags=re.IGNORECASE,
        )
        return text.strip(" \t\r\n:;-•✓✔✗✘+*")
