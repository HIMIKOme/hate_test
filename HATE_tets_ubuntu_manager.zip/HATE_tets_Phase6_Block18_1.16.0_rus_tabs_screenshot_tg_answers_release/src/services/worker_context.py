"""Контекст отдельного Test Worker: heartbeat, браузер и события Job."""
from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path
from typing import Any, Dict, Optional

from .event_bus import EventType
from .paths import project_root
from .job import JobState
from .worker_lifecycle import WorkerLifecycle, WorkerState


class WorkerContext:
    def __init__(self, worker_id: str, event_bus=None, logger=None, heartbeat_interval: float = 5.0):
        self.worker_id = worker_id
        self.event_bus = event_bus
        self.logger = logger
        self.heartbeat_interval = max(1.0, float(heartbeat_interval))
        self.resources: Dict[str, Any] = {}
        self.current_job_id: Optional[str] = None
        self._progress_sequence = 0
        self.started_at = time.time()
        self.last_heartbeat = time.time()
        self.browser_status = "offline"
        self.browser_profile: Optional[str] = None
        self.lifecycle = WorkerLifecycle()
        self._resource_lock = threading.RLock()
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._heartbeat_path = self._get_heartbeat_path()

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        try:
            self.lifecycle.transition(WorkerState.STARTING)
        except ValueError:
            self.lifecycle = WorkerLifecycle(WorkerState.STARTING)
        self._publish_lifecycle()
        self._write_heartbeat_file()
        self._thread = threading.Thread(
            target=self._heartbeat_loop,
            name=f"{self.worker_id}-heartbeat",
            daemon=True,
        )
        self._thread.start()
        try:
            self.lifecycle.transition(WorkerState.IDLE)
        except ValueError:
            pass
        self._publish_lifecycle()
        self.heartbeat()

    def stop(self) -> None:
        try:
            self.lifecycle.transition(WorkerState.STOPPING)
        except ValueError:
            pass
        self._publish_lifecycle()
        self._stop.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2)
        self._thread = None
        self.close_all()
        try:
            self._heartbeat_path.unlink(missing_ok=True)
        except OSError:
            pass
        self.lifecycle = WorkerLifecycle(WorkerState.OFFLINE)
        self._publish_lifecycle()

    def set_job(self, job_id: Optional[str]) -> None:
        with self._resource_lock:
            self.current_job_id = job_id
            self._progress_sequence = 0
            try:
                if job_id:
                    self.lifecycle.transition(WorkerState.BUSY)
                elif self.lifecycle.state not in {WorkerState.DRAINING, WorkerState.STOPPING, WorkerState.OFFLINE}:
                    self.lifecycle.transition(WorkerState.IDLE)
            except ValueError:
                pass
        self._publish_lifecycle()
        self.heartbeat()

    def mark_busy(self, job_id: str) -> None:
        self.set_job(job_id)

    def drain(self) -> None:
        with self._resource_lock:
            try:
                self.lifecycle.transition(WorkerState.DRAINING)
            except ValueError:
                pass
        self._publish_lifecycle()
        self.heartbeat()

    def undrain(self) -> None:
        with self._resource_lock:
            try:
                target = WorkerState.BUSY if self.current_job_id else WorkerState.IDLE
                self.lifecycle.transition(target)
            except ValueError:
                pass
        self._publish_lifecycle()
        self.heartbeat()

    @property
    def accepting_jobs(self) -> bool:
        with self._resource_lock:
            return self.lifecycle.state == WorkerState.IDLE

    def _publish_lifecycle(self) -> None:
        if self.event_bus:
            self.event_bus.publish(
                EventType.WORKER_STATE_CHANGED, source="worker", worker_id=self.worker_id,
                worker_state=self.lifecycle.state.value, job_id=self.current_job_id,
            )

    def _get_heartbeat_path(self) -> Path:
        base = project_root() / "data" / "heartbeats"
        base.mkdir(parents=True, exist_ok=True)
        return base / f"{self.worker_id}.json"

    def _write_heartbeat_file(self) -> None:
        with self._resource_lock:
            payload = {
                "worker_id": self.worker_id,
                "timestamp": self.last_heartbeat,
                "job_id": self.current_job_id,
                "pid": os.getpid(),
                "browser_status": self.browser_status,
                "browser_profile": self.browser_profile,
            }
        try:
            tmp = self._heartbeat_path.with_suffix(".tmp")
            tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
            tmp.replace(self._heartbeat_path)
        except OSError:
            pass

    def heartbeat(self) -> None:
        self.last_heartbeat = time.time()
        self._write_heartbeat_file()
        if self.event_bus:
            with self._resource_lock:
                job_id = self.current_job_id
                browser_status = self.browser_status
                browser_profile = self.browser_profile
            self.event_bus.publish(
                EventType.WORKER_HEARTBEAT,
                source="worker",
                worker_id=self.worker_id,
                job_id=job_id,
                browser_status=browser_status,
                browser_profile=browser_profile,
                timestamp=self.last_heartbeat,
            )

    def emit_job_state(
        self,
        job_id: str,
        state: JobState | str,
        *,
        stage: Optional[str] = None,
        error: str = "",
        correlation_id: Optional[str] = None,
    ) -> None:
        """Worker → Hub: запрос изменения состояния Job через Event Bus."""
        if not self.event_bus:
            return
        self.event_bus.publish(
            EventType.JOB_STATE_REQUESTED,
            source="worker",
            correlation_id=correlation_id,
            worker_id=self.worker_id,
            job_id=str(job_id),
            state=JobState(state).value,
            stage=stage,
            error=error,
        )

    def emit_job_progress(
        self,
        job_id: str,
        percent: float,
        *,
        current_question: int = 0,
        total_questions: int = 0,
        stage: Optional[str] = None,
        correlation_id: Optional[str] = None,
    ) -> None:
        """Worker → Hub: передача прогресса Job через Event Bus."""
        if not self.event_bus:
            return
        with self._resource_lock:
            self._progress_sequence += 1
            sequence = self._progress_sequence
        payload = {
            "stage": stage,
            "percent": float(percent),
            "current_question": int(current_question or 0),
            "total_questions": int(total_questions or 0),
            "revision": sequence,
        }
        self.event_bus.publish(
            EventType.JOB_PROGRESS_REQUESTED,
            source="worker",
            correlation_id=correlation_id,
            worker_id=self.worker_id,
            job_id=str(job_id),
            progress=float(percent),
            current_question=int(current_question or 0),
            total_questions=int(total_questions or 0),
            stage=stage,
            progress_revision=sequence,
            progress_context=payload,
        )

    def get_resource(self, name: str, factory):
        with self._resource_lock:
            if name not in self.resources or self.resources[name] is None:
                self.resources[name] = factory()
            return self.resources[name]

    def close_resource(self, name: str) -> None:
        with self._resource_lock:
            resource = self.resources.pop(name, None)
        if resource is None:
            return
        close = getattr(resource, "close", None)
        if callable(close):
            try:
                close()
            except Exception as exc:
                if self.logger:
                    self.logger.warning(f"{self.worker_id}: ошибка закрытия {name}: {exc}")
        if name == "chrome":
            with self._resource_lock:
                self.browser_status = "offline"
                self.browser_profile = None
            self.heartbeat()
            if self.event_bus:
                self.event_bus.publish(
                    EventType.BROWSER_STOPPED,
                    source="worker",
                    worker_id=self.worker_id,
                    job_id=self.current_job_id,
                )

    def close_all(self) -> None:
        for name in list(self.resources):
            self.close_resource(name)

    def acquire_browser(self, logger=None):
        """Создаёт/возвращает Chrome только для текущего Worker."""
        with self._resource_lock:
            existing = self.resources.get("chrome")
            if existing is not None:
                driver = getattr(existing, "driver", None)
                if driver is not None:
                    self.browser_status = "online"
                    return driver

        from automation.browser import BrowserSession

        browser_logger = logger or self.logger
        session = self.get_resource(
            "chrome",
            lambda: BrowserSession(browser_logger, self.worker_id, event_bus=self.event_bus),
        )
        try:
            driver = session.get()
        except Exception as exc:
            with self._resource_lock:
                self.browser_status = "crashed"
                self.browser_profile = getattr(session, "profile_name", None)
                try:
                    self.lifecycle.transition(WorkerState.CRASHED)
                except ValueError:
                    pass
                self._publish_lifecycle()
            self.heartbeat()
            if self.event_bus:
                self.event_bus.publish(
                    EventType.BROWSER_CRASHED,
                    source="worker",
                    worker_id=self.worker_id,
                    job_id=self.current_job_id,
                    profile=self.browser_profile,
                    error=str(exc),
                )
            with self._resource_lock:
                self.resources.pop("chrome", None)
            raise

        with self._resource_lock:
            self.browser_status = "online"
            self.browser_profile = getattr(session, "profile_name", None)
            try:
                self.lifecycle.transition(WorkerState.BUSY if self.current_job_id else WorkerState.IDLE)
            except ValueError:
                pass
        self._publish_lifecycle()
        self.heartbeat()
        if self.event_bus:
            self.event_bus.publish(
                EventType.BROWSER_STARTED,
                source="worker",
                worker_id=self.worker_id,
                job_id=self.current_job_id,
                profile=self.browser_profile,
            )
        return driver

    def restart_browser(self, logger=None) -> bool:
        """Попытаться перезапустить Chrome для текущей Job.

        Метод намеренно работает только с ресурсом этого Worker. После закрытия
        старой сессии создаётся новая BrowserSession, если это удаётся.
        """
        with self._resource_lock:
            had_browser = self.resources.get("chrome") is not None
            job_id = self.current_job_id
        if not had_browser:
            return False
        try:
            self.lifecycle.transition(WorkerState.RECOVERING)
        except ValueError:
            pass
        self._publish_lifecycle()
        self.close_resource("chrome")
        try:
            self.acquire_browser(logger=logger or self.logger)
            try:
                self.lifecycle.transition(WorkerState.BUSY if self.current_job_id else WorkerState.IDLE)
            except ValueError:
                pass
            self._publish_lifecycle()
            return True
        except Exception:
            return False

    def release_browser(self) -> None:
        self.close_resource("chrome")

    def release_job_resources(self) -> None:
        self.close_all()
        with self._resource_lock:
            self.browser_status = "offline"
            self.browser_profile = None
        self.heartbeat()

    def snapshot(self) -> dict:
        with self._resource_lock:
            return {
                "worker_id": self.worker_id,
                "job_id": self.current_job_id,
                "browser_status": self.browser_status,
                "browser_profile": self.browser_profile,
                "started_at": self.started_at,
                "last_heartbeat": self.last_heartbeat,
                "alive": not self._stop.is_set(),
                "worker_state": self.lifecycle.state.value,
                "accepting_jobs": self.accepting_jobs,
                "draining": self.lifecycle.state == WorkerState.DRAINING,
            }

    def _heartbeat_loop(self) -> None:
        while not self._stop.wait(self.heartbeat_interval):
            self.heartbeat()
