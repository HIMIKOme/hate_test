"""Доменная модель Job и формальная машина состояний Job."""
from __future__ import annotations

import threading
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Iterable, Optional


class JobState(str, Enum):
    QUEUED = "QUEUED"
    STARTING = "STARTING"
    BROWSER_STARTING = "BROWSER_STARTING"
    OPENING = "OPENING"
    TESTING = "TESTING"
    COLLECTING = "COLLECTING"
    SAVING = "SAVING"
    NOTIFYING = "NOTIFYING"
    RETRY_WAIT = "RETRY_WAIT"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLING = "CANCELLING"
    CANCELLED = "CANCELLED"


class JobPriority(int, Enum):
    LOW = 10
    NORMAL = 20
    HIGH = 30
    VERY_HIGH = 40


class QueueType(str, Enum):
    TEST_QUEUE = "TEST_QUEUE"
    CACHE_QUEUE = "CACHE_QUEUE"
    NOTIFICATION_QUEUE = "NOTIFICATION_QUEUE"
    DIAGNOSTIC_QUEUE = "DIAGNOSTIC_QUEUE"


TERMINAL_STATES = frozenset({
    JobState.COMPLETED,
    JobState.FAILED,
    JobState.CANCELLED,
})


# Нормальный путь Job:
# QUEUED -> STARTING -> BROWSER_STARTING -> OPENING -> TESTING
# -> COLLECTING -> SAVING -> NOTIFYING -> COMPLETED
#
# В отдельных режимах некоторые этапы могут быть пропущены (например, при
# уже открытом тесте или когда режим не сохраняет отдельный результат), но
# переход всё равно должен находиться в этой таблице. Любое направление,
# которого здесь нет, считается ошибочным.
ALLOWED_TRANSITIONS = {
    JobState.QUEUED: frozenset({JobState.STARTING, JobState.CANCELLING, JobState.CANCELLED}),
    JobState.STARTING: frozenset({
        JobState.BROWSER_STARTING,
        JobState.OPENING,
        JobState.TESTING,
        JobState.COMPLETED,
        JobState.CANCELLING,
        JobState.FAILED,
        JobState.RETRY_WAIT,
    }),
    JobState.BROWSER_STARTING: frozenset({
        JobState.OPENING,
        JobState.TESTING,
        JobState.COMPLETED,
        JobState.CANCELLING,
        JobState.FAILED,
        JobState.RETRY_WAIT,
    }),
    JobState.OPENING: frozenset({
        JobState.TESTING,
        JobState.COLLECTING,
        JobState.COMPLETED,
        JobState.CANCELLING,
        JobState.FAILED,
        JobState.RETRY_WAIT,
    }),
    JobState.TESTING: frozenset({
        JobState.COLLECTING,
        JobState.SAVING,
        JobState.COMPLETED,
        JobState.CANCELLING,
        JobState.FAILED,
        JobState.RETRY_WAIT,
    }),
    JobState.COLLECTING: frozenset({
        JobState.SAVING,
        JobState.NOTIFYING,
        JobState.COMPLETED,
        JobState.CANCELLING,
        JobState.FAILED,
        JobState.RETRY_WAIT,
    }),
    JobState.SAVING: frozenset({
        JobState.NOTIFYING,
        JobState.COMPLETED,
        JobState.CANCELLING,
        JobState.FAILED,
        JobState.RETRY_WAIT,
    }),
    JobState.NOTIFYING: frozenset({
        JobState.COMPLETED,
        JobState.CANCELLING,
        JobState.FAILED,
        JobState.RETRY_WAIT,
    }),
    JobState.RETRY_WAIT: frozenset({JobState.QUEUED, JobState.CANCELLING, JobState.FAILED}),
    JobState.CANCELLING: frozenset({JobState.CANCELLED, JobState.FAILED}),
    JobState.COMPLETED: frozenset(),
    JobState.FAILED: frozenset(),
    JobState.CANCELLED: frozenset(),
}


class JobStateMachine:
    """Формальная, централизованная проверка переходов Job."""

    def __init__(self, state: JobState = JobState.QUEUED):
        self.state = JobState(state)

    @staticmethod
    def normalize_state(state: JobState | str) -> JobState:
        try:
            return JobState(state)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"Неизвестное состояние Job: {state!r}") from exc

    @classmethod
    def can_transition(cls, source: JobState | str, target: JobState | str) -> bool:
        source_state = cls.normalize_state(source)
        target_state = cls.normalize_state(target)
        if source_state == target_state:
            return True
        return target_state in ALLOWED_TRANSITIONS[source_state]

    @classmethod
    def validate_transition(cls, source: JobState | str, target: JobState | str) -> None:
        source_state = cls.normalize_state(source)
        target_state = cls.normalize_state(target)
        if source_state == target_state:
            return
        if not cls.can_transition(source_state, target_state):
            allowed = ", ".join(state.value for state in sorted(
                ALLOWED_TRANSITIONS[source_state], key=lambda item: item.value
            )) or "нет"
            raise ValueError(
                f"Недопустимый переход Job: {source_state.value} -> {target_state.value}. "
                f"Разрешено из {source_state.value}: {allowed}."
            )

    def transition(self, target: JobState | str) -> JobState:
        target_state = self.normalize_state(target)
        self.validate_transition(self.state, target_state)
        self.state = target_state
        return self.state

    @classmethod
    def allowed_from(cls, source: JobState | str) -> tuple[JobState, ...]:
        state = cls.normalize_state(source)
        return tuple(sorted(ALLOWED_TRANSITIONS[state], key=lambda item: item.value))


@dataclass
class JobProgress:
    """Канонический контекст прогресса Job, отделённый от state.

    ``revision`` нужен для защиты Hub/StateManager от устаревших progress-событий:
    более старый пакет не должен откатывать уже отображённый прогресс.
    """

    stage: str = "queued"
    percent: float = 0.0
    current_question: int = 0
    total_questions: int = 0
    revision: int = 0
    updated_at: float = field(default_factory=time.time)

    def update(
        self,
        *,
        percent: Optional[float] = None,
        stage: Optional[str] = None,
        current_question: Optional[int] = None,
        total_questions: Optional[int] = None,
        revision: Optional[int] = None,
    ) -> bool:
        if revision is not None:
            incoming_revision = int(revision)
            if incoming_revision < self.revision:
                return False
        else:
            incoming_revision = self.revision + 1

        new_percent = self.percent if percent is None else max(0.0, min(100.0, float(percent)))
        new_stage = self.stage if stage is None else str(stage)
        new_current = self.current_question if current_question is None else max(0, int(current_question))
        new_total = self.total_questions if total_questions is None else max(0, int(total_questions))

        changed = (
            new_percent != self.percent
            or new_stage != self.stage
            or new_current != self.current_question
            or new_total != self.total_questions
        )
        if revision is not None and incoming_revision > self.revision:
            changed = True

        if not changed:
            return False

        self.percent = new_percent
        self.stage = new_stage
        self.current_question = new_current
        self.total_questions = new_total
        self.revision = max(self.revision + 1, incoming_revision)
        self.updated_at = time.time()
        return True

    def to_dict(self) -> dict[str, Any]:
        return {
            "stage": self.stage,
            "percent": round(self.percent, 1),
            "current_question": self.current_question,
            "total_questions": self.total_questions,
            "revision": self.revision,
            "updated_at": self.updated_at,
        }


@dataclass
class Job:
    """Полноценное задание приложения.

    Job ID создаётся при конструировании, то есть до попадания Job в очередь.
    Состояние хранится отдельно от контекста прогресса.
    """

    url: str
    mode: str = "collect"
    user_name: str = ""
    telegram_chat_id: Optional[str] = None
    priority: JobPriority = JobPriority.NORMAL
    queue_type: QueueType = QueueType.TEST_QUEUE
    id: str = field(default_factory=lambda: f"job-{uuid.uuid4().hex[:12]}")
    created_at: float = field(default_factory=time.time)
    queued_at: Optional[float] = None
    started_at: Optional[float] = None
    finished_at: Optional[float] = None
    state: JobState = JobState.QUEUED
    progress_context: JobProgress = field(default_factory=JobProgress)
    attempts: int = 0
    worker_id: Optional[str] = None
    error: str = ""
    error_reason: str = ""
    result: Dict[str, Any] = field(default_factory=dict)
    artifact_paths: list[str] = field(default_factory=list)
    diagnostics: Dict[str, Any] = field(default_factory=dict)
    retry_of: Optional[str] = None
    retry_at: Optional[float] = None
    retry_history: list[Dict[str, Any]] = field(default_factory=list)
    attempt_id: Optional[str] = None
    attempt_started_at: Optional[float] = None
    idempotency_key: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    cancel_event: threading.Event = field(default_factory=threading.Event, repr=False)
    state_machine: JobStateMachine = field(default_factory=JobStateMachine, repr=False, compare=False)

    def __post_init__(self) -> None:
        self.state = JobState(self.state)
        self.queue_type = QueueType(self.queue_type)
        self.priority = JobPriority(self.priority)
        self.state_machine.state = self.state
        if self.queued_at is None:
            self.queued_at = self.created_at

    # Совместимый API старых блоков. Фактическое хранение находится в
    # progress_context, а не рядом с state.
    @property
    def stage(self) -> str:
        return self.progress_context.stage

    @stage.setter
    def stage(self, value: str) -> None:
        self.progress_context.update(stage=str(value))

    @property
    def progress(self) -> float:
        return self.progress_context.percent

    @progress.setter
    def progress(self, value: float) -> None:
        self.progress_context.update(percent=float(value))

    @property
    def current_question(self) -> int:
        return self.progress_context.current_question

    @current_question.setter
    def current_question(self, value: int) -> None:
        self.progress_context.update(current_question=int(value))

    @property
    def total_questions(self) -> int:
        return self.progress_context.total_questions

    @total_questions.setter
    def total_questions(self, value: int) -> None:
        self.progress_context.update(total_questions=int(value))

    @property
    def waiting_seconds(self) -> float:
        return self.waiting_seconds_at()

    def waiting_seconds_at(self, now: Optional[float] = None) -> float:
        now_value = time.time() if now is None else float(now)
        queued_at = self.queued_at if self.queued_at is not None else self.created_at
        return max(0.0, now_value - queued_at)

    def effective_priority(
        self,
        now: Optional[float] = None,
        *,
        aging_interval: float = 300.0,
        aging_boost: float = 1.0,
    ) -> float:
        if aging_interval <= 0:
            raise ValueError("aging_interval должен быть > 0")
        if self.state != JobState.QUEUED:
            return float(self.priority.value)
        waiting = self.waiting_seconds_at(now)
        return float(self.priority.value) + (waiting / aging_interval) * aging_boost

    @property
    def max_runtime_sec(self) -> float | None:
        """Индивидуальный лимит выполнения из metadata Job."""
        raw = self.metadata.get("max_runtime_sec") if isinstance(self.metadata, dict) else None
        if raw in (None, ""):
            return None
        try:
            value = float(raw)
        except (TypeError, ValueError):
            return None
        return value if value > 0 else None

    @property
    def max_attempts(self) -> int:
        from .retry_policy import RetryPolicy
        return RetryPolicy.max_attempts(self)

    @property
    def retry_policy(self) -> str:
        from .retry_policy import RetryPolicy
        return RetryPolicy.mode(self)

    @property
    def retry_backoff_sec(self) -> float:
        from .retry_policy import RetryPolicy
        return RetryPolicy.backoff(self, max(2, self.attempts + 1))

    @property
    def timeout_policy(self) -> str:
        raw = str(self.metadata.get("stuck_policy") or "recover_then_terminate").strip().lower()
        return raw if raw in {"recover_then_terminate", "allow"} else "recover_then_terminate"

    @property
    def allow_overrun(self) -> bool:
        value = self.metadata.get("allow_overrun") or self.metadata.get("allow_timeout")
        return bool(value) or self.timeout_policy == "allow"

    def runtime_seconds_at(self, now: Optional[float] = None) -> float | None:
        anchor = self.attempt_started_at or self.started_at
        if anchor is None:
            return None
        now_value = time.time() if now is None else float(now)
        return max(0.0, now_value - anchor)

    @property
    def stuck(self) -> bool:
        return bool((self.diagnostics or {}).get("timeout", {}).get("stuck"))

    @property
    def intervention_required(self) -> bool:
        timeout = (self.diagnostics or {}).get("timeout", {})
        return bool(timeout.get("intervention_required"))

    @property
    def recovery_attempts(self) -> int:
        return int((self.diagnostics or {}).get("timeout", {}).get("recovery_attempts", 0) or 0)

    @property
    def recovery_status(self) -> str:
        return str((self.diagnostics or {}).get("timeout", {}).get("recovery_status") or "none")

    @property
    def stuck_since(self) -> Optional[float]:
        value = (self.diagnostics or {}).get("timeout", {}).get("stuck_since")
        try:
            return float(value) if value is not None else None
        except (TypeError, ValueError):
            return None

    @property
    def allowed_next_states(self) -> tuple[JobState, ...]:
        return self.state_machine.allowed_from(self.state)

    def can_transition_to(self, state: JobState | str) -> bool:
        return self.state_machine.can_transition(self.state, state)

    def transition(self, state: JobState | str, *, stage: Optional[str] = None, error: str = "") -> None:
        target = self.state_machine.normalize_state(state)
        self.state_machine.validate_transition(self.state, target)
        if target != self.state:
            self.state_machine.transition(target)
            self.state = target

        if stage is not None:
            self.stage = stage
        if error:
            self.error = str(error)
            self.error_reason = str(error)

        now = time.time()
        if target == JobState.QUEUED and self.queued_at is None:
            self.queued_at = now
        if target == JobState.STARTING:
            if self.started_at is None:
                self.started_at = now
            self.attempt_started_at = now
            self.attempt_id = f"attempt-{uuid.uuid4().hex[:12]}"
        if target == JobState.QUEUED and self.started_at is not None and self.attempt_started_at is None:
            self.attempt_started_at = now
        if target == JobState.RETRY_WAIT:
            self.attempt_started_at = None
        if target in TERMINAL_STATES:
            self.finished_at = now
            if target == JobState.COMPLETED:
                self.progress = 100.0
                self.stage = stage or "completed"
            elif target == JobState.CANCELLED:
                self.stage = stage or "cancelled"
            elif target == JobState.FAILED:
                self.stage = stage or "failed"

    def request_cancel(self) -> bool:
        """Переводит выполняющуюся Job в CANCELLING и ставит cancel flag."""
        if self.state in TERMINAL_STATES:
            return False
        self.cancel_event.set()
        if self.state == JobState.QUEUED:
            self.transition(JobState.CANCELLED, stage="cancelled")
        elif self.state != JobState.CANCELLING:
            self.transition(JobState.CANCELLING, stage="cancelling")
        return True

    def update_progress(
        self,
        percent: float,
        *,
        stage: Optional[str] = None,
        current_question: Optional[int] = None,
        total_questions: Optional[int] = None,
        revision: Optional[int] = None,
    ) -> bool:
        updated = self.progress_context.update(
            percent=percent,
            stage=stage,
            current_question=current_question,
            total_questions=total_questions,
            revision=revision,
        )
        if not updated:
            return False
        if self.total_questions and self.current_question:
            expected = (self.current_question / self.total_questions) * 100.0
            # Не даём явно переданному значению полностью разойтись с контекстом.
            expected = min(100.0, expected)
            if expected > self.progress_context.percent:
                self.progress_context.update(percent=expected)
        return True

    def add_artifact(self, path: Any) -> None:
        if path is None:
            return
        value = str(path)
        if value and value not in self.artifact_paths:
            self.artifact_paths.append(value)

    def set_result(self, **values: Any) -> None:
        self.result.update(values)

    def to_dict(self) -> dict:
        progress = self.progress_context.to_dict()
        return {
            "id": self.id,
            "job_id": self.id,
            "url": self.url,
            "user_name": self.user_name,
            "telegram_chat_id": self.telegram_chat_id,
            "mode": self.mode,
            "priority": self.priority.name,
            "priority_value": self.priority.value,
            "queue_type": self.queue_type.value,
            "queue": self.queue_type.value,
            "effective_priority": round(self.effective_priority(), 2),
            "created_at": self.created_at,
            "queued_at": self.queued_at,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "state": self.state.value,
            "stage": progress["stage"],
            "progress": progress["percent"],
            "current_question": progress["current_question"],
            "total_questions": progress["total_questions"],
            "progress_context": progress,
            "progress_revision": progress["revision"],
            "progress_updated_at": progress["updated_at"],
            "allowed_next_states": [s.value for s in self.allowed_next_states],
            "attempts": self.attempts,
            "worker_id": self.worker_id,
            "error": self.error,
            "error_reason": self.error_reason,
            "result": dict(self.result),
            "artifact_paths": list(self.artifact_paths),
            "diagnostics": dict(self.diagnostics),
            "retry_of": self.retry_of,
            "retry_at": self.retry_at,
            "retry_history": [dict(item) for item in self.retry_history],
            "attempt_id": self.attempt_id,
            "attempt_started_at": self.attempt_started_at,
            "idempotency_key": self.idempotency_key,
            "max_attempts": self.max_attempts,
            "retry_policy": self.retry_policy,
            "retry_backoff_sec": self.retry_backoff_sec,
            "metadata": dict(self.metadata),
            "max_runtime_sec": self.max_runtime_sec,
            "runtime_seconds": round(self.runtime_seconds_at() or 0.0, 1),
            "timeout_policy": self.timeout_policy,
            "allow_overrun": self.allow_overrun,
            "stuck": self.stuck,
            "intervention_required": self.intervention_required,
            "stuck_since": self.stuck_since,
            "recovery_attempts": self.recovery_attempts,
            "recovery_status": self.recovery_status,
            "waiting_seconds": round(self.waiting_seconds, 1),
            "queue_position": None,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Job":
        """Восстановить Job из persisted snapshot без генерации нового ID."""
        if not isinstance(data, dict):
            raise ValueError("Некорректный snapshot Job")
        raw_id = str(data.get("id") or data.get("job_id") or "").strip()
        if not raw_id:
            raise ValueError("В snapshot Job отсутствует id")

        progress_raw = data.get("progress_context")
        progress_raw = dict(progress_raw) if isinstance(progress_raw, dict) else {}
        progress = JobProgress(
            stage=str(progress_raw.get("stage") or data.get("stage") or "queued"),
            percent=float(progress_raw.get("percent", data.get("progress", 0)) or 0),
            current_question=int(progress_raw.get("current_question", data.get("current_question", 0)) or 0),
            total_questions=int(progress_raw.get("total_questions", data.get("total_questions", 0)) or 0),
            revision=int(progress_raw.get("revision", data.get("progress_revision", 0)) or 0),
            updated_at=float(progress_raw.get("updated_at", data.get("progress_updated_at", time.time())) or time.time()),
        )
        try:
            priority = JobPriority[str(data.get("priority") or "NORMAL").upper()]
        except KeyError:
            priority = JobPriority.NORMAL
        queue_value = data.get("queue_type") or data.get("queue") or QueueType.TEST_QUEUE.value
        try:
            queue_type = QueueType(queue_value)
        except ValueError:
            queue_type = QueueType.TEST_QUEUE
        try:
            state = JobState(data.get("state") or JobState.QUEUED.value)
        except ValueError:
            state = JobState.QUEUED

        job = cls(
            url=str(data.get("url") or ""),
            mode=str(data.get("mode") or "collect"),
            user_name=str(data.get("user_name") or ""),
            telegram_chat_id=(str(data.get("telegram_chat_id")) if data.get("telegram_chat_id") not in (None, "") else None),
            priority=priority,
            queue_type=queue_type,
            id=raw_id,
            created_at=float(data.get("created_at", time.time()) or time.time()),
            queued_at=float(data.get("queued_at", data.get("created_at", time.time())) or time.time()),
            started_at=float(data["started_at"]) if data.get("started_at") is not None else None,
            finished_at=float(data["finished_at"]) if data.get("finished_at") is not None else None,
            state=state,
            progress_context=progress,
            attempts=int(data.get("attempts", 0) or 0),
            worker_id=(str(data.get("worker_id")) if data.get("worker_id") not in (None, "") else None),
            error=str(data.get("error") or ""),
            error_reason=str(data.get("error_reason") or ""),
            result=dict(data.get("result") or {}) if isinstance(data.get("result"), dict) else {},
            artifact_paths=[str(x) for x in (data.get("artifact_paths") or []) if x is not None],
            diagnostics=dict(data.get("diagnostics") or {}) if isinstance(data.get("diagnostics"), dict) else {},
            retry_of=(str(data.get("retry_of")) if data.get("retry_of") not in (None, "") else None),
            retry_at=float(data["retry_at"]) if data.get("retry_at") is not None else None,
            retry_history=[dict(x) for x in (data.get("retry_history") or []) if isinstance(x, dict)],
            attempt_id=(str(data.get("attempt_id")) if data.get("attempt_id") not in (None, "") else None),
            attempt_started_at=float(data["attempt_started_at"]) if data.get("attempt_started_at") is not None else None,
            idempotency_key=(str(data.get("idempotency_key")) if data.get("idempotency_key") not in (None, "") else None),
            metadata=dict(data.get("metadata") or {}) if isinstance(data.get("metadata"), dict) else {},
        )
        job.cancel_event.clear()
        return job

    @classmethod
    def state_matrix(cls) -> dict[str, tuple[str, ...]]:
        return {
            source.value: tuple(target.value for target in cls._sorted_states(targets))
            for source, targets in ALLOWED_TRANSITIONS.items()
        }

    @staticmethod
    def _sorted_states(states: Iterable[JobState]) -> list[JobState]:
        return sorted(states, key=lambda item: item.value)
