"""Формальная машина состояний Worker."""
from __future__ import annotations
from enum import Enum


class WorkerState(str, Enum):
    STARTING = "STARTING"
    IDLE = "IDLE"
    BUSY = "BUSY"
    RECOVERING = "RECOVERING"
    CRASHED = "CRASHED"
    DRAINING = "DRAINING"
    STOPPING = "STOPPING"
    OFFLINE = "OFFLINE"


ALLOWED = {
    WorkerState.OFFLINE: {WorkerState.STARTING},
    WorkerState.STARTING: {WorkerState.IDLE, WorkerState.CRASHED, WorkerState.STOPPING},
    WorkerState.IDLE: {WorkerState.BUSY, WorkerState.DRAINING, WorkerState.STOPPING, WorkerState.CRASHED},
    WorkerState.BUSY: {WorkerState.IDLE, WorkerState.RECOVERING, WorkerState.CRASHED, WorkerState.DRAINING, WorkerState.STOPPING},
    WorkerState.RECOVERING: {WorkerState.BUSY, WorkerState.IDLE, WorkerState.CRASHED, WorkerState.STOPPING},
    WorkerState.CRASHED: {WorkerState.RECOVERING, WorkerState.STARTING, WorkerState.IDLE, WorkerState.STOPPING, WorkerState.OFFLINE},
    WorkerState.DRAINING: {WorkerState.STOPPING, WorkerState.IDLE, WorkerState.OFFLINE},
    WorkerState.STOPPING: {WorkerState.OFFLINE},
}


class WorkerLifecycle:
    def __init__(self, state: WorkerState = WorkerState.OFFLINE):
        self.state = WorkerState(state)

    def can(self, target: WorkerState | str) -> bool:
        target = WorkerState(target)
        return target == self.state or target in ALLOWED[self.state]

    def transition(self, target: WorkerState | str) -> WorkerState:
        target = WorkerState(target)
        if not self.can(target):
            raise ValueError(f"Недопустимый переход Worker: {self.state.value} -> {target.value}")
        self.state = target
        return target
