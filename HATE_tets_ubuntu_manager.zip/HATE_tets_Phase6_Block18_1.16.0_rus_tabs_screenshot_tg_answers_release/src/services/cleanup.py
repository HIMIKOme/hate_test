"""Автоочистка старых файлов в data/answers, data/answers_program,
data/reports, data/logs.

Запускается при старте трея. Удаляет файлы старше N дней (по умолчанию 15).
Настройка `дней хранения` в config.txt.

Защита:
  • файлы, изменённые меньше часа назад, не трогаются;
  • файлы `latest.*` (актуальное состояние) не удаляются никогда.
"""
from __future__ import annotations

import time
from pathlib import Path

from .config import get_data_dir, load_settings

# Не трогаем файлы, изменённые меньше часа назад.
MIN_AGE_SECONDS = 3600


def cleanup_old_files(logger=None) -> None:
    try:
        settings = load_settings()
        days = int(settings.get("cleanup_days", 15))
    except Exception:
        days = 15
    if days < 1:
        days = 1

    threshold = time.time() - days * 86400
    now = time.time()

    data_dir = get_data_dir()
    targets = [
        data_dir / "answers",
        data_dir / "answers_program",
        data_dir / "reports",
        data_dir / "logs",
    ]

    removed = 0
    for target in targets:
        if not target.exists():
            continue
        for path in target.iterdir():
            if not path.is_file():
                continue

            # Не удаляем актуальные файлы latest.* — их читает проект.
            if path.name.startswith("latest."):
                continue

            try:
                mtime = path.stat().st_mtime
            except OSError:
                continue
            if mtime > threshold:
                continue
            if now - mtime < MIN_AGE_SECONDS:
                continue
            try:
                path.unlink()
                removed += 1
            except OSError as exc:
                if logger:
                    logger.debug(f"Не удалось удалить {path.name}: {exc}")

    if removed and logger:
        logger.info(
            f"Автоочистка: удалено {removed} файлов старше {days} дней."
        )
    elif logger:
        logger.info(f"Автоочистка: файлов старше {days} дней не найдено.")
