"""Контроль ресурсов перед запуском Job.

Намеренно не ограничивает и не мониторит свободное место на диске.
"""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass

try:
    import psutil
except Exception:  # pragma: no cover
    psutil = None


@dataclass(frozen=True)
class ResourceDecision:
    allowed: bool
    cpu_percent: float | None
    memory_percent: float | None
    reason: str = ""

    def to_dict(self) -> dict:
        return {
            "allowed": self.allowed,
            "cpu_percent": self.cpu_percent,
            "memory_percent": self.memory_percent,
            "reason": self.reason,
        }


class ResourceManager:
    def __init__(self, logger=None, *, cpu_limit_percent: float = 90.0, memory_limit_percent: float = 90.0):
        self.logger = logger
        self.cpu_limit_percent = max(1.0, min(100.0, float(cpu_limit_percent)))
        self.memory_limit_percent = max(1.0, min(100.0, float(memory_limit_percent)))
        self._lock = threading.RLock()
        self._last = ResourceDecision(True, None, None, "psutil_unavailable")
        self._last_updated = 0.0

    def check(self, *, force: bool = False) -> ResourceDecision:
        with self._lock:
            now = time.time()
            if not force and now - self._last_updated < 0.75:
                return self._last
            if psutil is None:
                self._last = ResourceDecision(True, None, None, "psutil_unavailable")
            else:
                cpu = float(psutil.cpu_percent(interval=0.0))
                memory = float(psutil.virtual_memory().percent)
                reasons = []
                if cpu >= self.cpu_limit_percent:
                    reasons.append(f"cpu {cpu:.1f}% >= {self.cpu_limit_percent:.1f}%")
                if memory >= self.memory_limit_percent:
                    reasons.append(f"memory {memory:.1f}% >= {self.memory_limit_percent:.1f}%")
                self._last = ResourceDecision(not reasons, cpu, memory, "; ".join(reasons))
            self._last_updated = now
            return self._last

    def snapshot(self) -> dict:
        decision = self.check()
        return {
            **decision.to_dict(),
            "cpu_limit_percent": self.cpu_limit_percent,
            "memory_limit_percent": self.memory_limit_percent,
            "disk_limit_enabled": False,
            "timestamp": self._last_updated,
        }
