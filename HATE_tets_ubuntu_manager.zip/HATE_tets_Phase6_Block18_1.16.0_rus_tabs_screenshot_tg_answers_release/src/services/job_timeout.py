"""Политика и вычисление лимитов времени выполнения Job.

Watchdog использует этот модуль как чистую функцию над публичным IPC snapshot.
Модуль не импортирует Hub/JobManager/Worker, поэтому внешняя проверка остаётся
архитектурно независимой от основного процесса.
"""
from __future__ import annotations

from typing import Any

DEFAULT_JOB_TIMEOUT_SEC = 3600.0
DEFAULT_STUCK_POLICY = "recover_then_terminate"
ALLOWED_STUCK_POLICIES = frozenset({"recover_then_terminate", "allow"})


def _as_positive(value: Any, default: float | None = None) -> float | None:
    if value is None or value == "":
        return default
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    if number <= 0:
        return default
    return number


def job_timeout_seconds(job: dict[str, Any], default_timeout: float) -> float:
    """Вернуть эффективный timeout Job.

    Приоритет: ``job.max_runtime_sec`` → ``metadata.max_runtime_sec`` →
    системный timeout Watchdog.
    """
    direct = _as_positive(job.get("max_runtime_sec"))
    if direct is not None:
        return direct
    metadata = job.get("metadata") if isinstance(job.get("metadata"), dict) else {}
    override = _as_positive(metadata.get("max_runtime_sec"))
    if override is not None:
        return override
    return max(0.001, float(default_timeout))


def stuck_policy(job: dict[str, Any]) -> str:
    metadata = job.get("metadata") if isinstance(job.get("metadata"), dict) else {}
    raw = str(
        job.get("stuck_policy")
        or metadata.get("stuck_policy")
        or DEFAULT_STUCK_POLICY
    ).strip().lower()
    return raw if raw in ALLOWED_STUCK_POLICIES else DEFAULT_STUCK_POLICY


def allow_overrun(job: dict[str, Any]) -> bool:
    metadata = job.get("metadata") if isinstance(job.get("metadata"), dict) else {}
    return bool(
        job.get("allow_overrun")
        or job.get("allow_timeout")
        or metadata.get("allow_overrun")
        or metadata.get("allow_timeout")
        or stuck_policy(job) == "allow"
    )


def runtime_seconds(job: dict[str, Any], now: float) -> float | None:
    started = job.get("started_at")
    if started is None:
        return None
    try:
        stamp = float(started)
    except (TypeError, ValueError):
        return None
    if stamp <= 0:
        return None
    return max(0.0, float(now) - stamp)


def evaluate_job_timeout(
    job: dict[str, Any],
    *,
    now: float,
    default_timeout: float,
) -> dict[str, Any] | None:
    """Вернуть запись о превышении лимита только для реально активной Job."""
    state = str(job.get("state") or "")
    if state in {"QUEUED", "COMPLETED", "FAILED", "CANCELLED"}:
        return None
    runtime = runtime_seconds(job, now)
    if runtime is None:
        return None
    timeout = job_timeout_seconds(job, default_timeout)
    if runtime <= timeout:
        return None
    allowed = allow_overrun(job)
    return {
        "job_id": str(job.get("id") or job.get("job_id") or ""),
        "runtime_sec": round(runtime, 1),
        "timeout_sec": round(timeout, 1),
        "overrun_sec": round(max(0.0, runtime - timeout), 1),
        "worker_id": job.get("worker_id"),
        "stage": job.get("stage"),
        "policy": stuck_policy(job),
        "allow_overrun": allowed,
        "recovery_attempts": int(job.get("recovery_attempts", 0) or 0),
        "recovery_status": job.get("recovery_status") or "none",
        "stuck_since": job.get("stuck_since"),
        "intervention_required": not allowed,
    }
