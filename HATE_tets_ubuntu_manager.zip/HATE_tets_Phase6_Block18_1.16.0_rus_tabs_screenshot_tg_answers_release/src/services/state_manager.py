"""Единый in-memory источник состояния приложения.

StateManager подписан на EventBus и превращает поток событий в актуальный
снимок, который могут читать Web/GUI/диагностика. Он не владеет JobManager.
"""
from __future__ import annotations
import threading
import time
from typing import Any, Dict
from .version import APP_VERSION


class StateManager:
    def __init__(self, event_bus, version: str = APP_VERSION):
        self.version = version
        self._lock = threading.RLock()
        self._jobs: Dict[str, dict] = {}
        self._job_progress: Dict[str, dict] = {}
        self._workers: Dict[str, dict] = {}
        self._components: Dict[str, dict] = {}
        self._events: list[dict] = []
        self._max_events = 200
        self.application_status = "Online"
        event_bus.subscribe_all(self._on_event)

    def _on_event(self, event: dict) -> None:
        event = dict(event)
        event.setdefault("timestamp", time.time())
        with self._lock:
            if event.get("type") != "StateSnapshot":
                self._events.append(event)
            if len(self._events) > self._max_events:
                del self._events[:-self._max_events]

            job = event.get("job")
            if isinstance(job, dict) and job.get("id"):
                job_id = str(job["id"])
                self._jobs[job_id] = dict(job)
                progress = job.get("progress_context")
                if isinstance(progress, dict):
                    self._update_job_progress_locked(
                        job_id,
                        progress,
                        state=job.get("state"),
                        worker_id=job.get("worker_id"),
                        event_id=event.get("event_id"),
                    )

            worker_id = event.get("worker_id")
            if worker_id:
                wid = str(worker_id)
                worker = self._workers.setdefault(wid, {"worker_id": wid})
                if event["type"] == "WorkerStopped":
                    worker["alive"] = False
                elif event["type"] in {"WorkerStarted", "WorkerHeartbeat"}:
                    worker["alive"] = True
                if event.get("worker_state") is not None:
                    worker["worker_state"] = str(event.get("worker_state"))
                    worker["draining"] = str(event.get("worker_state")) == "DRAINING"
                if event.get("browser_status") is not None:
                    worker["browser_status"] = event.get("browser_status")
                if event.get("browser_profile") is not None or event["type"] in {"BrowserStopped", "BrowserCrashed"}:
                    worker["browser_profile"] = event.get("browser_profile") or event.get("profile")
                if event["type"] == "BrowserStarted":
                    worker["browser_status"] = "online"
                elif event["type"] == "BrowserStopped":
                    worker["browser_status"] = "offline"
                elif event["type"] == "BrowserCrashed":
                    worker["browser_status"] = "crashed"
                if event.get("job_id") is not None:
                    worker["job_id"] = event.get("job_id")
                if event.get("timestamp") is not None:
                    worker["last_heartbeat"] = event.get("timestamp")

            component = event.get("component")
            if component:
                self._components[str(component)] = {
                    "component": str(component),
                    "status": event.get("status", "unknown"),
                    "timestamp": event["timestamp"],
                    "message": event.get("message", ""),
                }

    def _update_job_progress_locked(
        self,
        job_id: str,
        progress: dict,
        *,
        state: str | None = None,
        worker_id: str | None = None,
        event_id: str | None = None,
    ) -> None:
        incoming_revision = int(progress.get("revision", 0) or 0)
        current = self._job_progress.get(job_id)
        current_revision = int(current.get("revision", -1) or -1) if current else -1
        if incoming_revision < current_revision:
            return
        payload = {
            "job_id": job_id,
            "stage": str(progress.get("stage") or ""),
            "percent": float(progress.get("percent", 0) or 0),
            "current_question": int(progress.get("current_question", 0) or 0),
            "total_questions": int(progress.get("total_questions", 0) or 0),
            "revision": incoming_revision,
            "updated_at": float(progress.get("updated_at", time.time()) or time.time()),
            "state": state or (current or {}).get("state"),
            "worker_id": worker_id if worker_id is not None else (current or {}).get("worker_id"),
            "event_id": event_id or (current or {}).get("event_id"),
        }
        self._job_progress[job_id] = payload

    def set_component(self, component: str, status: str, message: str = "") -> None:
        with self._lock:
            self._components[component] = {
                "component": component, "status": status,
                "timestamp": time.time(), "message": message,
            }

    def snapshot(self, jobs_snapshot: dict | None = None) -> dict:
        with self._lock:
            jobs = list(self._jobs.values())
            job_progress = {key: dict(value) for key, value in self._job_progress.items()}
            workers = list(self._workers.values())
            events = list(self._events)
            components = dict(self._components)
        if jobs_snapshot is not None:
            # JobManager остаётся авторитетом для очереди/истории.
            jobs = [
                *jobs_snapshot.get("queued", []),
                *jobs_snapshot.get("active", []),
                *jobs_snapshot.get("history", []),
            ]
        return {
            "ok": True,
            "application_status": self.application_status,
            "version": self.version,
            "jobs": jobs_snapshot or {
                "queued": [j for j in jobs if j.get("state") == "QUEUED"],
                "active": [j for j in jobs if j.get("state") not in {"QUEUED", "COMPLETED", "FAILED", "CANCELLED"}],
                "history": [j for j in jobs if j.get("state") in {"COMPLETED", "FAILED", "CANCELLED"}],
                "queue_size": sum(1 for j in jobs if j.get("state") == "QUEUED"),
                "running": sum(1 for j in jobs if j.get("state") not in {"QUEUED", "COMPLETED", "FAILED", "CANCELLED"}),
            },
            "workers": workers,
            "job_progress": job_progress,
            "components": components,
            "events": events,
        }
