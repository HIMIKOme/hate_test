"""Веб-панель управления HATE_tets.

Простой HTTP-сервер на стандартной библиотеке. Слушает 0.0.0.0 —
доступен из локальной сети по адресу http://<lan-ip>:<port>/.

Возможности:
  - просмотр / редактирование config.txt через браузер;
  - управление белым списком;
  - статистика;
  - команды: перезапустить бота, остановить трей, открыть папку ответов,
    «Стоп всё» — прерывает все тесты и закрывает Chrome.
  - при старте сообщает рабочий LAN-адрес через on_link_ready().
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from .answers import get_answers_dir
from .cache import Cache
from .config import (
    _normalize_whitelist,
    get_config_txt_path,
    load_settings,
    request_reload,
    save_settings,
)
from .net_utils import get_lan_ip
from .job_manager import JobManager
from .event_bus import EventBus

DEFAULT_PORT = 8765
PORT_RANGE = 30
BIND_HOST = "0.0.0.0"


# ---------------------------------------------------------------------------
# HTML
# ---------------------------------------------------------------------------

PAGE_HTML = """<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8">
<title>HATE_tets — панель управления</title>
<style>
  * { box-sizing: border-box; }
  body {
    font-family: -apple-system, "Segoe UI", Roboto, sans-serif;
    background: #f5f5f7; color: #1c1c1e; margin: 0; padding: 24px;
  }
  .container { max-width: 720px; margin: 0 auto; }
  h1 { font-size: 22px; margin: 0 0 4px; }
  .sub { color: #777; font-size: 13px; margin-bottom: 20px; }
  .card {
    background: #fff; border-radius: 12px; padding: 20px;
    box-shadow: 0 1px 3px rgba(0,0,0,.06); margin-bottom: 16px;
  }
  .card h2 { font-size: 15px; margin: 0 0 14px; color: #333; }
  .row { margin-bottom: 12px; }
  label { display: block; font-size: 12px; color: #555; margin-bottom: 4px; }
  input[type=text], input[type=number] {
    width: 100%; padding: 8px 10px; border: 1px solid #ccc;
    border-radius: 6px; font-size: 13px; font-family: inherit;
  }
  input:focus { outline: none; border-color: #0071e3; }
  .btns { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 12px; }
  button {
    background: #0071e3; color: #fff; border: none; border-radius: 6px;
    padding: 9px 16px; font-size: 13px; cursor: pointer; font-family: inherit;
  }
  button:hover { background: #005bb5; }
  button.secondary { background: #e5e5ea; color: #1c1c1e; }
  button.secondary:hover { background: #d1d1d6; }
  button.danger { background: #c0392b; }
  button.danger:hover { background: #a02920; }
  button.stop-all {
    background: #b91c1c; font-weight: 600; padding: 12px 22px;
    font-size: 14px;
  }
  button.stop-all:hover { background: #991b1b; }
  button.x {
    background: transparent; color: #c0392b; padding: 2px 8px;
    font-size: 14px; font-weight: bold; border-radius: 4px;
  }
  button.x:hover { background: #f4d3d0; }
  .stats { display: flex; gap: 24px; flex-wrap: wrap; }
  .stat .val { font-size: 22px; font-weight: 600; }
  .stat .lbl { font-size: 12px; color: #777; }
  .toast {
    position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%);
    background: #1c1c1e; color: #fff; padding: 10px 20px; border-radius: 8px;
    font-size: 13px; opacity: 0; transition: opacity .3s; pointer-events: none;
  }
  .toast.show { opacity: 1; }
  .path { font-family: Consolas, monospace; font-size: 11px; color: #555;
    background: #f0f0f0; padding: 6px 10px; border-radius: 6px;
    word-break: break-all; }
  .hint { font-size: 11px; color: #888; margin-top: 4px; }
  .wl-list { margin-top: 10px; }
  .wl-item {
    display: flex; justify-content: space-between; align-items: center;
    padding: 6px 10px; background: #f5f5f7; border-radius: 6px;
    margin-bottom: 4px; font-size: 13px; font-family: Consolas, monospace;
  }
  .wl-item.empty { color: #999; font-style: italic; font-family: inherit; }
  .inline { display: flex; gap: 8px; align-items: center; }
  .inline input { flex: 1; }
  .panel-url {
    font-family: Consolas, monospace; font-size: 13px; color: #005bb5;
    background: #eef5ff; padding: 8px 12px; border-radius: 6px;
    word-break: break-all; cursor: pointer; user-select: all;
    border: 1px dashed #b9d6ff;
  }
  .panel-url:hover { background: #e0eeff; }
</style>
</head>
<body>
<div class="container">
  <h1>HATE_tets</h1>
  <div class="sub">Панель управления. Доступна в локальной сети.</div>

  <div class="card" style="padding:14px 20px">
    <div class="hint" style="margin:0 0 6px 0">
      Адрес для других устройств в этой сети (нажмите, чтобы скопировать):
    </div>
    <div class="panel-url" id="panel-url" title="Клик — скопировать">—</div>
  </div>

  <div class="card">
    <h2>Состояние приложения <span id="app-status" style="font-size:12px">● В сети</span></h2>
    <div class="stats">
      <div class="stat"><div class="val" id="stat-running">—</div><div class="lbl">выполняется</div></div>
      <div class="stat"><div class="val" id="stat-queued">—</div><div class="lbl">в очереди</div></div>
      <div class="stat"><div class="val" id="stat-job">—</div><div class="lbl">текущее задание</div></div>
    </div>
  </div>

  <div class="card">
    <h2>Текущие задания</h2>
    <div id="jobs-list" class="hint">Нет активных заданий.</div>
  </div>

  <div class="card">
    <h2>Статистика</h2>
    <div class="stats">
      <div class="stat"><div class="val" id="stat-uptime">—</div><div class="lbl">время работы приложения</div></div>
      <div class="stat"><div class="val" id="stat-cache">—</div><div class="lbl">в кэше</div></div>
      <div class="stat"><div class="val" id="stat-browser">—</div><div class="lbl">Браузер</div></div>
      <div class="stat"><div class="val" id="stat-port">—</div><div class="lbl">порт панели</div></div>
    </div>
  </div>

  <div class="card">
    <h2>Управление</h2>
    <div class="btns" style="margin-top:0">
      <button class="stop-all" onclick="stopAll()">⛔ Остановить всё</button>
      <button class="secondary" onclick="restartBot()">Перезапустить бота</button>
      <button class="secondary" onclick="openAnswers()">Открыть папку ответов</button>
      <button class="danger" onclick="stopTray()">Остановить приложение</button>
    </div>
    <div class="hint">
      «Стоп всё» прерывает все запущенные тесты, чистит очередь и закрывает Chrome.
      Бот остаётся живым и продолжит принимать новые ссылки.
    </div>
  </div>

  <div class="card">
    <h2>Белый список пользователей</h2>
    <div class="hint" style="margin-bottom:8px">
      Только эти пользователи могут использовать команду /r для прохождения теста на 100%.
    </div>
    <div class="inline">
      <input type="text" id="wl-input" placeholder="@имя_пользователя">
      <button onclick="wlAdd()">Добавить</button>
    </div>
    <div class="wl-list" id="wl-list"></div>
  </div>

  <div class="card">
    <h2>Настройки Telegram</h2>
    <div class="row">
      <label>Токен Telegram-бота</label>
      <input type="text" id="token" placeholder="123456:ABC...">
    </div>
    <div class="row">
      <label>Чат 1</label>
      <input type="text" id="chat1" placeholder="-1001234567890">
    </div>
    <div class="row">
      <label>Чат 2</label>
      <input type="text" id="chat2" placeholder="">
    </div>
    <div class="row">
      <label>Чат 3</label>
      <input type="text" id="chat3" placeholder="">
    </div>
    <div class="row">
      <label>Контакт для сообщений об ошибках и ссылки на панель</label>
      <input type="text" id="contact" placeholder="@your_username">
    </div>
    <div class="row">
      <label>Дней хранения файлов</label>
      <input type="number" id="days" min="1" max="365" placeholder="15">
    </div>
    <div class="btns">
      <button onclick="saveConfig()">Сохранить настройки</button>
    </div>
  </div>

  <div class="card">
    <h2>Служебное</h2>
    <div class="path" id="config-path">Путь к config.txt: …</div>
  </div>
</div>

<div class="toast" id="toast"></div>

<script>
function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg; el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 2500);
}

async function api(method, url, body) {
  const opts = { method, headers: { 'Content-Type': 'application/json' } };
  if (body) opts.body = JSON.stringify(body);
  const r = await fetch(url, opts);
  return r.json();
}

function fmtUptime(sec) {
  if (sec < 60) return sec + 'с';
  if (sec < 3600) return Math.floor(sec/60) + 'м';
  const h = Math.floor(sec/3600);
  const m = Math.floor((sec%3600)/60);
  return h + 'ч ' + m + 'м';
}

let lastUrl = '';

async function loadState() {
  const s = await api('GET', '/api/state');
  document.getElementById('token').value = s.config.telegram_token || '';
  document.getElementById('chat1').value = s.config.telegram_chats[0] || '';
  document.getElementById('chat2').value = s.config.telegram_chats[1] || '';
  document.getElementById('chat3').value = s.config.telegram_chats[2] || '';
  document.getElementById('contact').value = s.config.error_contact || '';
  document.getElementById('days').value = s.config.cleanup_days || 15;
  document.getElementById('worker-count').value = s.config.worker_count || 4;
  document.getElementById('stat-uptime').textContent = fmtUptime(s.uptime);
  document.getElementById('stat-cache').textContent = s.cache_size;
  document.getElementById('stat-browser').textContent = s.browser_open ? 'открыт' : 'закрыт';
  document.getElementById('stat-port').textContent = s.port;
  document.getElementById('stat-running').textContent = (s.jobs && s.jobs.running) || 0;
  document.getElementById('stat-queued').textContent = (s.jobs && s.jobs.queue_size) || 0;
  const active = (s.jobs && s.jobs.active) || [];
  document.getElementById('stat-job').textContent = active.length ? active[0].id : '—';
  document.getElementById('app-status').textContent = '● ' + (s.application_status || 'Online');
  renderJobs(s.jobs || {});
  document.getElementById('config-path').textContent = 'Путь к config.txt: ' + s.config_path;
  if (s.url) {
    lastUrl = s.url;
    document.getElementById('panel-url').textContent = s.url;
  }
  renderWhitelist(s.config.whitelist || []);
}

function renderJobs(data) {
  const box = document.getElementById('jobs-list');
  const jobs = [...(data.active || []), ...(data.queued || []), ...(data.history || []).slice(0, 20)];
  const sizes = data.queue_sizes || {};
  const summary = Object.entries(sizes).map(([k,v]) => escapeHtml(k.replace('_QUEUE','')) + ': ' + v).join(' · ');
  if (!jobs.length) { box.innerHTML = '<div class="hint">Нет заданий.</div><div class="hint">' + summary + '</div>'; return; }
  box.innerHTML = '<div class="hint" style="margin-bottom:8px">Очереди: ' + summary + '</div>' + jobs.map(j => {
    const pct = Number(j.progress || 0);
    const pos = j.state === 'QUEUED' ? ' · позиция ' + (j.queue_position || '—') + ' · ожидание ' + Math.round(j.waiting_seconds || 0) + 'с' : '';
    const priority = String(j.priority || 'NORMAL').toUpperCase();
    const priorityButtons = j.state === 'QUEUED' ? `<select onchange="setPriority('${escapeHtml(j.id)}', this.value)" style="font-size:11px;padding:3px 5px;margin-right:6px">
      <option value="LOW" ${priority === 'LOW' ? 'selected' : ''}>Низкий</option>
      <option value="NORMAL" ${priority === 'NORMAL' ? 'selected' : ''}>Обычный</option>
      <option value="HIGH" ${priority === 'HIGH' ? 'selected' : ''}>Высокий</option>
      <option value="VERY_HIGH" ${priority === 'VERY_HIGH' ? 'selected' : ''}>Очень высокий</option>
    </select>` : '';
    const cancel = ['QUEUED','STARTING','BROWSER_STARTING','OPENING','TESTING','COLLECTING','SAVING','NOTIFYING','CANCELLING'].includes(j.state) ? `<button class="x" onclick="cancelJob('${escapeHtml(j.id)}')">Отменить</button>` : '';
    const retry = ['COMPLETED','FAILED','CANCELLED'].includes(j.state) ? `<button class="x" onclick="retryJob('${escapeHtml(j.id)}')">Повторить</button>` : '';
    return `<div style="padding:10px 0;border-bottom:1px solid #eee">
      <div><b>${escapeHtml(j.id)}</b> · ${escapeHtml(j.queue_type || 'TEST_QUEUE')} · ${escapeHtml(j.state)} · ${escapeHtml(j.stage || '')}${pos}</div>
      <div style="font-size:12px;color:#666;word-break:break-all">${escapeHtml(j.url || j.mode || '')}</div>
      <div style="margin-top:6px;background:#eee;border-radius:4px;height:7px;overflow:hidden"><div style="width:${Math.max(0, Math.min(100, pct))}%;height:100%;background:#0071e3"></div></div>
      <div style="font-size:11px;color:#777;margin-top:4px">${pct.toFixed(0)}% · priority ${escapeHtml(j.priority || '')} · эффективный приоритет ${Number(j.effective_priority || 0).toFixed(2)} · исполнитель ${escapeHtml(j.worker_id || '—')}</div>
      <div style="margin-top:5px">${priorityButtons}${cancel}${retry}</div>
    </div>`;
  }).join('');
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

async function cancelJob(jobId) {
  const r = await api('POST', '/api/jobs/cancel', {job_id: jobId});
  toast(r.ok ? 'Задание отменено' : (r.error || 'Не удалось отменить'));
  loadState();
}

async function setPriority(jobId, priority) {
  const r = await api('POST', '/api/jobs/priority', {job_id: jobId, priority});
  toast(r.ok ? 'Приоритет изменён' : (r.error || 'Не удалось изменить приоритет'));
  loadState();
}

async function retryJob(jobId) {
  const r = await api('POST', '/api/jobs/retry', {job_id: jobId});
  toast(r.ok ? 'Повторное задание поставлено в очередь' : (r.error || 'Не удалось повторить'));
  loadState();
}

function renderWhitelist(list) {
  const box = document.getElementById('wl-list');
  if (!list || list.length === 0) {
    box.innerHTML = '<div class="wl-item empty">Список пуст</div>';
    return;
  }
  box.innerHTML = list.map(u =>
    `<div class="wl-item">
       <span>@${u}</span>
       <button class="x" onclick="wlRemove('${u}')" title="Удалить">✕</button>
     </div>`
  ).join('');
}

async function wlAdd() {
  const inp = document.getElementById('wl-input');
  const name = inp.value.trim();
  if (!name) return;
  const r = await api('POST', '/api/whitelist/add', { username: name });
  if (r.ok) {
    inp.value = '';
    toast('Добавлен');
    renderWhitelist(r.whitelist);
  } else {
    toast('Ошибка: ' + (r.error || '?'));
  }
}

async function wlRemove(name) {
  const r = await api('POST', '/api/whitelist/remove', { username: name });
  if (r.ok) {
    toast('Удалён');
    renderWhitelist(r.whitelist);
  } else {
    toast('Ошибка: ' + (r.error || '?'));
  }
}

async function saveConfig() {
  const body = {
    telegram_token: document.getElementById('token').value.trim(),
    telegram_chats: [
      document.getElementById('chat1').value.trim(),
      document.getElementById('chat2').value.trim(),
      document.getElementById('chat3').value.trim(),
    ],
    error_contact: document.getElementById('contact').value.trim(),
    cleanup_days: parseInt(document.getElementById('days').value) || 15,
    worker_count: Math.max(1, Math.min(16, parseInt(document.getElementById('worker-count').value) || 4)),
  };
  const r = await api('POST', '/api/config', body);
  if (r.ok) { toast('Сохранено'); loadState(); }
  else { toast('Ошибка: ' + (r.error || 'неизвестно')); }
}

async function stopAll() {
  if (!confirm('Прервать все активные тесты и закрыть Chrome?')) return;
  const r = await api('POST', '/api/stop_all', {});
  toast(r.ok ? 'Остановлено' : 'Ошибка: ' + (r.error || '?'));
  loadState();
}

async function restartBot() {
  const r = await api('POST', '/api/restart_bot', {});
  toast(r.ok ? 'Бот перезапущен' : 'Ошибка: ' + (r.error || '?'));
}

async function stopTray() {
  if (!confirm('Точно остановить трей? Бот перестанет работать.')) return;
  await api('POST', '/api/stop_tray', {});
  toast('Трей останавливается...');
}

async function openAnswers() {
  const r = await api('POST', '/api/open_answers', {});
  toast(r.ok ? 'Папка открыта' : 'Ошибка: ' + (r.error || '?'));
}

document.getElementById('wl-input').addEventListener('keydown', e => {
  if (e.key === 'Enter') wlAdd();
});

document.getElementById('panel-url').addEventListener('click', () => {
  if (!lastUrl) return;
  try {
    navigator.clipboard.writeText(lastUrl).then(
      () => toast('Скопировано'),
      () => toast('Не удалось скопировать')
    );
  } catch (e) {
    toast('Не удалось скопировать');
  }
});

loadState();
setInterval(loadState, 5000);
</script>
</body>
</html>
"""


# ---------------------------------------------------------------------------
# HTTP-обработчик
# ---------------------------------------------------------------------------

class _Handler(BaseHTTPRequestHandler):
    panel: "WebPanel" = None  # type: ignore

    def log_message(self, fmt, *args):
        pass

    def _send_html(self, html: str, status: int = 200) -> None:
        body = html.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_json(self, data: Dict[str, Any], status: int = 200) -> None:
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json(self) -> Dict[str, Any]:
        length = int(self.headers.get("Content-Length", 0))
        if not length:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return {}

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            self._send_html(PAGE_HTML)
        elif self.path == "/api/state":
            self._send_json(self.panel.get_state())
        elif self.path == "/api/jobs":
            self._send_json(self.panel.get_jobs())
        else:
            self._send_json({"ok": False, "error": "not found"}, 404)

    def do_POST(self):
        if self.path == "/api/config":
            self._send_json(self.panel.save_config(self._read_json()))
        elif self.path == "/api/restart_bot":
            self._send_json(self.panel.restart_bot())
        elif self.path == "/api/stop_tray":
            self._send_json(self.panel.stop_tray())
        elif self.path == "/api/stop_all":
            self._send_json(self.panel.stop_all())
        elif self.path == "/api/open_answers":
            self._send_json(self.panel.open_answers())
        elif self.path == "/api/jobs/cancel":
            self._send_json(self.panel.cancel_job(self._read_json()))
        elif self.path == "/api/whitelist/add":
            self._send_json(self.panel.whitelist_add(self._read_json()))
        elif self.path == "/api/whitelist/remove":
            self._send_json(self.panel.whitelist_remove(self._read_json()))
        else:
            self._send_json({"ok": False, "error": "not found"}, 404)


# ---------------------------------------------------------------------------
# Публичный класс
# ---------------------------------------------------------------------------

class WebPanel:
    def __init__(
        self,
        logger,
        on_restart_bot: Optional[Callable[[], bool]] = None,
        on_stop_tray: Optional[Callable[[], None]] = None,
        on_link_ready: Optional[Callable[[str], None]] = None,
        on_stop_all: Optional[Callable[[], None]] = None,
        job_manager: Optional[JobManager] = None,
        event_bus: Optional[EventBus] = None,
    ):
        self.logger = logger
        self.on_restart_bot = on_restart_bot
        self.on_stop_tray = on_stop_tray
        self.on_link_ready = on_link_ready
        self.on_stop_all = on_stop_all
        self.job_manager = job_manager
        self.event_bus = event_bus

        self._server: Optional[ThreadingHTTPServer] = None
        self._thread: Optional[threading.Thread] = None
        self._port: int = 0
        self._lan_ip: str = "127.0.0.1"
        self._started_at: float = time.time()

    def start(self) -> None:
        for port in range(DEFAULT_PORT, DEFAULT_PORT + PORT_RANGE):
            try:
                server = ThreadingHTTPServer((BIND_HOST, port), _Handler)
                _Handler.panel = self
                self._server = server
                self._port = port
                break
            except OSError:
                continue

        if self._server is None:
            if self.logger:
                self.logger.error(
                    f"Не удалось запустить веб-панель: порты "
                    f"{DEFAULT_PORT}–{DEFAULT_PORT + PORT_RANGE - 1} заняты."
                )
            return

        self._lan_ip = get_lan_ip()

        self._thread = threading.Thread(
            target=self._serve, name="web-panel", daemon=True,
        )
        self._thread.start()

        if self.logger:
            self.logger.info(
                f"Веб-панель доступна: {self.url} "
                f"(локально: http://127.0.0.1:{self._port}/)"
            )

        if self.on_link_ready is not None:
            threading.Thread(
                target=self._safe_link_callback,
                args=(self.url,),
                name="web-panel-link-cb",
                daemon=True,
            ).start()

    def _safe_link_callback(self, url: str) -> None:
        try:
            if self.on_link_ready is not None:
                self.on_link_ready(url)
        except Exception as exc:
            if self.logger:
                self.logger.warning(f"on_link_ready: {exc}")

    def _serve(self) -> None:
        try:
            self._server.serve_forever(poll_interval=0.5)
        except Exception as exc:
            if self.logger:
                self.logger.warning(f"Веб-панель остановлена: {exc}")

    def stop(self) -> None:
        if self._server is not None:
            try:
                self._server.shutdown()
                self._server.server_close()
            except Exception:
                pass
            self._server = None
            if self.logger:
                self.logger.info("Веб-панель остановлена.")

    @property
    def port(self) -> int:
        return self._port

    @property
    def lan_ip(self) -> str:
        return self._lan_ip

    @property
    def url(self) -> str:
        if self._port == 0:
            return ""
        host = self._lan_ip or "127.0.0.1"
        return f"http://{host}:{self._port}/"

    # ------------------------------------------------------------------ #
    # API
    # ------------------------------------------------------------------ #

    def get_state(self) -> Dict[str, Any]:
        try:
            settings = load_settings()
        except Exception:
            settings = {
                "telegram_token": "",
                "telegram_chats": ["", "", ""],
                "error_contact": "",
                "cleanup_days": 15,
                "whitelist": [],
            }

        try:
            cache_size = len(Cache().data)
        except Exception:
            cache_size = 0

        try:
            config_path = str(get_config_txt_path())
        except Exception:
            config_path = "?"

        job_state = self.job_manager.snapshot() if self.job_manager is not None else {"queued": [], "active": [], "history": [], "queue_size": 0, "running": 0, "workers": []}
        browser_open = any(
            worker.get("browser_status") == "online"
            for worker in job_state.get("workers", [])
            if worker.get("alive")
        )
        return {
            "ok": True,
            "config": settings,
            "config_path": config_path,
            "cache_size": cache_size,
            "browser_open": browser_open,
            "uptime": int(time.time() - self._started_at),
            "port": self._port,
            "lan_ip": self._lan_ip,
            "url": self.url,
            "jobs": job_state,
            "application_status": "Online",
        }

    def get_jobs(self) -> Dict[str, Any]:
        if self.job_manager is None:
            return {"ok": True, "queued": [], "active": [], "history": []}
        return {"ok": True, **self.job_manager.snapshot()}

    def cancel_job(self, data: Dict[str, Any]) -> Dict[str, Any]:
        if self.job_manager is None:
            return {"ok": False, "error": "JobManager не подключён"}
        job_id = str(data.get("job_id") or "").strip()
        if not job_id:
            return {"ok": False, "error": "job_id не задан"}
        return {"ok": self.job_manager.cancel(job_id)}

    def save_config(self, data: Dict[str, Any]) -> Dict[str, Any]:
        try:
            current = load_settings()
            save_settings({
                "telegram_token": data.get("telegram_token", current.get("telegram_token", "")),
                "telegram_chats": data.get("telegram_chats", current.get("telegram_chats", ["", "", ""])),
                "error_contact": data.get("error_contact", current.get("error_contact", "")),
                "cleanup_days": data.get("cleanup_days", current.get("cleanup_days", 15)),
                "whitelist": current.get("whitelist", []),
                "worker_count": data.get("worker_count", current.get("worker_count", 4)),
                "auxiliary_worker_count": data.get("auxiliary_worker_count", current.get("auxiliary_worker_count", 1)),
            })
            if self.logger:
                self.logger.info("Настройки сохранены через веб-панель.")
            return {"ok": True}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    # ------------------------------------------------------------------ #
    # Whitelist
    # ------------------------------------------------------------------ #
    def whitelist_add(self, data: Dict[str, Any]) -> Dict[str, Any]:
        try:
            name = str(data.get("username") or "").strip()
            if not name:
                return {"ok": False, "error": "пустой username"}

            norm = _normalize_whitelist(name)
            if not norm:
                return {"ok": False, "error": "некорректный username"}

            current = load_settings()
            wl = list(current.get("whitelist", []))
            for n in norm:
                if n not in wl:
                    wl.append(n)

            current["whitelist"] = wl
            save_settings(current)

            if self.logger:
                self.logger.info(f"Веб-панель: whitelist += {norm}")

            return {"ok": True, "whitelist": wl}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def whitelist_remove(self, data: Dict[str, Any]) -> Dict[str, Any]:
        try:
            name = str(data.get("username") or "").strip()
            if not name:
                return {"ok": False, "error": "пустой username"}

            norm = _normalize_whitelist(name)
            if not norm:
                return {"ok": False, "error": "некорректный username"}

            current = load_settings()
            wl = [u for u in current.get("whitelist", []) if u not in norm]

            current["whitelist"] = wl
            save_settings(current)

            if self.logger:
                self.logger.info(f"Веб-панель: whitelist -= {norm}")

            return {"ok": True, "whitelist": wl}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    # ------------------------------------------------------------------ #
    def restart_bot(self) -> Dict[str, Any]:
        if self.on_restart_bot is None:
            return {"ok": False, "error": "обработчик не подключён"}
        try:
            result = self.on_restart_bot()
            return {"ok": bool(result)}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def stop_tray(self) -> Dict[str, Any]:
        if self.on_stop_tray is None:
            return {"ok": False, "error": "обработчик не подключён"}

        def _later():
            time.sleep(0.5)
            try:
                self.on_stop_tray()
            except Exception as exc:
                if self.logger:
                    self.logger.warning(f"Ошибка при остановке трея: {exc}")
        threading.Thread(target=_later, daemon=True).start()
        return {"ok": True}

    def stop_all(self) -> Dict[str, Any]:
        """Прерывает все активные тесты, чистит очередь и закрывает Chrome.

        Основную работу делает колбэк on_stop_all (метод TelegramBot) —
        он выставляет глобальный флаг, очищает очередь и внутреннее
        состояние бота. Здесь дополнительно закрываем Chrome.
        """
        # 1. Если подключён колбэк бота — делегируем ему остановку.
        if self.on_stop_all is not None:
            try:
                self.on_stop_all()
            except Exception as exc:
                if self.logger:
                    self.logger.warning(f"on_stop_all: {exc}")
        else:
            # Fallback — просто выставляем глобальный флаг.
            try:
                from services.global_state import request_stop
                request_stop()
            except Exception as exc:
                if self.logger:
                    self.logger.warning(
                        f"Не удалось установить глобальный флаг: {exc}"
                    )

        # 2. Chrome закрывается самими WorkerContext после отмены Job или остановки пула.

        if self.logger:
            self.logger.info("Веб-панель: запрошено «Стоп всё».")

        return {"ok": True}

    def open_answers(self) -> Dict[str, Any]:
        try:
            path = get_answers_dir()
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

        try:
            if sys.platform == "win32":
                os.startfile(str(path))  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(path)])
            else:
                subprocess.Popen(["xdg-open", str(path)])
            return {"ok": True, "path": str(path)}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}
