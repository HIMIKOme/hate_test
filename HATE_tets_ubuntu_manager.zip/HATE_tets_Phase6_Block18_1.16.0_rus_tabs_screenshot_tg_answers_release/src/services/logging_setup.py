"""Логирование: очередь для GUI (опционально) + файл с ротацией."""
from __future__ import annotations

import logging
import queue
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
from typing import Optional

from .config import get_data_dir


class JobContextFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        if not hasattr(record, "job_id"):
            record.job_id = "-"
        return True


class EventBusLogHandler(logging.Handler):
    """Делает обычные Python-логи live-событиями для независимого Web."""

    def __init__(self, event_bus):
        super().__init__(level=logging.INFO)
        self.event_bus = event_bus

    def emit(self, record: logging.LogRecord) -> None:
        try:
            message = self.format(record)
            self.event_bus.publish(
                "LogMessage",
                source=f"logger:{record.name}",
                level=record.levelname,
                message=message,
                logger=record.name,
                job_id=getattr(record, "job_id", None),
                timestamp=record.created,
            )
        except Exception:
            # Логирование не должно ломать бизнес-поток.
            pass


def attach_event_bus_logger(logger: logging.Logger, event_bus) -> EventBusLogHandler:
    handler = EventBusLogHandler(event_bus)
    handler.setFormatter(logging.Formatter("%(asctime)s  %(message)s", datefmt="%H:%M:%S"))
    logger.addHandler(handler)
    return handler


class QueueLogHandler(logging.Handler):
    def __init__(self, log_queue: "queue.Queue"):
        super().__init__()
        self.log_queue = log_queue

    def emit(self, record: logging.LogRecord) -> None:
        try:
            self.log_queue.put((record.levelname, self.format(record)))
        except Exception:
            pass


def get_logs_dir() -> Path:
    d = get_data_dir() / "logs"
    d.mkdir(parents=True, exist_ok=True)
    return d


def setup_logger(
    log_queue: Optional["queue.Queue"] = None,
    log_name: str = "app",
) -> logging.Logger:
    """Если log_queue is None — только файл (режим трея).

    Файлы ротируются ежедневно в полночь, храним последние 7 дней.
    """
    logger = logging.getLogger(f"hate_tets_{log_name}")
    logger.setLevel(logging.DEBUG)
    logger.handlers.clear()
    logger.propagate = False

    if log_queue is not None:
        qh = QueueLogHandler(log_queue)
        qh.setLevel(logging.INFO)
        qh.setFormatter(logging.Formatter("%(asctime)s  %(message)s", datefmt="%H:%M:%S"))
        qh.addFilter(JobContextFilter())
        logger.addHandler(qh)

    try:
        # Один файл на процесс — ротация сама добавит суффиксы по дате.
        log_file = get_logs_dir() / f"{log_name}.log"
        fh = TimedRotatingFileHandler(
            log_file,
            when="midnight",
            interval=1,
            backupCount=7,
            encoding="utf-8",
            delay=False,
        )
        fh.setLevel(logging.DEBUG)
        fh.addFilter(JobContextFilter())
        fh.setFormatter(logging.Formatter(
            "%(asctime)s [%(levelname)s] [job=%(job_id)s] %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        ))
        logger.addHandler(fh)
        logger.info(f"Логи сохраняются в файл: {log_file}")
    except Exception as exc:
        logger.warning(f"Не удалось создать файловый лог: {exc}")

    return logger
