"""Версия приложения единым источником для тонких клиентов."""
from pathlib import Path

from .paths import project_root

_ROOT = project_root()
try:
    APP_VERSION = (_ROOT / "VERSION").read_text(encoding="utf-8").strip() or "0.0.0"
except OSError:
    APP_VERSION = "0.0.0"
