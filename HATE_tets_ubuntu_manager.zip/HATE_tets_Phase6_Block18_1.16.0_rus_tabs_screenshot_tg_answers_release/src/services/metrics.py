"""Персистентные operational metrics и latency percentiles."""
from __future__ import annotations

import json
import math
import statistics
import threading
import time
from pathlib import Path
from typing import Any

from .ipc import base_dir

_LOCK = threading.RLock()
_PATH = base_dir() / "data" / "metrics.json"
_MAX_SAMPLES = 1000
_PROCESS_STARTED_AT = time.time()


def _default() -> dict[str, Any]:
    return {
        "jobs_started": 0,
        "jobs_completed": 0,
        "jobs_failed": 0,
        "jobs_retried": 0,
        "jobs_cancelled": 0,
        "worker_started": 0,
        "worker_stopped": 0,
        "browser_crashes": 0,
        "durations": [],
        "worker_busy_seconds": {},
        "worker_last_started": {},
        "worker_busy_since": {},
        "known_workers": [],
        "process_started_at": time.time(),
        "updated_at": time.time(),
    }


def _load_locked() -> dict[str, Any]:
    try:
        data = json.loads(_PATH.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            result = _default()
            result.update(data)
            result["durations"] = [float(x) for x in result.get("durations", []) if isinstance(x, (int, float))][- _MAX_SAMPLES :]
            if not isinstance(result.get("worker_busy_seconds"), dict):
                result["worker_busy_seconds"] = {}
            if not isinstance(result.get("worker_last_started"), dict):
                result["worker_last_started"] = {}
            if not isinstance(result.get("worker_busy_since"), dict):
                result["worker_busy_since"] = {}
            if not isinstance(result.get("known_workers"), list):
                result["known_workers"] = []
            return result
    except Exception:
        pass
    return _default()


def _save_locked(data: dict[str, Any]) -> None:
    _PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = _PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(_PATH)


def _percentile(values: list[float], p: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    position = (len(ordered) - 1) * p
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return ordered[lower]
    fraction = position - lower
    return ordered[lower] + (ordered[upper] - ordered[lower]) * fraction


def record_event(event: dict[str, Any]) -> None:
    event_type = str(event.get("type") or "")
    job = event.get("job") if isinstance(event.get("job"), dict) else {}
    queue_type = str(job.get("queue_type") or event.get("queue_type") or "")
    if queue_type and queue_type != "TEST_QUEUE":
        return
    with _LOCK:
        data = _load_locked()
        changed = False
        worker_id = str(event.get("worker_id") or "")
        now = float(event.get("timestamp") or time.time())
        if event_type == "JobStarted":
            data["jobs_started"] += 1
            if worker_id and worker_id not in data["known_workers"]:
                data["known_workers"].append(worker_id)
            changed = True
        elif event_type == "JobCompleted":
            data["jobs_completed"] += 1
            started = job.get("started_at") or event.get("started_at")
            finished = job.get("finished_at") or now
            try:
                duration = max(0.0, float(finished) - float(started)) if started else 0.0
            except (TypeError, ValueError):
                duration = 0.0
            if duration:
                data["durations"].append(duration)
                data["durations"] = data["durations"][-_MAX_SAMPLES:]
            changed = True
        elif event_type == "JobFailed":
            data["jobs_failed"] += 1
            started = job.get("started_at") or event.get("started_at")
            finished = job.get("finished_at") or now
            try:
                duration = max(0.0, float(finished) - float(started)) if started else 0.0
            except (TypeError, ValueError):
                duration = 0.0
            if duration:
                data["durations"].append(duration)
                data["durations"] = data["durations"][-_MAX_SAMPLES:]
            changed = True
        elif event_type == "JobRetryScheduled":
            data["jobs_retried"] += 1
            changed = True
        elif event_type == "JobCancelled":
            data["jobs_cancelled"] += 1
            changed = True
        elif event_type == "WorkerStarted":
            data["worker_started"] += 1
            changed = True
        elif event_type == "WorkerStopped":
            data["worker_stopped"] += 1
            changed = True
        elif event_type == "WorkerStateChanged":
            wid = str(event.get("worker_id") or "")
            state = str(event.get("worker_state") or "")
            if wid and wid not in data["known_workers"]:
                data["known_workers"].append(wid)
            if wid and state == "BUSY":
                data["worker_busy_since"][wid] = now
            elif wid and state in {"IDLE", "CRASHED", "STOPPING", "OFFLINE"}:
                since = data["worker_busy_since"].pop(wid, None)
                if since is not None:
                    data["worker_busy_seconds"][wid] = float(data["worker_busy_seconds"].get(wid, 0.0)) + max(0.0, now - float(since))
            changed = True
        elif event_type == "BrowserCrashed":
            data["browser_crashes"] += 1
            changed = True
        if changed:
            data["updated_at"] = now
            try:
                _save_locked(data)
            except OSError:
                pass


def snapshot() -> dict[str, Any]:
    with _LOCK:
        data = _load_locked()
        durations = list(data.get("durations") or [])
        process_started = _PROCESS_STARTED_AT
        now = time.time()
        uptime = max(1.0, now - process_started)
        busy_seconds = sum(float(x or 0) for x in (data.get("worker_busy_seconds") or {}).values())
        for _wid, since in (data.get("worker_busy_since") or {}).items():
            busy_seconds += max(0.0, now - float(since))
        worker_count = max(1, len(set(str(x) for x in (data.get("known_workers") or []))))
        utilization = min(100.0, (busy_seconds / (uptime * worker_count)) * 100.0)
        return {
            "jobs_started": int(data.get("jobs_started", 0)),
            "jobs_completed": int(data.get("jobs_completed", 0)),
            "jobs_failed": int(data.get("jobs_failed", 0)),
            "jobs_retried": int(data.get("jobs_retried", 0)),
            "jobs_cancelled": int(data.get("jobs_cancelled", 0)),
            "worker_started": int(data.get("worker_started", 0)),
            "worker_stopped": int(data.get("worker_stopped", 0)),
            "browser_crashes": int(data.get("browser_crashes", 0)),
            "latency_seconds": {
                "avg": round(statistics.fmean(durations), 3) if durations else 0.0,
                "p50": round(_percentile(durations, 0.50), 3),
                "p95": round(_percentile(durations, 0.95), 3),
                "p99": round(_percentile(durations, 0.99), 3),
                "samples": len(durations),
            },
            "worker_utilization_percent": round(utilization, 2),
            "worker_count_observed": worker_count,
            "uptime_seconds": round(uptime, 1),
            "updated_at": data.get("updated_at"),
        }
