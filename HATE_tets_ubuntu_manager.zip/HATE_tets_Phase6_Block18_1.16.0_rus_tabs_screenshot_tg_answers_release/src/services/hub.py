"""Центральный Hub/Application Manager.

Все команды создания/изменения Job проходят через Hub. Клиенты не получают
доступ к внутренним объектам Worker и не управляют очередью самостоятельно.
"""
from __future__ import annotations
from typing import Callable, Optional

from .event_bus import EventBus, EventType
from .job import Job, JobPriority, QueueType
from .job_manager import JobManager
from .circuit_breaker import CircuitBreaker
from .live_events import LiveEventServer
from .state_manager import StateManager
from .version import APP_VERSION
from .job_store import JobStore
from .idempotency import IdempotencyStore
from .diagnostics import DiagnosticsManager
from .resource_manager import ResourceManager


class Hub:
    def __init__(self, logger, worker_count: int = 1, auxiliary_worker_count: int = 1, version: str = APP_VERSION, job_store: Optional[JobStore] = None):
        self.logger = logger
        self.events = EventBus(logger)
        self.live_events = LiveEventServer(logger, snapshot_provider=self.snapshot)
        self.events.subscribe_all(self.live_events.publish)
        self.state = StateManager(self.events, version=version)
        try:
            from .config import get_data_dir, load_settings
            settings = load_settings()
            data_path = get_data_dir() / "circuit_breaker.json"
            self.circuit_breaker = CircuitBreaker(
                self.events, logger, data_path=data_path,
                failure_threshold=settings.get("circuit_failure_threshold", 3),
                window_sec=settings.get("circuit_window_sec", 300),
                cooldown_sec=settings.get("circuit_cooldown_sec", 120),
            )
        except Exception:
            self.circuit_breaker = CircuitBreaker(self.events, logger)
        self.job_store = job_store
        try:
            from .config import get_data_dir, load_settings
            settings_for_runtime = load_settings()
        except Exception:
            settings_for_runtime = {}
        self.idempotency_store = IdempotencyStore(
            get_data_dir() / "idempotency.json", logger=logger
        )
        self.diagnostics_manager = DiagnosticsManager(
            get_data_dir() / "diagnostics", logger=logger
        )
        self.resource_manager = ResourceManager(
            logger,
            cpu_limit_percent=settings_for_runtime.get("resource_cpu_limit_percent", 90),
            memory_limit_percent=settings_for_runtime.get("resource_memory_limit_percent", 90),
        )
        self.job_manager = JobManager(
            logger,
            event_bus=self.events,
            worker_count=worker_count,
            auxiliary_worker_count=auxiliary_worker_count,
            circuit_breaker=self.circuit_breaker,
            job_store=self.job_store,
            idempotency_store=self.idempotency_store,
            diagnostics_manager=self.diagnostics_manager,
            resource_manager=self.resource_manager,
        )
        self._handler: Optional[Callable] = None
        self._event_subscriptions: list[str] = []

        self.events.subscribe(EventType.WORKER_STARTED, self._component_event("worker", "online"))
        self.events.subscribe(EventType.WORKER_STOPPED, self._component_event("worker", "offline"))
        self._event_subscriptions.extend(
            self.events.subscribe_many(
                (
                    EventType.JOB_STARTED,
                    EventType.JOB_PROGRESS,
                    EventType.JOB_COMPLETED,
                    EventType.JOB_FAILED,
                    EventType.JOB_CANCELLED,
                    EventType.JOB_STATE_REQUESTED,
                    EventType.JOB_PROGRESS_REQUESTED,
                ),
                self._on_job_event,
            )
        )
        self.events.subscribe(EventType.BROWSER_CRASHED, self._on_browser_crashed)
        self.events.subscribe_all(self._publish_state_after_event)
        self.events.subscribe_all(self._persist_job_state_after_event)

    def _on_job_event(self, event: dict) -> None:
        """Единый event-driven вход изменения состояния Job в Hub."""
        event_type = EventBus.normalize_type(event.get("type", ""))
        try:
            changed = self.job_manager.apply_event(event)
        except ValueError as exc:
            self.logger.warning(
                f"Hub отклонил событие {event_type} для Job "
                f"{event.get('job_id')}: {exc}"
            )
            return
        if not changed:
            return

        job_id = event.get("job_id")
        job = self.job_manager.get(str(job_id)) if job_id else None
        if job is None:
            return

        # Worker отправляет запросы, Hub превращает их в канонические события.
        if event_type == EventType.JOB_STATE_REQUESTED.value:
            self.events.publish(
                EventType.JOB_STATE_CHANGED,
                source="hub",
                correlation_id=event.get("correlation_id"),
                job=job.to_dict(),
                worker_id=event.get("worker_id"),
                state=job.state.value,
            )
        elif event_type == EventType.JOB_PROGRESS_REQUESTED.value:
            self.events.publish(
                EventType.JOB_PROGRESS,
                source="hub",
                correlation_id=event.get("correlation_id"),
                job=job.to_dict(),
                worker_id=event.get("worker_id"),
            )

    def _publish_state_after_event(self, event: dict) -> None:
        """Отправить актуальный state snapshot в Event Bus после изменения состояния.

        Это presentation/transport событие: GUI/Web не вычисляют бизнес-состояние сами.
        LogMessage не дублируется полным snapshot, чтобы live-логи оставались дешёвыми.
        """
        event_type = EventBus.normalize_type(event.get("type", ""))
        if event_type == EventType.LOG_MESSAGE.value or event_type == "StateSnapshot":
            return
        stateful = {
            EventType.JOB_CREATED.value, EventType.JOB_QUEUED.value,
            EventType.JOB_STARTED.value, EventType.JOB_PROGRESS.value,
            EventType.JOB_COMPLETED.value, EventType.JOB_FAILED.value,
            EventType.JOB_CANCELLED.value, EventType.JOB_PRIORITY_CHANGED.value,
            EventType.JOB_RETRY.value, EventType.JOB_RESULT_UPDATED.value,
            EventType.JOB_ARTIFACT_ADDED.value, EventType.JOB_TELEGRAM_RECIPIENT_ADDED.value,
            EventType.WORKER_STARTED.value, EventType.WORKER_STOPPED.value,
            EventType.BROWSER_STARTED.value,
            EventType.BROWSER_STOPPED.value, EventType.BROWSER_CRASHED.value,
            EventType.HUB_STARTED.value, EventType.HUB_STOPPED.value,
            EventType.WORKER_POOL_STARTED.value, EventType.WORKER_POOL_STOPPED.value,
            EventType.JOB_STATE_CHANGED.value, EventType.COMPONENT_STATUS_CHANGED.value,
            EventType.JOB_RETRY_SCHEDULED.value, EventType.JOB_RETRY_READY.value,
            EventType.RESOURCE_THROTTLED.value, EventType.WORKER_STATE_CHANGED.value,
            EventType.WORKER_DRAINED.value, EventType.WORKER_UNDRAINED.value,
            EventType.JOB_STUCK.value, EventType.JOB_RECOVERY_STARTED.value,
            EventType.JOB_RECOVERY_SUCCEEDED.value, EventType.JOB_RECOVERY_FAILED.value,
            EventType.JOB_STUCK_TERMINATED.value,
            EventType.CIRCUIT_STATE_CHANGED.value, EventType.CIRCUIT_BLOCKED.value,
            EventType.CIRCUIT_PROBE_STARTED.value, EventType.CIRCUIT_PROBE_SUCCEEDED.value,
        }
        if event_type not in stateful:
            return
        try:
            self.events.publish(
                "StateSnapshot",
                source="state-manager",
                job_id=event.get("job_id"),
                state=self.snapshot(),
            )
        except Exception as exc:
            self.logger.debug(f"Не удалось опубликовать GUI state snapshot: {exc}")

    def _persist_job_state_after_event(self, event: dict) -> None:
        event_type = EventBus.normalize_type(event.get("type", ""))
        if event_type in {EventType.LOG_MESSAGE.value, "StateSnapshot", EventType.WORKER_HEARTBEAT.value}:
            return
        if event_type not in {
            EventType.JOB_CREATED.value, EventType.JOB_QUEUED.value, EventType.JOB_STARTED.value,
            EventType.JOB_PROGRESS.value, EventType.JOB_RETRY.value, EventType.JOB_COMPLETED.value,
            EventType.JOB_FAILED.value, EventType.JOB_CANCELLED.value, EventType.JOB_PRIORITY_CHANGED.value,
            EventType.JOB_RESULT_UPDATED.value, EventType.JOB_ARTIFACT_ADDED.value, EventType.JOB_STATE_CHANGED.value,
            EventType.JOB_STUCK.value, EventType.JOB_RECOVERY_STARTED.value, EventType.JOB_RECOVERY_SUCCEEDED.value,
            EventType.JOB_RECOVERY_FAILED.value, EventType.JOB_STUCK_TERMINATED.value,
            EventType.JOB_RETRY_SCHEDULED.value, EventType.JOB_RETRY_READY.value,
        }:
            return
        try:
            self.job_store.save(
                self.job_manager.persistence_snapshot(),
                process_version=self.state.version,
                recovery=self.job_manager.recovery_snapshot(),
            )
        except Exception as exc:
            self.logger.debug(f"JobStore: не удалось сохранить snapshot после {event_type}: {exc}")

    def _on_browser_crashed(self, event: dict) -> None:
        job_id = event.get("job_id")
        if not job_id:
            return
        job = self.job_manager.get(str(job_id))
        if job is None or job.state.value in {"COMPLETED", "FAILED", "CANCELLED"}:
            return
        self.events.publish(
            EventType.JOB_STATE_REQUESTED,
            source="hub",
            correlation_id=event.get("correlation_id"),
            worker_id=event.get("worker_id"),
            job_id=str(job_id),
            state="FAILED",
            stage="browser_failed",
            error=str(event.get("error") or "Chrome завершился с ошибкой"),
        )

    def _component_event(self, component: str, status: str):
        def handler(_event):
            self.state.set_component(component, status)
        return handler

    def set_job_handler(self, handler: Callable) -> None:
        """Назначить единый исполнитель Job; вызывается Application Manager."""
        self._handler = handler
        self.job_manager.set_handler(handler)

    def start(self) -> None:
        self.live_events.start()
        self.state.set_component("hub", "online")
        recovery = self.job_manager.restore_persisted_jobs(current_version=self.state.version)
        if recovery.get("recovered") or recovery.get("history_restored"):
            self.logger.info(
                "Восстановление Job после перезапуска: "
                f"queued={recovery.get('recovered', 0)}, history={recovery.get('history_restored', 0)}"
            )
        self.job_manager.start()
        self.events.publish(EventType.HUB_STARTED, source="hub", component="hub", status="online")

    def stop(self, cancel_pending: bool = True) -> None:
        self.job_manager.stop(cancel_pending=cancel_pending)
        self.state.set_component("hub", "offline")
        self.events.publish(EventType.HUB_STOPPED, source="hub", component="hub", status="offline")
        self.live_events.stop()

    def create_job(
        self, url: str, *, mode: str = "collect", user_name: str = "",
        telegram_chat_id: str | None = None,
        priority: JobPriority = JobPriority.NORMAL,
        queue_type: QueueType = QueueType.TEST_QUEUE,
        metadata: Optional[dict] = None,
        idempotency_key: str | None = None,
    ) -> Job:
        if not str(url).strip():
            raise ValueError("URL не задан")
        try:
            from .config import load_settings
            runtime_settings = load_settings()
        except Exception:
            runtime_settings = {}
        job_metadata = dict(metadata or {})
        job_metadata.setdefault("retry_max_attempts", runtime_settings.get("retry_max_attempts", 3))
        job_metadata.setdefault("retry_backoff_sec", runtime_settings.get("retry_backoff_sec", 5))
        job_metadata.setdefault("retry_backoff_max_sec", runtime_settings.get("retry_backoff_max_sec", 120))
        job_metadata.setdefault("retry_policy", runtime_settings.get("retry_policy", "auto"))
        return self.job_manager.create_job(
            url=str(url).strip(),
            mode=mode,
            user_name=user_name,
            telegram_chat_id=telegram_chat_id,
            priority=priority,
            queue_type=queue_type,
            metadata=job_metadata,
            idempotency_key=idempotency_key,
        )

    def submit_job(self, **kwargs) -> Job:
        return self.create_job(**kwargs)

    def cancel_job(self, job_id: str) -> bool:
        return self.job_manager.cancel(job_id)

    def cancel_all(self) -> int:
        return self.job_manager.cancel_all()

    def clear_pending(self) -> int:
        return self.job_manager.clear_pending()

    def retry_job(self, job_id: str) -> Optional[Job]:
        return self.job_manager.retry(job_id)

    def set_priority(self, job_id: str, priority: JobPriority) -> bool:
        return self.job_manager.set_priority(job_id, priority)

    def mark_job_stuck(self, job_id: str, **kwargs) -> bool:
        return self.job_manager.mark_job_stuck(job_id, **kwargs)

    def recover_stuck_job(self, job_id: str, **kwargs) -> bool:
        return self.job_manager.recover_stuck_job(job_id, **kwargs)

    def terminate_stuck_job(self, job_id: str, **kwargs) -> bool:
        return self.job_manager.terminate_stuck_job(job_id, **kwargs)

    def circuit_snapshot(self) -> dict:
        return self.circuit_breaker.snapshot()

    def circuit_status(self, url_or_site: str) -> dict:
        return self.circuit_breaker.status(url_or_site)

    def reset_circuit(self, url_or_site: str) -> bool:
        return self.circuit_breaker.reset(url_or_site)

    def queue_snapshot(self, queue_type: QueueType | str | None = None) -> dict:
        return self.job_manager.queue_snapshot(queue_type)

    def queue_position(self, job_id: str) -> Optional[int]:
        return self.job_manager.get_queue_position(job_id)

    def waiting_seconds(self, job_id: str) -> Optional[float]:
        return self.job_manager.get_waiting_seconds(job_id)

    def get_job_progress(self, job_id: str) -> Optional[dict]:
        """Канонический live-прогресс конкретной Job."""
        return self.job_manager.get_progress(job_id)

    def get_all_job_progress(self) -> dict[str, dict]:
        """Канонический live-прогресс всех Job."""
        return self.job_manager.get_progress_snapshot()

    def set_queue_handler(self, queue_type: QueueType | str, handler: Callable) -> None:
        self.job_manager.set_queue_handler(queue_type, handler)

    def submit_operation(self, queue_type: QueueType | str, operation: str, **kwargs) -> Job:
        return self.job_manager.submit_operation(queue_type, operation, **kwargs)

    def update_job(self, job: Job, *args, **kwargs) -> None:
        self.job_manager.update(job, *args, **kwargs)

    def set_result(self, job_id: str, **values) -> bool:
        return self.job_manager.set_result(job_id, **values)

    def add_artifact(self, job_id: str, path) -> bool:
        return self.job_manager.add_artifact(job_id, path)

    def get_job(self, job_id: str) -> Optional[Job]:
        return self.job_manager.get(job_id)

    def drain_worker(self, worker_id: str) -> bool:
        return self.job_manager.drain_worker(worker_id)

    def undrain_worker(self, worker_id: str) -> bool:
        return self.job_manager.undrain_worker(worker_id)

    def diagnostics_archive(self, job_id: str):
        return self.diagnostics_manager.get_archive(str(job_id))

    def snapshot(self) -> dict:
        snapshot = self.state.snapshot(self.job_manager.snapshot())
        try:
            from .statistics import snapshot as statistics_snapshot
            snapshot["statistics"] = statistics_snapshot()
        except Exception:
            snapshot.setdefault("statistics", {})
        try:
            snapshot["circuit_breakers"] = self.circuit_breaker.snapshot()
        except Exception:
            snapshot.setdefault("circuit_breakers", {})
        snapshot["recovery"] = self.job_manager.recovery_snapshot()
        snapshot["resource"] = self.resource_manager.snapshot()
        try:
            from .metrics import snapshot as metrics_snapshot
            snapshot["metrics"] = metrics_snapshot()
        except Exception:
            snapshot.setdefault("metrics", {})
        try:
            snapshot["idempotency"] = self.idempotency_store.snapshot()
        except Exception:
            snapshot.setdefault("idempotency", {})
        return snapshot

    # queue_snapshot выше принимает необязательный тип очереди и делегирует в JobManager.
