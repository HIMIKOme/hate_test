"""Circuit Breaker для проблемных сайтов.

Центрально блокирует новые TEST_QUEUE Job для сайта, если он систематически
завершает задания с ошибками. Состояние сохраняется между перезапусками,
а после cooldown разрешается ровно одна контрольная Job (probe).
"""
from __future__ import annotations

import json
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urlsplit

from .event_bus import EventBus, EventType


class CircuitState(str, Enum):
    NORMAL = "normal"
    PROBLEMATIC = "problematic"
    TEMPORARILY_BLOCKED = "temporarily_blocked"


class CircuitOpenError(RuntimeError):
    """Новая Job запрещена Circuit Breaker."""

    def __init__(self, site: str, *, blocked_until: Optional[float] = None, probe_in_flight: bool = False):
        self.site = site
        self.blocked_until = blocked_until
        self.probe_in_flight = probe_in_flight
        if probe_in_flight:
            reason = f"Сайт {site} временно заблокирован: уже выполняется контрольная попытка."
        elif blocked_until:
            remaining = max(0, int(round(blocked_until - time.time())))
            reason = f"Сайт {site} временно заблокирован Circuit Breaker ещё примерно на {remaining} сек."
        else:
            reason = f"Сайт {site} временно заблокирован Circuit Breaker."
        super().__init__(reason)


@dataclass
class SiteCircuit:
    site: str
    state: CircuitState = CircuitState.NORMAL
    failures: list[float] = field(default_factory=list)
    failure_count_total: int = 0
    success_count_total: int = 0
    blocked_until: Optional[float] = None
    probe_in_flight: bool = False
    probe_job_id: Optional[str] = None
    last_failure_at: Optional[float] = None
    last_success_at: Optional[float] = None
    last_error: str = ""
    updated_at: float = field(default_factory=time.time)

    def prune(self, now: float, window_sec: float) -> None:
        cutoff = now - max(1.0, float(window_sec))
        self.failures = [stamp for stamp in self.failures if stamp >= cutoff]

    def to_dict(self, now: Optional[float] = None) -> dict[str, Any]:
        now = time.time() if now is None else float(now)
        remaining = max(0.0, (self.blocked_until or 0.0) - now)
        return {
            "site": self.site,
            "state": self.state.value,
            "failure_count": len(self.failures),
            "failure_count_total": self.failure_count_total,
            "success_count_total": self.success_count_total,
            "blocked_until": self.blocked_until,
            "blocked_remaining_sec": round(remaining, 1) if remaining else 0.0,
            "probe_in_flight": self.probe_in_flight,
            "probe_job_id": self.probe_job_id,
            "last_failure_at": self.last_failure_at,
            "last_success_at": self.last_success_at,
            "last_error": self.last_error,
            "updated_at": self.updated_at,
        }


class CircuitBreaker:
    """Потокобезопасный Circuit Breaker для всех TEST_QUEUE Job."""

    def __init__(
        self,
        event_bus: EventBus,
        logger=None,
        *,
        data_path: Optional[Path] = None,
        failure_threshold: int = 3,
        window_sec: float = 300.0,
        cooldown_sec: float = 120.0,
    ):
        self.events = event_bus
        self.logger = logger
        self.data_path = Path(data_path) if data_path else None
        self.failure_threshold = max(2, int(failure_threshold))
        self.window_sec = max(10.0, float(window_sec))
        self.cooldown_sec = max(5.0, float(cooldown_sec))
        self._lock = threading.RLock()
        self._sites: dict[str, SiteCircuit] = {}
        self._load()
        self._subscriptions = self.events.subscribe_many(
            (EventType.JOB_COMPLETED, EventType.JOB_FAILED, EventType.JOB_CANCELLED),
            self._on_job_terminal,
        )

    # ------------------------- URL/site ---------------------------------
    @staticmethod
    def site_key(url: str) -> str:
        """Вернуть канонический host для одного сайта.

        HTTP(S) используется как единая площадка: scheme не разделяет circuit.
        Порт игнорируется, чтобы http/https и стандартный port считались одним
        логическим сайтом.
        """
        raw = str(url or "").strip()
        if not raw:
            return ""
        try:
            parsed = urlsplit(raw)
            host = (parsed.hostname or "").strip().lower().rstrip(".")
            if not host:
                return ""
            try:
                host = host.encode("idna").decode("ascii")
            except UnicodeError:
                pass
            return host
        except Exception:
            return ""

    # ------------------------- persistence ------------------------------
    def _load(self) -> None:
        if self.data_path is None or not self.data_path.exists():
            return
        try:
            payload = json.loads(self.data_path.read_text(encoding="utf-8"))
            sites = payload.get("sites") if isinstance(payload, dict) else None
            if not isinstance(sites, dict):
                return
            with self._lock:
                for site, raw in sites.items():
                    if not isinstance(raw, dict):
                        continue
                    state = raw.get("state", CircuitState.NORMAL.value)
                    try:
                        circuit_state = CircuitState(state)
                    except ValueError:
                        circuit_state = CircuitState.NORMAL
                    item = SiteCircuit(
                        site=str(site),
                        state=circuit_state,
                        failures=[float(x) for x in raw.get("failures", []) if isinstance(x, (int, float))],
                        failure_count_total=int(raw.get("failure_count_total", 0) or 0),
                        success_count_total=int(raw.get("success_count_total", 0) or 0),
                        blocked_until=float(raw["blocked_until"]) if raw.get("blocked_until") is not None else None,
                        probe_in_flight=False,  # probe does not survive process restart
                        probe_job_id=None,
                        last_failure_at=float(raw["last_failure_at"]) if raw.get("last_failure_at") is not None else None,
                        last_success_at=float(raw["last_success_at"]) if raw.get("last_success_at") is not None else None,
                        last_error=str(raw.get("last_error") or ""),
                        updated_at=float(raw.get("updated_at", time.time()) or time.time()),
                    )
                    self._sites[item.site] = item
        except Exception as exc:
            if self.logger:
                self.logger.warning(f"Circuit Breaker: не удалось загрузить состояние: {exc}")

    def _save_locked(self) -> None:
        if self.data_path is None:
            return
        try:
            self.data_path.parent.mkdir(parents=True, exist_ok=True)
            now = time.time()
            payload = {
                "version": 1,
                "updated_at": now,
                "settings": {
                    "failure_threshold": self.failure_threshold,
                    "window_sec": self.window_sec,
                    "cooldown_sec": self.cooldown_sec,
                },
                "sites": {},
            }
            for site, item in self._sites.items():
                item.prune(now, self.window_sec)
                data = item.to_dict(now)
                # runtime-only values не нужны после перезапуска.
                data["probe_in_flight"] = False
                data["probe_job_id"] = None
                payload["sites"][site] = data
            tmp = self.data_path.with_suffix(".tmp")
            tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            tmp.replace(self.data_path)
        except OSError as exc:
            if self.logger:
                self.logger.warning(f"Circuit Breaker: не удалось сохранить состояние: {exc}")

    # ------------------------- admission --------------------------------
    def admit(self, url: str) -> dict[str, Any]:
        """Проверить можно ли создать новую Job.

        Возвращает служебные metadata. При открытом circuit бросает
        ``CircuitOpenError``. После cooldown допускается только одна probe Job.
        """
        site = self.site_key(url)
        if not site:
            return {"site": "", "probe": False}

        event_payload: Optional[dict[str, Any]] = None
        now = time.time()
        with self._lock:
            item = self._sites.setdefault(site, SiteCircuit(site=site))
            item.prune(now, self.window_sec)

            if item.state == CircuitState.TEMPORARILY_BLOCKED:
                if item.blocked_until and now < item.blocked_until:
                    raise CircuitOpenError(site, blocked_until=item.blocked_until, probe_in_flight=item.probe_in_flight)
                if item.probe_in_flight:
                    raise CircuitOpenError(site, blocked_until=item.blocked_until, probe_in_flight=True)
                # cooldown завершён — ровно одна контрольная попытка.
                item.probe_in_flight = True
                item.probe_job_id = None
                item.updated_at = now
                event_payload = {
                    "site": site,
                    "state": item.state.value,
                    "probe": True,
                    "failure_count": len(item.failures),
                    "blocked_until": item.blocked_until,
                }
                self._save_locked()
                metadata = {
                    "circuit_site": site,
                    "circuit_probe": True,
                    "circuit_failure_count_at_admission": len(item.failures),
                    "probe": True,
                }
            else:
                metadata = {
                    "circuit_site": site,
                    "circuit_probe": False,
                    "circuit_failure_count_at_admission": len(item.failures),
                    "probe": False,
                }
                if item.state == CircuitState.PROBLEMATIC and len(item.failures) == 0:
                    item.state = CircuitState.NORMAL
                    item.updated_at = now
                self._save_locked()

        if event_payload is not None:
            self.events.publish(EventType.CIRCUIT_PROBE_STARTED, source="circuit-breaker", **event_payload)
        return metadata

    def abort_admission(self, url: str, *, probe: bool = False, reason: str = "submit_failed") -> None:
        if not probe:
            return
        site = self.site_key(url)
        if not site:
            return
        with self._lock:
            item = self._sites.get(site)
            if not item:
                return
            item.probe_in_flight = False
            item.probe_job_id = None
            item.updated_at = time.time()
            self._save_locked()

    def attach_job(self, job) -> None:
        site = self.site_key(getattr(job, "url", ""))
        if not site:
            return
        if not isinstance(getattr(job, "metadata", None), dict):
            job.metadata = {}
        job.metadata["circuit_site"] = site
        is_probe = bool(job.metadata.get("circuit_probe"))
        if is_probe:
            with self._lock:
                item = self._sites.setdefault(site, SiteCircuit(site=site))
                item.probe_in_flight = True
                item.probe_job_id = str(job.id)
                item.updated_at = time.time()
                self._save_locked()

    # ------------------------- terminal events --------------------------
    def _on_job_terminal(self, event: dict[str, Any]) -> None:
        job = event.get("job")
        if not isinstance(job, dict):
            return
        if str(job.get("queue_type") or "TEST_QUEUE") != "TEST_QUEUE":
            return
        url = str(job.get("url") or "")
        site = self.site_key(url)
        if not site:
            return
        event_type = EventBus.normalize_type(event.get("type", ""))
        if event_type == EventType.JOB_COMPLETED.value:
            self.record_success(site, job_id=str(job.get("id") or ""), probe=bool((job.get("metadata") or {}).get("circuit_probe")))
        elif event_type == EventType.JOB_FAILED.value:
            error = str(event.get("error") or job.get("error_reason") or job.get("error") or "Job failed")
            self.record_failure(site, error=error, job_id=str(job.get("id") or ""), probe=bool((job.get("metadata") or {}).get("circuit_probe")))
        elif event_type == EventType.JOB_CANCELLED.value:
            self.record_cancelled(site, job_id=str(job.get("id") or ""), probe=bool((job.get("metadata") or {}).get("circuit_probe")))

    def record_failure(self, site_or_url: str, *, error: str = "", job_id: str = "", probe: bool = False) -> None:
        site = self.site_key(site_or_url) if "://" in str(site_or_url) else str(site_or_url).strip().lower()
        if not site:
            return
        now = time.time()
        event_type: Optional[EventType] = None
        payload: dict[str, Any]
        with self._lock:
            item = self._sites.setdefault(site, SiteCircuit(site=site))
            item.prune(now, self.window_sec)
            item.failures.append(now)
            item.failure_count_total += 1
            item.last_failure_at = now
            item.last_error = str(error or "")[-1000:]
            item.updated_at = now
            item.probe_in_flight = False
            item.probe_job_id = None
            if len(item.failures) >= self.failure_threshold:
                item.state = CircuitState.TEMPORARILY_BLOCKED
                item.blocked_until = now + self.cooldown_sec
                event_type = EventType.CIRCUIT_BLOCKED
            else:
                item.state = CircuitState.PROBLEMATIC
                item.blocked_until = None
                event_type = EventType.CIRCUIT_STATE_CHANGED
            self._save_locked()
            payload = item.to_dict(now)
            payload.update({"job_id": job_id, "error": str(error or ""), "probe": bool(probe)})
        self.events.publish(event_type, source="circuit-breaker", **payload)

    def record_success(self, site_or_url: str, *, job_id: str = "", probe: bool = False) -> None:
        site = self.site_key(site_or_url) if "://" in str(site_or_url) else str(site_or_url).strip().lower()
        if not site:
            return
        now = time.time()
        with self._lock:
            item = self._sites.setdefault(site, SiteCircuit(site=site))
            had_failures = bool(item.failures) or item.state != CircuitState.NORMAL
            item.failures.clear()
            item.success_count_total += 1
            item.last_success_at = now
            item.last_error = ""
            item.blocked_until = None
            item.probe_in_flight = False
            item.probe_job_id = None
            item.state = CircuitState.NORMAL
            item.updated_at = now
            self._save_locked()
            payload = item.to_dict(now)
            payload.update({"job_id": job_id, "probe": bool(probe), "recovered": had_failures})
        self.events.publish(EventType.CIRCUIT_PROBE_SUCCEEDED if probe and had_failures else EventType.CIRCUIT_STATE_CHANGED, source="circuit-breaker", **payload)

    def record_cancelled(self, site_or_url: str, *, job_id: str = "", probe: bool = False) -> None:
        site = self.site_key(site_or_url) if "://" in str(site_or_url) else str(site_or_url).strip().lower()
        if not site or not probe:
            return
        now = time.time()
        with self._lock:
            item = self._sites.setdefault(site, SiteCircuit(site=site))
            item.probe_in_flight = False
            item.probe_job_id = None
            item.blocked_until = now + self.cooldown_sec
            item.state = CircuitState.TEMPORARILY_BLOCKED
            item.updated_at = now
            self._save_locked()
            payload = item.to_dict(now)
            payload.update({"job_id": job_id, "cancelled_probe": True})
        self.events.publish(EventType.CIRCUIT_BLOCKED, source="circuit-breaker", **payload)

    # ------------------------- queries ----------------------------------
    def status(self, url_or_site: str) -> dict[str, Any]:
        site = self.site_key(url_or_site) if "://" in str(url_or_site) else str(url_or_site or "").strip().lower()
        if not site:
            return {"site": "", "state": CircuitState.NORMAL.value}
        now = time.time()
        with self._lock:
            item = self._sites.get(site)
            if item is None:
                return {
                    "site": site,
                    "state": CircuitState.NORMAL.value,
                    "failure_count": 0,
                    "blocked_until": None,
                    "blocked_remaining_sec": 0.0,
                    "probe_in_flight": False,
                }
            item.prune(now, self.window_sec)
            # Если cooldown прошёл, UI показывает blocked до первой probe; admission
            # превратит следующую Job в контрольную попытку.
            return item.to_dict(now)

    def snapshot(self) -> dict[str, Any]:
        now = time.time()
        with self._lock:
            result = {}
            for site, item in sorted(self._sites.items()):
                item.prune(now, self.window_sec)
                result[site] = item.to_dict(now)
            return {
                "enabled": True,
                "failure_threshold": self.failure_threshold,
                "window_sec": self.window_sec,
                "cooldown_sec": self.cooldown_sec,
                "sites": result,
            }

    def reset(self, site_or_url: str) -> bool:
        site = self.site_key(site_or_url) if "://" in str(site_or_url) else str(site_or_url or "").strip().lower()
        if not site:
            return False
        now = time.time()
        with self._lock:
            if site not in self._sites:
                return False
            item = self._sites[site]
            item.state = CircuitState.NORMAL
            item.failures.clear()
            item.blocked_until = None
            item.probe_in_flight = False
            item.probe_job_id = None
            item.updated_at = now
            self._save_locked()
            payload = item.to_dict(now)
        self.events.publish(EventType.CIRCUIT_STATE_CHANGED, source="web", **payload, manual_reset=True)
        return True

    def close(self) -> None:
        for token in list(self._subscriptions):
            self.events.unsubscribe(token)
        self._subscriptions.clear()
