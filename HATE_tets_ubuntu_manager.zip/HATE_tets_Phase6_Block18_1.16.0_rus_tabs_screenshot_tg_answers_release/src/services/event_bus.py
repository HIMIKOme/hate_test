"""Типизированная внутренняя Event Bus для всех компонентов HATE_tets.

Шина является транспортом событий, а не владельцем бизнес-состояния. Компоненты
публикуют события и подписываются на них; подписчики никогда не получают
внутренние объекты Worker.
"""
from __future__ import annotations

import threading
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, Iterable, Optional


class EventType(str, Enum):
    # Обязательные системные события Block 6.
    JOB_CREATED = "JobCreated"
    JOB_STARTED = "JobStarted"
    JOB_PROGRESS = "JobProgress"
    JOB_RETRY = "JobRetry"
    JOB_COMPLETED = "JobCompleted"
    JOB_FAILED = "JobFailed"
    WORKER_STARTED = "WorkerStarted"
    WORKER_STOPPED = "WorkerStopped"
    BROWSER_STARTED = "BrowserStarted"
    BROWSER_CRASHED = "BrowserCrashed"

    # Канонические/вспомогательные события приложения.
    JOB_QUEUED = "JobQueued"
    JOB_STATE_CHANGED = "JobStateChanged"
    JOB_CANCELLED = "JobCancelled"
    JOB_PRIORITY_CHANGED = "JobPriorityChanged"
    JOB_RESULT_UPDATED = "JobResultUpdated"
    JOB_ARTIFACT_ADDED = "JobArtifactAdded"
    JOB_TELEGRAM_RECIPIENT_ADDED = "JobTelegramRecipientAdded"
    JOBS_RECOVERED_AFTER_RESTART = "JobsRecoveredAfterRestart"
    JOB_STUCK = "JobStuck"
    JOB_RECOVERY_STARTED = "JobRecoveryStarted"
    JOB_RECOVERY_SUCCEEDED = "JobRecoverySucceeded"
    JOB_RECOVERY_FAILED = "JobRecoveryFailed"
    JOB_STUCK_TERMINATED = "JobStuckTerminated"
    JOB_STATE_REQUESTED = "JobStateRequested"
    JOB_PROGRESS_REQUESTED = "JobProgressRequested"
    WORKER_HEARTBEAT = "WorkerHeartbeat"
    BROWSER_STOPPED = "BrowserStopped"
    HUB_STARTED = "HubStarted"
    HUB_STOPPED = "HubStopped"
    WORKER_POOL_STARTED = "WorkerPoolStarted"
    WORKER_POOL_STOPPED = "WorkerPoolStopped"
    LOG_MESSAGE = "LogMessage"
    COMPONENT_STATUS_CHANGED = "ComponentStatusChanged"
    CIRCUIT_STATE_CHANGED = "CircuitStateChanged"
    CIRCUIT_BLOCKED = "CircuitBlocked"
    CIRCUIT_PROBE_STARTED = "CircuitProbeStarted"
    CIRCUIT_PROBE_SUCCEEDED = "CircuitProbeSucceeded"
    JOB_RETRY_SCHEDULED = "JobRetryScheduled"
    JOB_RETRY_READY = "JobRetryReady"
    RESOURCE_THROTTLED = "ResourceThrottled"
    WORKER_STATE_CHANGED = "WorkerStateChanged"
    WORKER_DRAINED = "WorkerDrained"
    WORKER_UNDRAINED = "WorkerUndrained"


@dataclass(frozen=True)
class Event:
    """Неизменяемый конверт события. Payload остаётся совместимым со старым API."""

    type: str
    timestamp: float = field(default_factory=time.time)
    event_id: str = field(default_factory=lambda: f"evt-{uuid.uuid4().hex[:16]}")
    source: str = "system"
    correlation_id: Optional[str] = None
    payload: Dict[str, Any] = field(default_factory=dict)

    @property
    def job_id(self) -> Optional[str]:
        value = self.payload.get("job_id")
        if value:
            return str(value)
        job = self.payload.get("job")
        if isinstance(job, dict) and job.get("id"):
            return str(job["id"])
        return None

    @property
    def worker_id(self) -> Optional[str]:
        value = self.payload.get("worker_id")
        return str(value) if value is not None else None

    def to_dict(self) -> dict[str, Any]:
        data = dict(self.payload)
        data.update({
            "type": self.type,
            "timestamp": self.timestamp,
            "event_id": self.event_id,
            "source": self.source,
        })
        if self.correlation_id:
            data["correlation_id"] = self.correlation_id
        if self.job_id and "job_id" not in data:
            data["job_id"] = self.job_id
        if self.worker_id and "worker_id" not in data:
            data["worker_id"] = self.worker_id
        return data


Callback = Callable[[dict[str, Any]], None]


class EventBus:
    """Потокобезопасная pub/sub шина с wildcard-подписками.

    Callbacks получают обычный dict, поэтому существующие подписчики остаются
    совместимыми. Список подписчиков копируется под lock и вызывается вне lock,
    чтобы медленный потребитель не блокировал публикацию другим потребителям.
    """

    WILDCARD = "*"

    def __init__(self, logger=None):
        self.logger = logger
        self._subs: Dict[str, Dict[str, Callback]] = {}
        self._lock = threading.RLock()

    @staticmethod
    def normalize_type(event_type: str | EventType) -> str:
        if isinstance(event_type, EventType):
            return event_type.value
        value = str(event_type or "").strip()
        if not value:
            raise ValueError("Тип события не задан")
        return value

    def subscribe(
        self,
        event_type: str | EventType,
        callback: Callback,
    ) -> str:
        if not callable(callback):
            raise TypeError("EventBus callback должен быть callable")
        key = self.normalize_type(event_type)
        token = f"sub-{uuid.uuid4().hex[:12]}"
        with self._lock:
            self._subs.setdefault(key, {})[token] = callback
        return token

    def subscribe_many(self, event_types: Iterable[str | EventType], callback: Callback) -> list[str]:
        return [self.subscribe(event_type, callback) for event_type in event_types]

    def subscribe_all(self, callback: Callback) -> str:
        return self.subscribe(self.WILDCARD, callback)

    def unsubscribe(self, token: str) -> bool:
        with self._lock:
            for callbacks in self._subs.values():
                if token in callbacks:
                    del callbacks[token]
                    return True
        return False

    def publish(
        self,
        event_type: str | EventType,
        *,
        source: str = "system",
        correlation_id: Optional[str] = None,
        timestamp: Optional[float] = None,
        event: Optional[Event] = None,
        **data: Any,
    ) -> dict[str, Any]:
        if event is not None:
            if not isinstance(event, Event):
                raise TypeError("event должен быть экземпляром Event")
            envelope = event
        else:
            key = self.normalize_type(event_type)
            payload = dict(data)
            job = payload.get("job")
            if isinstance(job, dict) and job.get("id"):
                payload.setdefault("job_id", str(job["id"]))
            envelope = Event(
                type=key,
                timestamp=time.time() if timestamp is None else float(timestamp),
                source=str(source or "system"),
                correlation_id=correlation_id,
                payload=payload,
            )

        payload_dict = envelope.to_dict()
        with self._lock:
            callbacks = [
                *self._subs.get(envelope.type, {}).values(),
                *self._subs.get(self.WILDCARD, {}).values(),
            ]

        for callback in callbacks:
            try:
                callback(dict(payload_dict))
            except Exception as exc:  # noqa: BLE001
                if self.logger:
                    try:
                        self.logger.warning(
                            f"EventBus {envelope.type} subscriber failed: {exc}"
                        )
                    except Exception:
                        pass
        return payload_dict
