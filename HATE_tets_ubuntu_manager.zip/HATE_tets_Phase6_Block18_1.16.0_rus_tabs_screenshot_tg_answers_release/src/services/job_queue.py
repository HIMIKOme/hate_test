"""Централизованные очереди Job с приоритетом и aging.

Очередь не владеет выполнением Job. Она только отвечает за хранение ожидающих
Job, вычисление эффективного приоритета и выдачу следующего элемента.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Iterable, Optional

from .job import Job, JobPriority, QueueType


# Через каждые 5 минут ожидания Job получает +1 к эффективному приоритету.
# Это достаточно плавный aging и одновременно сохраняет исходную иерархию
# приоритетов на коротком горизонте.
AGING_INTERVAL_SECONDS = 300.0
AGING_BOOST_PER_INTERVAL = 1.0


@dataclass(frozen=True)
class QueueItem:
    job: Job
    effective_priority: float
    waiting_seconds: float
    position: int


class PriorityJobQueue:
    """Очередь одного типа операций.

    Сортировка выполняется непосредственно перед выдачей/снимком, поэтому
    изменение возраста Job не требует периодического обслуживания heap.
    """

    def __init__(self, queue_type: QueueType):
        self.queue_type = QueueType(queue_type)
        self._jobs: dict[str, Job] = {}

    @property
    def size(self) -> int:
        return len(self._jobs)

    def put(self, job: Job) -> None:
        if job.queue_type != self.queue_type:
            raise ValueError(
                f"Job {job.id} относится к {job.queue_type.value}, "
                f"а добавляется в {self.queue_type.value}"
            )
        if job.id in self._jobs:
            raise ValueError(f"Job ID уже находится в очереди: {job.id}")
        self._jobs[job.id] = job

    def remove(self, job_id: str) -> Optional[Job]:
        return self._jobs.pop(str(job_id), None)

    def contains(self, job_id: str) -> bool:
        return str(job_id) in self._jobs

    def get(self, job_id: str) -> Optional[Job]:
        return self._jobs.get(str(job_id))

    def _effective_priority(self, job: Job, now: float) -> float:
        return job.effective_priority(
            now=now,
            aging_interval=AGING_INTERVAL_SECONDS,
            aging_boost=AGING_BOOST_PER_INTERVAL,
        )

    def _sorted_jobs(self, now: Optional[float] = None) -> list[Job]:
        now = time.time() if now is None else float(now)
        return sorted(
            self._jobs.values(),
            key=lambda job: (
                -self._effective_priority(job, now),
                job.created_at,
                job.id,
            ),
        )

    def peek_all(self, now: Optional[float] = None) -> list[QueueItem]:
        now = time.time() if now is None else float(now)
        jobs = self._sorted_jobs(now)
        return [
            QueueItem(
                job=job,
                effective_priority=round(self._effective_priority(job, now), 3),
                waiting_seconds=round(job.waiting_seconds_at(now), 1),
                position=index,
            )
            for index, job in enumerate(jobs, start=1)
        ]

    def peek(self, now: Optional[float] = None) -> Optional[Job]:
        ordered = self._sorted_jobs(now)
        return ordered[0] if ordered else None

    def pop(self, now: Optional[float] = None) -> Optional[Job]:
        job = self.peek(now)
        if job is None:
            return None
        self._jobs.pop(job.id, None)
        return job

    def position(self, job_id: str, now: Optional[float] = None) -> Optional[int]:
        for item in self.peek_all(now):
            if item.job.id == str(job_id):
                return item.position
        return None

    def requeue(self, job: Job) -> None:
        if job.id in self._jobs:
            return
        self.put(job)

    def all_jobs(self) -> list[Job]:
        return list(self._jobs.values())

    def clear(self) -> list[Job]:
        jobs = list(self._jobs.values())
        self._jobs.clear()
        return jobs

    def snapshot(self, now: Optional[float] = None) -> list[dict]:
        items = self.peek_all(now)
        return [
            {
                **item.job.to_dict(),
                "queue_position": item.position,
                "effective_priority": item.effective_priority,
                "waiting_seconds": item.waiting_seconds,
            }
            for item in items
        ]

    def __iter__(self) -> Iterable[Job]:
        return iter(self._jobs.values())
