"""Crash-safe persistence для канонического состояния Job.

Хранилище не является владельцем JobManager: оно только атомарно сохраняет
сериализованный снимок Job и позволяет восстановить очередь после падения
основного процесса.
"""
from __future__ import annotations

import json
import os
import tempfile
import threading
import time
from pathlib import Path
from typing import Any, Iterable

SCHEMA_VERSION = 1
DEFAULT_MAX_HISTORY = 100


class JobStore:
    """Потокобезопасное атомарное JSON-хранилище Job."""

    def __init__(self, path: Path, *, max_history: int = DEFAULT_MAX_HISTORY, logger=None):
        self.path = Path(path)
        self.max_history = max(20, int(max_history))
        self.logger = logger
        self._lock = threading.RLock()

    def load(self) -> dict[str, Any]:
        """Загрузить снимок; повреждённый файл безопасно считается пустым."""
        with self._lock:
            try:
                payload = json.loads(self.path.read_text(encoding="utf-8"))
            except FileNotFoundError:
                return self._empty()
            except (OSError, ValueError, TypeError) as exc:
                if self.logger:
                    self.logger.warning(f"JobStore: не удалось прочитать {self.path}: {exc}")
                return self._empty()
            if not isinstance(payload, dict) or payload.get("schema_version") != SCHEMA_VERSION:
                if self.logger:
                    self.logger.warning("JobStore: неизвестная схема состояния Job; начинаю с пустого снимка.")
                return self._empty()
            jobs = payload.get("jobs")
            if not isinstance(jobs, list):
                jobs = []
            return {
                "schema_version": SCHEMA_VERSION,
                "updated_at": float(payload.get("updated_at", 0) or 0),
                "process_version": str(payload.get("process_version") or ""),
                "jobs": [item for item in jobs if isinstance(item, dict)],
                "recovery": dict(payload.get("recovery") or {}) if isinstance(payload.get("recovery"), dict) else {},
            }

    def save(
        self,
        jobs: Iterable[dict[str, Any]],
        *,
        process_version: str = "",
        recovery: dict[str, Any] | None = None,
    ) -> None:
        """Атомарно сохранить Job-снимок через временный файл + replace + fsync."""
        payload_jobs = [dict(job) for job in jobs if isinstance(job, dict) and job.get("id")]
        payload_jobs.sort(key=lambda item: float(item.get("finished_at") or item.get("created_at") or 0), reverse=True)

        terminal_states = {"COMPLETED", "FAILED", "CANCELLED"}
        non_terminal = [job for job in payload_jobs if str(job.get("state") or "") not in terminal_states]
        terminal = [job for job in payload_jobs if str(job.get("state") or "") in terminal_states][: self.max_history]
        final_jobs = non_terminal + terminal

        payload = {
            "schema_version": SCHEMA_VERSION,
            "updated_at": time.time(),
            "process_version": str(process_version or ""),
            "jobs": final_jobs,
            "recovery": dict(recovery or {}),
        }
        raw = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True)

        with self._lock:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            fd, temp_name = tempfile.mkstemp(prefix=self.path.name + ".", suffix=".tmp", dir=str(self.path.parent))
            temp_path = Path(temp_name)
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as handle:
                    handle.write(raw)
                    handle.flush()
                    os.fsync(handle.fileno())
                temp_path.replace(self.path)
            except OSError as exc:
                try:
                    temp_path.unlink(missing_ok=True)
                except OSError:
                    pass
                if self.logger:
                    self.logger.warning(f"JobStore: не удалось сохранить {self.path}: {exc}")
                raise

    @staticmethod
    def _empty() -> dict[str, Any]:
        return {
            "schema_version": SCHEMA_VERSION,
            "updated_at": 0.0,
            "process_version": "",
            "jobs": [],
            "recovery": {},
        }
