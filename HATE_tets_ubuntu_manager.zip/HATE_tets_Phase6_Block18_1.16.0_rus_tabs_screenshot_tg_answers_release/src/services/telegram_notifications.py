"""Асинхронные Telegram-уведомления по Event Bus.

Telegram не владеет очередью и не управляет TestRunner. Компонент получает только
события конкретных Job через Event Bus, обновляет одно служебное сообщение и на
финале отправляет ответы обычными сообщениями в фоновом потоке.
"""
from __future__ import annotations

import queue
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, Iterable, Optional

from .event_bus import EventType
from .telegram import MAX_MESSAGE_LEN, edit_text, send_text


_STAGE_LABELS = {
    "checking_link": "проверка ссылки",
    "starting": "запуск",
    "browser_starting": "запуск браузера",
    "opening": "открытие теста",
    "testing": "прохождение вопросов",
    "collecting": "сбор ответов",
    "saving": "сохранение",
    "notifying": "подготовка результата",
    "completed": "завершение",
    "failed": "ошибка",
    "cancelling": "отмена",
    "cancelled": "отменено",
}

_TERMINAL = {
    EventType.JOB_COMPLETED.value,
    EventType.JOB_FAILED.value,
    EventType.JOB_CANCELLED.value,
}


@dataclass
class _JobChannel:
    chat_ids: set[str] = field(default_factory=set)
    service_message_ids: Dict[str, int] = field(default_factory=dict)
    last_render_at: Dict[str, float] = field(default_factory=dict)
    last_text: Dict[str, str] = field(default_factory=dict)
    last_event: dict = field(default_factory=dict)
    acceptance_text: str = "✅ Задание принято."
    answer_messages_sent: set[str] = field(default_factory=set)
    created_at: float = field(default_factory=time.time)


class TelegramJobNotifier:
    """Фоновый Event Bus subscriber для сообщений Telegram по Job."""

    def __init__(
        self,
        token_provider: Callable[[], str],
        logger=None,
        hub=None,
        min_edit_interval: float = 1.0,
    ) -> None:
        self._token_provider = token_provider
        self.logger = logger
        self.hub = hub
        self.min_edit_interval = max(0.1, float(min_edit_interval))
        self._lock = threading.RLock()
        self._channels: Dict[str, _JobChannel] = {}
        self._pending: Dict[str, dict] = {}
        self._scheduled: set[str] = set()
        self._queue: queue.Queue[str | None] = queue.Queue()
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._worker, name="telegram-job-notifier", daemon=True)
        self._subscriptions: list[str] = []
        if hub is not None:
            self._subscriptions = hub.events.subscribe_many(
                (
                    EventType.JOB_CREATED,
                    EventType.JOB_STARTED,
                    EventType.JOB_PROGRESS,
                    EventType.JOB_STATE_CHANGED,
                    EventType.JOB_RESULT_UPDATED,
                    EventType.JOB_COMPLETED,
                    EventType.JOB_FAILED,
                    EventType.JOB_CANCELLED,
                ),
                self._on_event,
            )
        self._thread.start()

    def _get_token(self) -> str:
        try:
            return str(self._token_provider() or "").strip()
        except Exception:
            return ""

    @staticmethod
    def _job_from_event(event: dict) -> dict:
        value = event.get("job")
        return dict(value) if isinstance(value, dict) else {}

    @staticmethod
    def _recipient_ids(job: dict, event: dict) -> set[str]:
        result: set[str] = set()
        for value in (
            job.get("telegram_chat_id"),
            event.get("telegram_chat_id"),
        ):
            if value is not None and str(value).strip():
                result.add(str(value).strip())
        metadata = job.get("metadata") if isinstance(job.get("metadata"), dict) else {}
        values = metadata.get("telegram_chat_ids") if isinstance(metadata, dict) else None
        if isinstance(values, (list, tuple, set)):
            result.update(str(v).strip() for v in values if str(v).strip())
        return result

    def register_job(
        self,
        job_id: str,
        chat_ids: Iterable[str],
        acceptance_text: str,
        job_snapshot: Optional[dict] = None,
    ) -> None:
        job_id = str(job_id or "").strip()
        if not job_id:
            return
        recipients = {str(cid).strip() for cid in chat_ids if str(cid).strip()}
        with self._lock:
            channel = self._channels.setdefault(job_id, _JobChannel())
            channel.chat_ids.update(recipients)
            channel.acceptance_text = acceptance_text or channel.acceptance_text
            # submit_job() публикует JobCreated/JobQueued до того, как TelegramBot
            # успевает зарегистрировать Job. Сохраняем текущий снимок, чтобы
            # быстро завершившийся Job всё равно получил финальное сообщение.
            if isinstance(job_snapshot, dict):
                snapshot = dict(job_snapshot)
                state = str(snapshot.get("state") or "QUEUED")
                event_type = {
                    "COMPLETED": EventType.JOB_COMPLETED.value,
                    "FAILED": EventType.JOB_FAILED.value,
                    "CANCELLED": EventType.JOB_CANCELLED.value,
                    "STARTING": EventType.JOB_STARTED.value,
                }.get(state, EventType.JOB_STATE_CHANGED.value)
                self._pending[job_id] = {
                    "type": event_type,
                    "job_id": job_id,
                    "job": snapshot,
                    "state": state,
                    "source": "telegram-register",
                }
        self._queue.put(job_id)

    def add_recipient(self, job_id: str, chat_id: str) -> None:
        job_id = str(job_id or "").strip()
        chat_id = str(chat_id or "").strip()
        if not job_id or not chat_id:
            return
        with self._lock:
            channel = self._channels.setdefault(job_id, _JobChannel())
            channel.chat_ids.add(chat_id)
            if not channel.last_event:
                channel.last_event = {
                    "type": EventType.JOB_QUEUED.value,
                    "job_id": job_id,
                }
        self._queue.put(job_id)

    def _on_event(self, event: dict) -> None:
        event = dict(event or {})
        job = self._job_from_event(event)
        job_id = str(event.get("job_id") or job.get("id") or "").strip()
        if not job_id:
            return

        recipients = self._recipient_ids(job, event)
        if not recipients:
            return

        with self._lock:
            channel = self._channels.setdefault(job_id, _JobChannel())
            channel.chat_ids.update(recipients)
            channel.last_event = event
            if event.get("type") == EventType.JOB_CREATED.value:
                channel.acceptance_text = "✅ Задание принято."
            self._pending[job_id] = event
            if job_id not in self._scheduled:
                self._scheduled.add(job_id)
                self._queue.put(job_id)

    def _take_pending(self, job_id: str) -> tuple[dict | None, _JobChannel | None]:
        with self._lock:
            event = self._pending.pop(job_id, None)
            channel = self._channels.get(job_id)
            return (dict(event) if event else None, channel)

    def _reschedule_if_needed(self, job_id: str) -> None:
        with self._lock:
            self._scheduled.discard(job_id)
            if job_id in self._pending and not self._stop.is_set():
                self._scheduled.add(job_id)
                self._queue.put(job_id)

    def _worker(self) -> None:
        while not self._stop.is_set():
            try:
                job_id = self._queue.get(timeout=0.5)
            except queue.Empty:
                continue
            if job_id is None:
                return
            try:
                event, channel = self._take_pending(job_id)
                if channel is not None:
                    self._ensure_acceptance(token=self._get_token(), channel=channel)
                if event is not None and channel is not None:
                    self._process(job_id, event, channel)
            except Exception as exc:  # noqa: BLE001
                if self.logger:
                    self.logger.warning(f"Telegram notifier: {exc}")
            finally:
                self._reschedule_if_needed(job_id)

    def _ensure_acceptance(self, token: str, channel: _JobChannel) -> None:
        if not token or not channel.chat_ids:
            return
        missing = [chat_id for chat_id in sorted(channel.chat_ids) if chat_id not in channel.service_message_ids]
        for chat_id in missing:
            try:
                msg_id = send_text(token, chat_id, channel.acceptance_text)
                if msg_id is not None:
                    channel.service_message_ids[chat_id] = int(msg_id)
                    channel.last_render_at[chat_id] = time.time()
                    channel.last_text[chat_id] = channel.acceptance_text
            except Exception as exc:
                if self.logger:
                    self.logger.warning(f"Telegram notifier: initial message for {chat_id}: {exc}")

    def _process(self, job_id: str, event: dict, channel: _JobChannel) -> None:
        token = self._get_token()
        if not token or not channel.chat_ids:
            return

        event_type = str(event.get("type") or "")
        job = self._job_from_event(event)
        state = str(job.get("state") or event.get("state") or "")

        text = self._render_service_message(job_id, job, event)
        terminal = event_type in _TERMINAL or state in {"COMPLETED", "FAILED", "CANCELLED"}

        for chat_id in sorted(channel.chat_ids):
            message_id = channel.service_message_ids.get(chat_id)
            now = time.time()
            elapsed = now - channel.last_render_at.get(chat_id, 0.0)
            should_render = terminal or event_type not in {
                EventType.JOB_PROGRESS.value,
                EventType.JOB_RESULT_UPDATED.value,
            } or elapsed >= self.min_edit_interval
            if not should_render and message_id is not None:
                continue

            if message_id is None:
                msg_id = send_text(token, chat_id, text)
                if msg_id is not None:
                    channel.service_message_ids[chat_id] = int(msg_id)
                    channel.last_render_at[chat_id] = now
                    channel.last_text[chat_id] = text
            else:
                if channel.last_text.get(chat_id) != text:
                    ok = edit_text(token, chat_id, message_id, text)
                    if ok:
                        channel.last_render_at[chat_id] = now
                        channel.last_text[chat_id] = text

        if terminal and event_type == EventType.JOB_COMPLETED.value:
            self._send_final_answers(token, job, channel)

    @staticmethod
    def _duration(job: dict) -> float:
        try:
            start = float(job.get("started_at") or 0)
            finish = float(job.get("finished_at") or 0)
            if start and finish:
                return max(0.0, finish - start)
        except (TypeError, ValueError):
            pass
        return 0.0

    @staticmethod
    def _fmt_duration(seconds: float) -> str:
        total = max(0, int(round(seconds)))
        minutes, secs = divmod(total, 60)
        hours, minutes = divmod(minutes, 60)
        if hours:
            return f"{hours:02d}:{minutes:02d}:{secs:02d}"
        return f"{minutes:02d}:{secs:02d}"

    @staticmethod
    def _score_lines(score: dict) -> list[str]:
        if not isinstance(score, dict):
            return []
        lines: list[str] = []
        correct = score.get("correct")
        total = score.get("total")
        percent = score.get("percent")
        points = score.get("points")
        max_points = score.get("max_points")
        grade = score.get("grade")
        if correct is not None and total is not None:
            lines.append(f"Правильных ответов: {correct} из {total}")
        if percent is not None:
            lines.append(f"Результат: {percent}%")
        if points is not None:
            lines.append(
                f"Баллов: {points} из {max_points}" if max_points is not None else f"Баллов: {points}"
            )
        if grade:
            lines.append(f"Оценка: {grade}")
        return lines

    def _render_service_message(self, job_id: str, job: dict, event: dict) -> str:
        event_type = str(event.get("type") or "")
        state = str(job.get("state") or event.get("state") or "")
        progress = job.get("progress_context") if isinstance(job.get("progress_context"), dict) else {}
        stage = str(progress.get("stage") or job.get("stage") or event.get("stage") or "")
        percent = float(progress.get("percent", job.get("progress", 0)) or 0)
        current = int(progress.get("current_question", job.get("current_question", 0)) or 0)
        total = int(progress.get("total_questions", job.get("total_questions", 0)) or 0)
        url = str(job.get("url") or "")

        if event_type == EventType.JOB_COMPLETED.value or state == "COMPLETED":
            result = job.get("result") if isinstance(job.get("result"), dict) else {}
            title = str(result.get("test_title") or job.get("metadata", {}).get("test_title") or "Тест")
            questions = int(result.get("total_questions") or total or 0)
            answer_count = int(result.get("answer_count") or 0)
            status = str(result.get("result_status") or "completed")
            score = result.get("score") if isinstance(result.get("score"), dict) else {}
            lines = ["✅ Тест завершён", "", f"Название: {title}"]
            if questions:
                lines.append(f"Количество вопросов: {questions}")
            if answer_count:
                lines.append(f"Найдено ответов: {answer_count}")
            lines.extend(self._score_lines(score))
            lines.append(f"Время выполнения: {self._fmt_duration(self._duration(job))}")
            lines.append(f"Результат: {status}")
            lines.append(f"Ссылка: {url}")
            lines.append(f"Job ID: {job_id}")
            return "\n".join(lines)

        if event_type == EventType.JOB_FAILED.value or state == "FAILED":
            error = str(job.get("error_reason") or job.get("error") or event.get("error") or "Неизвестная ошибка")
            return f"❌ Тест завершён с ошибкой\n\nЭтап: {_STAGE_LABELS.get(stage, stage or 'ошибка')}\nПричина: {error}\n\nСсылка: {url}\nJob ID: {job_id}"

        if event_type == EventType.JOB_CANCELLED.value or state == "CANCELLED":
            return f"⛔ Тест отменён\n\nСсылка: {url}\nJob ID: {job_id}"

        stage_label = _STAGE_LABELS.get(stage, stage or "обработка")
        progress_line = f"\nПрогресс: {percent:.0f}%" if total or percent else ""
        question_line = f"\nВопрос: {current}/{total}" if total else ""
        if state == "QUEUED" or event_type == EventType.JOB_CREATED.value:
            return f"✅ Задание принято в очередь.\n\nЭтап: очередь\nСсылка: {url}\nJob ID: {job_id}"
        if event_type == EventType.JOB_STARTED.value or state == "STARTING":
            return f"🚀 Запуск Job\n\nЭтап: запуск\nСсылка: {url}\nJob ID: {job_id}"
        return f"🔄 Выполняю тест\n\nЭтап: {stage_label}{progress_line}{question_line}\n\nСсылка: {url}\nJob ID: {job_id}"

    @staticmethod
    def _split_message(text: str) -> list[str]:
        text = str(text or "").strip()
        if not text:
            return []
        if len(text) <= MAX_MESSAGE_LEN:
            return [text]

        chunks: list[str] = []
        current = ""
        for line in text.splitlines():
            candidate = f"{current}\n{line}" if current else line
            if len(candidate) <= MAX_MESSAGE_LEN:
                current = candidate
                continue
            if current:
                chunks.append(current)
                current = ""
            # Очень длинную отдельную строку режем безопасными блоками.
            while len(line) > MAX_MESSAGE_LEN:
                chunks.append(line[:MAX_MESSAGE_LEN])
                line = line[MAX_MESSAGE_LEN:]
            current = line
        if current:
            chunks.append(current)
        return chunks

    def _send_final_answers(self, token: str, job: dict, channel: _JobChannel) -> None:
        """Отправляет найденные ответы обычными сообщениями, а не файлом."""
        result = job.get("result") if isinstance(job.get("result"), dict) else {}
        text = str(result.get("telegram_text") or "").strip()

        # Для старого Job/кэша допускаем чтение short_path как текстового fallback,
        # но никогда не отправляем файл пользователю.
        if not text:
            raw_path = result.get("short_path")
            if raw_path:
                try:
                    p = Path(str(raw_path))
                    if p.exists() and p.is_file() and p.suffix.lower() in {".txt", ".text"}:
                        text = p.read_text(encoding="utf-8", errors="replace").strip()
                except OSError as exc:
                    if self.logger:
                        self.logger.warning(f"Telegram notifier: не удалось прочитать ответы {raw_path}: {exc}")

        chunks = self._split_message(text)
        if not chunks:
            if self.logger:
                self.logger.warning(
                    f"Telegram notifier: Job {job.get('id') or job.get('job_id')} завершён, "
                    "но telegram_text с ответами пуст."
                )
            return

        for chat_id in sorted(channel.chat_ids):
            if chat_id in channel.answer_messages_sent:
                continue
            success = True
            try:
                for chunk in chunks:
                    msg_id = send_text(token, chat_id, chunk)
                    if msg_id is None:
                        success = False
                        if self.logger:
                            self.logger.warning(
                                f"Telegram notifier: ответы Job {job.get('id') or job.get('job_id')} "
                                f"не отправлены полностью в {chat_id}."
                            )
                        break
            except Exception as exc:
                success = False
                if self.logger:
                    self.logger.warning(
                        f"Telegram notifier: ошибка отправки ответов Job "
                        f"{job.get('id') or job.get('job_id')} в {chat_id}: {exc}"
                    )
            if success:
                channel.answer_messages_sent.add(chat_id)


    def stop(self) -> None:
        self._stop.set()
        try:
            self._queue.put_nowait(None)
        except Exception:
            pass
        if self._thread.is_alive():
            self._thread.join(timeout=3)
        if self.hub is not None:
            for token in list(self._subscriptions):
                self.hub.events.unsubscribe(token)
        self._subscriptions.clear()

    def snapshot(self) -> dict:
        with self._lock:
            return {
                job_id: {
                    "chat_ids": sorted(channel.chat_ids),
                    "service_message_ids": dict(channel.service_message_ids),
                    "last_render_at": dict(channel.last_render_at),
                }
                for job_id, channel in self._channels.items()
            }
