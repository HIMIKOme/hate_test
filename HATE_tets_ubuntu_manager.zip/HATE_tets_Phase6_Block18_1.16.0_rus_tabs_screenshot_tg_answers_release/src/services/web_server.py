"""Постоянный независимый Web-процесс HATE_tets.

Block 8: Web является главным интерфейсом управления и при этом остаётся
отдельным процессом. Он не хранит ссылки на Hub/Worker/Telegram/Selenium:
состояние читает из IPC-снимка, команды отправляет через IPC.
"""
from __future__ import annotations

import json
import os
import sys
import subprocess
import threading
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict
from urllib.parse import parse_qs, urlparse

from .config import _normalize_whitelist, get_config_txt_path, load_settings, save_settings
from .live_events import connect_client
from .ipc import base_dir, read_state, send_command
from .net_utils import get_lan_ip
from .statistics import snapshot as statistics_snapshot
from .version import APP_VERSION
from .event_journal import read_events
from .metrics import snapshot as metrics_snapshot
from .diagnostics import DiagnosticsManager

DEFAULT_PORT = 8765
PORT_RANGE = 30
BIND_HOST = "0.0.0.0"
STALE_APP_HEARTBEAT = 10.0
STALE_WATCHDOG_HEARTBEAT = 15.0


def _read_json_file(path: Path, default: dict) -> dict:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else dict(default)
    except Exception:
        return dict(default)


def _heartbeat_age() -> float | None:
    hb = base_dir() / "data" / "heartbeats" / "app.json"
    try:
        payload = _read_json_file(hb, {})
        stamp = float(payload.get("timestamp", 0) or 0)
        if stamp <= 0:
            return None
        return max(0.0, time.time() - stamp)
    except Exception:
        return None


def _watchdog_status() -> dict[str, Any]:
    path = base_dir() / "data" / "watchdog.json"
    try:
        payload = _read_json_file(path, {})
        stamp = float(payload.get("timestamp", 0) or 0)
        age = max(0.0, time.time() - stamp) if stamp else None
        alive = age is not None and age <= STALE_WATCHDOG_HEARTBEAT
        return {"alive": alive, "age": round(age, 2) if age is not None else None, "pid": payload.get("pid"), "status": payload.get("status", "Offline"), "issues": list(payload.get("issues") or [])}
    except Exception:
        return {"alive": False, "age": None, "pid": None, "status": "Offline", "issues": ["watchdog heartbeat unavailable"]}


def _component_status(state: dict) -> dict[str, Any]:
    workers = list(state.get("workers") or [])
    test_workers = [w for w in workers if str(w.get("queue_type") or "TEST_QUEUE") == "TEST_QUEUE"]
    alive_workers = [w for w in test_workers if w.get("alive")]
    active = list((state.get("jobs") or {}).get("active") or [])
    queued = list((state.get("jobs") or {}).get("queued") or [])
    token = str((state.get("config") or {}).get("telegram_token") or "").strip()
    bot_running = bool(state.get("bot_running"))
    browser_online = [w for w in alive_workers if w.get("browser_status") == "online"]
    crashed_workers = [w for w in test_workers if w.get("browser_status") == "crashed"]
    watchdog = state.get("watchdog") if isinstance(state.get("watchdog"), dict) else _watchdog_status()
    if not watchdog:
        watchdog = _watchdog_status()

    age = _heartbeat_age()
    app_online = age is not None and age <= STALE_APP_HEARTBEAT
    if not app_online:
        overall = "Offline"
    elif active and not alive_workers:
        overall = "Critical"
    elif active and crashed_workers:
        overall = "Critical"
    elif token and not bot_running:
        overall = "Warning"
    elif test_workers and len(alive_workers) < len(test_workers):
        overall = "Warning"
    elif not test_workers:
        overall = "Warning"
    elif not watchdog["alive"]:
        overall = "Warning"
    else:
        overall = "Online"

    telegram_status = "Online" if bot_running else ("Warning" if token else "Offline")
    if not app_online:
        telegram_status = "Offline"

    if not alive_workers:
        worker_status = "Offline"
    elif len(alive_workers) < len(test_workers):
        worker_status = "Warning"
    else:
        worker_status = "Online"

    if not app_online:
        chrome_status = "Offline"
    elif crashed_workers or (active and not browser_online):
        chrome_status = "Critical"
    elif browser_online:
        chrome_status = "Online"
    else:
        chrome_status = "Idle"

    return {
        "overall": overall,
        "heartbeat_age": round(age, 2) if age is not None else None,
        "telegram": telegram_status,
        "telegram_running": bot_running,
        "worker": worker_status,
        "chrome": chrome_status,
        "worker_count": len(test_workers),
        "alive_worker_count": len(alive_workers),
        "active_jobs": len(active),
        "queued_jobs": len(queued),
        "watchdog": watchdog,
        "last_check": time.time(),
    }


def _all_jobs(state: dict) -> list[dict]:
    jobs = []
    seen: set[str] = set()
    for group in ("active", "queued", "retry_waiting", "history"):
        for job in ((state.get("jobs") or {}).get(group) or []):
            jid = str(job.get("id") or job.get("job_id") or "")
            if not jid or jid in seen:
                continue
            seen.add(jid)
            jobs.append(dict(job))
    return jobs


def _recent_history(state: dict, limit: int = 100) -> list[dict]:
    events = list(state.get("events") or [])
    events.sort(key=lambda item: float(item.get("timestamp", 0) or 0), reverse=True)
    return [
        {
            "timestamp": item.get("timestamp"),
            "event_id": item.get("event_id"),
            "type": item.get("type"),
            "source": item.get("source"),
            "job_id": item.get("job_id") or ((item.get("job") or {}).get("id") if isinstance(item.get("job"), dict) else None),
            "worker_id": item.get("worker_id"),
            "message": item.get("message") or item.get("error") or "",
        }
        for item in events[:max(1, min(int(limit), 200))]
    ]


def _dashboard(state: dict) -> dict[str, Any]:
    status = _component_status(state)
    jobs = state.get("jobs") or {}
    active = list(jobs.get("active") or [])
    current_job = active[0] if active else None
    last_error = (state.get("statistics") or {}).get("last_error")
    last_success = (state.get("statistics") or {}).get("last_success")
    return {
        "application_status": status["overall"],
        "status": status,
        "telegram": {"status": status["telegram"], "running": status["telegram_running"]},
        "workers": {
            "status": status["worker"],
            "count": status["worker_count"],
            "alive": status["alive_worker_count"],
            "items": list(state.get("workers") or []),
        },
        "chrome": {"status": status["chrome"]},
        "watchdog": status.get("watchdog", {}),
        "current_job": current_job,
        "queue_count": int(jobs.get("total_queue_size", jobs.get("queue_size", 0)) or 0),
        "retry_waiting_count": len(list(jobs.get("retry_waiting") or [])),
        "running_count": int(jobs.get("running", len(active)) or 0),
        "last_error": last_error,
        "last_success": last_success,
        "circuit_breakers": state.get("circuit_breakers", {}),
    }


def _decorate_state(state: dict) -> dict:
    state = dict(state)
    state["application_status"] = _component_status(state)["overall"]
    state["health"] = _component_status(state)
    state["dashboard"] = _dashboard(state)
    state["statistics"] = statistics_snapshot() or state.get("statistics", {})
    state["metrics"] = metrics_snapshot() or state.get("metrics", {})
    state["history"] = _recent_history(state, 100)
    state.setdefault("resource", {})
    state.setdefault("idempotency", {})
    state.setdefault("job_progress", {})
    state.setdefault("workers", [])
    state.setdefault("components", {})
    state.setdefault("events", [])
    state.setdefault("circuit_breakers", {})
    state["deployment"] = {"status": "disabled", "message": "Ubuntu Server: in-place rebuild disabled"}
    state.setdefault("version", APP_VERSION)
    try:
        state["config"] = load_settings()
        state["config_path"] = str(get_config_txt_path())
    except Exception:
        pass
    return state


def _shutdown_fallback_after(delay_sec: float = 8.0) -> None:
    """Страховка: если основной процесс не ответил на shutdown_all,
    через несколько секунд завершает приложение, watchdog и сам Web.
    """
    time.sleep(delay_sec)
    root = base_dir()
    pids: list[tuple[str, int]] = []
    for label, path in (
        ("app", root / "data" / "heartbeats" / "app.json"),
        ("watchdog", root / "data" / "heartbeats" / "watchdog.json"),
    ):
        try:
            payload = _read_json_file(path, {})
            pid = int(payload.get("pid") or 0)
            if pid > 0 and pid != os.getpid():
                pids.append((label, pid))
        except (ValueError, TypeError):
            pass
    for label, pid in pids:
        try:
            if sys.platform == "win32":
                subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True, check=False)
            else:
                os.kill(pid, 15)
        except (OSError, subprocess.SubprocessError):
            pass
    os._exit(0)


class _Handler(BaseHTTPRequestHandler):
    server_version = f"HATE_tets-Web/{APP_VERSION}"

    def log_message(self, fmt, *args):
        pass

    def _json(self, data: Dict[str, Any], status: int = 200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _html(self, html: str, status: int = 200):
        body = html.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _body(self) -> Dict[str, Any]:
        try:
            length = int(self.headers.get("Content-Length", 0))
            if length <= 0 or length > 2_000_000:
                return {}
            value = json.loads(self.rfile.read(length).decode("utf-8"))
            return value if isinstance(value, dict) else {}
        except Exception:
            return {}

    def do_GET(self):
        path = urlparse(self.path)
        route = path.path
        if route in ("/", "/index.html"):
            page = (Path(__file__).resolve().parent / "web_page.html").read_text(encoding="utf-8")
            self._html(page)
            return
        if route == "/health":
            state = _decorate_state(read_state())
            status = state["application_status"]
            self._json({"ok": True, "web": "online", "application_status": status, "health": state["health"], "version": state.get("version")})
            return
        if route == "/api/state":
            self._json(_decorate_state(read_state()))
            return
        if route == "/api/dashboard":
            state = _decorate_state(read_state())
            self._json({"ok": True, **state["dashboard"]})
            return
        if route == "/api/jobs":
            state = _decorate_state(read_state())
            self._json({"ok": True, **(state.get("jobs") or {}), "workers": state.get("workers", [])})
            return
        if route == "/api/queue":
            state = _decorate_state(read_state())
            jobs = state.get("jobs") or {}
            self._json({"ok": True, "queues": jobs.get("queues", {}), "queue_sizes": jobs.get("queue_sizes", {}), "total": jobs.get("total_queue_size", jobs.get("queue_size", 0))})
            return
        if route == "/api/jobs/progress":
            query = parse_qs(path.query)
            job_id = str((query.get("job_id") or [""])[0]).strip()
            state = read_state()
            progress_map = state.get("job_progress") or {}
            if job_id:
                progress = progress_map.get(job_id)
                if progress is None:
                    self._json({"ok": False, "error": "Job не найдена"}, 404)
                else:
                    self._json({"ok": True, "progress": progress})
            else:
                self._json({"ok": True, "progress": progress_map})
            return
        if route == "/api/history":
            query = parse_qs(path.query)
            try:
                limit = int((query.get("limit") or ["100"])[0])
            except (TypeError, ValueError):
                limit = 100
            state = _decorate_state(read_state())
            self._json({"ok": True, "history": _recent_history(state, limit)})
            return
        if route == "/api/statistics":
            self._json({"ok": True, "statistics": statistics_snapshot()})
            return
        if route == "/api/metrics":
            self._json({"ok": True, "metrics": metrics_snapshot()})
            return
        if route == "/api/resource":
            state = _decorate_state(read_state())
            self._json({"ok": True, "resource": state.get("resource", {})})
            return
        if route == "/api/event-log":
            query = parse_qs(path.query)
            try:
                limit = int((query.get("limit") or ["500"])[0])
            except (TypeError, ValueError):
                limit = 500
            self._json({"ok": True, "events": read_events(limit=limit)})
            return
        if route == "/api/jobs/diagnostics":
            query = parse_qs(path.query)
            job_id = str((query.get("job_id") or [""])[0]).strip()
            if not job_id:
                self._json({"ok": False, "error": "job_id не задан"}, 400)
                return
            manager = DiagnosticsManager(base_dir() / "data" / "diagnostics")
            archive = manager.get_archive(job_id)
            if archive is None or not archive.exists():
                self._json({"ok": False, "error": "Диагностика для Job отсутствует"}, 404)
                return
            body = archive.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "application/zip")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Content-Disposition", f'attachment; filename="{job_id}-diagnostics.zip"')
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
            return
        if route == "/api/events":
            self._events_stream()
            return
        if route == "/api/circuit-breakers":
            state = _decorate_state(read_state())
            self._json({"ok": True, "circuit_breakers": state.get("circuit_breakers", {})})
            return
        if route == "/api/deployment":
            data = _read_json_file(base_dir() / "data" / "deployment.json", {"status": "idle", "message": ""})
            self._json({"ok": True, **data})
            return
        if route == "/api/recovery":
            state = _decorate_state(read_state())
            self._json({"ok": True, "recovery": state.get("recovery", {}), "jobs_state_path": str(base_dir() / "data" / "jobs_state.json")})
            return
        self._json({"ok": False, "error": "not found"}, 404)

    def _events_stream(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-store")
        self.send_header("Connection", "keep-alive")
        self.send_header("X-Accel-Buffering", "no")
        self.send_header("X-HATE-Live-Transport", "tcp-push")
        self.end_headers()

        def emit(payload: dict[str, Any]) -> None:
            raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
            self.wfile.write(b"event: message\n")
            self.wfile.write(f"data: {raw}\n\n".encode("utf-8"))
            self.wfile.flush()

        # Новый клиент сначала получает целостный snapshot, после чего идут только
        # push-события. Это избавляет браузер от необходимости разбирать историю.
        try:
            emit({
                "type": "StateSnapshot",
                "timestamp": time.time(),
                "state": _decorate_state(read_state()),
            })
            client = connect_client(timeout=1.5)
            if client is None:
                emit({"type": "LiveUnavailable", "timestamp": time.time(), "retry_after_ms": 2000})
                return
            deadline = time.time() + 24 * 3600
            while time.time() < deadline:
                event = client.recv(timeout=10.0)
                if event is None:
                    # Это heartbeat транспорта, а не polling состояния.
                    self.wfile.write(b": keepalive\n\n")
                    self.wfile.flush()
                    continue
                if event.get("type") == "LiveConnected":
                    emit(event)
                    continue
                if event.get("type") == "LiveKeepalive":
                    self.wfile.write(b": keepalive\n\n")
                    self.wfile.flush()
                    continue
                emit(event)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        finally:
            try:
                client.close()  # type: ignore[name-defined]
            except Exception:
                pass

    def do_POST(self):
        data = self._body()
        route = urlparse(self.path).path
        if route == "/api/jobs/create":
            url = str(data.get("url") or "").strip()
            if not url:
                self._json({"ok": False, "error": "url не задан"}, 400)
                return
            metadata = dict(data.get("metadata") or {})
            raw_timeout = data.get("max_runtime_sec")
            if raw_timeout not in (None, ""):
                try:
                    timeout_value = float(raw_timeout)
                    if timeout_value > 0:
                        metadata["max_runtime_sec"] = timeout_value
                except (TypeError, ValueError):
                    pass
            if data.get("stuck_policy"):
                metadata["stuck_policy"] = str(data["stuck_policy"])
            if "allow_overrun" in data:
                metadata["allow_overrun"] = bool(data.get("allow_overrun"))
            command_id = send_command("create_job", {
                "url": url,
                "mode": str(data.get("mode") or "collect"),
                "user_name": str(data.get("user_name") or ""),
                "telegram_chat_id": str(data.get("telegram_chat_id") or ""),
                "priority": str(data.get("priority") or "NORMAL"),
                "queue_type": str(data.get("queue_type") or "TEST_QUEUE"),
                "metadata": metadata,
                "idempotency_key": str(data.get("idempotency_key") or "").strip() or None,
            })
            self._json({"ok": True, "command_id": command_id})
            return
        if route in {"/api/jobs/cancel", "/api/jobs/retry", "/api/jobs/priority", "/api/jobs/recover", "/api/jobs/terminate"}:
            job_id = str(data.get("job_id") or "").strip()
            if not job_id:
                self._json({"ok": False, "error": "job_id не задан"}, 400)
                return
            if route.endswith("/cancel"):
                command = "cancel_job"
            elif route.endswith("/retry"):
                command = "retry_job"
            elif route.endswith("/recover"):
                command = "recover_job"
            elif route.endswith("/terminate"):
                command = "terminate_job"
            else:
                command = "set_priority"
            payload = {"job_id": job_id}
            if command in {"recover_job", "terminate_job"}:
                payload["reason"] = str(data.get("reason") or "manual_web_action")
            if command == "set_priority":
                payload["priority"] = str(data.get("priority") or "NORMAL")
            self._json({"ok": True, "command_id": send_command(command, payload)})
            return
        if route in {"/api/workers/drain", "/api/workers/undrain"}:
            worker_id = str(data.get("worker_id") or "").strip()
            if not worker_id:
                self._json({"ok": False, "error": "worker_id не задан"}, 400)
                return
            command = "drain_worker" if route.endswith("/drain") else "undrain_worker"
            self._json({"ok": True, "command_id": send_command(command, {"worker_id": worker_id})})
            return
        if route == "/api/stop_all":
            self._json({"ok": True, "command_id": send_command("stop_all")})
            return
        if route == "/api/shutdown_all":
            command_id = send_command("shutdown_all")
            self._json({"ok": True, "command_id": command_id, "message": "Полное завершение запрошено."})
            # Ответ уже отправлен клиенту; дальше Web при необходимости
            # выступает страховочным терминатором.
            threading.Thread(target=_shutdown_fallback_after, name="web-shutdown-fallback", daemon=True).start()
            return
        if route == "/api/restart_bot":
            self._json({"ok": True, "command_id": send_command("restart_bot")})
            return
        if route == "/api/stop_tray":
            self._json({"ok": True, "command_id": send_command("stop_tray")})
            return
        if route == "/api/rebuild":
            self._json({"ok": False, "error": "Пересборка из Web-панели отключена в Ubuntu Server-релизе. Обновляйте файлы проекта и запускайте install.sh."}, 410)
            return
        if route == "/api/open_answers":
            self._json({"ok": True, "command_id": send_command("open_answers")})
            return
        if route == "/api/circuit-breakers/reset":
            site = str(data.get("site") or data.get("url") or "").strip()
            if not site:
                self._json({"ok": False, "error": "site/url не задан"}, 400)
                return
            self._json({"ok": True, "command_id": send_command("reset_circuit", {"site": site})})
            return
        if route == "/api/config":
            try:
                current = load_settings()
                current.update({
                    "telegram_token": data.get("telegram_token", current.get("telegram_token", "")),
                    "telegram_chats": data.get("telegram_chats", current.get("telegram_chats", ["", "", ""])),
                    "error_contact": data.get("error_contact", current.get("error_contact", "")),
                    "cleanup_days": data.get("cleanup_days", current.get("cleanup_days", 15)),
                    "worker_count": data.get("worker_count", current.get("worker_count", 4)),
                    "auxiliary_worker_count": data.get("auxiliary_worker_count", current.get("auxiliary_worker_count", 1)),
                    "circuit_failure_threshold": data.get("circuit_failure_threshold", current.get("circuit_failure_threshold", 3)),
                    "circuit_window_sec": data.get("circuit_window_sec", current.get("circuit_window_sec", 300)),
                    "circuit_cooldown_sec": data.get("circuit_cooldown_sec", current.get("circuit_cooldown_sec", 120)),
                    "retry_max_attempts": data.get("retry_max_attempts", current.get("retry_max_attempts", 3)),
                    "retry_backoff_sec": data.get("retry_backoff_sec", current.get("retry_backoff_sec", 5)),
                    "retry_backoff_max_sec": data.get("retry_backoff_max_sec", current.get("retry_backoff_max_sec", 120)),
                    "retry_policy": data.get("retry_policy", current.get("retry_policy", "auto")),
                    "resource_cpu_limit_percent": data.get("resource_cpu_limit_percent", current.get("resource_cpu_limit_percent", 90)),
                    "resource_memory_limit_percent": data.get("resource_memory_limit_percent", current.get("resource_memory_limit_percent", 90)),
                })
                save_settings(current)
                self._json({"ok": True, "config": load_settings(), "config_path": str(get_config_txt_path())})
            except Exception as exc:
                self._json({"ok": False, "error": str(exc)}, 500)
            return
        if route in {"/api/whitelist/add", "/api/whitelist/remove"}:
            try:
                name = str(data.get("username") or "").strip()
                norm = _normalize_whitelist(name)
                if not norm:
                    self._json({"ok": False, "error": "некорректный username"}, 400)
                    return
                current = load_settings()
                wl = list(current.get("whitelist", []))
                if route.endswith("/add"):
                    for item in norm:
                        if item not in wl:
                            wl.append(item)
                else:
                    wl = [item for item in wl if item not in norm]
                current["whitelist"] = wl
                save_settings(current)
                self._json({"ok": True, "whitelist": wl})
            except Exception as exc:
                self._json({"ok": False, "error": str(exc)}, 500)
            return
        self._json({"ok": False, "error": "not found"}, 404)


def run_server() -> int:
    logger_path = base_dir() / "data" / "logs"
    logger_path.mkdir(parents=True, exist_ok=True)
    server = None
    port = 0
    for candidate in range(DEFAULT_PORT, DEFAULT_PORT + PORT_RANGE):
        try:
            server = ThreadingHTTPServer((BIND_HOST, candidate), _Handler)
            port = candidate
            break
        except OSError:
            continue
    if server is None:
        (logger_path / "web.log").open("a", encoding="utf-8").write("Не удалось найти свободный порт\n")
        return 2

    lan_ip = get_lan_ip()
    info_path = base_dir() / "data" / "web.json"
    info_path.parent.mkdir(parents=True, exist_ok=True)
    info_path.write_text(
        json.dumps({"pid": os.getpid(), "port": port, "lan_ip": lan_ip, "url": f"http://{lan_ip}:{port}/", "version": APP_VERSION}, ensure_ascii=False),
        encoding="utf-8",
    )
    try:
        server.serve_forever(poll_interval=0.5)
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(run_server())
