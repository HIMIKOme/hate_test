"""Центральный менеджер Job и независимых приоритетных очередей."""
from __future__ import annotations

import threading
import time
from typing import Callable, Dict, List, Optional

from .event_bus import EventBus, EventType
from .job import Job, JobPriority, JobState, QueueType, TERMINAL_STATES
from .job_queue import PriorityJobQueue
from .worker_context import WorkerContext
from .circuit_breaker import CircuitBreaker
from .job_store import JobStore
from .retry_policy import RetryPolicy
from .idempotency import IdempotencyStore, IdempotencyConflict
from .diagnostics import DiagnosticsManager
from .metrics import record_event as record_metric_event
from .resource_manager import ResourceManager


class JobManager:
    """Единый владелец Job и всех рабочих очередей.

    TEST_QUEUE обслуживается Test Worker-ами, а CACHE/NOTIFICATION/DIAGNOSTIC
    имеют отдельные очереди и собственные worker-потоки, когда для них назначен
    обработчик. Благодаря этому служебные операции не занимают тестовых Worker.
    """

    AUXILIARY_QUEUES = (
        QueueType.CACHE_QUEUE,
        QueueType.NOTIFICATION_QUEUE,
        QueueType.DIAGNOSTIC_QUEUE,
    )

    def __init__(
        self,
        logger,
        event_bus: Optional[EventBus] = None,
        worker_count: int = 1,
        auxiliary_worker_count: int = 1,
        circuit_breaker: Optional[CircuitBreaker] = None,
        job_store: Optional[JobStore] = None,
        idempotency_store: Optional[IdempotencyStore] = None,
        diagnostics_manager: Optional[DiagnosticsManager] = None,
        resource_manager: Optional[ResourceManager] = None,
    ):
        self.logger = logger
        self.events = event_bus or EventBus(logger)
        self.worker_count = max(1, int(worker_count))
        self.auxiliary_worker_count = max(1, min(4, int(auxiliary_worker_count)))
        self._jobs: Dict[str, Job] = {}
        self._queues: Dict[QueueType, PriorityJobQueue] = {
            queue_type: PriorityJobQueue(queue_type) for queue_type in QueueType
        }
        # Совместимость с кодом предыдущих блоков: _pending больше не является
        # владельцем очереди и возвращает только TEST_QUEUE.
        self._callbacks: Dict[str, Callable] = {}
        self._queue_handlers: Dict[QueueType, Callable] = {}
        self._lock = threading.RLock()
        self._wake = threading.Condition(self._lock)
        self._aux_wake = threading.Condition(self._lock)
        self._stop = False
        self._threads: List[threading.Thread] = []
        self._aux_threads: List[threading.Thread] = []
        self._active: Dict[str, Job] = {}
        self._worker_seq = 0
        self._aux_worker_seq = 0
        self._contexts: Dict[str, WorkerContext] = {}
        self._handler: Optional[Callable] = None
        self.circuit_breaker = circuit_breaker
        self.job_store = job_store
        self.idempotency_store = idempotency_store
        self.diagnostics_manager = diagnostics_manager
        self.resource_manager = resource_manager or ResourceManager(logger)
        self._retry_timers: Dict[str, threading.Timer] = {}
        self._retry_waiting: Dict[str, Job] = {}
        self._draining_workers: set[str] = set()
        self._last_resource_block_reason = ""
        self._recovery_summary: dict = {"recovered": 0, "history_restored": 0, "discarded": 0, "source_version": "", "recovered_at": None}

    @property
    def _pending(self) -> list[Job]:
        return self._queues[QueueType.TEST_QUEUE].all_jobs()

    @property
    def queues(self) -> Dict[QueueType, PriorityJobQueue]:
        return dict(self._queues)

    def restore_persisted_jobs(self, *, current_version: str = "") -> dict:
        """Восстановить queued/history Job после перезапуска процесса.

        Job, которая была активной при предыдущем процессе, переводится обратно
        в QUEUED: её браузерный контекст больше не существует и продолжение
        выполнения с середины небезопасно.
        """
        if self.job_store is None:
            return dict(self._recovery_summary)
        snapshot = self.job_store.load()
        jobs = list(snapshot.get("jobs") or [])
        recovered = history_restored = discarded = 0
        recovered_ids: list[str] = []
        now = time.time()
        with self._lock:
            if self._jobs:
                return dict(self._recovery_summary)
            for raw in jobs:
                try:
                    job = Job.from_dict(raw)
                except (TypeError, ValueError, KeyError):
                    discarded += 1
                    continue
                if job.id in self._jobs:
                    discarded += 1
                    continue
                original_state = job.state.value
                if job.state in TERMINAL_STATES:
                    self._jobs[job.id] = job
                    if self.idempotency_store and job.idempotency_key:
                        self.idempotency_store.bind(job.idempotency_key, job.id, self._job_fingerprint(job))
                    history_restored += 1
                    continue

                job.state_machine.state = JobState.QUEUED
                job.state = JobState.QUEUED
                job.retry_at = None
                job.attempt_started_at = None
                job.worker_id = None
                job.started_at = None
                job.finished_at = None
                job.cancel_event.clear()
                job.queued_at = job.queued_at or job.created_at or now
                job.progress_context.update(percent=0.0, stage="recovered_after_restart", current_question=0, revision=job.progress_context.revision + 1)
                recovery = job.diagnostics.setdefault("restart_recovery", {})
                recovery.update({
                    "recovered_at": now,
                    "previous_state": original_state,
                    "reason": "process_restart",
                    "source_version": snapshot.get("process_version") or "",
                    "target_version": str(current_version or ""),
                })
                job.diagnostics.setdefault("recovery_history", []).append(dict(recovery))
                self._jobs[job.id] = job
                if self.idempotency_store and job.idempotency_key:
                    self.idempotency_store.bind(job.idempotency_key, job.id, self._job_fingerprint(job))
                self._queues[job.queue_type].put(job)
                self._callbacks[job.id] = self._queue_handlers.get(job.queue_type)
                if self.circuit_breaker is not None and job.queue_type == QueueType.TEST_QUEUE:
                    try:
                        self.circuit_breaker.attach_job(job)
                    except Exception:
                        pass
                recovered += 1
                recovered_ids.append(job.id)

            self._recovery_summary = {
                "recovered": recovered,
                "history_restored": history_restored,
                "discarded": discarded,
                "recovered_job_ids": recovered_ids,
                "source_version": str(snapshot.get("process_version") or ""),
                "target_version": str(current_version or ""),
                "recovered_at": now,
            }
            self._wake.notify_all()
            self._aux_wake.notify_all()

        if recovered or history_restored or discarded:
            self.events.publish(
                EventType.JOBS_RECOVERED_AFTER_RESTART,
                source="job-store",
                recovered=recovered,
                history_restored=history_restored,
                discarded=discarded,
                job_ids=recovered_ids,
                source_version=snapshot.get("process_version") or "",
            )
            try:
                self.job_store.save(self.persistence_snapshot(), process_version=current_version, recovery=self._recovery_summary)
            except OSError:
                pass
        return dict(self._recovery_summary)

    def recovery_snapshot(self) -> dict:
        with self._lock:
            return dict(self._recovery_summary)

    def persistence_snapshot(self) -> list[dict]:
        with self._lock:
            jobs = [job.to_dict() for job in self._jobs.values()]
        jobs.sort(key=lambda item: float(item.get("created_at") or 0))
        return jobs

    def set_handler(self, handler: Callable) -> None:
        if not callable(handler):
            raise TypeError("Job handler должен быть callable")
        with self._lock:
            self._handler = handler
            self._queue_handlers[QueueType.TEST_QUEUE] = handler
            for job in self._jobs.values():
                if job.state == JobState.QUEUED and job.queue_type == QueueType.TEST_QUEUE:
                    self._callbacks[job.id] = handler

    def set_queue_handler(self, queue_type: QueueType | str, handler: Callable) -> None:
        queue = QueueType(queue_type)
        if queue == QueueType.TEST_QUEUE:
            return self.set_handler(handler)
        if not callable(handler):
            raise TypeError("Queue handler должен быть callable")
        with self._lock:
            self._queue_handlers[queue] = handler
            if self._threads and not self._stop:
                self._start_auxiliary_workers_locked(queue)
            self._aux_wake.notify_all()

    def start(self) -> None:
        with self._lock:
            if self._threads:
                return
            self._stop = False
            for _ in range(self.worker_count):
                self._worker_seq += 1
                worker_id = f"worker-{self._worker_seq}"
                context = WorkerContext(worker_id, self.events, self.logger)
                self._contexts[worker_id] = context
                context.start()
                t = threading.Thread(
                    target=self._worker_loop,
                    args=(worker_id,),
                    name=worker_id,
                    daemon=True,
                )
                self._threads.append(t)
                t.start()
            for queue_type in self.AUXILIARY_QUEUES:
                if queue_type in self._queue_handlers:
                    self._start_auxiliary_workers_locked(queue_type)
        self.events.publish(
            "WorkerPoolStarted",
            worker_count=self.worker_count,
            auxiliary_worker_count=self.auxiliary_worker_count,
            queues=[q.value for q in QueueType],
        )

    def _start_auxiliary_workers_locked(self, queue_type: QueueType) -> None:
        existing = sum(
            1 for t in self._aux_threads if t.is_alive() and queue_type.value in t.name
        )
        for _ in range(self.auxiliary_worker_count - existing):
            self._aux_worker_seq += 1
            worker_id = f"queue-{queue_type.value.lower()}-{self._aux_worker_seq}"
            t = threading.Thread(
                target=self._aux_worker_loop,
                args=(queue_type, worker_id),
                name=worker_id,
                daemon=True,
            )
            self._aux_threads.append(t)
            t.start()

    def stop(self, cancel_pending: bool = True) -> None:
        with self._lock:
            self._stop = True
            for timer in self._retry_timers.values():
                timer.cancel()
            self._retry_timers.clear()
            if cancel_pending:
                for job in list(self._retry_waiting.values()):
                    if job.state == JobState.RETRY_WAIT:
                        job.cancel_event.set()
                        job.retry_at = None
                        job.transition(JobState.CANCELLING, stage="cancelling")
                        job.transition(JobState.CANCELLED, stage="cancelled")
                        self.events.publish(EventType.JOB_CANCELLED, source="hub", job=job.to_dict(), reason="manager_stop")
                self._retry_waiting.clear()
                for queue in self._queues.values():
                    for job in queue.clear():
                        if job.state == JobState.QUEUED:
                            job.cancel_event.set()
                            job.transition(JobState.CANCELLED, stage="cancelled")
                            self.events.publish(EventType.JOB_CANCELLED, source="hub", job=job.to_dict())
            self._wake.notify_all()
            self._aux_wake.notify_all()
        for t in list(self._threads) + list(self._aux_threads):
            if t.is_alive():
                t.join(timeout=3)
        with self._lock:
            self._threads.clear()
            self._aux_threads.clear()
            contexts = list(self._contexts.values())
            self._contexts.clear()
        for context in contexts:
            context.close_all()
            context.stop()
        self.events.publish(EventType.WORKER_POOL_STOPPED, source="hub")

    def create_job(
        self,
        url: str,
        *,
        mode: str = "collect",
        user_name: str = "",
        telegram_chat_id: Optional[str] = None,
        priority: JobPriority = JobPriority.NORMAL,
        queue_type: QueueType = QueueType.TEST_QUEUE,
        metadata: Optional[dict] = None,
        idempotency_key: Optional[str] = None,
    ) -> Job:
        clean_url = str(url).strip()
        queue = QueueType(queue_type)
        job_metadata = dict(metadata or {})
        idem_key = str(idempotency_key or job_metadata.pop("idempotency_key", "") or "").strip() or None
        fingerprint = self._request_fingerprint(clean_url, mode, user_name, telegram_chat_id, priority, queue, job_metadata)

        # Весь admission/reservation/submission проходит под одним JobManager lock:
        # это исключает гонку двух одинаковых idempotency-запросов и двойной probe.
        with self._lock:
            if idem_key and self.idempotency_store:
                existing = self.idempotency_store.lookup(idem_key)
                if existing:
                    existing_id = str(existing.get("job_id") or "")
                    existing_job = self._jobs.get(existing_id)
                    if existing_job is not None:
                        if str(existing.get("fingerprint") or "") != fingerprint:
                            raise IdempotencyConflict("Idempotency key уже связан с другим запросом")
                        existing_data = self._queue_snapshot_job_locked(existing_job)
                        self.events.publish(EventType.JOB_QUEUED, source="idempotency", job=existing_data, idempotent_reuse=True)
                        return existing_job
                    # Старый mapping может встретиться до restore-процесса; безопасно освобождаем его.
                    self.idempotency_store.release(idem_key, existing_id)

            admission = {"site": "", "probe": False}
            if queue == QueueType.TEST_QUEUE and self.circuit_breaker is not None:
                admission = self.circuit_breaker.admit(clean_url)
            if admission.get("site"):
                job_metadata["circuit_site"] = admission["site"]
            if admission.get("probe"):
                job_metadata["circuit_probe"] = True
            job = Job(
                url=clean_url,
                mode=mode,
                user_name=user_name,
                telegram_chat_id=telegram_chat_id,
                priority=JobPriority(priority),
                queue_type=queue,
                metadata=job_metadata,
                idempotency_key=idem_key,
            )
            try:
                if self.circuit_breaker is not None:
                    self.circuit_breaker.attach_job(job)
                if idem_key and self.idempotency_store:
                    existing_id = self.idempotency_store.reserve(idem_key, fingerprint, job.id)
                    if existing_id:
                        existing_job = self._jobs.get(existing_id)
                        if existing_job is not None:
                            return existing_job
                        self.idempotency_store.release(idem_key, existing_id)
                self.submit(job)
            except Exception:
                if idem_key and self.idempotency_store:
                    self.idempotency_store.release(idem_key, job.id)
                if self.circuit_breaker is not None:
                    self.circuit_breaker.abort_admission(clean_url, probe=bool(admission.get("probe")))
                raise
            return job

    def submit_operation(
        self,
        queue_type: QueueType | str,
        operation: str,
        *,
        priority: JobPriority = JobPriority.NORMAL,
        metadata: Optional[dict] = None,
    ) -> Job:
        queue = QueueType(queue_type)
        if queue == QueueType.TEST_QUEUE:
            raise ValueError("Для TEST_QUEUE используйте create_job")
        return self.create_job(
            url="",
            mode=str(operation or queue.value.lower()),
            priority=priority,
            queue_type=queue,
            metadata=metadata,
        )

    @staticmethod
    def _request_fingerprint(url, mode, user_name, telegram_chat_id, priority, queue_type, metadata) -> str:
        from .idempotency import IdempotencyStore
        clean_metadata = {
            str(key): value for key, value in dict(metadata or {}).items()
            if not str(key).startswith("circuit_")
        }
        payload = {
            "url": str(url).strip(), "mode": str(mode), "user_name": str(user_name),
            "telegram_chat_id": str(telegram_chat_id or ""), "priority": JobPriority(priority).name,
            "queue_type": QueueType(queue_type).value, "metadata": clean_metadata,
        }
        return IdempotencyStore.fingerprint(payload)

    def _job_fingerprint(self, job: Job) -> str:
        return self._request_fingerprint(job.url, job.mode, job.user_name, job.telegram_chat_id, job.priority, job.queue_type, job.metadata)

    def submit(self, job: Job) -> str:
        with self._lock:
            if job.id in self._jobs:
                raise ValueError(f"Job ID уже существует: {job.id}")
            queue = QueueType(job.queue_type)
            handler = self._queue_handlers.get(queue)
            if handler is None:
                if queue == QueueType.TEST_QUEUE and self._handler is not None:
                    handler = self._handler
                else:
                    # Служебная Job может быть поставлена в свою очередь ещё до
                    # регистрации обработчика. Она не влияет на TEST_QUEUE.
                    handler = None
            self._jobs[job.id] = job
            self._callbacks[job.id] = handler
            queue_obj = self._queues[queue]
            queue_obj.put(job)
            self._wake.notify_all()
            self._aux_wake.notify_all()
            snapshot = self._queue_snapshot_job_locked(job)
        self.events.publish(EventType.JOB_CREATED, source="hub", job=snapshot)
        self.events.publish(EventType.JOB_QUEUED, source="hub", job=snapshot)
        return job.id

    def get(self, job_id: str) -> Optional[Job]:
        with self._lock:
            return self._jobs.get(job_id)

    def update(self, job: Job, state: Optional[JobState] = None, **fields) -> None:
        with self._lock:
            if state is not None:
                job.transition(state, stage=fields.pop("stage", None), error=fields.pop("error", ""))
            for key, value in fields.items():
                if hasattr(job, key):
                    setattr(job, key, value)
            snapshot = self._snapshot_job_locked(job)
        event = "JobStateChanged" if state is not None else "JobProgress"
        self.events.publish(event, source="hub", job=snapshot)

    def set_progress(
        self,
        job: Job,
        progress: float,
        *,
        stage: Optional[str] = None,
        current_question: Optional[int] = None,
        total_questions: Optional[int] = None,
    ) -> None:
        with self._lock:
            job.update_progress(
                progress,
                stage=stage,
                current_question=current_question,
                total_questions=total_questions,
            )
            snapshot = self._snapshot_job_locked(job)
        self.events.publish(EventType.JOB_PROGRESS, source="hub", job=snapshot)

    def get_progress(self, job_id: str) -> Optional[dict]:
        """Вернуть только канонический live-контекст прогресса Job."""
        with self._lock:
            job = self._jobs.get(str(job_id))
            if job is None:
                return None
            progress = job.progress_context.to_dict()
            progress["job_id"] = job.id
            progress["state"] = job.state.value
            progress["worker_id"] = job.worker_id
            return progress

    def get_progress_snapshot(self) -> dict[str, dict]:
        """Снимок прогресса всех Job, пригодный для Web/GUI/диагностики."""
        with self._lock:
            return {
                job.id: {
                    **job.progress_context.to_dict(),
                    "job_id": job.id,
                    "state": job.state.value,
                    "worker_id": job.worker_id,
                }
                for job in self._jobs.values()
            }

    def _remove_from_queues_locked(self, job_id: str) -> None:
        for queue in self._queues.values():
            if queue.remove(job_id) is not None:
                return

    def cancel(self, job_id: str) -> bool:
        with self._lock:
            job = self._jobs.get(job_id)
            if not job or job.state in TERMINAL_STATES:
                return False

            # RETRY_WAIT не имеет Worker, который позже завершит CANCELLING,
            # поэтому отменяем timer и переводим Job сразу в terminal state.
            if job.state == JobState.RETRY_WAIT:
                timer = self._retry_timers.pop(job.id, None)
                if timer is not None:
                    timer.cancel()
                self._retry_waiting.pop(job.id, None)
                job.cancel_event.set()
                job.retry_at = None
                job.transition(JobState.CANCELLING, stage="cancelling")
                job.transition(JobState.CANCELLED, stage="cancelled")
                snapshot = job.to_dict()
                self.events.publish(EventType.JOB_CANCELLED, source="hub", job=snapshot, reason="cancelled_during_retry_wait")
                self._wake.notify_all()
                self._aux_wake.notify_all()
                return True

            changed = job.request_cancel()
            if not changed:
                return False
            if job.state == JobState.CANCELLED:
                self._remove_from_queues_locked(job_id)
                self.events.publish(EventType.JOB_CANCELLED, source="hub", job=job.to_dict())
            else:
                self.events.publish(EventType.JOB_STATE_CHANGED, source="hub", job=job.to_dict())
            self._wake.notify_all()
            self._aux_wake.notify_all()
            return True

    def set_priority(self, job_id: str, priority: JobPriority) -> bool:
        with self._lock:
            job = self._jobs.get(job_id)
            if not job or job.state in TERMINAL_STATES:
                return False
            job.priority = JobPriority(priority)
            snapshot = self._queue_snapshot_job_locked(job)
            self._wake.notify_all()
            self._aux_wake.notify_all()
        self.events.publish(EventType.JOB_PRIORITY_CHANGED, source="hub", job=snapshot)
        return True

    def retry(self, job_id: str) -> Optional[Job]:
        with self._lock:
            old = self._jobs.get(job_id)
            if not old or old.state not in TERMINAL_STATES:
                return None
            old_data = {
                "url": old.url, "mode": old.mode, "user_name": old.user_name,
                "telegram_chat_id": old.telegram_chat_id, "priority": old.priority,
                "queue_type": old.queue_type,
                "metadata": {k: v for k, v in old.metadata.items() if not str(k).startswith("circuit_")},
                "old_id": old.id,
            }
        job = self.create_job(
            url=old_data["url"], mode=old_data["mode"], user_name=old_data["user_name"],
            telegram_chat_id=old_data["telegram_chat_id"], priority=old_data["priority"],
            queue_type=old_data["queue_type"], metadata=old_data["metadata"],
        )
        job.retry_of = old_data["old_id"]
        with self._lock:
            self._callbacks[job.id] = self._queue_handlers.get(job.queue_type)
            snapshot = self._queue_snapshot_job_locked(job)
        self.events.publish(EventType.JOB_RETRY, source="hub", source_job_id=old_data["old_id"], job=snapshot)
        return job

    def set_result(self, job_id: str, **values) -> bool:
        with self._lock:
            job = self._jobs.get(job_id)
            if not job:
                return False
            job.set_result(**values)
            snapshot = self._snapshot_job_locked(job)
        self.events.publish(EventType.JOB_RESULT_UPDATED, source="hub", job=snapshot)
        return True

    def add_artifact(self, job_id: str, path) -> bool:
        with self._lock:
            job = self._jobs.get(job_id)
            if not job:
                return False
            job.add_artifact(path)
            snapshot = self._snapshot_job_locked(job)
        self.events.publish(EventType.JOB_ARTIFACT_ADDED, source="hub", job=snapshot)
        return True

    def apply_event(self, event: dict) -> bool:
        """Применить событие к каноническому Job-состоянию.

        Этот метод используется Hub для событий, пришедших от Worker через Event Bus.
        Он ничего не публикует сам, чтобы не создавать циклическую цепочку событий.
        """
        event_type = EventBus.normalize_type(event.get("type", ""))
        job_id = str(event.get("job_id") or ((event.get("job") or {}).get("id") if isinstance(event.get("job"), dict) else "") or "")
        if not job_id:
            return False
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None:
                return False

            changed = False
            worker_id = event.get("worker_id")
            if worker_id and job.worker_id != str(worker_id):
                job.worker_id = str(worker_id)
                changed = True

            if event_type == EventType.JOB_STARTED.value:
                # Event-driven запуск должен синхронизировать и очередь, и active.
                if self._queues[job.queue_type].contains(job.id):
                    self._queues[job.queue_type].remove(job.id)
                    self._active[job.id] = job
                    changed = True
                elif job.id not in self._active and job.state not in TERMINAL_STATES:
                    self._active[job.id] = job
                    changed = True
                if job.state == JobState.QUEUED:
                    job.transition(JobState.STARTING, stage="starting")
                    changed = True
            elif event_type in {EventType.JOB_STATE_REQUESTED.value, EventType.JOB_STATE_CHANGED.value}:
                target_raw = event.get("state") or ((event.get("job") or {}).get("state") if isinstance(event.get("job"), dict) else None)
                if target_raw:
                    target = JobState(target_raw)
                    if job.state != target:
                        job.transition(
                            target,
                            stage=event.get("stage"),
                            error=str(event.get("error") or ""),
                        )
                        changed = True
                    elif event.get("stage"):
                        job.stage = str(event["stage"])
            elif event_type in {EventType.JOB_PROGRESS_REQUESTED.value, EventType.JOB_PROGRESS.value}:
                progress_context = event.get("progress_context")
                if isinstance(progress_context, dict):
                    percent = progress_context.get("percent", event.get("progress", job.progress))
                    current = progress_context.get("current_question", event.get("current_question", job.current_question))
                    total = progress_context.get("total_questions", event.get("total_questions", job.total_questions))
                    stage = progress_context.get("stage", event.get("stage"))
                else:
                    percent = event.get("progress", job.progress)
                    current = event.get("current_question", job.current_question)
                    total = event.get("total_questions", job.total_questions)
                    stage = event.get("stage")
                revision_raw = event.get("progress_revision")
                if revision_raw is None and isinstance(progress_context, dict):
                    revision_raw = progress_context.get("revision")
                revision = int(revision_raw) if revision_raw is not None else None
                changed = job.update_progress(
                    float(percent),
                    stage=stage,
                    current_question=int(current or 0),
                    total_questions=int(total or 0),
                    revision=revision,
                )
            elif event_type == EventType.JOB_COMPLETED.value:
                if job.state != JobState.COMPLETED:
                    job.transition(JobState.COMPLETED, stage="completed")
                    changed = True
                self._active.pop(job.id, None)
            elif event_type == EventType.JOB_FAILED.value:
                error = str(event.get("error") or ((event.get("job") or {}).get("error") if isinstance(event.get("job"), dict) else "") or "Job failed")
                if job.state != JobState.FAILED:
                    job.transition(JobState.FAILED, stage="failed", error=error)
                    changed = True
                elif error and not job.error:
                    job.error = error
                    job.error_reason = error
                    changed = True
                self._active.pop(job.id, None)
            elif event_type == EventType.JOB_CANCELLED.value:
                if job.state not in TERMINAL_STATES:
                    if job.state == JobState.QUEUED:
                        self._queues[job.queue_type].remove(job.id)
                        job.transition(JobState.CANCELLED, stage="cancelled")
                    else:
                        if job.state != JobState.CANCELLING:
                            job.transition(JobState.CANCELLING, stage="cancelling")
                        job.transition(JobState.CANCELLED, stage="cancelled")
                    self._active.pop(job.id, None)
                    changed = True

            if not changed:
                return False
            return True

    def mark_job_stuck(
        self,
        job_id: str,
        *,
        runtime_sec: float | None = None,
        timeout_sec: float | None = None,
        reason: str = "watchdog_timeout",
    ) -> bool:
        """Зафиксировать превышение лимита как диагностическое состояние Job."""
        with self._lock:
            job = self._jobs.get(str(job_id))
            if not job or job.state in TERMINAL_STATES:
                return False
            timeout_info = job.diagnostics.setdefault("timeout", {})
            already_stuck = bool(timeout_info.get("stuck"))
            now = time.time()
            timeout_info.update({
                "stuck": True,
                "intervention_required": not job.allow_overrun,
                "detected_at": timeout_info.get("detected_at") or now,
                "stuck_since": timeout_info.get("stuck_since") or now,
                "runtime_sec": float(runtime_sec if runtime_sec is not None else (job.runtime_seconds_at(now) or 0.0)),
                "timeout_sec": float(timeout_sec if timeout_sec is not None else (job.max_runtime_sec or 0.0)),
                "reason": str(reason),
                "policy": job.timeout_policy,
                "recovery_status": timeout_info.get("recovery_status") or "pending",
            })
            snapshot = self._snapshot_job_locked(job)
        if not already_stuck:
            self.events.publish(
                EventType.JOB_STUCK, source="watchdog", job=snapshot,
                reason=str(reason), runtime_sec=snapshot["runtime_seconds"],
                timeout_sec=snapshot["max_runtime_sec"],
                intervention_required=snapshot["intervention_required"],
            )
        return True

    def recover_stuck_job(self, job_id: str, *, reason: str = "watchdog_timeout") -> bool:
        """Попытаться восстановить зависшую Job через Chrome её Worker."""
        with self._lock:
            job = self._jobs.get(str(job_id))
            if not job or job.state in TERMINAL_STATES:
                return False
            timeout_info = job.diagnostics.setdefault("timeout", {})
            if not timeout_info.get("stuck"):
                timeout_info.update({
                    "stuck": True,
                    "intervention_required": not job.allow_overrun,
                    "stuck_since": time.time(),
                    "reason": str(reason),
                })
            if job.allow_overrun:
                return False
            context = self._contexts.get(job.worker_id or "")
            worker_id = job.worker_id
            attempt = int(timeout_info.get("recovery_attempts", 0) or 0) + 1
            timeout_info["recovery_attempts"] = attempt
            timeout_info["recovery_status"] = "recovery_requested"
            timeout_info["last_recovery_at"] = time.time()
            job.diagnostics["timeout"] = timeout_info
            snapshot_started = self._snapshot_job_locked(job)
        self.events.publish(
            EventType.JOB_RECOVERY_STARTED, source="watchdog", job=snapshot_started,
            worker_id=worker_id, recovery_attempt=attempt, reason=str(reason),
            action="restart_chrome",
        )
        ok = bool(context and context.restart_browser(self.logger))
        with self._lock:
            current = self._jobs.get(str(job_id))
            if current is None:
                return ok
            timeout_info = current.diagnostics.setdefault("timeout", {})
            timeout_info["recovery_status"] = "recovered" if ok else "recovery_failed"
            timeout_info["last_recovery_result"] = "success" if ok else "failed"
            current.diagnostics["timeout"] = timeout_info
            snapshot = self._snapshot_job_locked(current)
        self.events.publish(
            EventType.JOB_RECOVERY_SUCCEEDED if ok else EventType.JOB_RECOVERY_FAILED,
            source="watchdog", job=snapshot, worker_id=worker_id,
            recovery_attempt=attempt, reason=str(reason), action="restart_chrome",
        )
        return ok

    def terminate_stuck_job(self, job_id: str, *, reason: str = "watchdog_timeout") -> bool:
        """Принудительно завершить зависшую Job и освободить ресурсы её Worker."""
        with self._lock:
            job = self._jobs.get(str(job_id))
            if not job or job.state in TERMINAL_STATES:
                return False
            timeout_info = job.diagnostics.setdefault("timeout", {})
            timeout_info["stuck"] = True
            timeout_info["intervention_required"] = True
            timeout_info["force_terminate"] = True
            timeout_info["recovery_status"] = "terminating"
            timeout_info["terminated_at"] = time.time()
            timeout_info["termination_reason"] = str(reason)
            job.cancel_event.set()
            context = self._contexts.get(job.worker_id or "")
            worker_id = job.worker_id
            self._active.pop(job.id, None)
            job_id_value = job.id
            

        if context is not None:
            try:
                context.release_job_resources()
            except Exception as exc:
                if self.logger:
                    self.logger.warning(f"Worker {worker_id}: ошибка освобождения зависшей Job {job_id_value}: {exc}")

        with self._lock:
            current = self._jobs.get(job_id_value)
            if current is None:
                return False
            if current.state not in TERMINAL_STATES:
                current.transition(JobState.FAILED, stage="stuck_terminated", error=f"Превышен лимит выполнения Job ({reason}).")
            timeout_info = current.diagnostics.setdefault("timeout", {})
            timeout_info["recovery_status"] = "terminated"
            timeout_info["intervention_required"] = False
            snapshot = self._snapshot_job_locked(current)
            self._wake.notify_all()
        self.events.publish(
            EventType.JOB_STUCK_TERMINATED, source="watchdog", job=snapshot,
            worker_id=worker_id, reason=str(reason),
        )
        self.events.publish(EventType.JOB_FAILED, source="watchdog", job=snapshot,
                            error=snapshot.get("error"), worker_id=worker_id,
                            reason=str(reason))
        return True

    def clear_pending(self) -> int:
        count = 0
        with self._lock:
            for queue_type, queue in self._queues.items():
                for job in queue.clear():
                    if job.state == JobState.QUEUED:
                        job.cancel_event.set()
                        job.transition(JobState.CANCELLED, stage="cancelled")
                        count += 1
                        self.events.publish(EventType.JOB_CANCELLED, source="hub", job=job.to_dict())
            self._wake.notify_all()
            self._aux_wake.notify_all()
        return count

    def cancel_all(self) -> int:
        with self._lock:
            jobs = [j for j in self._jobs.values() if j.state not in TERMINAL_STATES]
        count = 0
        for job in jobs:
            if self.cancel(job.id):
                count += 1
        return count

    def get_queue_position(self, job_id: str) -> Optional[int]:
        with self._lock:
            job = self._jobs.get(str(job_id))
            if not job or job.state != JobState.QUEUED:
                return None
            return self._queues[job.queue_type].position(job.id)

    def get_waiting_seconds(self, job_id: str) -> Optional[float]:
        with self._lock:
            job = self._jobs.get(str(job_id))
            if not job or job.state != JobState.QUEUED:
                return None
            return round(job.waiting_seconds, 1)

    def queue_snapshot(self, queue_type: Optional[QueueType | str] = None) -> dict:
        with self._lock:
            now = None
            if queue_type is not None:
                queue = QueueType(queue_type)
                jobs = self._queues[queue].snapshot(now)
                return {
                    "queue_type": queue.value,
                    "queue_size": len(jobs),
                    "jobs": jobs,
                }

            queues = {
                q.value: self._queues[q].snapshot(now)
                for q in QueueType
            }
            return {
                "queues": queues,
                "queue_sizes": {q.value: len(queues[q.value]) for q in QueueType},
                "total_queue_size": sum(len(items) for items in queues.values()),
            }

    def snapshot(self, include_history: bool = True) -> dict:
        with self._lock:
            queued = []
            for queue_type in QueueType:
                queued.extend(self._queues[queue_type].snapshot())
            queued.sort(
                key=lambda j: (
                    j["queue_type"],
                    -float(j["effective_priority"]),
                    float(j["created_at"]),
                    j["id"],
                )
            )
            active = [
                self._snapshot_job_locked(j)
                for j in self._active.values()
                if j.state not in TERMINAL_STATES and j.state != JobState.RETRY_WAIT
            ]
            retry_waiting = [self._snapshot_job_locked(j) for j in self._retry_waiting.values()]
            history = [j for j in self._jobs.values() if j.state in TERMINAL_STATES]
            history_dicts = [self._snapshot_job_locked(j) for j in sorted(history, key=lambda x: x.finished_at or 0, reverse=True)[:50]]
            queues = {
                q.value: self._queues[q].snapshot()
                for q in QueueType
            }
            workers = [context.snapshot() for context in self._contexts.values()]
            workers.sort(key=lambda item: item["worker_id"])
            return {
                "queued": queued,
                "active": active,
                "retry_waiting": retry_waiting,
                "history": history_dicts if include_history else [],
                "queue_size": len(queued),
                "running": len(active),
                "worker_count": self.worker_count,
                "available_worker_count": sum(1 for item in workers if item.get("alive") and not item.get("job_id")),
                "workers": workers,
                "queue_sizes": {q.value: len(queues[q.value]) for q in QueueType},
                "queues": queues,
                "total_queue_size": len(queued),
                "resource": self.resource_manager.snapshot(),
            }

    def _snapshot_job_locked(self, job: Job) -> dict:
        snapshot = job.to_dict()
        if job.state == JobState.QUEUED:
            queue = self._queues[job.queue_type]
            snapshot["queue_position"] = queue.position(job.id)
        else:
            snapshot["queue_position"] = None
        return snapshot

    def _queue_snapshot_job_locked(self, job: Job) -> dict:
        return self._snapshot_job_locked(job)

    def _next_job(self, queue_type: QueueType) -> Optional[Job]:
        return self._queues[queue_type].pop()

    def _wait_for_test_job_locked(self, worker_id: str | None = None) -> Optional[Job]:
        while not self._stop:
            if worker_id:
                context = self._contexts.get(worker_id)
                if worker_id in self._draining_workers or (context is not None and not context.accepting_jobs):
                    self._wake.wait(timeout=1.0)
                    continue
            decision = self.resource_manager.check()
            if not decision.allowed:
                if decision.reason != self._last_resource_block_reason:
                    self._last_resource_block_reason = decision.reason
                    self.events.publish(EventType.RESOURCE_THROTTLED, source="resource-manager", reason=decision.reason, resource=decision.to_dict())
                self._wake.wait(timeout=0.75)
                continue
            self._last_resource_block_reason = ""
            job = self._next_job(QueueType.TEST_QUEUE)
            if job is not None:
                return job
            self._wake.wait(timeout=1.0)
        return None

    def _prepare_job_locked(self, job: Job, worker_id: str, queue_type: QueueType) -> Optional[Callable]:
        job.worker_id = worker_id
        self._active[job.id] = job
        if job.cancel_event.is_set():
            if job.state == JobState.QUEUED:
                job.transition(JobState.CANCELLED, stage="cancelled")
            self._active.pop(job.id, None)
            return None
        job.attempts += 1
        job.retry_at = None
        # Каждый attempt имеет независимый progress lifecycle.
        job.progress_context.update(percent=0.0, stage="starting", current_question=0, total_questions=0)
        job.transition(JobState.STARTING, stage="starting")
        if queue_type == QueueType.TEST_QUEUE:
            context = self._contexts.get(worker_id)
            if context:
                context.mark_busy(job.id)
        return self._callbacks.get(job.id) or self._queue_handlers.get(queue_type)

    def _finish_job(self, job: Job, exc: Optional[Exception]) -> dict:
        if job.state not in TERMINAL_STATES:
            timeout_info = (job.diagnostics or {}).get("timeout", {})
            if timeout_info.get("force_terminate"):
                job.transition(JobState.FAILED, stage="stuck_terminated", error=f"Превышен лимит выполнения Job ({timeout_info.get('termination_reason') or 'watchdog_timeout'}).")
            elif job.cancel_event.is_set():
                if job.state != JobState.CANCELLING:
                    job.transition(JobState.CANCELLING, stage="cancelling")
                job.transition(JobState.CANCELLED, stage="cancelled")
            elif exc is not None:
                job.transition(JobState.FAILED, stage="failed", error=str(exc))
            else:
                job.transition(JobState.COMPLETED, stage="completed")
        return job.to_dict()

    def _execute_callback(self, job: Job, callback: Callable, context=None) -> Optional[Exception]:
        try:
            callback(job, context)
            return None
        except Exception as exc:  # noqa: BLE001
            return exc

    def _schedule_retry_locked(self, job: Job, exc: Exception, decision, diagnostic=None) -> None:
        now = time.time()
        retry_at = now + float(decision.delay_sec)
        job.retry_at = retry_at
        job.error = str(exc)
        job.error_reason = "retry_scheduled"
        entry = {
            "attempt": job.attempts, "attempt_id": job.attempt_id, "timestamp": now,
            "error": str(exc), "exception_type": type(exc).__name__,
            "delay_sec": float(decision.delay_sec), "retry_at": retry_at,
            "diagnostics": dict(diagnostic or {}),
        }
        job.retry_history.append(entry)
        job.diagnostics.setdefault("retries", []).append(dict(entry))
        job.transition(JobState.RETRY_WAIT, stage="retry_wait", error=str(exc))
        self._retry_waiting[job.id] = job
        timer = threading.Timer(float(decision.delay_sec), self._enqueue_retry, args=(job.id,))
        timer.daemon = True
        self._retry_timers[job.id] = timer
        timer.start()

    def _enqueue_retry(self, job_id: str) -> None:
        with self._lock:
            timer = self._retry_timers.pop(str(job_id), None)
            job = self._retry_waiting.pop(str(job_id), None)
            if self._stop or job is None or job.state != JobState.RETRY_WAIT or job.cancel_event.is_set():
                return
            job.retry_at = None
            job.queued_at = time.time()
            job.transition(JobState.QUEUED, stage="queued_after_retry")
            self._queues[job.queue_type].requeue(job)
            snapshot = self._queue_snapshot_job_locked(job)
            self._wake.notify_all()
            self._aux_wake.notify_all()
        self.events.publish(EventType.JOB_RETRY_READY, source="retry-policy", job=snapshot)
        self.events.publish(EventType.JOB_QUEUED, source="retry-policy", job=snapshot)

    def drain_worker(self, worker_id: str) -> bool:
        with self._lock:
            worker_id = str(worker_id)
            if worker_id not in self._contexts:
                return False
            self._draining_workers.add(worker_id)
            context = self._contexts[worker_id]
            context.drain()
            self.events.publish(EventType.WORKER_DRAINED, source="hub", worker_id=worker_id, worker_state=context.state.value)
            self._wake.notify_all()
            return True

    def undrain_worker(self, worker_id: str) -> bool:
        with self._lock:
            worker_id = str(worker_id)
            if worker_id not in self._contexts:
                return False
            self._draining_workers.discard(worker_id)
            context = self._contexts[worker_id]
            context.undrain()
            self.events.publish(EventType.WORKER_UNDRAINED, source="hub", worker_id=worker_id, worker_state=context.state.value)
            self._wake.notify_all()
            return True

    def _worker_loop(self, worker_id: str) -> None:
        self.events.publish(EventType.WORKER_STARTED, source="worker", worker_id=worker_id, queue_type=QueueType.TEST_QUEUE.value)
        while True:
            with self._lock:
                job = self._wait_for_test_job_locked(worker_id)
                if self._stop:
                    break
                if job is None:
                    continue
                context = self._contexts.get(worker_id)
                if context:
                    context.set_job(job.id)
                callback = self._prepare_job_locked(job, worker_id, QueueType.TEST_QUEUE)
                if job.state == JobState.CANCELLED:
                    snapshot = job.to_dict()
                    self.events.publish("JobCancelled", job=snapshot)
                    if context:
                        context.set_job(None)
                    continue
                self.events.publish(EventType.JOB_STARTED, source="worker", worker_id=worker_id, job=job.to_dict(), state=job.state.value)
            exc = RuntimeError("Для Job не назначен callback") if callback is None else self._execute_callback(job, callback, context)
            diagnostic = None
            if exc is not None and self.diagnostics_manager is not None:
                try:
                    diagnostic = self.diagnostics_manager.capture_failure(job, exc, context, phase="worker")
                    job.diagnostics["latest_capture"] = diagnostic
                except Exception as diagnostic_exc:
                    if self.logger:
                        self.logger.warning(f"Diagnostics {job.id}: {diagnostic_exc}")
            if context:
                try:
                    # Chrome и остальные ресурсы всегда освобождаются до следующей Job,
                    # даже если текущая Job будет автоматически повторена.
                    context.release_job_resources()
                except Exception as resource_exc:
                    if self.logger:
                        self.logger.warning(
                            f"Worker {worker_id}: ошибка очистки ресурсов Job {job.id}: {resource_exc}"
                        )
                    if exc is None:
                        exc = resource_exc
            should_retry = False
            decision = None
            with self._lock:
                if exc is not None and not job.cancel_event.is_set() and not ((job.diagnostics or {}).get("timeout", {}).get("force_terminate")):
                    decision = RetryPolicy.decide(job, exc)
                    should_retry = decision.retry
                    if should_retry:
                        self._schedule_retry_locked(job, exc, decision, diagnostic)
                self._active.pop(job.id, None)
                if context:
                    context.set_job(None)
                if should_retry:
                    snapshot = self._snapshot_job_locked(job)
                else:
                    snapshot = self._finish_job(job, exc)
                self._wake.notify_all()
            if should_retry:
                if self.logger:
                    self.logger.warning(f"Job {job.id}: ошибка, повтор через {decision.delay_sec:.1f}с ({job.attempts}/{decision.max_attempts})")
                self.events.publish(EventType.JOB_RETRY_SCHEDULED, source="worker", job=snapshot, retry_at=job.retry_at, delay_sec=decision.delay_sec, attempt=job.attempts, max_attempts=decision.max_attempts, reason=decision.reason)
            elif exc is not None:
                if self.logger:
                    self.logger.error(f"Job {job.id} завершилась ошибкой: {exc}")
                self.events.publish(EventType.JOB_FAILED, source="worker", job=snapshot)
            elif job.state == JobState.COMPLETED:
                self.events.publish(EventType.JOB_COMPLETED, source="worker", job=snapshot)
            else:
                self.events.publish("JobCancelled", job=snapshot)
        self.events.publish(EventType.WORKER_STOPPED, source="worker", worker_id=worker_id, queue_type=QueueType.TEST_QUEUE.value)

    def _aux_worker_loop(self, queue_type: QueueType, worker_id: str) -> None:
        self.events.publish(EventType.WORKER_STARTED, source="worker", worker_id=worker_id, queue_type=queue_type.value)
        while True:
            with self._lock:
                while not self._stop:
                    job = self._next_job(queue_type)
                    if job is not None:
                        break
                    self._aux_wake.wait(timeout=1.0)
                if self._stop:
                    break
                callback = self._prepare_job_locked(job, worker_id, queue_type)
                if job.state == JobState.CANCELLED:
                    snapshot = job.to_dict()
                    self.events.publish("JobCancelled", job=snapshot)
                    continue
                self.events.publish(EventType.JOB_STARTED, source="worker", worker_id=worker_id, job=job.to_dict(), state=job.state.value)
            exc = RuntimeError(f"Для {queue_type.value} не назначен callback") if callback is None else self._execute_callback(job, callback, None)
            with self._lock:
                snapshot = self._finish_job(job, exc)
                self._active.pop(job.id, None)
                self._aux_wake.notify_all()
            if exc is not None:
                if self.logger:
                    self.logger.error(f"{queue_type.value} Job {job.id}: {exc}")
                self.events.publish(EventType.JOB_FAILED, source="worker", job=snapshot)
            elif job.state == JobState.COMPLETED:
                self.events.publish(EventType.JOB_COMPLETED, source="worker", job=snapshot)
            else:
                self.events.publish("JobCancelled", job=snapshot)
        self.events.publish(EventType.WORKER_STOPPED, source="worker", worker_id=worker_id, queue_type=queue_type.value)
