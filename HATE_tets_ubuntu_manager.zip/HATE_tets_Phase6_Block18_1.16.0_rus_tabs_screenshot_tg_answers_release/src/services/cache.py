"""Кэш пройденных тестов.

Хранится в data/cache.json.

Формат записи:
    {
        "cheatsheet_path": "...",
        "short_path": "...",
        "telegram_text": "...",
        "timestamp": "2026-09-24 22:20:58",
        "answers": [
            {"q": "Когда произошло первое столкновение...", "letter": "А"},
            ...
        ]
    }

Поле answers добавлено позже — старые записи мигрируются при загрузке
через перепарсинг cheatsheet_path.
"""
from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from .config import get_data_dir

MAX_CACHE_ENTRIES = 500

_CHEAT_QUESTION_RE = re.compile(r"^Вопрос №\d+:\s*(.+)$")
_CHEAT_ANSWER_RE = re.compile(r"^Правильный ответ:\s*(.+)$")
_OPTION_LETTER_RE = re.compile(r"^\s*\(?([А-Яа-яЁёA-Za-z])[\s\)\.\:\-]\s*")


def _cache_path() -> Path:
    return get_data_dir() / "cache.json"


def _extract_letter(text: str) -> Optional[str]:
    if not text:
        return None
    m = _OPTION_LETTER_RE.match(text)
    return m.group(1).upper() if m else None


def _migrate_answers_from_file(cheatsheet_path: str) -> List[Dict[str, str]]:
    """Восстанавливает пары {q, letter} из сохранённого .txt-файла."""
    p = Path(cheatsheet_path)
    if not p.exists():
        return []
    try:
        lines = p.read_text(encoding="utf-8").splitlines()
    except OSError:
        return []

    result: List[Dict[str, str]] = []
    current_q: Optional[str] = None
    for raw in lines:
        line = raw.strip()
        mq = _CHEAT_QUESTION_RE.match(line)
        if mq:
            current_q = mq.group(1).strip()
            continue
        ma = _CHEAT_ANSWER_RE.match(line)
        if ma and current_q:
            letter = _extract_letter(ma.group(1))
            result.append({"q": current_q, "letter": letter or ""})
            current_q = None
    return result


class Cache:
    def __init__(self, logger=None):
        self.logger = logger
        self.data: Dict[str, Dict[str, Any]] = {}
        self._load()
        self._migrate_legacy()

    # ------------------------------------------------------------------ #
    def _load(self) -> None:
        path = _cache_path()
        if not path.exists():
            return
        try:
            self.data = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(self.data, dict):
                self.data = {}
        except Exception as exc:
            if self.logger:
                self.logger.warning(f"Не удалось прочитать кэш: {exc}")
            self.data = {}

    def _save(self) -> None:
        try:
            _cache_path().write_text(
                json.dumps(self.data, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except OSError as exc:
            if self.logger:
                self.logger.warning(f"Не удалось сохранить кэш: {exc}")

    def _migrate_legacy(self) -> None:
        """Добавляет поле answers там, где его нет, парся .txt-шпаргалку."""
        changed = 0
        for url, entry in list(self.data.items()):
            if not isinstance(entry, dict):
                continue
            if "answers" in entry and isinstance(entry["answers"], list):
                continue
            cheat = entry.get("cheatsheet_path")
            if not cheat:
                entry["answers"] = []
                changed += 1
                continue
            pairs = _migrate_answers_from_file(cheat)
            entry["answers"] = pairs
            changed += 1
        if changed:
            self._save()
            if self.logger:
                self.logger.info(f"Кэш: мигрировано записей: {changed}.")

    def _enforce_limit(self) -> None:
        if len(self.data) <= MAX_CACHE_ENTRIES:
            return
        items = sorted(
            self.data.items(),
            key=lambda kv: (kv[1] or {}).get("timestamp", ""),
        )
        to_remove = len(self.data) - MAX_CACHE_ENTRIES
        for url, _ in items[:to_remove]:
            self.data.pop(url, None)
        if self.logger and to_remove > 0:
            self.logger.info(f"Кэш переполнен — удалено {to_remove} старых записей.")
        self._save()

    # ------------------------------------------------------------------ #
    def get(self, url: str) -> Optional[Dict[str, Any]]:
        url = (url or "").strip()
        return self.data.get(url)

    def put(
        self,
        url: str,
        cheatsheet_path: Path,
        short_path: Path,
        telegram_text: str,
        answers: Optional[List[Dict[str, str]]] = None,
    ) -> None:
        url = (url or "").strip()
        self.data[url] = {
            "cheatsheet_path": str(cheatsheet_path),
            "short_path": str(short_path),
            "telegram_text": telegram_text,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "answers": answers or [],
        }
        self._save()
        self._enforce_limit()
        if self.logger:
            self.logger.info(f"URL добавлен в кэш: {url}")
