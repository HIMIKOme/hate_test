"""Кросс-процессный live transport для Web/SSE.

Hub публикует события в локальный TCP broker. Web-процесс подключается к broker
как клиент и уже преобразует поток в Server-Sent Events. В отличие от частого
polling файла журнала, доставка идёт push-моделью и не зависит от чтения файла.
"""
from __future__ import annotations

import json
import os
import queue
import socket
import socketserver
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Optional

from .ipc import base_dir

DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 18765
PORT_RANGE = 25
ENDPOINT_FILE = "live_events.json"
PROTOCOL = "hate-live-events-v1"
QUEUE_SIZE = 512


def endpoint_path() -> Path:
    path = base_dir() / "data" / "ipc" / ENDPOINT_FILE
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def read_endpoint() -> dict[str, Any]:
    return _read_json(endpoint_path())


def _write_endpoint(payload: dict[str, Any]) -> None:
    path = endpoint_path()
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def clear_endpoint(pid: int | None = None) -> None:
    path = endpoint_path()
    try:
        current = _read_json(path)
        if pid is None or int(current.get("pid", 0) or 0) == int(pid):
            path.unlink(missing_ok=True)
    except Exception:
        pass


class _Client:
    def __init__(self, conn: socket.socket, address: Any):
        self.conn = conn
        self.address = address
        self.queue: queue.Queue[bytes] = queue.Queue(maxsize=QUEUE_SIZE)
        self.closed = threading.Event()

    def offer(self, payload: bytes) -> None:
        if self.closed.is_set():
            return
        try:
            self.queue.put_nowait(payload)
        except queue.Full:
            # Медленный браузер не должен блокировать Hub.
            try:
                self.queue.get_nowait()
            except queue.Empty:
                pass
            try:
                self.queue.put_nowait(payload)
            except queue.Full:
                pass

    def close(self) -> None:
        self.closed.set()
        try:
            self.conn.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        try:
            self.conn.close()
        except OSError:
            pass


class _ThreadingTCPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(self, server_address, handler_cls, owner):
        self.owner = owner
        super().__init__(server_address, handler_cls)


def _recv_line(conn: socket.socket, timeout: float = 2.0, max_bytes: int = 256) -> bytes | None:
    conn.settimeout(timeout)
    buf = bytearray()
    try:
        while len(buf) < max_bytes:
            chunk = conn.recv(1)
            if not chunk:
                return None
            if chunk == b"\n":
                return bytes(buf)
            buf.extend(chunk)
    except OSError:
        return None
    return None


class _Handler(socketserver.BaseRequestHandler):
    def handle(self) -> None:
        owner: "LiveEventServer" = self.server.owner
        conn = self.request
        # Первой строкой клиент сообщает протокол. Вторая строка может быть
        # необязательным запросом SNAPSHOT — нужен независимым GUI-клиентам.
        hello = _recv_line(conn, timeout=2.0)
        if hello != PROTOCOL.encode("utf-8"):
            return
        request = _recv_line(conn, timeout=0.15)
        want_snapshot = request == b"SNAPSHOT"

        client = _Client(conn, self.client_address)
        owner._register(client)
        try:
            client.offer((json.dumps({
                "type": "LiveConnected",
                "timestamp": time.time(),
                "protocol": PROTOCOL,
                "server_pid": os.getpid(),
                "event_id": f"live-{uuid.uuid4().hex[:12]}",
            }, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8"))
            if want_snapshot and owner.snapshot_provider is not None:
                try:
                    client.offer((json.dumps({
                        "type": "StateSnapshot",
                        "timestamp": time.time(),
                        "source": "live-broker",
                        "state": owner.snapshot_provider(),
                    }, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8"))
                except Exception as exc:
                    if owner.logger:
                        owner.logger.debug(f"Live snapshot provider failed: {exc}")
            while not owner.stopping.is_set() and not client.closed.is_set():
                try:
                    payload = client.queue.get(timeout=10.0)
                except queue.Empty:
                    try:
                        conn.sendall(b"{\"type\":\"LiveKeepalive\"}\n")
                    except OSError:
                        break
                    continue
                try:
                    conn.sendall(payload)
                except OSError:
                    break
        finally:
            owner._unregister(client)
            client.close()


class LiveEventClient:
    """Блокирующий клиент локального live broker."""

    def __init__(self, sock: socket.socket):
        self.sock = sock
        self.sock.settimeout(12.0)
        self._buffer = b""

    def recv(self, timeout: float = 12.0) -> Optional[dict[str, Any]]:
        self.sock.settimeout(timeout)
        deadline = time.time() + timeout
        while time.time() < deadline:
            marker = self._buffer.find(b"\n")
            if marker >= 0:
                raw, self._buffer = self._buffer[:marker], self._buffer[marker + 1:]
                if not raw:
                    continue
                try:
                    value = json.loads(raw.decode("utf-8"))
                except (ValueError, UnicodeDecodeError):
                    continue
                return value if isinstance(value, dict) else None
            try:
                chunk = self.sock.recv(65536)
            except socket.timeout:
                return None
            except OSError:
                return None
            if not chunk:
                return None
            self._buffer += chunk
        return None

    def close(self) -> None:
        try:
            self.sock.close()
        except OSError:
            pass


def connect_client(timeout: float = 2.0, request_snapshot: bool = False) -> Optional[LiveEventClient]:
    endpoint = read_endpoint()
    if endpoint.get("protocol") != PROTOCOL:
        return None
    try:
        host = str(endpoint.get("host") or DEFAULT_HOST)
        port = int(endpoint.get("port") or 0)
    except (TypeError, ValueError):
        return None
    if not port:
        return None
    try:
        sock = socket.create_connection((host, port), timeout=timeout)
        payload = (PROTOCOL + "\n" + ("SNAPSHOT\n" if request_snapshot else ""))
        sock.sendall(payload.encode("utf-8"))
        return LiveEventClient(sock)
    except OSError:
        return None


class LiveEventServer:
    """Неблокирующий broadcaster локальных событий для независимого Web."""

    def __init__(self, logger=None, host: str = DEFAULT_HOST, snapshot_provider=None):
        self.logger = logger
        self.host = host
        self.snapshot_provider = snapshot_provider
        self.port: int | None = None
        self._server: _ThreadingTCPServer | None = None
        self._thread: threading.Thread | None = None
        self._clients: set[_Client] = set()
        self._clients_lock = threading.RLock()
        self.stopping = threading.Event()
        self.pid = os.getpid()

    def start(self) -> int:
        if self._server is not None:
            return int(self.port or 0)
        server = None
        for candidate in range(DEFAULT_PORT, DEFAULT_PORT + PORT_RANGE):
            try:
                server = _ThreadingTCPServer((self.host, candidate), _Handler, self)
                self.port = candidate
                break
            except OSError:
                continue
        if server is None:
            raise OSError("Не удалось открыть live event TCP-порт")
        self._server = server
        self.stopping.clear()
        self._thread = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.2}, name="live-events", daemon=True)
        self._thread.start()
        _write_endpoint({
            "protocol": PROTOCOL,
            "host": self.host,
            "port": self.port,
            "pid": self.pid,
            "started_at": time.time(),
            "endpoint": f"{self.host}:{self.port}",
        })
        return int(self.port)

    def publish(self, event: dict[str, Any]) -> None:
        """Быстро поставить событие в очереди клиентов; никогда не блокирует Hub."""
        try:
            payload = (json.dumps(dict(event), ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")
        except Exception:
            return
        with self._clients_lock:
            clients = list(self._clients)
        for client in clients:
            client.offer(payload)

    def _register(self, client: _Client) -> None:
        with self._clients_lock:
            self._clients.add(client)

    def _unregister(self, client: _Client) -> None:
        with self._clients_lock:
            self._clients.discard(client)

    def stop(self) -> None:
        self.stopping.set()
        with self._clients_lock:
            clients = list(self._clients)
            self._clients.clear()
        for client in clients:
            client.close()
        server, self._server = self._server, None
        if server is not None:
            try:
                server.shutdown()
            except Exception:
                pass
            try:
                server.server_close()
            except OSError:
                pass
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2)
        self._thread = None
        clear_endpoint(self.pid)
        self.port = None
