"""Общее состояние deployment/rebuild для независимых процессов."""
from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path
from typing import Any

from .ipc import base_dir

DEPLOYMENT_PATH = base_dir() / "data" / "deployment.json"
DEPLOYMENT_LOCK = base_dir() / "data" / "deployment.lock"
DEPLOYMENT_MARKER = base_dir() / "data" / "deployment.in_progress"
DEPLOYMENT_SNAPSHOT = base_dir() / "data" / "deployment_snapshot.json"
REBUILD_STATES = {"preparing", "stopping", "building", "starting", "checking", "rollback"}
STAGE_ORDER = ("preparing", "stopping", "building", "starting", "checking", "online")
SEMVER_RE = re.compile(r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$")


def read(path: Path | None = None, default: dict | None = None) -> dict:
    fallback = dict(default or {})
    target = path or DEPLOYMENT_PATH
    try:
        value = json.loads(target.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else fallback
    except Exception:
        return fallback


def write_status(status: str, message: str = "", **extra: Any) -> dict:
    DEPLOYMENT_PATH.parent.mkdir(parents=True, exist_ok=True)
    previous = read(default={})
    now = time.time()
    history = list(previous.get("history") or [])
    entry = {"status": status, "message": message, "timestamp": now, **extra}
    history.append(entry)
    history = history[-50:]
    payload = dict(entry)
    payload["history"] = history
    tmp = DEPLOYMENT_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(DEPLOYMENT_PATH)
    return payload


def set_marker(active: bool) -> None:
    DEPLOYMENT_MARKER.parent.mkdir(parents=True, exist_ok=True)
    if active:
        DEPLOYMENT_MARKER.write_text(json.dumps({"timestamp": time.time(), "pid": os.getpid()}), encoding="utf-8")
    else:
        try:
            DEPLOYMENT_MARKER.unlink(missing_ok=True)
        except OSError:
            pass


def is_active() -> bool:
    return DEPLOYMENT_MARKER.exists()


def valid_semver(value: str) -> bool:
    return bool(SEMVER_RE.fullmatch(str(value or "").strip()))


def save_snapshot(snapshot: dict) -> None:
    DEPLOYMENT_SNAPSHOT.parent.mkdir(parents=True, exist_ok=True)
    safe = dict(snapshot)
    cfg = safe.get("config")
    if isinstance(cfg, dict):
        cfg = dict(cfg)
        for key in ("telegram_token", "bot_token", "api_key", "password", "secret"):
            if key in cfg:
                cfg[key] = "***"
        safe["config"] = cfg
    safe["saved_at"] = time.time()
    tmp = DEPLOYMENT_SNAPSHOT.with_suffix(".tmp")
    tmp.write_text(json.dumps(safe, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(DEPLOYMENT_SNAPSHOT)


def stage_rank(status: str) -> int:
    try:
        return STAGE_ORDER.index(status)
    except ValueError:
        return -1
