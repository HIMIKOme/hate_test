"""Персистентный idempotency store для защиты от повторной постановки Job."""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
import threading
import time
from pathlib import Path
from typing import Any


class IdempotencyConflict(ValueError):
    pass


class IdempotencyStore:
    SCHEMA_VERSION = 1
    DEFAULT_TTL_SEC = 30 * 24 * 3600

    def __init__(self, path: Path, logger=None, *, ttl_sec: float = DEFAULT_TTL_SEC):
        self.path = Path(path)
        self.logger = logger
        self.ttl_sec = max(60.0, float(ttl_sec))
        self._lock = threading.RLock()
        self._items: dict[str, dict[str, Any]] = {}
        self._loaded = False

    @staticmethod
    def fingerprint(payload: dict[str, Any]) -> str:
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def _prune_expired_locked(self, now: float | None = None) -> bool:
        now = time.time() if now is None else float(now)
        cutoff = now - self.ttl_sec
        before = len(self._items)
        self._items = {
            key: value for key, value in self._items.items()
            if float(value.get("last_seen_at", value.get("created_at", 0)) or 0) >= cutoff
        }
        return len(self._items) != before

    def _load_locked(self) -> None:
        if self._loaded:
            return
        self._loaded = True
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
            if payload.get("schema_version") != self.SCHEMA_VERSION:
                return
            items = payload.get("items")
            if isinstance(items, dict):
                self._items = {str(k): dict(v) for k, v in items.items() if isinstance(v, dict) and v.get("job_id")}
        except (OSError, ValueError, TypeError):
            self._items = {}

    def lookup(self, key: str) -> dict[str, Any] | None:
        key = str(key or "").strip()
        if not key:
            return None
        with self._lock:
            self._load_locked()
            changed = self._prune_expired_locked()
            item = self._items.get(key)
            if item:
                item["last_seen_at"] = time.time()
                changed = True
            if changed:
                self._save_locked()
            return dict(item) if item else None

    def reserve(self, key: str, fingerprint: str, job_id: str) -> str | None:
        key = str(key or "").strip()
        if not key:
            return None
        with self._lock:
            self._load_locked()
            self._prune_expired_locked()
            existing = self._items.get(key)
            if existing:
                if str(existing.get("fingerprint") or "") != str(fingerprint or ""):
                    raise IdempotencyConflict(f"Idempotency key уже использовался с другим запросом: {key}")
                return str(existing.get("job_id"))
            self._items[key] = {"job_id": str(job_id), "fingerprint": str(fingerprint), "created_at": time.time(), "last_seen_at": time.time()}
            self._save_locked()
            return None

    def release(self, key: str, job_id: str) -> None:
        key = str(key or "").strip()
        with self._lock:
            self._load_locked()
            item = self._items.get(key)
            if item and str(item.get("job_id")) == str(job_id):
                self._items.pop(key, None)
                self._save_locked()

    def bind(self, key: str, job_id: str, fingerprint: str = "") -> None:
        key = str(key or "").strip()
        if not key:
            return
        with self._lock:
            self._load_locked()
            self._items[key] = {
                "job_id": str(job_id),
                "fingerprint": str(fingerprint or ""),
                "created_at": time.time(),
                "last_seen_at": time.time(),
            }
            self._save_locked()

    def prune(self, valid_job_ids: set[str]) -> None:
        with self._lock:
            self._load_locked()
            before = len(self._items)
            self._items = {k: v for k, v in self._items.items() if str(v.get("job_id")) in valid_job_ids}
            if len(self._items) != before:
                self._save_locked()

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            self._load_locked()
            return {"count": len(self._items), "items": {k: dict(v) for k, v in self._items.items()}}

    def _save_locked(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"schema_version": self.SCHEMA_VERSION, "updated_at": time.time(), "items": self._items}
        raw = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True)
        fd, name = tempfile.mkstemp(prefix=self.path.name + ".", suffix=".tmp", dir=str(self.path.parent))
        tmp = Path(name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                fh.write(raw)
                fh.flush()
                os.fsync(fh.fileno())
            tmp.replace(self.path)
        finally:
            try:
                tmp.unlink(missing_ok=True)
            except OSError:
                pass
