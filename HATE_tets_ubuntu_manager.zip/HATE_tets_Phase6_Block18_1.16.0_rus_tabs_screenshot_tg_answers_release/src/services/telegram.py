"""Отправка сообщений/файлов, удаление сообщений, long-polling."""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path
from typing import List, Optional

from .statistics import record_telegram

MAX_MESSAGE_LEN = 4000

# Если Telegram просит подождать дольше — всё равно обрежем до этого лимита.
MAX_RETRY_AFTER = 60.0

# Общее число попыток на один запрос (включая первую).
MAX_ATTEMPTS = 3


# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------

def _read_retry_after(http_error: urllib.error.HTTPError) -> float:
    """Достаёт retry_after из тела ответа Telegram (в секундах)."""
    try:
        body = json.loads(http_error.read().decode("utf-8"))
        retry_after = float(body.get("parameters", {}).get("retry_after", 3))
    except Exception:
        retry_after = 3.0
    return min(max(retry_after, 1.0), MAX_RETRY_AFTER)


def _post_with_retry(
    url: str,
    data: bytes,
    headers: Optional[dict] = None,
    timeout: float = 15.0,
) -> Optional[dict]:
    """POST-запрос с обработкой 429 (Too Many Requests).

    При 429 — читает `retry_after` из ответа и повторяет запрос
    после паузы. Прочие HTTP-ошибки и сетевые сбои — не retry'ятся
    (кроме короткой паузы на сетевые сбои).
    """
    for attempt in range(MAX_ATTEMPTS):
        req = urllib.request.Request(url, data=data, method="POST")
        if headers:
            for k, v in headers.items():
                req.add_header(k, v)

        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            if e.code == 429:
                wait = _read_retry_after(e)
                time.sleep(wait)
                continue
            # 4xx/5xx, кроме 429 — отдаём тело как есть (там ошибка).
            try:
                return json.loads(e.read().decode("utf-8"))
            except Exception:
                return None
        except Exception:
            # Сетевой сбой — короткая пауза и повтор.
            if attempt < MAX_ATTEMPTS - 1:
                time.sleep(1.0 * (attempt + 1))
                continue
            return None
    return None


def _api_call_json(token: str, method: str, params: dict, timeout: float = 15.0) -> Optional[dict]:
    url = f"https://api.telegram.org/bot{token}/{method}"
    data = urllib.parse.urlencode(params).encode("utf-8")
    return _post_with_retry(url, data, timeout=timeout)


def _api_call_multipart(token, method, fields, files, timeout=60.0) -> Optional[dict]:
    boundary = "----HATE_tets" + uuid.uuid4().hex
    body = bytearray()

    for name, value in fields.items():
        body.extend(f"--{boundary}\r\n".encode("utf-8"))
        body.extend(f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode("utf-8"))
        body.extend(str(value).encode("utf-8"))
        body.extend(b"\r\n")

    for name, (filename, data, ctype) in files.items():
        body.extend(f"--{boundary}\r\n".encode("utf-8"))
        body.extend(
            f'Content-Disposition: form-data; name="{name}"; filename="{filename}"\r\n'.encode("utf-8")
        )
        body.extend(f"Content-Type: {ctype}\r\n\r\n".encode("utf-8"))
        body.extend(data)
        body.extend(b"\r\n")

    body.extend(f"--{boundary}--\r\n".encode("utf-8"))

    url = f"https://api.telegram.org/bot{token}/{method}"
    headers = {"Content-Type": f"multipart/form-data; boundary={boundary}"}
    return _post_with_retry(url, bytes(body), headers=headers, timeout=timeout)


# ---------------------------------------------------------------------------
# Базовые методы
# ---------------------------------------------------------------------------

def get_updates(token: str, offset: int, timeout: int = 20) -> Optional[list]:
    params = {"offset": offset, "timeout": timeout, "allowed_updates": '["message","channel_post"]'}
    result = _api_call_json(token, "getUpdates", params, timeout=timeout + 10)
    if not result or not result.get("ok"):
        return None
    return result.get("result", [])


def send_text(token: str, chat_id: str, text: str) -> Optional[int]:
    """Отправляет текст. Возвращает message_id или None при ошибке."""
    if not token or not chat_id:
        record_telegram("error", success=False)
        return None
    result = _api_call_json(token, "sendMessage", {
        "chat_id": chat_id,
        "text": text,
        "disable_web_page_preview": "true",
    })
    if result and result.get("ok"):
        record_telegram("message", success=True)
        return result.get("result", {}).get("message_id")
    record_telegram("error", success=False)
    return None


def edit_text(token: str, chat_id: str, message_id: int, text: str) -> bool:
    """Изменяет существующее служебное сообщение Telegram."""
    if not token or not chat_id or not message_id or text is None:
        record_telegram("error", success=False)
        return False
    result = _api_call_json(token, "editMessageText", {
        "chat_id": chat_id,
        "message_id": message_id,
        "text": text,
        "disable_web_page_preview": "true",
    })
    ok = bool(result and result.get("ok"))
    if not ok:
        record_telegram("error", success=False)
    return ok


def delete_message(token: str, chat_id: str, message_id: int) -> bool:
    if not token or not chat_id or not message_id:
        return False
    result = _api_call_json(token, "deleteMessage", {
        "chat_id": chat_id,
        "message_id": message_id,
    })
    return bool(result and result.get("ok"))


def send_photo(token: str, chat_id: str, file_path: Path, caption: str = "") -> bool:
    """Отправляет PNG/JPEG как фото в Telegram."""
    if not token or not chat_id:
        record_telegram("error", success=False)
        return False
    path = Path(file_path)
    if not path.exists() or not path.is_file():
        record_telegram("error", success=False)
        return False
    try:
        data = path.read_bytes()
    except OSError:
        record_telegram("error", success=False)
        return False

    fields = {"chat_id": chat_id}
    if caption:
        fields["caption"] = caption
    files = {"photo": (path.name, data, "image/png")}
    result = _api_call_multipart(token, "sendPhoto", fields, files)
    ok = bool(result and result.get("ok"))
    if ok:
        record_telegram("photo", success=True)
    else:
        record_telegram("error", success=False)
    return ok


def send_document(token: str, chat_id: str, file_path: Path, caption: str = "") -> bool:
    if not token or not chat_id:
        record_telegram("error", success=False)
        return False
    path = Path(file_path)
    if not path.exists() or not path.is_file():
        record_telegram("error", success=False)
        return False
    try:
        data = path.read_bytes()
    except OSError:
        record_telegram("error", success=False)
        return False

    fields = {"chat_id": chat_id}
    if caption:
        fields["caption"] = caption
    files = {"document": (path.name, data, "text/plain")}
    result = _api_call_multipart(token, "sendDocument", fields, files)
    ok = bool(result and result.get("ok"))
    if ok:
        record_telegram("document", success=True)
    else:
        record_telegram("error", success=False)
    return ok


# ---------------------------------------------------------------------------
# Разбиение текста
# ---------------------------------------------------------------------------

def _split_text(text: str, limit: int = MAX_MESSAGE_LEN) -> List[str]:
    if len(text) <= limit:
        return [text]
    chunks = []
    current = ""
    for line in text.split("\n"):
        cand = current + ("\n" if current else "") + line
        if len(cand) > limit:
            if current:
                chunks.append(current)
            current = line
        else:
            current = cand
    if current:
        chunks.append(current)
    return chunks


# ---------------------------------------------------------------------------
# Массовая отправка
# ---------------------------------------------------------------------------

def send_to_all(
    token: str,
    chat_ids: List[str],
    text: str,
    file_path: Optional[Path] = None,
    logger=None,
) -> int:
    valid = [c.strip() for c in chat_ids if c and c.strip()]
    if not valid:
        if logger:
            logger.info("Группа в телеграмме не указана — пропускаю отправку.")
        return 0

    chunks = _split_text(text)
    success = 0

    for chat_id in valid:
        ok_text = True
        for chunk in chunks:
            if send_text(token, chat_id, chunk) is None:
                ok_text = False
                break

        ok_file = True
        if file_path is not None:
            ok_file = send_document(token, chat_id, file_path)

        if ok_text and ok_file:
            success += 1
            if logger:
                if file_path is not None:
                    logger.info(f"Ответы и файл отправлены в Telegram (chat_id={chat_id}).")
                else:
                    logger.info(f"Ответы отправлены в Telegram (chat_id={chat_id}).")
        else:
            if logger:
                reason = "текст и файл" if not ok_text and not ok_file else "текст" if not ok_text else "файл"
                logger.warning(f"Не удалось отправить в Telegram (chat_id={chat_id}): {reason}.")
    return success
