"""Политика автоматических повторов Job."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any
import math


@dataclass(frozen=True)
class RetryDecision:
    retry: bool
    attempt: int
    max_attempts: int
    delay_sec: float
    reason: str


class RetryPolicy:
    DEFAULT_MAX_ATTEMPTS = 3
    DEFAULT_BACKOFF_SEC = 5.0
    DEFAULT_BACKOFF_MAX_SEC = 120.0

    NON_RETRYABLE = (KeyboardInterrupt, SystemExit, MemoryError, PermissionError, ValueError)

    @classmethod
    def max_attempts(cls, job) -> int:
        metadata = getattr(job, "metadata", {}) or {}
        raw = metadata.get("retry_max_attempts", metadata.get("max_attempts", cls.DEFAULT_MAX_ATTEMPTS))
        try:
            return max(1, min(10, int(raw)))
        except (TypeError, ValueError):
            return cls.DEFAULT_MAX_ATTEMPTS

    @classmethod
    def mode(cls, job) -> str:
        value = str((getattr(job, "metadata", {}) or {}).get("retry_policy", "auto") or "auto").strip().lower()
        return value if value in {"auto", "never"} else "auto"

    @classmethod
    def backoff(cls, job, next_attempt: int) -> float:
        metadata = getattr(job, "metadata", {}) or {}
        try:
            base = max(0.0, float(metadata.get("retry_backoff_sec", cls.DEFAULT_BACKOFF_SEC)))
        except (TypeError, ValueError):
            base = cls.DEFAULT_BACKOFF_SEC
        try:
            ceiling = max(base, float(metadata.get("retry_backoff_max_sec", cls.DEFAULT_BACKOFF_MAX_SEC)))
        except (TypeError, ValueError):
            ceiling = cls.DEFAULT_BACKOFF_MAX_SEC
        return round(min(ceiling, base * math.pow(2, max(0, next_attempt - 2))), 3)

    @classmethod
    def is_retryable(cls, job, exc: Exception | None) -> bool:
        if cls.mode(job) == "never":
            return False
        metadata: dict[str, Any] = getattr(job, "metadata", {}) or {}
        if metadata.get("retryable") is False:
            return False
        if exc is not None and isinstance(exc, cls.NON_RETRYABLE):
            return False
        return True

    @classmethod
    def decide(cls, job, exc: Exception | None = None) -> RetryDecision:
        attempt = int(getattr(job, "attempts", 0) or 0)
        maximum = cls.max_attempts(job)
        if attempt >= maximum:
            return RetryDecision(False, attempt, maximum, 0.0, "max_attempts_reached")
        if not cls.is_retryable(job, exc):
            return RetryDecision(False, attempt, maximum, 0.0, "non_retryable")
        next_attempt = attempt + 1
        return RetryDecision(True, attempt, maximum, cls.backoff(job, next_attempt), "retryable_failure")
