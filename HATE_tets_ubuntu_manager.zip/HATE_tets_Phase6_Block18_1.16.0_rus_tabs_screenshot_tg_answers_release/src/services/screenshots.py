"""Утилиты для снятия скриншотов страниц Selenium/Chrome."""
from __future__ import annotations

import base64
from pathlib import Path


def capture_page_screenshot(driver, path: Path, logger=None) -> bool:
    """Сохраняет всю текущую страницу в PNG; есть fallback на обычный screenshot."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)

    try:
        payload = driver.execute_cdp_cmd(
            "Page.captureScreenshot",
            {"format": "png", "captureBeyondViewport": True, "fromSurface": True},
        )
        data = (payload or {}).get("data") or ""
        if data:
            target.write_bytes(base64.b64decode(data))
            if target.exists() and target.stat().st_size > 0:
                return True
    except Exception as exc:
        if logger:
            logger.debug(f"CDP-скриншот не получен, использую fallback: {exc}")

    try:
        ok = bool(driver.save_screenshot(str(target)))
        return ok and target.exists() and target.stat().st_size > 0
    except Exception as exc:
        if logger:
            logger.warning(f"Fallback-скриншот не получен: {exc}")
        return False
