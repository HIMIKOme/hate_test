"""Stable project paths for source and frozen runtime modes."""
from __future__ import annotations

import sys
from pathlib import Path


def _looks_like_project(path: Path) -> bool:
    return (path / "VERSION").is_file() or (path / "data").is_dir() and (path / "src").is_dir()


def project_root() -> Path:
    candidates: list[Path] = []
    try:
        candidates.append(Path.cwd().resolve())
    except Exception:
        pass
    try:
        exe_dir = Path(sys.executable).resolve().parent
        candidates.extend([exe_dir, exe_dir.parent])
    except Exception:
        pass
    candidates.append(Path(__file__).resolve().parents[2])

    seen: set[Path] = set()
    for candidate in candidates:
        candidate = candidate.resolve()
        if candidate in seen:
            continue
        seen.add(candidate)
        if _looks_like_project(candidate):
            return candidate

    return Path(__file__).resolve().parents[2]
