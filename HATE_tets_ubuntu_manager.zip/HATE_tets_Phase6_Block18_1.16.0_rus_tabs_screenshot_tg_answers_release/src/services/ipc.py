"""Простой файловый IPC между постоянным Web-процессом и приложением."""
from __future__ import annotations

import json
import os
import sys
import time
import uuid
from pathlib import Path
from typing import Any, Dict, Optional
from .paths import project_root
from .version import APP_VERSION


def base_dir() -> Path:
    return project_root()


def ipc_dir() -> Path:
    path = base_dir() / "data" / "ipc"
    path.mkdir(parents=True, exist_ok=True)
    return path


def state_path() -> Path:
    return ipc_dir() / "state.json"


def commands_dir() -> Path:
    path = ipc_dir() / "commands"
    path.mkdir(parents=True, exist_ok=True)
    return path


def publish_state(state: Dict[str, Any]) -> None:
    payload = dict(state)
    payload.setdefault("timestamp", time.time())
    path = state_path()
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


def read_state() -> Dict[str, Any]:
    try:
        return json.loads(state_path().read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return {"ok": True, "application_status": "Offline", "version": APP_VERSION, "jobs": {"queued": [], "active": [], "history": [], "queue_size": 0, "running": 0}}


def send_command(name: str, payload: Optional[Dict[str, Any]] = None) -> str:
    command_id = f"cmd-{int(time.time() * 1000)}-{uuid.uuid4().hex[:8]}"
    data = {
        "id": command_id,
        "command": name,
        "payload": payload or {},
        "created_at": time.time(),
    }
    target = commands_dir() / f"{command_id}.json"
    tmp = target.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    tmp.replace(target)
    return command_id


def responses_dir() -> Path:
    path = ipc_dir() / "responses"
    path.mkdir(parents=True, exist_ok=True)
    return path


def response_path(command_id: str) -> Path:
    return responses_dir() / f"{command_id}.json"


def write_response(command_id: str, payload: Dict[str, Any]) -> None:
    target = response_path(command_id)
    data = dict(payload)
    data.setdefault("command_id", command_id)
    data.setdefault("timestamp", time.time())
    tmp = target.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    tmp.replace(target)


def read_response(command_id: str) -> Dict[str, Any] | None:
    try:
        value = json.loads(response_path(command_id).read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else None
    except (OSError, ValueError, TypeError):
        return None


def remove_response(command_id: str) -> None:
    try:
        response_path(command_id).unlink(missing_ok=True)
    except OSError:
        pass


def iter_commands():
    for path in sorted(commands_dir().glob("*.json"), key=lambda p: p.stat().st_mtime):
        try:
            yield path, json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError, TypeError):
            continue


def remove_command(path: Path) -> None:
    try:
        path.unlink(missing_ok=True)
    except OSError:
        pass

