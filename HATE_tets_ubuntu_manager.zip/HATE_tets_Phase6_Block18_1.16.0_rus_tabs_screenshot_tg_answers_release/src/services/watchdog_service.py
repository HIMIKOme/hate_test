"""Внешний Watchdog HATE_tets.

Watchdog живёт отдельным процессом и не импортирует Hub/JobManager/Worker.
Он наблюдает только публичные признаки здоровья: heartbeat-файлы, IPC-снимок,
HTTP health Web и PID. Восстановление выполняется через запуск независимых
процессов или IPC-команды, поэтому Web не требует перезапуска приложения.
"""
from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
import threading
import tempfile
import time
import urllib.request
from pathlib import Path
from typing import Any

from .ipc import base_dir, read_state, send_command
from .config import load_settings
from .job_timeout import evaluate_job_timeout

DEFAULT_CONFIG: dict[str, Any] = {
    "interval_sec": 5.0,
    "stale_sec": 15.0,
    "web_timeout_sec": 2.0,
    "job_timeout_sec": 3600.0,
    "stuck_recovery_grace_sec": 20.0,
    "stuck_max_recovery_attempts": 1,
    "terminate_stuck_jobs": True,
    "queue_stale_sec": 900.0,
    "recovery_cooldown_sec": 30.0,
    "max_recoveries": 3,
    "recovery_window_sec": 600.0,
    "auto_recover": True,
}

ROOT = base_dir()
HEARTBEATS = ROOT / "data" / "heartbeats"
STATUS_PATH = ROOT / "data" / "watchdog.json"
LOCK_PATH = ROOT / "data" / "watchdog.lock"
LOG_PATH = ROOT / "data" / "watchdog.log"
CONTROL_PATH = ROOT / "data" / "watchdog_config.json"
SHUTDOWN_MARKER = ROOT / "data" / "watchdog_shutdown.json"
DEPLOYMENT_MARKER = ROOT / "data" / "deployment.in_progress"


def _now() -> float:
    return time.time()


def _read_json(path: Path, default: Any = None) -> Any:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value
    except Exception:
        return default


def _write_json(path: Path, payload: dict[str, Any]) -> bool:
    """Безопасная запись JSON, устойчивая к WinError 32.

    Каждый процесс использует уникальный временный файл. Замена целевого
    файла повторяется при кратковременной блокировке Windows; ошибка записи
    не должна останавливать сам watchdog.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", delete=False, dir=path.parent,
            prefix=f".{path.name}.{os.getpid()}.", suffix=".tmp"
        ) as handle:
            json.dump(payload, handle, ensure_ascii=False, indent=2)
            handle.flush()
            try:
                os.fsync(handle.fileno())
            except OSError:
                pass
            tmp_path = Path(handle.name)
        for attempt in range(8):
            try:
                os.replace(tmp_path, path)
                return True
            except PermissionError:
                if attempt < 7:
                    time.sleep(0.15)
                    continue
                return False
            except OSError:
                if attempt < 7:
                    time.sleep(0.15)
                    continue
                return False
    except OSError:
        return False
    finally:
        if tmp_path is not None:
            try:
                tmp_path.unlink(missing_ok=True)
            except OSError:
                pass


def _env_bool(value: str | None, fallback: bool) -> bool:
    if value is None:
        return fallback
    return str(value).strip().lower() not in {"0", "false", "no", "off"}


def load_config() -> dict[str, Any]:
    cfg = dict(DEFAULT_CONFIG)
    raw = _read_json(CONTROL_PATH, {})
    if isinstance(raw, dict):
        for key, value in raw.items():
            if key in cfg:
                cfg[key] = value
    env_map = {
        "interval_sec": ("HATE_WATCHDOG_INTERVAL", float),
        "stale_sec": ("HATE_WATCHDOG_STALE", float),
        "web_timeout_sec": ("HATE_WATCHDOG_WEB_TIMEOUT", float),
        "job_timeout_sec": ("HATE_WATCHDOG_JOB_TIMEOUT", float),
        "stuck_recovery_grace_sec": ("HATE_WATCHDOG_STUCK_RECOVERY_GRACE", float),
        "stuck_max_recovery_attempts": ("HATE_WATCHDOG_STUCK_MAX_RECOVERY", int),
        "queue_stale_sec": ("HATE_WATCHDOG_QUEUE_STALE", float),
        "recovery_cooldown_sec": ("HATE_WATCHDOG_RECOVERY_COOLDOWN", float),
        "max_recoveries": ("HATE_WATCHDOG_MAX_RECOVERIES", int),
        "recovery_window_sec": ("HATE_WATCHDOG_RECOVERY_WINDOW", float),
    }
    for key, (env_key, caster) in env_map.items():
        if os.getenv(env_key) is not None:
            try:
                cfg[key] = caster(os.getenv(env_key))
            except (TypeError, ValueError):
                pass
    cfg["auto_recover"] = _env_bool(os.getenv("HATE_WATCHDOG_AUTO_RECOVER"), bool(cfg["auto_recover"]))
    cfg["interval_sec"] = max(1.0, float(cfg["interval_sec"]))
    cfg["stale_sec"] = max(cfg["interval_sec"] * 2, float(cfg["stale_sec"]))
    cfg["web_timeout_sec"] = max(0.5, float(cfg["web_timeout_sec"]))
    cfg["job_timeout_sec"] = max(1.0, float(cfg["job_timeout_sec"]))
    cfg["stuck_recovery_grace_sec"] = max(0.5, float(cfg["stuck_recovery_grace_sec"]))
    cfg["stuck_max_recovery_attempts"] = max(0, int(cfg["stuck_max_recovery_attempts"]))
    cfg["terminate_stuck_jobs"] = bool(cfg.get("terminate_stuck_jobs", True))
    cfg["queue_stale_sec"] = max(30.0, float(cfg["queue_stale_sec"]))
    cfg["recovery_cooldown_sec"] = max(1.0, float(cfg["recovery_cooldown_sec"]))
    cfg["recovery_window_sec"] = max(cfg["recovery_cooldown_sec"], float(cfg["recovery_window_sec"]))
    cfg["max_recoveries"] = max(1, int(cfg["max_recoveries"]))
    return cfg


def log(message: str) -> None:
    HEARTBEATS.mkdir(parents=True, exist_ok=True)
    line = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message}\n"
    try:
        with LOG_PATH.open("a", encoding="utf-8") as handle:
            handle.write(line)
    except OSError:
        pass
    print(line, end="", flush=True)


def _pid_alive(pid: Any) -> bool:
    try:
        value = int(pid)
    except (TypeError, ValueError):
        return False
    if value <= 0 or value == os.getpid():
        return value == os.getpid()
    try:
        os.kill(value, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def _detached_flags() -> int:
    if sys.platform != "win32":
        return 0
    return (
        getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        | getattr(subprocess, "DETACHED_PROCESS", 0)
    )


def _python_script(script: str, *args: str) -> list[str]:
    return [sys.executable, str(ROOT / script), *args]


def _dist_exe(name: str) -> Path | None:
    for candidate in (ROOT / "dist" / f"{name}.exe", ROOT / "dist" / name):
        if candidate.exists() and candidate.is_file():
            return candidate
    return None


def _terminate_pid(pid: Any) -> bool:
    try:
        value = int(pid)
    except (TypeError, ValueError):
        return False
    if value <= 0 or value == os.getpid():
        return False
    try:
        if sys.platform == "win32":
            result = subprocess.run(["taskkill", "/PID", str(value), "/T", "/F"], capture_output=True, text=True, check=False)
            return result.returncode == 0
        os.kill(value, signal.SIGTERM)
        return True
    except (ProcessLookupError, OSError):
        return False


def _launch(kind: str, *, extra: list[str] | None = None) -> bool:
    if kind == "app":
        exe = _dist_exe("HATE_tets_tray")
        command = [str(exe)] if exe else _python_script("tray.py")
    elif kind == "web":
        exe = _dist_exe("HATE_tets_tray")
        command = ([str(exe), "--web-server"] if exe else _python_script("tray.py", "--web-server"))
    elif kind == "watchdog":
        exe = _dist_exe("HATE_tets_watchdog")
        command = [str(exe)] if exe else _python_script("watchdog.py")
    else:
        raise ValueError(f"Unknown launch kind: {kind}")
    if extra:
        command.extend(extra)
    try:
        subprocess.Popen(
            command,
            cwd=str(ROOT),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
            creationflags=_detached_flags(),
        )
        return True
    except Exception as exc:
        log(f"Не удалось запустить {kind}: {exc}")
        return False


def _web_info() -> dict[str, Any]:
    return _read_json(ROOT / "data" / "web.json", {}) if (ROOT / "data" / "web.json").exists() else {}


def web_alive(config: dict[str, Any]) -> bool:
    info = _web_info()
    port = int(info.get("port", 0) or 0)
    if port <= 0:
        return False
    try:
        with urllib.request.urlopen(
            f"http://127.0.0.1:{port}/health", timeout=float(config["web_timeout_sec"])
        ) as response:
            return response.status == 200
    except Exception:
        return False


def heartbeat_status(path: Path, now: float, stale_sec: float) -> dict[str, Any]:
    payload = _read_json(path, {})
    if not isinstance(payload, dict):
        payload = {}
    stamp = float(payload.get("timestamp", 0) or 0)
    age = None if stamp <= 0 else max(0.0, now - stamp)
    return {
        "id": path.stem,
        "alive": age is not None and age <= stale_sec,
        "age": round(age, 2) if age is not None else None,
        "pid": payload.get("pid"),
        "job_id": payload.get("job_id"),
        "browser_status": payload.get("browser_status"),
        "browser_profile": payload.get("browser_profile"),
        "queue_type": payload.get("queue_type"),
        "running": payload.get("running"),
    }


def _fresh_shutdown_marker(max_age: float = 60.0) -> bool:
    # Marker намеренной остановки живёт до следующего запуска приложения.
    # max_age оставлен в сигнатуре для обратной совместимости.
    payload = _read_json(SHUTDOWN_MARKER, {})
    return isinstance(payload, dict) and payload.get("intentional") is True


def mark_intentional_shutdown(reason: str = "user") -> None:
    _write_json(SHUTDOWN_MARKER, {"timestamp": _now(), "reason": reason, "pid": os.getpid(), "intentional": True})


def clear_shutdown_marker() -> None:
    try:
        SHUTDOWN_MARKER.unlink(missing_ok=True)
    except OSError:
        pass


class Watchdog:
    """Независимый внешний watchdog."""

    def __init__(self, logger=None, config: dict[str, Any] | None = None):
        self.logger = logger
        self.config = config or load_config()
        self.started_at = _now()
        self._stop = threading.Event()
        self._last_snapshot: dict[str, Any] | None = None
        self._recoveries: dict[str, list[float]] = {}
        self._recovery_cooldowns: dict[str, float] = {}
        self._stuck_notified: set[str] = set()
        self._last_recovery_at: float = 0.0
        self._last_signature: dict[str, Any] | None = None
        self._lock_acquired = False

    def _log(self, message: str) -> None:
        if self.logger:
            try:
                self.logger.warning(message)
            except Exception:
                pass
        log(message)

    def acquire(self) -> bool:
        LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
        if LOCK_PATH.exists():
            existing = _read_json(LOCK_PATH, {})
            if isinstance(existing, dict) and _pid_alive(existing.get("pid")):
                return False
            try:
                LOCK_PATH.unlink(missing_ok=True)
            except OSError:
                return False
        try:
            fd = os.open(str(LOCK_PATH), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, json.dumps({"pid": os.getpid(), "started_at": self.started_at}).encode("utf-8"))
            os.close(fd)
            self._lock_acquired = True
            return True
        except FileExistsError:
            return False
        except OSError:
            return False

    def release(self) -> None:
        if not self._lock_acquired:
            return
        try:
            LOCK_PATH.unlink(missing_ok=True)
        except OSError:
            pass
        self._lock_acquired = False

    def stop(self) -> None:
        self._stop.set()

    def _can_recover(self, component: str) -> bool:
        now = _now()
        cooldown_until = self._recovery_cooldowns.get(component, 0.0)
        if now < cooldown_until:
            return False
        history = [stamp for stamp in self._recoveries.get(component, []) if now - stamp <= float(self.config["recovery_window_sec"])]
        self._recoveries[component] = history
        if len(history) >= int(self.config["max_recoveries"]):
            return False
        return True

    def _record_recovery(self, component: str) -> None:
        now = _now()
        self._recoveries.setdefault(component, []).append(now)
        self._recovery_cooldowns[component] = now + float(self.config["recovery_cooldown_sec"])
        self._last_recovery_at = now

    def recover_app(self, reason: str) -> bool:
        if not bool(self.config["auto_recover"]) or not self._can_recover("app"):
            return False
        if _fresh_shutdown_marker():
            self._log("App отмечен как намеренно остановленный — автозапуск пропущен.")
            return False
        self._record_recovery("app")
        self._log(f"Watchdog: восстанавливаю приложение: {reason}")
        current = _read_json(HEARTBEATS / "app.json", {})
        pid = current.get("pid") if isinstance(current, dict) else None
        if pid and _pid_alive(pid):
            _terminate_pid(pid)
            deadline = time.time() + 5.0
            while time.time() < deadline and _pid_alive(pid):
                time.sleep(0.2)
        return _launch("app")

    def recover_web(self, reason: str) -> bool:
        if not bool(self.config["auto_recover"]) or not self._can_recover("web"):
            return False
        self._record_recovery("web")
        self._log(f"Watchdog: восстанавливаю Web без остановки приложения: {reason}")
        info = _web_info()
        pid = info.get("pid") if isinstance(info, dict) else None
        if pid and _pid_alive(pid):
            _terminate_pid(pid)
            time.sleep(0.3)
        return _launch("web")

    def send_recovery_command(self, command: str, *, payload: dict[str, Any] | None = None, component: str) -> bool:
        if not bool(self.config["auto_recover"]) or not self._can_recover(component):
            return False
        self._record_recovery(component)
        command_id = send_command(command, payload or {})
        self._log(f"Watchdog: отправлена команда {command} ({command_id}) для {component}.")
        return True

    def _inspect_workers(self, now: float) -> dict[str, Any]:
        items: list[dict[str, Any]] = []
        for pattern in ("worker-*.json", "queue-*.json"):
            for path in HEARTBEATS.glob(pattern):
                items.append(heartbeat_status(path, now, float(self.config["stale_sec"])))
        items.sort(key=lambda item: item["id"])
        return {
            "count": len(items),
            "alive": sum(1 for item in items if item["alive"]),
            "items": items,
        }

    def _inspect_queue_and_jobs(self, state: dict[str, Any], now: float) -> dict[str, Any]:
        jobs = state.get("jobs") if isinstance(state.get("jobs"), dict) else {}
        queued = list(jobs.get("queued") or [])
        active = list(jobs.get("active") or [])
        oldest_wait = 0.0
        for job in queued:
            stamp = float(job.get("queued_at") or job.get("created_at") or 0)
            if stamp > 0:
                oldest_wait = max(oldest_wait, now - stamp)

        stuck: list[dict[str, Any]] = []
        allowed_overrun: list[dict[str, Any]] = []
        timeout = float(self.config["job_timeout_sec"])
        for job in active:
            result = evaluate_job_timeout(job, now=now, default_timeout=timeout)
            if result is None:
                continue
            if result["allow_overrun"]:
                allowed_overrun.append(result)
            else:
                stuck.append(result)

        queue_stale = bool(queued) and oldest_wait > float(self.config["queue_stale_sec"]) and not active
        return {
            "queued": len(queued),
            "active": len(active),
            "total": int(jobs.get("total_queue_size", jobs.get("queue_size", len(queued))) or 0),
            "oldest_wait_sec": round(oldest_wait, 1),
            "stale": queue_stale,
            "stuck_jobs": stuck,
            "allowed_overrun_jobs": allowed_overrun,
        }

    def inspect_once(self) -> dict[str, Any]:
        now = _now()
        state = read_state()
        app_hb = heartbeat_status(HEARTBEATS / "app.json", now, float(self.config["stale_sec"]))
        telegram_path = HEARTBEATS / "telegram.json"
        telegram = heartbeat_status(telegram_path, now, float(self.config["stale_sec"])) if telegram_path.exists() else {
            "id": "telegram", "alive": False, "age": None, "pid": None, "running": False,
        }
        workers = self._inspect_workers(now)
        queue = self._inspect_queue_and_jobs(state, now)
        web_ok = web_alive(self.config)

        components = state.get("components") if isinstance(state.get("components"), dict) else {}
        hub_status = ((components.get("hub") or {}).get("status") or "offline")
        hub_ok = app_hb["alive"] and str(hub_status).lower() == "online"
        try:
            settings = load_settings()
        except Exception:
            settings = {}
        token_configured = bool(str(settings.get("telegram_token") or "").strip())
        telegram_ok = not token_configured or telegram["alive"]

        browsers = [item for item in workers["items"] if item.get("queue_type") == "TEST_QUEUE" or item["id"].startswith("worker-")]
        crashed_browsers = [item for item in browsers if item.get("browser_status") == "crashed"]
        active_without_workers = queue["active"] > 0 and workers["alive"] == 0

        issues: list[str] = []
        if not app_hb["alive"]:
            issues.append("app heartbeat stale")
        elif not hub_ok:
            issues.append("hub not online")
        if not web_ok:
            issues.append("web unavailable")
        if token_configured and not telegram_ok:
            issues.append("telegram heartbeat stale")
        expected_workers = int((state.get("jobs") or {}).get("worker_count", 0) or 0)
        worker_failure = (expected_workers > 0 and workers["alive"] < expected_workers) or any(not item.get("alive") for item in workers["items"])
        if active_without_workers:
            issues.append("active jobs without workers")
        if worker_failure:
            issues.append("worker heartbeat stale")
        if crashed_browsers:
            issues.append("browser crashed")
        if queue["stale"]:
            issues.append("queue stale")
        if queue["stuck_jobs"]:
            issues.append("stuck jobs")

        snapshot = {
            "ok": not issues,
            "status": "Online" if not issues else ("Critical" if any("heartbeat" in x or "active jobs" in x or "browser" in x for x in issues) else "Warning"),
            "timestamp": now,
            "pid": os.getpid(),
            "uptime": round(now - self.started_at, 1),
            "components": {
                "app": app_hb,
                "hub": {"alive": hub_ok, "status": hub_status},
                "web": {"alive": web_ok, "pid": _web_info().get("pid"), "port": _web_info().get("port")},
                "telegram": telegram,
                "workers": workers,
                "chrome": {
                    "crashed_workers": [item["id"] for item in crashed_browsers],
                    "online_count": sum(1 for item in browsers if item.get("browser_status") == "online"),
                },
            },
            "queue": queue,
            "issues": issues,
            "config": dict(self.config),
            "recoveries": {key: len(value) for key, value in self._recoveries.items()},
            "last_recovery_at": self._last_recovery_at,
        }
        return snapshot

    def _apply_recovery(self, snapshot: dict[str, Any]) -> None:
        components = snapshot["components"]
        if not components["app"]["alive"]:
            self.recover_app("heartbeat отсутствует")
        elif not components["hub"]["alive"]:
            self.recover_app("Hub не сообщает online")
        if not components["web"]["alive"]:
            self.recover_web("HTTP health недоступен")
        state = read_state()
        try:
            settings = load_settings()
        except Exception:
            settings = {}
        if components["telegram"].get("alive") is False:
            configured = bool(str(settings.get("telegram_token") or "").strip())
            if configured:
                self.send_recovery_command("restart_bot", component="telegram")
        workers = components["workers"]
        expected_workers = int((state.get("jobs") or {}).get("worker_count", 0) or 0)
        worker_failure = (expected_workers > 0 and workers.get("alive", 0) < expected_workers) or any(not item.get("alive") for item in workers.get("items", []))
        if worker_failure:
            # Worker heartbeat создаётся отдельным потоком. Безопасное восстановление
            # зависшего callback на уровне процесса — перезапуск приложения. Web остаётся.
            self.recover_app("heartbeat Worker устарел")
        if snapshot["queue"].get("stale") and not snapshot["queue"].get("active"):
            self.recover_app("очередь долго не обслуживается")
        active_stuck_ids = set()
        for item in snapshot["queue"]["stuck_jobs"]:
            job_id = item.get("job_id")
            if not job_id:
                continue
            active_stuck_ids.add(job_id)
            if job_id not in self._stuck_notified:
                self._stuck_notified.add(job_id)
                self._log(
                    f"Watchdog: Job {job_id} признана зависшей: runtime={item['runtime_sec']}с, "
                    f"limit={item['timeout_sec']}с, worker={item.get('worker_id')}, stage={item.get('stage')}"
                )
                try:
                    command_id = send_command("mark_job_stuck", {
                        "job_id": job_id,
                        "runtime_sec": item["runtime_sec"],
                        "timeout_sec": item["timeout_sec"],
                        "reason": "watchdog_timeout",
                    })
                    self._log(f"Watchdog: зафиксировано зависание Job {job_id} ({command_id}).")
                except Exception as exc:
                    self._log(f"Watchdog: не удалось зафиксировать зависание Job {job_id}: {exc}")

            attempts = int(item.get("recovery_attempts", 0) or 0)
            status = str(item.get("recovery_status") or "none")
            stuck_since = float(item.get("stuck_since") or snapshot["timestamp"])
            age = max(0.0, snapshot["timestamp"] - stuck_since)
            max_attempts = int(self.config.get("stuck_max_recovery_attempts", 1))

            if attempts < max_attempts and status not in {"terminated"}:
                self.send_recovery_command(
                    "recover_job",
                    payload={"job_id": job_id, "reason": "watchdog_timeout"},
                    component=f"job-recovery:{job_id}",
                )
            elif (
                bool(self.config.get("terminate_stuck_jobs", True))
                and age >= float(self.config["stuck_recovery_grace_sec"])
                and status not in {"terminated", "recovery_requested"}
            ):
                self.send_recovery_command(
                    "terminate_job",
                    payload={"job_id": job_id, "reason": "watchdog_timeout"},
                    component=f"job-terminate:{job_id}",
                )

        self._stuck_notified.intersection_update(active_stuck_ids)
        if components["chrome"].get("crashed_workers"):
            self.recover_app("Chrome crashed у Worker: " + ", ".join(components["chrome"]["crashed_workers"]))

    def run_once(self) -> dict[str, Any]:
        if DEPLOYMENT_MARKER.exists():
            payload = {
                "status": "Deployment",
                "issues": ["deployment in progress"],
                "deployment_active": True,
                "timestamp": _now(),
                "pid": os.getpid(),
            }
            _write_json(STATUS_PATH, payload)
            _write_json(HEARTBEATS / "watchdog.json", payload)
            return payload
        snapshot = self.inspect_once()
        signature = {
            "status": snapshot["status"],
            "issues": tuple(snapshot["issues"]),
            "queue": snapshot["queue"]["total"],
            "stuck": tuple(item["job_id"] for item in snapshot["queue"]["stuck_jobs"]),
            "allowed_overrun": tuple(item["job_id"] for item in snapshot["queue"].get("allowed_overrun_jobs", [])),
            "workers_alive": snapshot["components"]["workers"]["alive"],
            "workers_count": snapshot["components"]["workers"]["count"],
            "web": snapshot["components"]["web"]["alive"],
            "telegram": snapshot["components"]["telegram"]["alive"],
        }
        if signature != self._last_signature:
            self._log(
                "health " + json.dumps(signature, ensure_ascii=False)
            )
            self._last_signature = signature
        _write_json(STATUS_PATH, snapshot)
        _write_json(HEARTBEATS / "watchdog.json", {
            "timestamp": snapshot["timestamp"],
            "pid": os.getpid(),
            "status": snapshot["status"],
            "issues": snapshot["issues"],
            "uptime": snapshot["uptime"],
        })
        self._apply_recovery(snapshot)
        return snapshot

    def run(self) -> int:
        if not self.acquire():
            log("Watchdog уже запущен другим процессом.")
            return 2
        log(f"Watchdog started, pid={os.getpid()}, config={self.config}")
        try:
            while not self._stop.is_set():
                try:
                    self.run_once()
                except Exception as exc:
                    self._log(f"Watchdog cycle error: {exc}")
                    # Повторная запись статуса здесь не должна превращать
                    # кратковременную блокировку Windows в падение watchdog.
                    _write_json(STATUS_PATH, {
                        "ok": False,
                        "status": "Critical",
                        "timestamp": _now(),
                        "pid": os.getpid(),
                        "issues": [f"watchdog internal error: {exc}"],
                    })
                self._stop.wait(float(self.config["interval_sec"]))
        finally:
            try:
                (HEARTBEATS / "watchdog.json").unlink(missing_ok=True)
            except OSError:
                pass
            self.release()
            log("Watchdog stopped")
        return 0
