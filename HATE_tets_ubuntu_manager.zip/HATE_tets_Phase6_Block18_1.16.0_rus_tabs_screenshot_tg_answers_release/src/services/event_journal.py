"""Персистентный event log с атомарной записью и безопасной ротацией."""
from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path
from typing import Any, Dict

from .ipc import base_dir

_LOCK = threading.RLock()
_MAX_BYTES = 10 * 1024 * 1024
_KEEP_OLD = 5


def event_path() -> Path:
    path = base_dir() / "data" / "ipc" / "events.jsonl"
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _rotate_locked(path: Path, incoming_bytes: int) -> None:
    try:
        if not path.exists() or path.stat().st_size + incoming_bytes <= _MAX_BYTES:
            return
    except OSError:
        return
    for index in range(_KEEP_OLD, 0, -1):
        src = path.with_name(f"events.jsonl.{index}")
        dst = path.with_name(f"events.jsonl.{index + 1}")
        try:
            if src.exists():
                if index == _KEEP_OLD:
                    src.unlink(missing_ok=True)
                else:
                    src.replace(dst)
        except OSError:
            pass
    try:
        path.replace(path.with_name("events.jsonl.1"))
    except OSError:
        pass


def append_event(event: Dict[str, Any]) -> None:
    payload = dict(event)
    payload.setdefault("timestamp", time.time())
    line = json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n"
    path = event_path()
    with _LOCK:
        try:
            _rotate_locked(path, len(line.encode("utf-8")))
            with path.open("a", encoding="utf-8") as fh:
                fh.write(line)
                fh.flush()
                os.fsync(fh.fileno())
        except OSError:
            pass


def journal_paths() -> list[Path]:
    root = event_path().parent
    current = event_path()
    paths = [current]
    for index in range(1, _KEEP_OLD + 1):
        candidate = root / f"events.jsonl.{index}"
        if candidate.exists():
            paths.append(candidate)
    return paths


def read_events(limit: int = 500) -> list[dict[str, Any]]:
    limit = max(1, min(int(limit), 5000))
    items: list[dict[str, Any]] = []
    with _LOCK:
        for path in reversed(journal_paths()):
            try:
                with path.open("r", encoding="utf-8") as fh:
                    for line in fh:
                        try:
                            value = json.loads(line)
                        except (ValueError, TypeError):
                            continue
                        if isinstance(value, dict):
                            items.append(value)
            except OSError:
                continue
    items.sort(key=lambda item: float(item.get("timestamp", 0) or 0), reverse=True)
    return items[:limit]


def read_events_from(path: Path, offset: int) -> tuple[list[dict], int]:
    events: list[dict] = []
    try:
        with path.open("r", encoding="utf-8") as fh:
            fh.seek(offset)
            while True:
                line = fh.readline()
                if not line:
                    break
                try:
                    events.append(json.loads(line))
                except (ValueError, TypeError):
                    continue
            return events, fh.tell()
    except (OSError, ValueError):
        return [], offset
