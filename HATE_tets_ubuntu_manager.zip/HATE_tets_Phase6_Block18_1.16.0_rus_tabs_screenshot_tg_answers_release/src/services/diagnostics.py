"""Сбор диагностики Job и подготовка ZIP-архива."""
from __future__ import annotations

import json
import os
import platform
import shutil
import time
import traceback
import zipfile
from pathlib import Path
from typing import Any

from .ipc import base_dir
from .event_journal import read_events


class DiagnosticsManager:
    def __init__(self, root: Path | None = None, logger=None):
        self.root = Path(root or (base_dir() / "data" / "diagnostics"))
        self.logger = logger

    def _job_dir(self, job_id: str) -> Path:
        return self.root / str(job_id)

    def capture_failure(self, job, exc: Exception | None = None, context=None, *, phase: str = "worker") -> dict[str, Any]:
        directory = self._job_dir(job.id) / f"attempt-{max(1, int(getattr(job, 'attempts', 0) or 0)):03d}"
        directory.mkdir(parents=True, exist_ok=True)
        captured_at = time.time()
        info = {
            "captured_at": captured_at,
            "job_id": job.id,
            "attempt": int(getattr(job, "attempts", 0) or 0),
            "phase": phase,
            "state": getattr(getattr(job, "state", None), "value", getattr(job, "state", "")),
            "url": str(getattr(job, "url", "")),
        }
        if exc is not None:
            info["exception_type"] = type(exc).__name__
            info["error"] = str(exc)
            (directory / "traceback.txt").write_text("".join(traceback.format_exception(type(exc), exc, exc.__traceback__)), encoding="utf-8")
        (directory / "job.json").write_text(json.dumps(job.to_dict(), ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        (directory / "capture.json").write_text(json.dumps(info, ensure_ascii=False, indent=2), encoding="utf-8")
        (self._job_dir(job.id) / "latest.json").write_text(
            json.dumps(info, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        system = {
            "platform": platform.platform(),
            "python": platform.python_version(),
            "pid": os.getpid(),
            "captured_at": captured_at,
        }
        (directory / "system.json").write_text(json.dumps(system, ensure_ascii=False, indent=2), encoding="utf-8")

        try:
            events = [
                item for item in read_events(limit=5000)
                if str(item.get("job_id") or ((item.get("job") or {}).get("id") if isinstance(item.get("job"), dict) else "")) == str(job.id)
            ]
            (directory / "events.json").write_text(json.dumps(events, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
        except Exception as event_exc:
            if self.logger:
                self.logger.debug(f"Diagnostics event capture skipped: {event_exc}")

        driver = None
        try:
            browser = (getattr(context, "resources", {}) or {}).get("chrome") if context is not None else None
            driver = getattr(browser, "driver", None)
            if driver is not None:
                try:
                    driver.save_screenshot(str(directory / "screenshot.png"))
                except Exception as screenshot_exc:
                    (directory / "screenshot_error.txt").write_text(str(screenshot_exc), encoding="utf-8")
                try:
                    html = driver.page_source
                    (directory / "page.html").write_text(str(html), encoding="utf-8")
                except Exception as html_exc:
                    (directory / "page_source_error.txt").write_text(str(html_exc), encoding="utf-8")
        except Exception as exc2:
            if self.logger:
                self.logger.debug(f"Diagnostics browser capture skipped: {exc2}")

        archive = self.archive(job.id)
        info["directory"] = str(directory)
        info["attempt_directory"] = str(directory)
        info["archive"] = str(archive) if archive else None
        info["available"] = bool(archive and archive.exists())
        return info

    def archive(self, job_id: str) -> Path | None:
        directory = self._job_dir(job_id)
        if not directory.exists():
            return None
        archive = self.root / f"{job_id}-diagnostics.zip"
        tmp = archive.with_suffix(".tmp")
        try:
            with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED) as zf:
                for file in sorted(directory.rglob("*")):
                    if file.is_file():
                        zf.write(file, file.relative_to(directory))
            tmp.replace(archive)
            return archive
        except (OSError, zipfile.BadZipFile):
            try:
                tmp.unlink(missing_ok=True)
            except OSError:
                pass
            return None

    def get_archive(self, job_id: str) -> Path | None:
        archive = self.root / f"{job_id}-diagnostics.zip"
        if archive.exists() and archive.is_file():
            return archive
        return self.archive(job_id)

    def metadata(self, job_id: str) -> dict[str, Any]:
        directory = self._job_dir(job_id)
        capture = directory / "latest.json"
        if not capture.exists():
            candidates = sorted(directory.glob("attempt-*/capture.json"))
            capture = candidates[-1] if candidates else capture
        if not capture.exists():
            return {"job_id": str(job_id), "available": False}
        try:
            payload = json.loads(capture.read_text(encoding="utf-8"))
            payload["available"] = bool(self.get_archive(job_id))
            return payload
        except Exception:
            return {"job_id": str(job_id), "available": bool(self.get_archive(job_id))}
