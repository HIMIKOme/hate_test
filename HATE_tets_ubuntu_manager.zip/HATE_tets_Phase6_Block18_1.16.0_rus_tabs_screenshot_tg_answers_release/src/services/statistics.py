"""Персистентная статистика Web Dashboard.

Статистика обновляется по системным событиям и переживает перезапуск основного
процесса. Хранилище компактное: только агрегаты и последние ошибки/успехи.
"""
from __future__ import annotations

import json
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

from .ipc import base_dir

_LOCK = threading.RLock()
_PATH = base_dir() / "data" / "statistics.json"


def _default() -> dict[str, Any]:
    return {
        "tests_total": 0,
        "tests_completed": 0,
        "tests_failed": 0,
        "error_total": 0,
        "answers_saved": 0,
        "duration_total": 0.0,
        "duration_count": 0,
        "daily": {},
        "last_success": None,
        "last_error": None,
        "telegram_messages_sent": 0,
        "telegram_documents_sent": 0,
        "telegram_send_errors": 0,
        "updated_at": time.time(),
    }


def _load_locked() -> dict[str, Any]:
    try:
        data = json.loads(_PATH.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            merged = _default()
            merged.update(data)
            if not isinstance(merged.get("daily"), dict):
                merged["daily"] = {}
            return merged
    except Exception:
        pass
    return _default()


def _save_locked(data: dict[str, Any]) -> None:
    _PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = _PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(_PATH)


def _day(ts: float) -> str:
    return datetime.fromtimestamp(float(ts)).strftime("%Y-%m-%d")


def _trim_daily(data: dict[str, Any], keep: int = 45) -> None:
    daily = data.get("daily") or {}
    if len(daily) <= keep:
        return
    for key in sorted(daily)[:-keep]:
        daily.pop(key, None)


def _daily_row(data: dict[str, Any], ts: float) -> dict[str, int]:
    daily = data.setdefault("daily", {})
    key = _day(ts)
    row = daily.setdefault(key, {"started": 0, "completed": 0, "failed": 0})
    for name in ("started", "completed", "failed"):
        row.setdefault(name, 0)
    return row


def record_event(event: Dict[str, Any]) -> None:
    """Обновить агрегаты по одному Event Bus событию.

    Учитываются только TEST_QUEUE Job-события, чтобы служебные очереди не
    попадали в число выполненных тестов.
    """
    event_type = str(event.get("type") or "")
    job = event.get("job") if isinstance(event.get("job"), dict) else {}
    queue_type = str(job.get("queue_type") or event.get("queue_type") or "")
    if queue_type and queue_type != "TEST_QUEUE":
        return
    job_id = str(event.get("job_id") or job.get("id") or "")
    if not job_id:
        return
    ts = float(event.get("timestamp") or time.time())

    with _LOCK:
        data = _load_locked()
        changed = False
        if event_type == "JobStarted":
            data["tests_total"] = int(data.get("tests_total", 0)) + 1
            _daily_row(data, ts)["started"] += 1
            changed = True
        elif event_type in {"JobCompleted", "JobFailed"}:
            started = job.get("started_at")
            finished = job.get("finished_at") or ts
            try:
                duration = max(0.0, float(finished) - float(started)) if started else 0.0
            except (TypeError, ValueError):
                duration = 0.0
            if duration:
                data["duration_total"] = float(data.get("duration_total", 0.0)) + duration
                data["duration_count"] = int(data.get("duration_count", 0)) + 1
            row = _daily_row(data, ts)
            if event_type == "JobCompleted":
                data["tests_completed"] = int(data.get("tests_completed", 0)) + 1
                row["completed"] += 1
                answer_count = 0
                try:
                    answer_count = int((job.get("result") or {}).get("answer_count", 0) or 0)
                except (TypeError, ValueError):
                    answer_count = 0
                data["answers_saved"] = int(data.get("answers_saved", 0)) + max(0, answer_count)
                data["last_success"] = {
                    "job_id": job_id,
                    "timestamp": ts,
                    "url": job.get("url", ""),
                    "duration": round(duration, 3),
                    "answer_count": max(0, answer_count),
                }
            else:
                data["tests_failed"] = int(data.get("tests_failed", 0)) + 1
                row["failed"] += 1
                error = str(job.get("error_reason") or job.get("error") or event.get("error") or "Неизвестная ошибка")
                data["last_error"] = {
                    "job_id": job_id,
                    "timestamp": ts,
                    "url": job.get("url", ""),
                    "error": error,
                }
                data["error_total"] = int(data.get("error_total", 0)) + 1
            changed = True
        elif event_type == "BrowserCrashed":
            data["error_total"] = int(data.get("error_total", 0)) + 1
            changed = True

        if changed:
            data["updated_at"] = ts
            _trim_daily(data)
            try:
                _save_locked(data)
            except OSError:
                pass


def record_telegram(kind: str, success: bool = True) -> None:
    key = {
        "message": "telegram_messages_sent",
        "document": "telegram_documents_sent",
        "error": "telegram_send_errors",
    }.get(str(kind))
    if key is None:
        return
    with _LOCK:
        data = _load_locked()
        data[key] = int(data.get(key, 0)) + (1 if success or key == "telegram_send_errors" else 0)
        data["updated_at"] = time.time()
        try:
            _save_locked(data)
        except OSError:
            pass


def snapshot() -> dict[str, Any]:
    with _LOCK:
        data = _load_locked()
        now_day = _day(time.time())
        row = (data.get("daily") or {}).get(now_day, {"started": 0, "completed": 0, "failed": 0})
        completed = int(data.get("tests_completed", 0))
        failed = int(data.get("tests_failed", 0))
        duration_count = int(data.get("duration_count", 0))
        average = (float(data.get("duration_total", 0.0)) / duration_count) if duration_count else 0.0
        return {
            "tests_today": int(row.get("started", 0)),
            "successes_today": int(row.get("completed", 0)),
            "errors_today": int(row.get("failed", 0)),
            "tests_total": int(data.get("tests_total", 0)),
            "successful_total": completed,
            "errors_total": int(data.get("error_total", failed)),
            "average_duration_seconds": round(average, 2),
            "answers_saved": int(data.get("answers_saved", 0)),
            "messages_sent": int(data.get("telegram_messages_sent", 0)) + int(data.get("telegram_documents_sent", 0)),
            "telegram_messages_sent": int(data.get("telegram_messages_sent", 0)),
            "telegram_documents_sent": int(data.get("telegram_documents_sent", 0)),
            "telegram_send_errors": int(data.get("telegram_send_errors", 0)),
            "last_success": data.get("last_success"),
            "last_error": data.get("last_error"),
            "updated_at": data.get("updated_at"),
        }
