"""Изолированная Chrome-сессия, принадлежащая одному Test Worker.

В Block 5 браузер больше не хранится в глобальных `_driver`/
`_current_profile_dir`. Каждый Worker создаёт свой BrowserSession, получает
уникальный user-data-dir и закрывает его после завершения своей Job.
"""
from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
import threading
import time
from pathlib import Path
from typing import Optional

from selenium.webdriver.chrome.webdriver import WebDriver as ChromeWebDriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service


def _detect_chrome_user_data_dir() -> str:
    home = Path.home()
    if os.name == "nt":
        local_app = os.environ.get("LOCALAPPDATA") or str(home / "AppData" / "Local")
        return str(Path(local_app) / "Google" / "Chrome" / "User Data")
    if sys.platform == "darwin":
        return str(home / "Library" / "Application Support" / "Google" / "Chrome")
    return str(home / ".config" / "google-chrome")


SOURCE_USER_DATA_DIR = _detect_chrome_user_data_dir()
SOURCE_PROFILE_DIR = "Default"
PROFILE_PREFIX = "HATE_tets_profile_"
MASTER_DIRNAME = "HATE_tets_profile_master"
MASTER_FILES = ("Preferences", "Secure Preferences", "Local State")

# Это только синхронизация подготовки файлов профиля. Состояния Chrome здесь нет.
_PROFILE_PREPARE_LOCK = threading.RLock()


def _master_dir() -> Path:
    return Path(tempfile.gettempdir()) / MASTER_DIRNAME


def _ensure_master(logger) -> Path:
    master = _master_dir()
    source_user_data = Path(SOURCE_USER_DATA_DIR)
    source_default = source_user_data / SOURCE_PROFILE_DIR
    source_ext = source_default / "Extensions"

    # На Ubuntu Server обычно нет пользовательского Chrome-профиля.
    # Это нормальный сценарий: создаём чистый рабочий профиль вместо падения.
    master_ext = master / SOURCE_PROFILE_DIR / "Extensions"
    need_update = True
    if master_ext.exists():
        try:
            need_update = master_ext.stat().st_mtime < source_ext.stat().st_mtime
        except OSError:
            pass

    if not need_update:
        return master

    logger.info("Подготавливаю мастер-профиль Chrome...")
    if master.exists():
        shutil.rmtree(master, ignore_errors=True)
    (master / SOURCE_PROFILE_DIR).mkdir(parents=True, exist_ok=True)

    if source_ext.exists():
        try:
            shutil.copytree(source_ext, master_ext, dirs_exist_ok=True)
        except (OSError, shutil.Error) as exc:
            logger.warning(f"Не удалось скопировать Extensions: {exc}")

    for name in MASTER_FILES:
        src = source_user_data / name if name == "Local State" else source_default / name
        dst = master / name if name == "Local State" else master / SOURCE_PROFILE_DIR / name
        if src.exists():
            try:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
            except (OSError, shutil.Error) as exc:
                logger.debug(f"Пропускаю {name}: {exc}")

    local_state = master / "Local State"
    if local_state.exists():
        try:
            data = json.loads(local_state.read_text(encoding="utf-8"))
            data.pop("sync", None)
            data.pop("signin", None)
            data.pop("account_info", None)
            local_state.write_text(json.dumps(data), encoding="utf-8")
        except Exception:
            pass

    logger.info("Мастер-профиль готов.")
    return master


def _cleanup_old_profiles(logger) -> None:
    temp_dir = Path(tempfile.gettempdir())
    now = time.time()
    removed = 0
    for path in temp_dir.glob(f"{PROFILE_PREFIX}*"):
        if not path.is_dir():
            continue
        lock_file = path / ".hate_worker_active"
        try:
            if lock_file.exists() and now - lock_file.stat().st_mtime < 3600:
                continue
            shutil.rmtree(path)
            removed += 1
        except (OSError, PermissionError) as exc:
            logger.debug(f"Не удалось удалить {path.name}: {exc}")
    if removed:
        logger.info(f"Очистка старых рабочих профилей: удалено {removed}.")


def _prepare_worker_profile(logger) -> Path:
    with _PROFILE_PREPARE_LOCK:
        _cleanup_old_profiles(logger)
        master = _ensure_master(logger)
        target = Path(tempfile.gettempdir()) / f"{PROFILE_PREFIX}{time.time_ns()}"
        logger.info(f"Worker-профиль: {target.name}")
        try:
            shutil.copytree(master, target, dirs_exist_ok=True)
        except (OSError, shutil.Error) as exc:
            shutil.rmtree(target, ignore_errors=True)
            raise RuntimeError(f"Ошибка при копировании профиля: {exc}") from exc
        return target


def _is_driver_alive(driver: Optional[ChromeWebDriver]) -> bool:
    if driver is None:
        return False
    try:
        _ = driver.current_url
        return True
    except Exception:
        return False


def bring_to_front(driver: Optional[ChromeWebDriver], logger=None) -> None:
    """Операция только над явно переданным Driver, без глобального состояния."""
    if driver is None:
        return
    try:
        driver.execute_cdp_cmd("Page.bringToFront", {})
    except Exception as exc:
        if logger:
            logger.debug(f"Page.bringToFront не сработал: {exc}")
    try:
        driver.execute_script("window.focus();")
    except Exception:
        pass


class BrowserSession:
    """Chrome-сессия, принадлежащая ровно одному Worker.

    Внутри одной Job `get()` возвращает тот же Driver. После завершения Job
    WorkerContext вызывает `close()` и профиль удаляется.
    """

    def __init__(self, logger, worker_id: str, event_bus=None):
        self.logger = logger
        self.worker_id = worker_id
        self.event_bus = event_bus
        self.driver: Optional[ChromeWebDriver] = None
        self._profile_dir: Optional[Path] = None
        self._lock_file: Optional[Path] = None
        self._lock = threading.RLock()
        self.started_at: Optional[float] = None
        self.profile_name: Optional[str] = None

    def get(self) -> ChromeWebDriver:
        with self._lock:
            if _is_driver_alive(self.driver):
                return self.driver  # type: ignore[return-value]
            self.close()
            self.driver = self._open()
            self.started_at = time.time()
            self.profile_name = self._profile_dir.name if self._profile_dir else None
            return self.driver

    def _open(self) -> ChromeWebDriver:
        profile_dir = _prepare_worker_profile(self.logger)
        options = Options()
        options.add_argument(f"--user-data-dir={profile_dir}")
        options.add_argument(f"--profile-directory={SOURCE_PROFILE_DIR}")
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_argument("--start-maximized")
        options.add_argument("--no-first-run")
        options.add_argument("--no-default-browser-check")
        options.add_argument("--disable-sync")
        if sys.platform.startswith("linux"):
            options.add_argument("--headless=new")
            options.add_argument("--no-sandbox")
            options.add_argument("--disable-dev-shm-usage")
            options.add_argument("--disable-gpu")
        options.add_argument("--disable-background-networking")
        options.add_argument("--disable-component-update")
        options.add_argument("--disable-default-apps")
        options.add_argument(
            "--disable-features=AccountConsistency,SigninAllowed,ChromeSignin,"
            "OptimizationHints,MediaRouter,AutofillServerCommunication"
        )
        # Selenium 4.15+ includes Selenium Manager and can resolve the
        # matching driver itself. This avoids webdriver-manager and its
        # separate cache/dependency on Ubuntu Server.
        service = Service()
        try:
            driver = ChromeWebDriver(service=service, options=options)
            try:
                driver.execute_script(
                    "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});"
                )
            except Exception:
                pass
        except Exception:
            shutil.rmtree(profile_dir, ignore_errors=True)
            raise

        self._profile_dir = profile_dir
        self.profile_name = profile_dir.name
        self._lock_file = profile_dir / ".hate_worker_active"
        try:
            self._lock_file.write_text(self.worker_id, encoding="utf-8")
        except OSError:
            pass
        self.logger.info(
            f"Worker {self.worker_id}: Chrome запущен с профилем {profile_dir.name}."
        )
        return driver

    def close(self) -> None:
        with self._lock:
            driver = self.driver
            self.driver = None
            if driver is not None:
                try:
                    driver.quit()
                except Exception:
                    pass
            if self._lock_file is not None:
                try:
                    self._lock_file.unlink(missing_ok=True)
                except OSError:
                    pass
            if self._profile_dir is not None:
                try:
                    shutil.rmtree(self._profile_dir, ignore_errors=True)
                except Exception:
                    pass
            self._profile_dir = None
            self._lock_file = None
            self.profile_name = None
            self.started_at = None
