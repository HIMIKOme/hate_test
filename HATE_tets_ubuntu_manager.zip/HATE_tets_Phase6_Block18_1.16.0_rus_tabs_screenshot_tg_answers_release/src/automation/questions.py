"""Поиск и клик по варианту ответа.

Поддерживает:
  • radio / checkbox;
  • matching — заполнение <select> по тексту правого варианта
    (номер строки может перемешиваться между прохождениями);
  • open_text — ввод текста в input.otp-textbox (всегда "не знаю").
"""
from __future__ import annotations

import re
import time
from typing import Dict, List, Optional, Tuple

from selenium.common.exceptions import (
    StaleElementReferenceException,
    WebDriverException,
)
from selenium.webdriver.common.by import By

from .base import check_stop


_OPTION_LETTER_RE = re.compile(r"^\s*\(?([А-Яа-яЁёA-Za-z])[\s\)\.\:\-]\s*")
_STRIP_LETTER_PREFIX_RE = re.compile(r"^\s*\(?[А-Яа-яЁёA-Za-z]\s*[\)\.\:\-]\s*")
_NORM_RE = re.compile(r"[^а-яёa-z0-9]+", re.IGNORECASE)

_WS_CHARS = (
    "\xa0", "\u2007", "\u2008", "\u2009", "\u200a", "\u202f",
    "\u200b", "\u200c", "\u200d", "\u2060",
    "\t", "\n", "\r",
)

_LETTER_ALIAS = {
    "A": {"A", "А"}, "B": {"B", "В"}, "C": {"C", "С"},
    "D": {"D", "Д", "Г"}, "E": {"E", "Е"},
    "А": {"A", "А"}, "Б": {"B", "Б"}, "В": {"B", "В"},
    "Г": {"D", "Г", "Д"}, "Д": {"D", "Д", "Г"}, "Е": {"E", "Е"},
}

_NAME_MARKERS = ("фио", "фамил", "имя", "surname", "lastname", "firstname")

OPEN_TEXT_FALLBACK = "не знаю"


def _normalize_text(s: str) -> str:
    if not s:
        return ""
    for ws in _WS_CHARS:
        s = s.replace(ws, " ")
    return _NORM_RE.sub("", s.lower())


def _normalize_ws(s: str) -> str:
    if not s:
        return ""
    for ws in _WS_CHARS:
        s = s.replace(ws, " ")
    return re.sub(r"\s+", " ", s).strip()


def _extract_digits(s: str) -> str:
    if not s:
        return ""
    return re.sub(r"\D", "", s)


def _strip_letter_prefix(s: str) -> str:
    if not s:
        return ""
    return _STRIP_LETTER_PREFIX_RE.sub("", s).strip()


def _letters_match(saved: str, actual: str) -> bool:
    a = (saved or "").strip().upper()
    b = (actual or "").strip().upper()
    if not a or not b:
        return False
    if a == b:
        return True
    return b in _LETTER_ALIAS.get(a, set())


# ---------------------------------------------------------------------------
# Проверка «Ответьте, пожалуйста, на вопрос»
# ---------------------------------------------------------------------------

def has_not_answered_warning(runner) -> bool:
    try:
        runner.driver.switch_to.default_content()
    except WebDriverException:
        return False

    js = """
    var els = document.querySelectorAll(
        'span, div, p, .alert, .modal, .modal-content, .modal-body, .toast'
    );
    for (var i = 0; i < els.length; i++) {
        var e = els[i];
        if (e.offsetParent === null) continue;
        var t = (e.textContent || '').trim();
        if (!t) continue;
        if (t.indexOf('Ответьте, пожалуйста') >= 0) return true;
        if (t.indexOf('Ответьте пожалуйста') >= 0) return true;
    }
    return false;
    """
    try:
        return bool(runner.driver.execute_script(js))
    except WebDriverException:
        return False


# ---------------------------------------------------------------------------
# Режим collect
# ---------------------------------------------------------------------------

def answer_current_question(runner) -> bool:
    found = find_first_answer_any_frame(runner)
    if found is None:
        return False
    element, context = found
    try:
        element.click()
    except (WebDriverException, StaleElementReferenceException):
        try:
            runner.driver.execute_script("arguments[0].click();", element)
        except (WebDriverException, StaleElementReferenceException) as exc:
            runner.logger.warning(f"Не удалось кликнуть: {exc}")
            return False
    runner.logger.info(f"Клинут первый вариант ответа ({context}).")
    return True


def find_first_answer_any_frame(runner, max_depth: int = 6):
    runner.driver.switch_to.default_content()
    result = find_in_current_context(runner, timeout=3)
    if result is not None:
        return result[0], f"основной документ / {result[1]}"
    return search_in_frames(runner, 0, max_depth, [])


def search_in_frames(runner, depth, max_depth, path):
    if depth >= max_depth:
        return None
    try:
        frames = runner.driver.find_elements(By.CSS_SELECTOR, "iframe, frame")
    except WebDriverException:
        return None

    for index, frame in enumerate(frames):
        try:
            runner.driver.switch_to.frame(frame)
        except (WebDriverException, StaleElementReferenceException):
            continue
        result = find_in_current_context(runner, timeout=3)
        if result is not None:
            return result[0], f"iframe {'.'.join(map(str, path + [index]))} / {result[1]}"
        nested = search_in_frames(runner, depth + 1, max_depth, path + [index])
        if nested is not None:
            return nested
        try:
            runner.driver.switch_to.parent_frame()
        except WebDriverException:
            runner.driver.switch_to.default_content()
            return None
    return None


def find_in_current_context(runner, timeout: float = 3):
    end_time = time.time() + timeout
    selector = (
        'input[type="radio"], input[type="checkbox"], '
        '[role="radio"], [role="checkbox"], [role="option"], '
        'label:has(input[type="radio"]), label:has(input[type="checkbox"]), '
        'button[class*="answer"], button[class*="option"], '
        '[data-answer], [data-option], [data-choice], '
        '[class*="answer-item"], [class*="answer_item"], '
        '[class*="answer-option"], [class*="answerOption"], '
        '[class*="option-item"], [class*="option_item"], '
        '[class*="choice-item"], [class*="choice_item"], '
        'label.otp-input'
    )
    while time.time() < end_time:
        check_stop(runner)
        try:
            elements = runner.driver.find_elements(By.CSS_SELECTOR, selector)
        except WebDriverException:
            elements = []

        for element in elements:
            try:
                tag = (element.tag_name or "").lower()
                role = (element.get_attribute("role") or "").lower()
                typ = (element.get_attribute("type") or "").lower()
                classes = (element.get_attribute("class") or "").lower()
                data_a = element.get_attribute("data-answer")
                data_o = element.get_attribute("data-option")
                data_c = element.get_attribute("data-choice")

                if tag == "input" and typ in {"radio", "checkbox"}:
                    if element.is_displayed() and element.is_enabled():
                        return element, "input"
                    label = None
                    el_id = element.get_attribute("id")
                    if el_id:
                        try:
                            label = runner.driver.find_element(
                                By.CSS_SELECTOR, f'label[for="{el_id}"]'
                            )
                        except WebDriverException:
                            label = None
                    if label is None:
                        try:
                            label = element.find_element(By.XPATH, "ancestor::label[1]")
                        except WebDriverException:
                            label = None
                    if label is not None and label.is_displayed() and label.is_enabled():
                        return label, "label для input"
                    continue

                if not element.is_displayed() or not element.is_enabled():
                    continue

                if tag == "label" and element.find_elements(
                    By.CSS_SELECTOR, 'input[type="radio"], input[type="checkbox"]'
                ):
                    return element, "label"

                if role in {"radio", "checkbox", "option"}:
                    return element, f"role={role}"

                if data_a or data_o or data_c:
                    return element, "data-*"

                if "otp-input" in classes or "otp-checkbox" in classes:
                    return element, "label.otp-input"

                if any(
                    token in classes
                    for token in (
                        "answer-item", "answer_item", "answer-option", "answeroption",
                        "option-item", "option_item", "choice-item", "choice_item",
                    )
                ) or (tag == "button" and ("answer" in classes or "option" in classes)):
                    return element, f"class={classes[:60]}"
            except (StaleElementReferenceException, WebDriverException):
                continue
        time.sleep(0.1)
    return None


def log_answer_diagnostics(runner) -> None:
    try:
        runner.driver.switch_to.default_content()
        frames = len(runner.driver.find_elements(By.CSS_SELECTOR, "iframe, frame"))
        inputs = len(runner.driver.find_elements(By.CSS_SELECTOR, "input"))
        buttons = len(runner.driver.find_elements(By.CSS_SELECTOR, "button"))
        labels = len(runner.driver.find_elements(By.CSS_SELECTOR, "label"))
        roles = len(runner.driver.find_elements(
            By.CSS_SELECTOR, '[role="radio"], [role="checkbox"], [role="option"]'
        ))
        runner.logger.error(
            f"Диагностика страницы: iframe/frame={frames}, input={inputs}, "
            f"label={labels}, button={buttons}, role-option={roles}."
        )
    except WebDriverException as exc:
        runner.logger.error(f"Не удалось собрать диагностику: {exc}")


# ---------------------------------------------------------------------------
# Определение типа вопроса
# ---------------------------------------------------------------------------

def has_matching_block(runner) -> bool:
    try:
        runner.driver.switch_to.default_content()
        els = runner.driver.find_elements(By.CSS_SELECTOR, "div.matching-div")
    except WebDriverException:
        return False
    for el in els:
        try:
            if el.is_displayed():
                return True
        except (WebDriverException, StaleElementReferenceException):
            continue
    return False


def has_open_text_input(runner) -> bool:
    try:
        runner.driver.switch_to.default_content()
        els = runner.driver.find_elements(By.CSS_SELECTOR, "input.otp-textbox")
    except WebDriverException:
        return False
    for el in els:
        try:
            if not el.is_displayed() or not el.is_enabled():
                continue
            typ = (el.get_attribute("type") or "").lower()
            if typ in ("text", ""):
                return True
        except (WebDriverException, StaleElementReferenceException):
            continue
    return False


# ---------------------------------------------------------------------------
# Stub для collect
# ---------------------------------------------------------------------------

def fill_matching_stub(runner, logger=None) -> bool:
    log = logger or runner.logger
    try:
        runner.driver.switch_to.default_content()
    except WebDriverException:
        pass

    try:
        container = None
        for el in runner.driver.find_elements(By.CSS_SELECTOR, "div.matching-div"):
            try:
                if el.is_displayed():
                    container = el
                    break
            except (WebDriverException, StaleElementReferenceException):
                continue
        if container is None:
            log.warning("fill_matching_stub: matching-div не найден.")
            return False

        selects = container.find_elements(By.CSS_SELECTOR, "select.otp-select")
        if not selects:
            log.warning("fill_matching_stub: нет select-ов.")
            return False

        options_per_select: List[List[str]] = []
        for s in selects:
            try:
                opts = s.find_elements(By.TAG_NAME, "option")
            except WebDriverException:
                opts = []
            values: List[str] = []
            for o in opts:
                try:
                    v = o.get_attribute("value") or ""
                except (WebDriverException, StaleElementReferenceException):
                    continue
                if v and v != "0":
                    values.append(v)
            options_per_select.append(values)

        any_filled = False
        for i, s in enumerate(selects):
            vals = options_per_select[i] if i < len(options_per_select) else []
            if not vals:
                continue
            value = vals[i % len(vals)]
            try:
                from selenium.webdriver.support.ui import Select
                try:
                    Select(s).select_by_value(value)
                except WebDriverException:
                    runner.driver.execute_script(
                        """
                        var s = arguments[0], v = arguments[1];
                        s.value = v;
                        s.dispatchEvent(new Event('input', {bubbles: true}));
                        s.dispatchEvent(new Event('change', {bubbles: true}));
                        if (window.jQuery) {
                            try { jQuery(s).trigger('change'); } catch(e) {}
                            try { jQuery(s).trigger('input'); } catch(e) {}
                        }
                        """,
                        s, value,
                    )
                any_filled = True
            except WebDriverException as exc:
                log.debug(f"fill_matching_stub: select#{i}: {exc}")

        time.sleep(0.5)
        return any_filled
    except Exception as exc:
        log.warning(f"fill_matching_stub: {exc}")
        return False


def fill_open_text_stub(runner, value: str = OPEN_TEXT_FALLBACK, logger=None) -> bool:
    log = logger or runner.logger
    try:
        runner.driver.switch_to.default_content()
    except WebDriverException:
        pass

    try:
        els = runner.driver.find_elements(By.CSS_SELECTOR, "input.otp-textbox")
    except WebDriverException:
        return False

    for el in els:
        try:
            if not el.is_displayed() or not el.is_enabled():
                continue
            typ = (el.get_attribute("type") or "").lower()
            if typ not in ("text", ""):
                continue
        except (WebDriverException, StaleElementReferenceException):
            continue

        try:
            el.clear()
        except WebDriverException:
            pass
        try:
            el.send_keys(value)
            time.sleep(0.3)
            return True
        except WebDriverException:
            pass
        try:
            runner.driver.execute_script(
                """
                var el = arguments[0], v = arguments[1];
                el.value = v;
                el.dispatchEvent(new Event('input', {bubbles: true}));
                el.dispatchEvent(new Event('change', {bubbles: true}));
                if (window.jQuery) {
                    try { jQuery(el).trigger('input'); } catch(e) {}
                    try { jQuery(el).trigger('change'); } catch(e) {}
                }
                """,
                el, value,
            )
            time.sleep(0.3)
            return True
        except WebDriverException as exc:
            log.debug(f"fill_open_text_stub: {exc}")
    return False


# ---------------------------------------------------------------------------
# Чтение текста вопроса
# ---------------------------------------------------------------------------

def read_question_text(runner) -> str:
    try:
        runner.driver.switch_to.default_content()

        try:
            els = runner.driver.find_elements(
                By.XPATH, "//span[contains(@class,'qtext')]//strong"
            )
        except WebDriverException:
            els = []

        strongs: list = []
        for el in els:
            try:
                if not el.is_displayed():
                    continue
            except (WebDriverException, StaleElementReferenceException):
                continue

            parts: list = []
            try:
                prev_sibs = el.find_elements(By.XPATH, "preceding-sibling::strong")
            except (WebDriverException, StaleElementReferenceException):
                prev_sibs = []
            for p in prev_sibs:
                try:
                    pt = _normalize_ws(p.text or "")
                    if pt:
                        parts.append(pt)
                except (WebDriverException, StaleElementReferenceException):
                    continue
            try:
                own = _normalize_ws(el.text or "")
            except (WebDriverException, StaleElementReferenceException):
                own = ""
            if own:
                parts.append(own)

            combined = " ".join(parts).strip()
            if not combined or len(combined) < 3 or len(combined) > 500:
                continue
            if _OPTION_LETTER_RE.match(combined):
                continue
            if combined not in strongs:
                strongs.append(combined)

        if strongs:
            for t in reversed(strongs):
                if t.rstrip().endswith("?") or len(t) >= 20:
                    return t
            return strongs[-1]

        try:
            els = runner.driver.find_elements(
                By.XPATH, "//span[contains(@class,'qtext')]/p[1]"
            )
        except WebDriverException:
            els = []

        for el in els:
            try:
                if not el.is_displayed():
                    continue
                t = _normalize_ws(el.text or "")
                if not t or len(t) < 3 or len(t) > 500:
                    continue
                if _OPTION_LETTER_RE.match(t):
                    continue
                return t
            except (WebDriverException, StaleElementReferenceException):
                continue

        try:
            qtext_els = runner.driver.find_elements(By.CSS_SELECTOR, "span.qtext")
        except WebDriverException:
            qtext_els = []

        for qt in qtext_els:
            try:
                if not qt.is_displayed():
                    continue
                full = _normalize_ws(qt.text or "")
                if not full:
                    continue
                m = re.search(r"\n\s*[А-ЯA-Z]\s*[\)\.\:\-]", full)
                if m:
                    full = full[:m.start()].strip()
                if 3 <= len(full) <= 500:
                    return full
            except (WebDriverException, StaleElementReferenceException):
                continue
    except WebDriverException:
        pass
    return ""


# ---------------------------------------------------------------------------
# Radio / checkbox
# ---------------------------------------------------------------------------

def _iter_answer_labels(runner):
    selectors = (
        "label.otp-input",
        "label.otp-checkbox",
        "div#d-q-ans-container label",
        "div[id='d-q-ans-container'] label",
        "label",
    )
    for sel in selectors:
        try:
            runner.driver.switch_to.default_content()
            els = runner.driver.find_elements(By.CSS_SELECTOR, sel)
        except WebDriverException:
            continue
        if not els:
            continue

        yielded_any = False
        for el in els:
            try:
                if not el.is_displayed() or not el.is_enabled():
                    continue
                text = (el.text or "").strip()
                if not text:
                    continue
                yielded_any = True
                yield el, text
            except (WebDriverException, StaleElementReferenceException):
                continue
        if yielded_any:
            return


def _is_checkbox_question(runner) -> bool:
    try:
        runner.driver.switch_to.default_content()
        els = runner.driver.find_elements(By.CSS_SELECTOR, "label.otp-checkbox")
    except WebDriverException:
        return False
    for el in els:
        try:
            if el.is_displayed():
                return True
        except (WebDriverException, StaleElementReferenceException):
            continue
    return False


def _try_click_el(runner, el) -> bool:
    try:
        el.click()
        return True
    except (WebDriverException, StaleElementReferenceException):
        pass
    try:
        runner.driver.execute_script("arguments[0].click();", el)
        return True
    except (WebDriverException, StaleElementReferenceException):
        pass
    return False


def _find_matching_index(runner, match_fn) -> int:
    try:
        for i, (_el, text) in enumerate(_iter_answer_labels(runner)):
            try:
                if match_fn(text):
                    return i
            except Exception:
                continue
    except Exception:
        pass
    return -1


def _click_by_index(runner, index: int) -> bool:
    if index < 0:
        return False
    try:
        for i, (el, _text) in enumerate(_iter_answer_labels(runner)):
            if i == index:
                return _try_click_el(runner, el)
    except Exception:
        return False
    return False


def answer_by_letter(runner, letter: str, max_attempts: int = 2) -> bool:
    if not letter:
        return False

    def _match(text: str) -> bool:
        m = _OPTION_LETTER_RE.match(text)
        if not m:
            return False
        return _letters_match(letter, m.group(1))

    for attempt in range(max_attempts):
        idx = _find_matching_index(runner, _match)
        if idx < 0:
            return False
        if _click_by_index(runner, idx):
            suffix = "" if attempt == 0 else f" (retry {attempt})"
            runner.logger.info(f"Клинут вариант {letter} (по букве){suffix}.")
            return True
        time.sleep(0.15)
    return False


def answer_by_text(runner, target_text: str, max_attempts: int = 2) -> bool:
    if not target_text:
        return False

    target_norm = _normalize_text(target_text)
    if not target_norm:
        return False
    target_digits = _extract_digits(target_text)

    def _match_exact(text: str) -> bool:
        text_wo = _strip_letter_prefix(text)
        return (target_norm == _normalize_text(text)
                or target_norm == _normalize_text(text_wo))

    def _match_substring(text: str) -> bool:
        if len(target_norm) < 8:
            return False
        text_wo = _strip_letter_prefix(text)
        n_full = _normalize_text(text)
        n_wo = _normalize_text(text_wo)
        return (target_norm in n_full or n_full in target_norm
                or target_norm in n_wo or n_wo in target_norm)

    def _match_digits(text: str) -> bool:
        if len(target_digits) < 2:
            return False
        text_wo = _strip_letter_prefix(text)
        return (target_digits == _extract_digits(text)
                or target_digits == _extract_digits(text_wo))

    strategies = [
        ("по тексту", _match_exact),
        ("по тексту (fuzzy)", _match_substring),
        ("по цифрам", _match_digits),
    ]
    for strategy_name, match_fn in strategies:
        for attempt in range(max_attempts):
            idx = _find_matching_index(runner, match_fn)
            if idx < 0:
                break
            if _click_by_index(runner, idx):
                suffix = "" if attempt == 0 else f" (retry {attempt})"
                runner.logger.info(f"Клинут вариант {strategy_name}{suffix}.")
                return True
            time.sleep(0.15)
    return False


def _try_one_with_retry(runner, letter: str, text: str):
    def _try_once():
        if letter and answer_by_letter(runner, letter, max_attempts=1):
            return "буква"
        if text and answer_by_text(runner, text, max_attempts=1):
            return "текст"
        if text:
            text_wo = _strip_letter_prefix(text)
            if text_wo and text_wo != text and answer_by_text(runner, text_wo, max_attempts=1):
                return "текст без префикса"
        return ""

    how = _try_once()
    if how:
        return True, how

    for i in range(4):
        time.sleep(0.15)
        how = _try_once()
        if how:
            return True, f"{how} (retry {i + 1})"
    return False, ""


def answer_by_saved_item(runner, item: dict):
    if not item:
        return False, ""

    t = item.get("type") or "radio"

    if t == "matching":
        return answer_matching_from_item(runner, item)
    if t == "open_text":
        return answer_open_text_from_item(runner, item)

    corrects = item.get("corrects")
    if not corrects:
        letter = (item.get("letter") or "").strip()
        text = (item.get("text") or "").strip()
        if letter or text:
            corrects = [{"letter": letter, "text": text}]
    if not corrects:
        return False, ""

    is_checkbox = _is_checkbox_question(runner)
    results: List[str] = []
    any_clicked = False
    tried_pairs = set()

    for c in corrects:
        letter = (c.get("letter") or "").strip()
        text = (c.get("text") or "").strip()
        key = (letter, text)
        if key in tried_pairs:
            continue
        tried_pairs.add(key)

        success, how = _try_one_with_retry(runner, letter, text)
        if success:
            any_clicked = True
            results.append(how)
            if not is_checkbox:
                break
        else:
            if not is_checkbox:
                return False, ""
            results.append(f"(пропущен: {letter or text[:30]})")

    if any_clicked:
        return True, ", ".join(results)
    return False, ""


# ---------------------------------------------------------------------------
# Matching — по кэшу
# ---------------------------------------------------------------------------

def _read_matching_pairs(runner) -> List[Dict[str, object]]:
    try:
        runner.driver.switch_to.default_content()
    except WebDriverException:
        return []

    try:
        container = runner.driver.find_element(By.CSS_SELECTOR, "div.matching-div")
    except (WebDriverException, StaleElementReferenceException):
        return []

    result: List[Dict[str, object]] = []

    # UL-вариант
    try:
        lis = container.find_elements(By.CSS_SELECTOR, "div.lst1 li")
    except WebDriverException:
        lis = []
    if lis:
        for li in lis:
            try:
                sel_el = li.find_element(By.CSS_SELECTOR, "select.otp-select")
                txt_el = li.find_element(By.CSS_SELECTOR, "div.txt")
                left = _normalize_ws(txt_el.text or "")
            except (WebDriverException, StaleElementReferenceException):
                continue
            if left:
                result.append({"left": left, "select_el": sel_el})
        if result:
            return result

    # TABLE-вариант
    try:
        trs = container.find_elements(By.CSS_SELECTOR, "table.matching-tbl tr")
    except WebDriverException:
        trs = []
    for tr in trs:
        try:
            tds = tr.find_elements(By.XPATH, "./td")
            if len(tds) < 2:
                continue
            left = _normalize_ws(tds[0].text or "")
            sel_el = tds[1].find_element(By.CSS_SELECTOR, "select.otp-select")
        except (WebDriverException, StaleElementReferenceException):
            continue
        if left:
            result.append({"left": left, "select_el": sel_el})
    return result


def _read_right_column_map(runner) -> Dict[str, str]:
    """Читает правый столбец matching-div: {num_str: text}."""
    try:
        runner.driver.switch_to.default_content()
    except WebDriverException:
        return {}

    try:
        container = runner.driver.find_element(By.CSS_SELECTOR, "div.matching-div")
    except (WebDriverException, StaleElementReferenceException):
        return {}

    result: Dict[str, str] = {}

    # UL-вариант
    try:
        lis = container.find_elements(By.CSS_SELECTOR, "div.lst2 li")
    except WebDriverException:
        lis = []
    for li in lis:
        try:
            num_el = li.find_element(By.CSS_SELECTOR, "div.num")
            txt_el = li.find_element(By.CSS_SELECTOR, "div.txt")
            num_str = _normalize_ws(num_el.text or "")
            text = _normalize_ws(txt_el.text or "")
        except (WebDriverException, StaleElementReferenceException):
            continue
        if num_str and text:
            result[num_str] = text
    if result:
        return result

    # TABLE-вариант
    try:
        tables = container.find_elements(By.CSS_SELECTOR, "table.matching-tbl")
    except WebDriverException:
        tables = []
    for table in tables:
        try:
            trs = table.find_elements(By.CSS_SELECTOR, "tr")
        except WebDriverException:
            trs = []
        for tr in trs:
            try:
                num_el = tr.find_element(By.CSS_SELECTOR, "td.td-number")
                tds = tr.find_elements(By.TAG_NAME, "td")
                text = ""
                for td in tds:
                    cls = td.get_attribute("class") or ""
                    if "td-number" in cls:
                        continue
                    cand = _normalize_ws(td.text or "")
                    if cand:
                        text = cand
                        break
                num_str = _normalize_ws(num_el.text or "")
            except (WebDriverException, StaleElementReferenceException):
                continue
            if num_str and text:
                result[num_str] = text
        if result:
            return result

    return result


def _read_select_options(select_el) -> List[Tuple[str, str]]:
    try:
        opts = select_el.find_elements(By.TAG_NAME, "option")
    except WebDriverException:
        return []
    result: List[Tuple[str, str]] = []
    for o in opts:
        try:
            v = o.get_attribute("value") or ""
            t = (o.text or "").strip()
        except (WebDriverException, StaleElementReferenceException):
            continue
        if not v or v == "0":
            continue
        result.append((v, t))
    return result


def _select_option_by_number(runner, select_el, num: int) -> bool:
    target = str(num)
    options = _read_select_options(select_el)
    value = None
    for v, t in options:
        if t.strip() == target:
            value = v
            break
    if value is None:
        if 1 <= num <= len(options):
            value = options[num - 1][0]
    if value is None:
        return False

    try:
        from selenium.webdriver.support.ui import Select
        Select(select_el).select_by_value(value)
        return True
    except Exception:
        pass

    try:
        runner.driver.execute_script(
            """
            var s = arguments[0], v = arguments[1];
            s.value = v;
            s.dispatchEvent(new Event('input', {bubbles: true}));
            s.dispatchEvent(new Event('change', {bubbles: true}));
            if (window.jQuery) {
                try { jQuery(s).trigger('change'); } catch(e) {}
                try { jQuery(s).trigger('input'); } catch(e) {}
            }
            """,
            select_el, value,
        )
        return True
    except WebDriverException:
        return False


def answer_matching_from_item(runner, item: dict):
    matching = item.get("matching") or []
    if not matching:
        return False, ""

    pairs = _read_matching_pairs(runner)
    if not pairs:
        runner.logger.warning("Matching: не нашёл select-ов на странице.")
        return False, ""

    # Читаем текущий правый столбец: {num_str: right_text}
    right_map = _read_right_column_map(runner)

    tried: List[str] = []
    any_ok = False
    for pair in pairs:
        left = pair["left"]
        select_el = pair["select_el"]

        target_num: Optional[int] = None
        target_text: str = ""

        # Ищем сохранённую пару по тексту левой колонки.
        for saved in matching:
            saved_left = _normalize_ws(str(saved.get("left") or ""))
            if not saved_left:
                continue
            if saved_left == left or saved_left in left or left in saved_left:
                target_text = _normalize_ws(str(saved.get("right_text") or ""))
                try:
                    target_num = int(saved.get("right") or 0)
                except (TypeError, ValueError):
                    target_num = 0
                break

        # Если есть right_text — ищем по нему актуальный num.
        if target_text and right_map:
            for num_str, rtext in right_map.items():
                if _normalize_ws(rtext) == target_text:
                    try:
                        target_num = int(num_str)
                    except ValueError:
                        pass
                    break

        if not target_num or target_num <= 0:
            tried.append(f"(нет пары для {left[:30]})")
            continue
        if _select_option_by_number(runner, select_el, target_num):
            any_ok = True
            tried.append(f"{left[:20]}={target_num}")

    if any_ok:
        return True, "matching: " + ", ".join(tried)
    return False, ""


# ---------------------------------------------------------------------------
# Open text — всегда "не знаю"
# ---------------------------------------------------------------------------

def answer_open_text_from_item(runner, item: dict = None):
    try:
        runner.driver.switch_to.default_content()
    except WebDriverException:
        return False, ""

    try:
        inp = runner.driver.find_element(By.CSS_SELECTOR, "input.otp-textbox")
    except (WebDriverException, StaleElementReferenceException):
        return False, ""

    if not inp.is_displayed() or not inp.is_enabled():
        return False, ""

    value = OPEN_TEXT_FALLBACK

    try:
        inp.clear()
    except WebDriverException:
        pass

    typed = False
    try:
        inp.send_keys(value)
        typed = True
    except WebDriverException:
        try:
            runner.driver.execute_script(
                "arguments[0].value = arguments[1];", inp, value
            )
            typed = True
        except WebDriverException as exc:
            runner.logger.warning(f"open_text: не удалось ввести: {exc}")

    if typed:
        runner.logger.info(f"open_text: введено {value!r}.")
        return True, value
    return False, ""
