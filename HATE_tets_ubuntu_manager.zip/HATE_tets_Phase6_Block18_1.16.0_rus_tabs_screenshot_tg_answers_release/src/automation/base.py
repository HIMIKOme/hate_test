"""Общие константы, исключение и утилиты для пакета automation."""
from __future__ import annotations

import time

from selenium.common.exceptions import (
    StaleElementReferenceException,
    WebDriverException,
)
from selenium.webdriver.common.by import By

ELEMENT_WAIT_TIMEOUT = 10
MAX_CONSECUTIVE_FAILURES = 5
FIRST_QUESTION_WAIT_TIMEOUT = 5.0


class TestAutomationError(Exception):
    """Ошибка в процессе прохождения теста."""


def find_first(runner, xpaths, timeout: float):
    end_time = time.time() + timeout
    while time.time() < end_time:
        check_stop(runner)
        for xpath in xpaths:
            try:
                elements = runner.driver.find_elements(By.XPATH, xpath)
            except WebDriverException:
                continue
            for element in elements:
                try:
                    if element.is_displayed() and element.is_enabled():
                        return element
                except StaleElementReferenceException:
                    continue
        time.sleep(0.05)
    return None


def safe_click(runner, element) -> None:
    try:
        element.click()
        return
    except StaleElementReferenceException:
        pass
    except Exception:
        pass

    try:
        runner.driver.execute_script("arguments[0].click();", element)
        return
    except StaleElementReferenceException:
        raise
    except Exception as exc:
        raise TestAutomationError(
            f"Не удалось кликнуть по элементу: {exc}"
        ) from exc


def check_stop(runner) -> None:
    """Прерывает работу, если пользователь нажал «Стоп» в GUI/панели.

    Проверяет ДВА флага:
      - runner.stop_event — остановка текущего запуска (кнопка «Стоп»
        в GUI);
      - services.global_state.is_stop_requested — «Стоп всё» из веб-панели,
        сбрасывается при старте нового задания.
    """
    if runner.stop_event.is_set():
        raise TestAutomationError("Остановлено пользователем.")
    try:
        from services.global_state import is_stop_requested
        if is_stop_requested():
            raise TestAutomationError("Остановлено через веб-панель.")
    except ImportError:
        pass
