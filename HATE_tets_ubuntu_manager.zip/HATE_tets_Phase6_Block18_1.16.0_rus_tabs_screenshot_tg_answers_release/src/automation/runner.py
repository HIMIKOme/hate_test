"""TestRunner — оркестратор автоматизации.

Режимы:
  • collect  — обычный проход теста, сбор всех правильных ответов.
  • 100      — решение теста на 100% по сохранённым ответам.

Особенность: если сайт после «Далее» пишет «Ответьте, пожалуйста, на
вопрос» — значит ответ не принят, и мы повторяем тот же вопрос заново.
"""
from __future__ import annotations

import random
import re
import threading
import time
from typing import Callable, List, Optional

from selenium.common.exceptions import (
    StaleElementReferenceException,
    WebDriverException,
)
from selenium.webdriver.common.by import By

import page_selectors as sel
from services.answers import AnswersExtractor, save_answers
from services.config import load_settings

from .base import (
    TestAutomationError,
    ELEMENT_WAIT_TIMEOUT,
    MAX_CONSECUTIVE_FAILURES,
    FIRST_QUESTION_WAIT_TIMEOUT,
    check_stop,
    find_first,
    safe_click,
)
from .browser import BrowserSession, bring_to_front
from .navigation import (
    click_confirm_yes,
    extract_result_score,
    go_to_next,
    has_confirm_finish_modal,
    is_result_page,
    log_result_summary,
)
from .questions import (
    OPEN_TEXT_FALLBACK,
    answer_by_saved_item,
    answer_current_question,
    fill_matching_stub,
    fill_open_text_stub,
    has_matching_block,
    has_not_answered_warning,
    has_open_text_input,
    log_answer_diagnostics,
    read_question_text,
)


_NORM_RE = re.compile(r"[^а-яёa-z0-9]+", re.IGNORECASE)
_WS_CHARS = ("\xa0", "\u2007", "\u2008", "\u2009", "\u200a", "\u202f",
             "\u200b", "\u200c", "\u200d", "\u2060", "\t", "\n", "\r")

SECONDS_PER_QUESTION = 10
RANDOM_EXTRA_MIN = 1
RANDOM_EXTRA_MAX = 10
POST_RESULT_PAUSE = 2.0

MAX_NOT_ANSWERED_RETRIES = 3

_NAME_MARKERS = ("фио", "фамил", "имя", "surname", "lastname", "firstname")

_START_SEQUENCE_XPATHS = [
    "//button[contains(normalize-space(text()),'Принять')]",
    "//button[contains(normalize-space(text()),'Согласен')]",
    "//button[contains(normalize-space(text()),'Продолжить')]",
    "//button[contains(normalize-space(text()),'Начать')]",
    "//button[contains(normalize-space(text()),'Пройти')]",
    "//button[contains(normalize-space(text()),'Старт')]",
    "//a[contains(normalize-space(text()),'Начать')]",
    "//a[contains(normalize-space(text()),'Пройти')]",
    "//a[contains(normalize-space(text()),'Старт')]",
    "//input[@id='btnNext']",
]


def _normalize_question(text: str) -> str:
    if not text:
        return ""
    for ch in _WS_CHARS:
        text = text.replace(ch, " ")
    return _NORM_RE.sub("", text.lower())


def _find_item_for_question(
    question_text: str,
    saved_answers: List[dict],
    question_number: int = 0,
) -> Optional[dict]:
    if not saved_answers:
        return None

    target = _normalize_question(question_text) if question_text else ""

    if target:
        for item in saved_answers:
            if _normalize_question(item.get("q", "")) == target:
                return item

        if len(target) >= 20:
            for item in saved_answers:
                n = _normalize_question(item.get("q", ""))
                if not n:
                    continue
                if target in n or n in target:
                    return item

    if question_number > 0:
        marker = f"#{question_number}"
        for item in saved_answers:
            if (item.get("q") or "").strip() == marker:
                return item

    return None


def _page_fingerprint(runner) -> str:
    try:
        txt = runner.driver.execute_script("""
            var q = document.querySelector('.otp-item-view-question[id^="dq_"]');
            if (q && q.id) return q.id;
            if (location.href.indexOf('testresult') >= 0) return 'RESULT';
            var md = document.querySelector('div.matching-div');
            if (md && md.id) return md.id;
            var inp = document.querySelector('input.otp-textbox');
            if (inp && inp.offsetParent !== null) return 'OPEN-TEXT';
            var num = document.querySelector('.otp-item-view-question .qnumber .num');
            if (num) return 'Q:' + (num.textContent || '').trim();
            return 'B:' + (document.body ? (document.body.innerText || '').substring(0, 60) : '');
        """) or ""
    except Exception:
        return "DEAD"
    return txt


class TestRunner:
    def __init__(
        self,
        url: str,
        logger,
        stop_event: threading.Event,
        max_attempts: int = 1,
        telegram_chat_ids: Optional[List[str]] = None,
        on_complete: Optional[Callable[[str, dict], None]] = None,
        mode: str = "collect",
        saved_answers: Optional[List[dict]] = None,
        reset_cookies: bool = False,
        user_name: str = "",
        driver=None,
        browser_session=None,
        worker_id: str = "",
        job_id: Optional[str] = None,
        on_stage: Optional[Callable[[str], None]] = None,
        on_progress: Optional[Callable[[float, int, int], None]] = None,
        capture_result_screenshot: bool = False,
    ):
        self.url = url
        self.logger = logger
        self.stop_event = stop_event
        self.driver = driver
        self.browser_session = browser_session
        self.worker_id = worker_id or f"runner-{threading.get_ident()}"
        self._owns_browser_session = False
        self.correct_answers: list = []
        self.max_attempts = max(1, int(max_attempts))
        # Legacy argument kept for compatibility; Telegram delivery is handled by Event Bus.
        self.telegram_chat_ids = telegram_chat_ids
        self.on_complete = on_complete
        self.mode = mode if mode in ("collect", "100") else "collect"
        self.saved_answers = saved_answers or []
        self.reset_cookies = reset_cookies
        self.user_name = (user_name or "").strip()
        self.job_id = job_id or ""
        self.on_stage = on_stage
        self.on_progress = on_progress
        self.capture_result_screenshot = bool(capture_result_screenshot)
        self.result_screenshot_path: str = ""

        self.result_status: str = ""
        self.result_score: dict = {}
        self.fallback_to_collect = False
        self._matched = 0
        self._unmatched = 0

        self._total_questions: int = 0
        self._per_question_delay: float = 0.0
        self.test_title: str = "Тест"

    # ------------------------------------------------------------------ #
    def run(self) -> None:
        try:
            attempt = 0
            while attempt < self.max_attempts:
                attempt += 1
                if self.stop_event.is_set():
                    self.logger.info("Остановлено пользователем до начала попытки.")
                    return
                if self.max_attempts > 1:
                    self.logger.info(f"=== Попытка {attempt} из {self.max_attempts} ===")
                try:
                    self._single_attempt()
                    self.logger.info("Работа автоматизации завершена.")
                    return
                except TestAutomationError as exc:
                    if self.stop_event.is_set():
                        self.logger.error(f"Остановлено пользователем: {exc}")
                        return
                    if attempt < self.max_attempts:
                        self.logger.warning(
                            f"Попытка {attempt} завершилась ошибкой: {exc}. "
                            f"Перезапускаю ({attempt + 1}/{self.max_attempts})..."
                        )
                        time.sleep(0.5)
                        continue
                    self.logger.error(
                        f"Все {self.max_attempts} попыток завершились ошибкой. "
                        f"Последняя: {exc}"
                    )
                    raise
                except WebDriverException as exc:
                    msg = exc.msg if hasattr(exc, "msg") else str(exc)
                    if self.stop_event.is_set():
                        self.logger.error(f"Остановлено пользователем: {msg}")
                        return
                    if attempt < self.max_attempts:
                        self.logger.warning(
                            f"Попытка {attempt}: ошибка браузера: {msg}. "
                            f"Перезапускаю ({attempt + 1}/{self.max_attempts})..."
                        )
                        time.sleep(0.5)
                        continue
                    self.logger.error(
                        f"Все {self.max_attempts} попыток: ошибка браузера. {msg}"
                    )
                    raise
                except Exception as exc:  # noqa: BLE001
                    if attempt < self.max_attempts:
                        self.logger.warning(
                            f"Попытка {attempt}: непредвиденная ошибка: {exc}. "
                            f"Перезапускаю ({attempt + 1}/{self.max_attempts})..."
                        )
                        time.sleep(0.5)
                        continue
                    self.logger.error(f"Непредвиденная ошибка: {exc}")
                    raise
        finally:
            # Если driver принадлежит Worker, TestRunner его не закрывает и не теряет.
            if self._owns_browser_session and self.browser_session is not None:
                try:
                    self.browser_session.close()
                except Exception:
                    pass
                self.browser_session = None
            self.driver = None

    def _single_attempt(self) -> None:
        if self.driver is None:
            if self.browser_session is None:
                self.browser_session = BrowserSession(self.logger, self.worker_id)
                self._owns_browser_session = True
            self.driver = self.browser_session.get()
        bring_to_front(self.driver, self.logger)

        if self.mode == "100":
            if self.reset_cookies:
                try:
                    self.driver.delete_all_cookies()
                    self.logger.info("Куки сброшены — тест будет пройден заново.")
                except WebDriverException as exc:
                    self.logger.debug(f"Не удалось сбросить куки: {exc}")

            self._open_test_url()
            if is_result_page(self):
                self.logger.info(
                    "После открытия сразу видна страница результата — "
                    "сбрасываю куки и открываю заново."
                )
                try:
                    self.driver.delete_all_cookies()
                except WebDriverException:
                    pass
                self._open_test_url()

            self._total_questions = self._read_total_questions_from_start_page()
            self._compute_delay_plan()

            self._start_test_if_needed()
            self._answer_loop_100()
            return

        self._open_test_url()
        self._start_test_if_needed()
        self._answer_loop()

    def request_stop(self) -> None:
        self.stop_event.set()

    # ------------------------------------------------------------------ #
    def _read_total_questions_from_start_page(self) -> int:
        xpaths = [
            "//div[contains(@class,'otp-item-view-itemscount')]//b",
            "//div[contains(@class,'itemscount')]//b",
            "//*[contains(text(),'Количество вопросов в тесте')]/..//b",
        ]
        for xp in xpaths:
            try:
                els = self.driver.find_elements(By.XPATH, xp)
            except WebDriverException:
                continue
            for el in els:
                try:
                    txt = (el.text or "").strip()
                except (WebDriverException, StaleElementReferenceException):
                    continue
                m = re.search(r"\d+", txt)
                if m:
                    n = int(m.group(0))
                    if n > 0:
                        self.logger.info(f"Режим 100: вопросов в тесте — {n}.")
                        return n
        self.logger.warning(
            "Режим 100: не удалось определить число вопросов "
            "на стартовой странице."
        )
        return 0

    def _compute_delay_plan(self) -> None:
        n = self._total_questions
        if n <= 0:
            n = len(self.saved_answers)
        if n <= 0:
            self._per_question_delay = float(SECONDS_PER_QUESTION)
            self.logger.info(
                f"Режим 100: пауза {self._per_question_delay:.1f} сек/вопрос "
                "(число вопросов неизвестно)."
            )
            return

        extra = random.randint(RANDOM_EXTRA_MIN, RANDOM_EXTRA_MAX)
        total = n * SECONDS_PER_QUESTION + extra
        self._per_question_delay = total / n
        self.logger.info(
            f"Режим 100: план задержки — {n} вопросов × "
            f"{self._per_question_delay:.2f} сек ≈ {total} сек "
            f"(+{extra} сек случайных)."
        )

    def _interruptible_sleep(self, seconds: float) -> None:
        if seconds <= 0:
            return
        end = time.time() + seconds
        while time.time() < end:
            check_stop(self)
            remaining = end - time.time()
            time.sleep(min(0.2, max(0.0, remaining)))

    # ------------------------------------------------------------------ #
    def _open_test_url(self) -> None:
        self._set_stage("opening")
        self.logger.info(f"Открываю ссылку теста: {self.url}")
        self.driver.get(self.url)
        try:
            title = str(self.driver.title or "").strip()
            if title:
                self.test_title = title
        except Exception:
            pass
        self.logger.info("Страница загружена.")
        bring_to_front(self.driver, self.logger)

    # ------------------------------------------------------------------ #
    def _has_question(self) -> bool:
        try:
            self.driver.switch_to.default_content()
        except WebDriverException:
            return False

        try:
            for el in self.driver.find_elements(By.CSS_SELECTOR, "div.matching-div"):
                try:
                    if el.is_displayed():
                        return True
                except (WebDriverException, StaleElementReferenceException):
                    continue
        except WebDriverException:
            pass

        try:
            for el in self.driver.find_elements(By.CSS_SELECTOR, "input.otp-textbox"):
                try:
                    if el.is_displayed() and el.is_enabled():
                        return True
                except (WebDriverException, StaleElementReferenceException):
                    continue
        except WebDriverException:
            pass

        try:
            for el in self.driver.find_elements(
                By.CSS_SELECTOR,
                "label.otp-input, label.otp-checkbox, "
                "input[type='radio'], input[type='checkbox']"
            ):
                try:
                    if el.is_displayed():
                        return True
                except (WebDriverException, StaleElementReferenceException):
                    continue
        except WebDriverException:
            pass

        return False

    def _try_click_start_button(self) -> str:
        for xp in _START_SEQUENCE_XPATHS:
            try:
                els = self.driver.find_elements(By.XPATH, xp)
            except WebDriverException:
                continue
            for el in els:
                try:
                    if not el.is_displayed() or not el.is_enabled():
                        continue
                except (WebDriverException, StaleElementReferenceException):
                    continue
                try:
                    el.click()
                except (WebDriverException, StaleElementReferenceException):
                    try:
                        self.driver.execute_script("arguments[0].click();", el)
                    except (WebDriverException, StaleElementReferenceException):
                        continue
                return xp
        return ""

    def _start_test_if_needed(self) -> None:
        check_stop(self)
        self.logger.info("Ищу кнопку начала теста...")

        end = time.time() + ELEMENT_WAIT_TIMEOUT * 3
        iteration = 0
        last_clicked = ""
        same_clicks = 0

        while time.time() < end:
            iteration += 1
            check_stop(self)

            if is_result_page(self):
                return

            if self._has_question():
                self.logger.info(
                    f"Первый вопрос найден (итерация {iteration})."
                )
                return

            clicked = self._try_click_start_button()
            if clicked:
                self.logger.info(
                    f"[{iteration}] клик по кнопке старта: {clicked[:80]}"
                )
                if clicked == last_clicked:
                    same_clicks += 1
                else:
                    same_clicks = 1
                    last_clicked = clicked

                if same_clicks >= 5:
                    self.logger.warning(
                        f"Кнопка '{clicked[:60]}' нажата {same_clicks} раз — "
                        "страница не меняется."
                    )
                    break

                time.sleep(1.2)
                continue

            time.sleep(0.5)

        if self._has_question():
            self.logger.info("Первый вопрос найден (после цикла).")
            return

        self.logger.warning(
            f"Первый вопрос не появился за {iteration} итераций — "
            "продолжаю, возможно, тест уже начат."
        )

    # ------------------------------------------------------------------ #
    def _answer_any_question(self, question_number: int) -> bool:
        if has_matching_block(self):
            self.logger.info(f"Вопрос #{question_number}: matching (stub).")
            return fill_matching_stub(self)

        if has_open_text_input(self):
            self.logger.info(
                f"Вопрос #{question_number}: open-text → {OPEN_TEXT_FALLBACK!r}."
            )
            return fill_open_text_stub(self, OPEN_TEXT_FALLBACK)

        self.logger.info(f"Вопрос #{question_number}: radio/checkbox.")
        return answer_current_question(self)

    # ------------------------------------------------------------------ #
    # Режим collect
    # ------------------------------------------------------------------ #

    def _answer_loop(self) -> None:
        self._set_stage("testing")
        question_number = 0
        consecutive_failures = 0
        not_answered_retries = 0

        while True:
            check_stop(self)

            if has_confirm_finish_modal(self):
                if click_confirm_yes(self):
                    self._wait_for_result(timeout=5.0)
                    self._finish_test()
                    return

            if is_result_page(self):
                self._finish_test()
                return

            question_number += 1
            self._set_progress(question_number)
            self.logger.info(f"Вопрос #{question_number}: обрабатываю...")

            try:
                answered = self._answer_any_question(question_number)
            except StaleElementReferenceException:
                self.logger.debug("Элемент устарел, повтор.")
                question_number -= 1
                continue

            if not answered:
                self.logger.warning(
                    f"Вопрос #{question_number}: не удалось ответить. "
                    "Повторная попытка..."
                )
                time.sleep(0.4)
                try:
                    answered = self._answer_any_question(question_number)
                except StaleElementReferenceException:
                    question_number -= 1
                    continue
                if not answered:
                    log_answer_diagnostics(self)
                    raise TestAutomationError(
                        f"Вопрос #{question_number}: не удалось ответить."
                    )

            try:
                next_clicked = go_to_next(self)
            except StaleElementReferenceException:
                self.logger.debug("Элемент устарел при 'Далее', повтор.")
                continue

            if not next_clicked:
                consecutive_failures += 1
                self.logger.warning(
                    f"Вопрос #{question_number}: кнопка 'далее' не найдена "
                    f"({consecutive_failures}/{MAX_CONSECUTIVE_FAILURES})."
                )
                if is_result_page(self):
                    self._finish_test()
                    return
                if consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
                    raise TestAutomationError(
                        "Не удаётся найти кнопку перехода несколько раз подряд."
                    )
                continue
            else:
                consecutive_failures = 0

            time.sleep(0.4)
            if has_not_answered_warning(self):
                not_answered_retries += 1
                self.logger.warning(
                    f"Вопрос #{question_number}: сайт пишет "
                    f"«Ответьте, пожалуйста» — ответ не принят "
                    f"(попытка {not_answered_retries}/{MAX_NOT_ANSWERED_RETRIES})."
                )
                if not_answered_retries >= MAX_NOT_ANSWERED_RETRIES:
                    raise TestAutomationError(
                        f"Вопрос #{question_number}: сайт {MAX_NOT_ANSWERED_RETRIES} раз "
                        "не принял ответ."
                    )
                question_number -= 1
                time.sleep(0.6)
                continue
            else:
                not_answered_retries = 0

            time.sleep(0.2)

    def _set_stage(self, stage: str) -> None:
        """Сообщить текущий этап через callback, который Worker связывает с Event Bus."""
        if self.on_stage is not None:
            try:
                self.on_stage(str(stage))
            except Exception as exc:
                self.logger.debug(f"Не удалось отправить stage-событие: {exc}")

    def _set_progress(self, current_question: int) -> None:
        total = self._total_questions or len(self.saved_answers)
        if total > 0:
            percent = min(100.0, (float(current_question) / float(total)) * 100.0)
        else:
            percent = 0.0
        if self.on_progress is not None:
            try:
                self.on_progress(percent, int(current_question), int(total))
            except Exception as exc:
                self.logger.debug(f"Не удалось отправить progress-событие: {exc}")

    # ------------------------------------------------------------------ #
    # Режим 100
    # ------------------------------------------------------------------ #

    def _answer_loop_100(self) -> None:
        self._set_stage("testing")
        if not self.saved_answers:
            self.logger.warning(
                "Режим 100: сохранённых ответов нет — переключаюсь на сбор."
            )
            self.fallback_to_collect = True
            self.result_status = "partial"
            self._answer_loop()
            return

        question_number = 0
        consecutive_failures = 0
        no_progress = 0
        not_answered_retries = 0

        while True:
            check_stop(self)

            if has_confirm_finish_modal(self):
                if click_confirm_yes(self):
                    self._wait_for_result(timeout=5.0)
                    self._set_final_status()
                    return

            if is_result_page(self):
                self._set_final_status()
                return

            question_number += 1
            self._set_progress(question_number)
            time.sleep(0.4)
            fp_before = _page_fingerprint(self)

            # Инициализируем ЗАРАНЕЕ — на случай, если try упадёт
            # с не-Stale исключением (например, WebDriverException).
            answered = False
            how = ""
            next_clicked = False

            try:
                q_text = read_question_text(self)
                item = _find_item_for_question(
                    q_text, self.saved_answers, question_number,
                )

                if item:
                    answered, how = answer_by_saved_item(self, item)
                    if answered:
                        self._matched += 1
                        self.logger.info(
                            f"Вопрос #{question_number}: {how}."
                        )
                    else:
                        self.logger.warning(
                            f"Вопрос #{question_number}: не удалось "
                            "ответить из кэша — fallback."
                        )
                        answered = self._answer_any_question(question_number)
                        self._unmatched += 1
                else:
                    self.logger.warning(
                        f"Вопрос #{question_number}: нет совпадения в кэше. "
                        "Fallback."
                    )
                    answered = self._answer_any_question(question_number)
                    self._unmatched += 1

                if answered and self._per_question_delay > 0:
                    self._interruptible_sleep(self._per_question_delay)

                next_clicked = go_to_next(self)

            except StaleElementReferenceException:
                self.logger.debug("Элемент устарел, повтор.")
                question_number -= 1
                continue

            if not answered:
                log_answer_diagnostics(self)
                raise TestAutomationError(
                    f"Вопрос #{question_number}: не удалось ответить."
                )

            if not next_clicked:
                consecutive_failures += 1
                self.logger.warning(
                    f"Вопрос #{question_number}: кнопка 'далее' не найдена "
                    f"({consecutive_failures}/{MAX_CONSECUTIVE_FAILURES})."
                )
                if is_result_page(self):
                    self._set_final_status()
                    return
                if consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
                    raise TestAutomationError(
                        "Не удаётся найти кнопку перехода несколько раз подряд."
                    )
                continue
            else:
                consecutive_failures = 0

            time.sleep(0.4)
            if has_not_answered_warning(self):
                not_answered_retries += 1
                self.logger.warning(
                    f"Вопрос #{question_number}: сайт пишет "
                    f"«Ответьте, пожалуйста» — ответ не принят "
                    f"(попытка {not_answered_retries}/{MAX_NOT_ANSWERED_RETRIES})."
                )
                if not_answered_retries >= MAX_NOT_ANSWERED_RETRIES:
                    raise TestAutomationError(
                        f"Вопрос #{question_number}: сайт {MAX_NOT_ANSWERED_RETRIES} раз "
                        "не принял ответ."
                    )
                question_number -= 1
                time.sleep(0.6)
                continue
            else:
                not_answered_retries = 0

            time.sleep(0.3)
            fp_after = _page_fingerprint(self)
            if fp_after == fp_before:
                no_progress += 1
                if no_progress >= 3:
                    self.logger.warning(
                        "Режим 100: страница не меняется 3 раза подряд."
                    )
                    no_progress = 0
            else:
                no_progress = 0

    # ------------------------------------------------------------------ #
    # Финал
    # ------------------------------------------------------------------ #

    def _set_final_status(self) -> None:
        try:
            time.sleep(POST_RESULT_PAUSE)
        except Exception:
            pass

        try:
            self._fill_user_name_if_possible()
        except Exception as exc:
            self.logger.warning(f"Ошибка при вводе ФИО: {exc}")

        score = extract_result_score(self)
        self.result_score = score
        if self.capture_result_screenshot:
            self._capture_result_screenshot()
        percent = score.get("percent")

        if percent is not None and percent >= 100:
            self.result_status = "success"
            self.fallback_to_collect = False
            self.logger.info(
                f"Режим 100: подтверждено {percent}% "
                f"(совпало {self._matched}, не совпало {self._unmatched})."
            )
            return

        if percent is not None:
            self.result_status = "partial"
            self.fallback_to_collect = True
            self.logger.warning(
                f"Режим 100: результат {percent}% — переключаюсь на сбор."
            )
            return

        if self._unmatched > 0:
            self.result_status = "partial"
            self.fallback_to_collect = True
            self.logger.warning(
                "Режим 100: процент не найден, часть не совпала — сбор."
            )
        else:
            self.result_status = "unknown"
            self.fallback_to_collect = False
            self.logger.warning(
                "Режим 100: процент/баллы не найдены на странице."
            )

    # ------------------------------------------------------------------ #
    def _capture_result_screenshot(self) -> None:
        """Сохраняет итоговую страницу теста в PNG, пока Chrome ещё открыт."""
        try:
            from services.config import get_data_dir

            directory = get_data_dir() / "screenshots"
            directory.mkdir(parents=True, exist_ok=True)
            safe_job = re.sub(r"[^A-Za-z0-9_.-]+", "_", self.job_id or "result")[:80] or "result"
            path = directory / f"{safe_job}_{int(time.time() * 1000)}.png"

            from services.screenshots import capture_page_screenshot
            captured = capture_page_screenshot(self.driver, path, logger=self.logger)

            if captured:
                self.result_screenshot_path = str(path)
                self.logger.info(f"Скриншот итоговой страницы сохранён: {path.name}")
            else:
                self.logger.warning("Не удалось сохранить скриншот итоговой страницы.")
        except Exception as exc:
            self.logger.warning(f"Не удалось сделать скриншот итоговой страницы: {exc}")
            self.result_screenshot_path = ""

    def _fill_user_name_if_possible(self) -> None:
        if not self.user_name:
            return

        anchor = None
        end = time.time() + 5.0
        while time.time() < end:
            anchor = self._find_username_anchor()
            if anchor is not None:
                break
            time.sleep(0.2)

        if anchor is None:
            self.logger.info(
                "Поле 'Ваше имя' на странице результата не найдено."
            )
            return

        self.logger.info(f"Ввожу ФИО: {self.user_name!r}")
        try:
            try:
                anchor.click()
            except (WebDriverException, StaleElementReferenceException):
                self.driver.execute_script("arguments[0].click();", anchor)
        except Exception as exc:
            self.logger.warning(f"Клик по 'Введите ваше имя' не удался: {exc}")
            return

        time.sleep(0.6)

        input_el = self._find_username_input()
        if input_el is None:
            self.logger.warning(
                "После клика по 'Введите ваше имя' поле ввода не появилось."
            )
            return

        try:
            input_el.clear()
        except WebDriverException:
            pass

        typed_ok = False
        try:
            input_el.send_keys(self.user_name)
            typed_ok = True
        except WebDriverException:
            try:
                self.driver.execute_script(
                    "arguments[0].value = arguments[1];", input_el, self.user_name
                )
                typed_ok = True
            except WebDriverException as exc:
                self.logger.warning(f"Не удалось ввести текст в поле ФИО: {exc}")

        if not typed_ok:
            return

        time.sleep(0.3)

        if self._try_save_username():
            self.logger.info("ФИО отправлено (кнопка сохранения).")
            time.sleep(0.5)
            return

        self.logger.info(
            "Кнопка сохранения ФИО не найдена — пробую нажать Enter."
        )
        try:
            from selenium.webdriver.common.keys import Keys
            input_el.send_keys(Keys.RETURN)
            time.sleep(0.5)
        except WebDriverException:
            pass

    def _find_username_anchor(self):
        xpaths = [
            "//div[@id='app-public-result-username']//a",
            "//app-public-result-username//a",
            "//*[contains(@class,'result-username-container')]//a",
        ]
        for xp in xpaths:
            try:
                els = self.driver.find_elements(By.XPATH, xp)
            except WebDriverException:
                continue
            for el in els:
                try:
                    if el.is_displayed() and el.is_enabled():
                        return el
                except (WebDriverException, StaleElementReferenceException):
                    continue
        return None

    def _find_username_input(self):
        selectors = [
            "#app-public-result-username input[type='text']",
            "app-public-result-username input[type='text']",
            "app-public-result-username input",
            ".result-username-container input[type='text']",
            ".result-username-container input",
        ]
        for css in selectors:
            try:
                els = self.driver.find_elements(By.CSS_SELECTOR, css)
            except WebDriverException:
                continue
            for el in els:
                try:
                    if el.is_displayed():
                        return el
                except (WebDriverException, StaleElementReferenceException):
                    continue

        try:
            modals = self.driver.find_elements(
                By.CSS_SELECTOR, "#dGlobalModal, .modal"
            )
        except WebDriverException:
            modals = []
        for m in modals:
            try:
                inputs = m.find_elements(
                    By.CSS_SELECTOR, "input[type='text'], input:not([type])"
                )
            except WebDriverException:
                continue
            for el in inputs:
                try:
                    if el.is_displayed():
                        return el
                except (WebDriverException, StaleElementReferenceException):
                    continue
        return None

    def _try_save_username(self) -> bool:
        xpaths = [
            "//app-public-result-username//button",
            "//div[@id='app-public-result-username']//button",
            "//*[contains(@class,'result-username-container')]//button",
            "//app-public-result-username//input[@type='submit']",
        ]
        for xp in xpaths:
            try:
                els = self.driver.find_elements(By.XPATH, xp)
            except WebDriverException:
                continue
            for el in els:
                try:
                    if el.is_displayed() and el.is_enabled():
                        try:
                            el.click()
                        except (WebDriverException, StaleElementReferenceException):
                            self.driver.execute_script("arguments[0].click();", el)
                        return True
                except (WebDriverException, StaleElementReferenceException):
                    continue
        return False

    # ------------------------------------------------------------------ #
    def _wait_for_result(self, timeout: float) -> None:
        end = time.time() + timeout
        while time.time() < end:
            check_stop(self)
            if is_result_page(self):
                return
            time.sleep(0.15)

    def _finish_test(self) -> None:
        self._set_stage("collecting")
        self.logger.info("Обнаружена страница результата — тест завершён.")
        log_result_summary(self)
        self._collect_correct_answers()

    def _test_title(self) -> str:
        return str(self.test_title or "Тест")

    def _collect_correct_answers(self) -> None:
        self.logger.info("Открываю 'Показать мои ответы'...")
        extractor = AnswersExtractor(self.driver, self.logger, self.stop_event)
        answers = extractor.collect()
        self.correct_answers = answers
        if not answers:
            self.logger.warning("Правильные ответы не найдены.")
            return

        self._set_stage("saving")
        result = save_answers(answers, self.logger, job_id=self.job_id or None)
        if not result:
            return

        self.logger.info(f"Всего правильных ответов: {len(answers)}.")

        self._set_stage("notifying")

        # Telegram — внешний клиент JobManager. Runner только формирует результат;
        # доставка текста/файла выполняется отдельным Event Bus notifier асинхронно.
        result["total_questions"] = int(self._total_questions or len(answers))
        result["test_title"] = self._test_title()

        if self.on_complete is not None:
            try:
                self.on_complete(self.url, result)
            except Exception as exc:
                self.logger.warning(f"Ошибка в on_complete: {exc}")
