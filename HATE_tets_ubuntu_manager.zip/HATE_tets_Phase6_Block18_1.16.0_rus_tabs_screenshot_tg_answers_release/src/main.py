"""HATE_tets — единственная точка входа Ubuntu Server."""
from __future__ import annotations

import platform
import sys


def main() -> int:
    if not sys.platform.startswith("linux"):
        print("HATE_tets: этот релиз предназначен только для Ubuntu/Linux.", file=sys.stderr)
        return 2
    from tray import main as server_main
    return int(server_main())


if __name__ == "__main__":
    raise SystemExit(main())
