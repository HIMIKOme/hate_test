"""Точка входа отдельного внешнего Watchdog."""
from __future__ import annotations

from services.watchdog_service import Watchdog


if __name__ == "__main__":
    raise SystemExit(Watchdog().run())
