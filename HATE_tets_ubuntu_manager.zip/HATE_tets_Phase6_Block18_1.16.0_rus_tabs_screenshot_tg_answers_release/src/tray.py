"""Точка входа HATE_tets_tray."""
from __future__ import annotations

import threading
import time
import os
from pathlib import Path
import json
import sys
import urllib.request
import subprocess
import signal

from services.cleanup import cleanup_old_files
from services.paths import project_root
from services.config import consume_reload_request, load_settings
from services.logging_setup import attach_event_bus_logger, setup_logger
from services.telegram_bot import TelegramBot
from services.event_journal import append_event
from services.statistics import record_event, snapshot as statistics_snapshot
from services.metrics import record_event as record_metric_event, snapshot as metrics_snapshot
from services.hub import Hub
from services.ipc import iter_commands, remove_command, publish_state, write_response
from services.watchdog_service import clear_shutdown_marker, mark_intentional_shutdown
from services.version import APP_VERSION
from services.job_store import JobStore


def _root_dir() -> Path:
    return project_root()


def _read_pid_file(path: Path) -> int | None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        pid = int(payload.get("pid") or 0)
        return pid if pid > 0 else None
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return None


def _terminate_external_pid(pid: int | None, name: str) -> None:
    if not pid or pid == os.getpid():
        return
    try:
        from services.watchdog_service import _terminate_pid
        if _terminate_pid(pid):
            logger_msg = f"Полное завершение: процесс {name} ({pid}) остановлен."
        else:
            logger_msg = f"Полное завершение: процесс {name} ({pid}) уже завершён или недоступен."
        # Логгер появится в main(); используем print, если helper вызван до него.
        print(logger_msg, flush=True)
    except Exception as exc:
        print(f"Полное завершение: не удалось остановить {name} ({pid}): {exc}", flush=True)


def main() -> int:
    if "--web-server" in sys.argv:
        from services.web_server import run_server
        return run_server()

    logger = setup_logger(log_queue=None, log_name="tray")
    clear_shutdown_marker()
    logger.info("=== HATE_tets tray стартует ===")
    heartbeat_dir = _root_dir() / "data" / "heartbeats"
    heartbeat_dir.mkdir(parents=True, exist_ok=True)
    app_hb = heartbeat_dir / "app.json"
    app_stop = threading.Event()
    def _app_heartbeat():
        while not app_stop.wait(3):
            try:
                tmp = app_hb.with_suffix(".tmp")
                tmp.write_text(json.dumps({"timestamp": time.time(), "pid": os.getpid()}), encoding="utf-8")
                tmp.replace(app_hb)
            except OSError:
                pass
    try:
        app_hb.write_text(json.dumps({"timestamp": time.time(), "pid": os.getpid()}), encoding="utf-8")
    except OSError:
        pass
    threading.Thread(target=_app_heartbeat, name="app-heartbeat", daemon=True).start()

    # Web работает отдельным процессом и не зависит от жизненного цикла Worker.
    def _web_health(port: int) -> bool:
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{port}/health", timeout=0.7) as response:
                return response.status == 200
        except Exception:
            return False

    def _ensure_web_process() -> None:
        info_path = _root_dir() / "data" / "web.json"
        try:
            if info_path.exists():
                info = json.loads(info_path.read_text(encoding="utf-8"))
                port = int(info.get("port", 0))
                if port and _web_health(port):
                    logger.info(f"Независимый Web уже работает на порту {port}.")
                    return
        except Exception:
            pass
        try:
            command = [sys.executable, "--web-server"] if getattr(sys, "frozen", False) else [sys.executable, str(Path(__file__).resolve()), "--web-server"]
            subprocess.Popen(
                command,
                cwd=str(_root_dir()),
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                close_fds=True,
            )
            logger.info("Запущен независимый Web-процесс.")
        except Exception as exc:
            logger.error(f"Не удалось запустить независимый Web: {exc}")

    _ensure_web_process()

    # Ubuntu Server-релиз не запускает отдельный desktop/watchdog-процесс. systemd отвечает за автоперезапуск.

    try:
        cleanup_old_files(logger)
    except Exception as exc:
        logger.warning(f"Ошибка автоочистки: {exc}")

    initial = load_settings()
    initial_token = (initial.get("telegram_token") or "").strip()

    worker_count = int(initial.get("worker_count", 4) or 4)
    worker_count = max(1, min(worker_count, 16))
    auxiliary_worker_count = int(initial.get("auxiliary_worker_count", 1) or 1)
    auxiliary_worker_count = max(1, min(auxiliary_worker_count, 4))
    # Hub — единственная точка владения JobManager/EventBus/StateManager.
    hub = Hub(
        logger,
        worker_count=worker_count,
        auxiliary_worker_count=auxiliary_worker_count,
        version=APP_VERSION,
        job_store=JobStore(_root_dir() / "data" / "jobs_state.json", logger=logger),
    )
    attach_event_bus_logger(logger, hub.events)
    hub.events.subscribe_all(append_event)
    hub.events.subscribe_all(record_event)
    hub.events.subscribe_all(record_metric_event)
    bot = TelegramBot(initial_token, logger, hub=hub)
    hub.set_job_handler(bot._process_job)
    hub.start()
    job_manager = hub.job_manager
    state = {"running": False}
    lock = threading.Lock()
    rebuild_requested = threading.Event()

    # --- Колбэки для веб-панели --- #
    def _start_bot(token: str) -> bool:
        if not token:
            return False
        with lock:
            if state["running"]:
                return True
        bot.token = token
        try:
            bot.start()
        except Exception as exc:
            logger.error(f"Не удалось запустить бота: {exc}")
            return False
        with lock:
            state["running"] = True
        hub.events.publish(
            "ComponentStatusChanged", source="telegram", component="telegram",
            status="online", message="Telegram бот запущен",
        )
        return True

    def _stop_bot() -> None:
        try:
            bot.stop()
        except Exception:
            pass
        with lock:
            state["running"] = False
        hub.events.publish(
            "ComponentStatusChanged", source="telegram", component="telegram",
            status="offline", message="Telegram бот остановлен",
        )

    def _panel_restart_bot() -> bool:
        logger.info("Веб-панель: перезапускаю бота.")
        _stop_bot()
        s = load_settings()
        new_token = (s.get("telegram_token") or "").strip()
        if not new_token:
            logger.warning("Веб-панель: токен пуст — бот не запущен.")
            return False
        time.sleep(0.3)
        return _start_bot(new_token)

    _tray_state: dict = {}

    def _panel_stop_tray() -> None:
        logger.info("Веб-панель: останавливаю трей по запросу.")
        _stop_bot()
        try:
            icon = _tray_state.get("icon")
            if icon is not None:
                icon.stop()
        except Exception as exc:
            logger.warning(f"Не удалось остановить иконку: {exc}")

    def _shutdown_all_processes() -> None:
        """Полностью выключает приложение и независимые дочерние процессы."""
        if not rebuild_requested.is_set():
            mark_intentional_shutdown("web_shutdown_all")
        logger.warning("Веб-панель: выполняю ПОЛНОЕ завершение всех процессов HATE_tets.")
        try:
            bot.stop_all_work()
        except Exception:
            pass
        _stop_bot()
        try:
            hub.stop(cancel_pending=True)
        except Exception as exc:
            logger.warning(f"Полное завершение: ошибка остановки Hub/Worker: {exc}")

        # Web независим от Hub, поэтому его PID нужно завершить явно.
        web_pid = _read_pid_file(_root_dir() / "data" / "web.json")
        watchdog_pid = _read_pid_file(_root_dir() / "data" / "heartbeats" / "watchdog.json")
        _terminate_external_pid(web_pid, "Web")
        if watchdog_pid and watchdog_pid != os.getpid():
            _terminate_external_pid(watchdog_pid, "Watchdog")
        try:
            (_root_dir() / "data" / "web.json").unlink(missing_ok=True)
        except OSError:
            pass
        try:
            icon = _tray_state.get("icon")
            if icon is not None:
                icon.stop()
        except Exception as exc:
            logger.warning(f"Полное завершение: не удалось остановить иконку: {exc}")

    # --- Отправка ссылки на веб-панель в ЛС --- #
    def _send_panel_link(url: str) -> None:
        try:
            s = load_settings()
            username = (s.get("error_contact") or "").strip()
        except Exception as exc:
            logger.warning(f"Не удалось прочитать контакт для отправки ссылки: {exc}")
            return

        if not username:
            logger.info(
                "Веб-панель: юзернейм не задан в config.txt — "
                "ссылка в Telegram не отправляется."
            )
            return

        with lock:
            bot_running = state["running"]
        if not bot_running or not bot.token:
            logger.info(
                "Веб-панель: бот не запущен — ссылка в Telegram не отправляется."
            )
            return

        text = (
            "Веб-панель HATE_tets запущена.\n"
            f"Адрес в локальной сети: {url}\n\n"
            "Открой эту ссылку с любого устройства в той же сети."
        )

        for attempt in range(1, 4):
            ok = False
            try:
                ok = bot.send_to_username(username, text)
            except Exception as exc:
                logger.warning(f"Отправка ссылки ({attempt}/3): {exc}")
                ok = False
            if ok:
                logger.info(f"Ссылка на веб-панель отправлена ({username}).")
                return
            if attempt < 3:
                time.sleep(5)

        logger.warning(
            f"Веб-панель: не удалось отправить ссылку {username} "
            "после 3 попыток. Возможно, пользователь ещё не писал боту."
        )

    # --- Автозапуск бота --- #
    if initial_token:
        _start_bot(initial_token)
    else:
        logger.warning(
            "Токен Telegram не задан — бот запустится автоматически, "
            "как только токен появится в config.txt (проверка раз в 2 секунды)."
        )

    # --- IPC: команды от независимого Web --- #
    def _command_watcher() -> None:
        while True:
            time.sleep(0.4)
            for path, command in list(iter_commands()):
                try:
                    name = command.get("command")
                    payload = command.get("payload") or {}
                    if name == "create_job":
                        try:
                            priority = payload.get("priority", "NORMAL")
                            from services.job import JobPriority
                            if isinstance(priority, str):
                                priority = JobPriority[priority.upper()]
                            from services.job import QueueType
                            try:
                                queue_type = QueueType[str(payload.get("queue_type") or "TEST_QUEUE").upper()]
                            except KeyError:
                                queue_type = QueueType.TEST_QUEUE
                            job = hub.submit_job(
                                url=str(payload.get("url") or ""),
                                mode=str(payload.get("mode") or "collect"),
                                user_name=str(payload.get("user_name") or ""),
                                telegram_chat_id=str(payload.get("telegram_chat_id") or "") or None,
                                priority=priority,
                                queue_type=queue_type,
                                metadata=dict(payload.get("metadata") or {}),
                                idempotency_key=str(payload.get("idempotency_key") or "").strip() or None,
                            )
                            logger.info(f"Hub: создана Job {job.id} из внешнего клиента.")
                        except Exception as exc:
                            logger.error(f"Hub: не удалось создать Job: {exc}")
                    elif name == "retry_job":
                        hub.retry_job(str(payload.get("job_id") or ""))
                    elif name == "set_priority":
                        try:
                            from services.job import JobPriority
                            hub.set_priority(str(payload.get("job_id") or ""), JobPriority[str(payload.get("priority") or "NORMAL").upper()])
                        except Exception as exc:
                            logger.warning(f"Hub: изменение приоритета: {exc}")
                    elif name == "cancel_job":
                        hub.cancel_job(str(payload.get("job_id") or ""))
                    elif name == "drain_worker":
                        hub.drain_worker(str(payload.get("worker_id") or ""))
                    elif name == "undrain_worker":
                        hub.undrain_worker(str(payload.get("worker_id") or ""))
                    elif name == "mark_job_stuck":
                        hub.mark_job_stuck(
                            str(payload.get("job_id") or ""),
                            runtime_sec=payload.get("runtime_sec"),
                            timeout_sec=payload.get("timeout_sec"),
                            reason=str(payload.get("reason") or "watchdog_timeout"),
                        )
                    elif name == "recover_job":
                        hub.recover_stuck_job(
                            str(payload.get("job_id") or ""),
                            reason=str(payload.get("reason") or "watchdog_timeout"),
                        )
                    elif name == "reset_circuit":
                        hub.reset_circuit(str(payload.get("site") or payload.get("url") or ""))
                    elif name == "terminate_job":
                        hub.terminate_stuck_job(
                            str(payload.get("job_id") or ""),
                            reason=str(payload.get("reason") or "watchdog_timeout"),
                        )
                    elif name == "stop_all":
                        try:
                            bot.stop_all_work()
                        except Exception:
                            pass
                        job_manager.cancel_all()
                        # Chrome принадлежит WorkerContext и закрывается самим Worker.
                    elif name == "restart_bot":
                        _panel_restart_bot()
                    elif name == "stop_tray":
                        _panel_stop_tray()
                    elif name == "shutdown_all":
                        _shutdown_all_processes()
                    elif name == "prepare_rebuild":
                        command_id = str(command.get("id") or "")
                        if command_id:
                            write_response(command_id, {"ok": False, "error": "Пересборка отключена в Ubuntu Server-релизе."})
                    elif name == "rebuild_project":
                        logger.warning("Пересборка отключена в Ubuntu Server-релизе.")
                    elif name == "open_answers":
                        try:
                            from services.answers import get_answers_dir
                            path_to_open = get_answers_dir()
                            if sys.platform == "win32":
                                os.startfile(str(path_to_open))
                            elif sys.platform == "darwin":
                                subprocess.Popen(["open", str(path_to_open)])
                            else:
                                subprocess.Popen(["xdg-open", str(path_to_open)])
                        except Exception as exc:
                            logger.warning(f"IPC open_answers: {exc}")
                    else:
                        logger.warning(f"Неизвестная Web-команда: {name}")
                except Exception as exc:
                    logger.warning(f"Ошибка обработки Web-команды: {exc}")
                finally:
                    remove_command(path)

    threading.Thread(target=_command_watcher, name="web-command-watcher", daemon=True).start()

    def _read_watchdog_status() -> dict:
        try:
            payload = json.loads((_root_dir() / "data" / "watchdog.json").read_text(encoding="utf-8"))
            return payload if isinstance(payload, dict) else {}
        except Exception:
            return {}

    # --- Публикация состояния для независимого Web --- #
    def _state_publisher() -> None:
        while True:
            try:
                settings = load_settings()
                jobs = job_manager.snapshot(include_history=True)
                with lock:
                    bot_running = bool(state["running"])
                state_snapshot = hub.state.snapshot(jobs)
                state_snapshot["circuit_breakers"] = hub.circuit_snapshot()
                workers = state_snapshot["workers"]
                browser_open = any(
                    bool(worker.get("browser_status") == "online")
                    for worker in workers
                    if worker.get("alive")
                )
                web_info = {}
                try:
                    web_info = json.loads((_root_dir() / "data" / "web.json").read_text(encoding="utf-8"))
                except Exception:
                    pass
                publish_state({
                    "ok": True,
                    "application_status": "Online",
                    "bot_running": bot_running,
                    "browser_open": browser_open,
                    "uptime": int(time.time() - app_start_time),
                    "port": web_info.get("port", 0),
                    "lan_ip": web_info.get("lan_ip", "127.0.0.1"),
                    "url": web_info.get("url", ""),
                    "cache_size": len(getattr(bot.cache, "data", {}) or {}),
                    "jobs": jobs,
                    "workers": workers,
                    "job_progress": state_snapshot.get("job_progress", {}),
                    "components": state_snapshot.get("components", {}),
                    "version": APP_VERSION,
                    "queue_summary": jobs.get("queue_sizes", {}),
                    "events": state_snapshot.get("events", []),
                    "statistics": statistics_snapshot(),
                    "metrics": metrics_snapshot(),
                    "resource": hub.resource_manager.snapshot(),
                    "idempotency": hub.idempotency_store.snapshot(),
                    "recovery": hub.job_manager.recovery_snapshot(),
                    "watchdog": _read_watchdog_status(),
                    "pid": os.getpid(),
                })
            except Exception as exc:
                logger.debug(f"state publisher: {exc}")
            time.sleep(1.0)

    app_start_time = time.time()
    threading.Thread(target=_state_publisher, name="web-state-publisher", daemon=True).start()

    # --- Watcher --- #
    def _watcher() -> None:
        while True:
            time.sleep(2)
            try:
                forced = consume_reload_request()
                s = load_settings()
                new_token = (s.get("telegram_token") or "").strip()

                with lock:
                    is_running = state["running"]

                if forced:
                    logger.info("Получен сигнал перезагрузки настроек из файла.")

                if rebuild_requested.is_set():
                    continue

                if not is_running:
                    if new_token:
                        logger.info("Токен найден — запускаю бота.")
                        _start_bot(new_token)
                else:
                    if new_token != bot.token:
                        logger.info("Токен изменился — перезапускаю бота.")
                        _stop_bot()
                        if new_token:
                            _start_bot(new_token)
                        else:
                            logger.warning("Новый токен пуст — бот остановлен.")
                    elif forced:
                        logger.info("Настройки перечитаны, изменений нет.")
            except Exception as exc:
                logger.warning(f"Watcher: {exc}")

    threading.Thread(target=_watcher, name="tg-watcher", daemon=True).start()

    # Web работает отдельным процессом; состояние и команды идут через IPC.

    # --- Ubuntu Server lifecycle ---
    def _on_quit(signum=None, frame=None) -> None:
        if rebuild_requested.is_set():
            return
        mark_intentional_shutdown("service_stop")
        logger.info("Останавливаю Telegram-бота и Worker-пул...")
        _stop_bot()
        try:
            hub.stop(cancel_pending=True)
        except Exception as exc:
            logger.warning(f"Ошибка остановки JobManager: {exc}")
        app_stop.set()

    if sys.platform.startswith("linux"):
        signal.signal(signal.SIGTERM, _on_quit)
        signal.signal(signal.SIGINT, _on_quit)
        logger.info("HATE_tets работает в Ubuntu Server режиме. Web-панель доступна через LAN.")
        try:
            while not app_stop.wait(1.0):
                pass
        finally:
            _on_quit()
    else:
        # Исходный tray оставлен только для совместимости с историческими тестами;
        # Ubuntu-релиз не содержит и не устанавливает GUI/tray зависимости.
        logger.error("Этот релиз предназначен только для Ubuntu/Linux.")

    app_stop.set()
    try:
        current = {}
        try:
            current = json.loads((_root_dir() / "data" / "ipc" / "state.json").read_text(encoding="utf-8"))
        except Exception:
            pass
        current.update({"ok": True, "application_status": "Offline", "bot_running": False})
        publish_state(current)
    except Exception:
        pass
    try: app_hb.unlink(missing_ok=True)
    except OSError: pass
    logger.info("=== HATE_tets tray завершён ===")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
