#!/usr/bin/env bash
set -euo pipefail
if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files hate-tets.service >/dev/null 2>&1; then
  if [[ "${EUID}" -eq 0 ]]; then systemctl stop hate-tets.service; else sudo systemctl stop hate-tets.service; fi
else
  pkill -f 'src/main.py' || true
fi
