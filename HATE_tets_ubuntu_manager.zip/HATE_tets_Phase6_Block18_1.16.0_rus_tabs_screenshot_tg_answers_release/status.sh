#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files hate-tets.service >/dev/null 2>&1; then
  if [[ "${EUID}" -eq 0 ]]; then systemctl --no-pager status hate-tets.service || true; else sudo systemctl --no-pager status hate-tets.service || true; fi
fi
if [[ -f "$ROOT/data/web.json" ]]; then
  echo
  echo "Web-панель:"
  cat "$ROOT/data/web.json"
fi
