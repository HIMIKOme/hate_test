#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

if [[ "$(uname -s)" != "Linux" ]]; then
  echo "Ошибка: этот установщик предназначен только для Ubuntu/Linux."
  exit 2
fi
if ! command -v apt-get >/dev/null 2>&1; then
  echo "Ошибка: нужен Ubuntu/Debian с apt-get."
  exit 2
fi

SUDO=""
if [[ "${EUID}" -ne 0 ]]; then
  if ! command -v sudo >/dev/null 2>&1; then
    echo "Ошибка: нужен sudo."
    exit 2
  fi
  SUDO="sudo"
fi

echo "[1/6] Устанавливаю системные зависимости..."
$SUDO apt-get update
DEBIAN_FRONTEND=noninteractive $SUDO apt-get install -y python3 python3-venv python3-pip ca-certificates curl chromium

echo "[2/6] Создаю виртуальное окружение..."
python3 -m venv "$ROOT/venv"
"$ROOT/venv/bin/python" -m pip install --upgrade pip wheel setuptools

echo "[3/6] Устанавливаю Python-зависимости..."
"$ROOT/venv/bin/python" -m pip install -r "$ROOT/config/requirements.txt"

echo "[4/6] Создаю каталоги..."
mkdir -p "$ROOT/data/logs" "$ROOT/data/heartbeats" "$ROOT/data/ipc" "$ROOT/data/screenshots" "$ROOT/data/diagnostics" "$ROOT/data/releases"
touch "$ROOT/data/.gitkeep"
chmod +x "$ROOT/start.sh" "$ROOT/stop.sh" "$ROOT/status.sh"

echo "[5/6] Проверяю Python-код и тесты..."
"$ROOT/venv/bin/python" -m compileall -q "$ROOT/src"
"$ROOT/venv/bin/python" "$ROOT/tests/run_tests.py"

echo "[6/6] Устанавливаю systemd-сервис..."
SERVICE="hate-tets.service"
TMP="/tmp/$SERVICE"
cat > "$TMP" <<UNIT
[Unit]
Description=HATE_tets Ubuntu Server
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=$ROOT
ExecStart=$ROOT/venv/bin/python $ROOT/src/main.py
Restart=always
RestartSec=5
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
UNIT
$SUDO cp "$TMP" "/etc/systemd/system/$SERVICE"
$SUDO systemctl daemon-reload
$SUDO systemctl enable "$SERVICE"

# Telegram Manager: управление установкой и запуском проектов без SSH.
$SUDO mkdir -p "$ROOT/data/manager" "$ROOT/data/managed_projects"
printf '%s\n' '8522666040:AAHZh3nk1LwtfT917Vi2sudVg_bbetgM2JA' | $SUDO tee "$ROOT/data/manager/token" >/dev/null
printf '%s\n' '5554369191' | $SUDO tee "$ROOT/data/manager/admin_id" >/dev/null
$SUDO chmod 600 "$ROOT/data/manager/token" "$ROOT/data/manager/admin_id"
MANAGER_SERVICE="hate-ubuntu-manager.service"
MANAGER_TMP="/tmp/$MANAGER_SERVICE"
cat > "$MANAGER_TMP" <<UNIT2
[Unit]
Description=HATE Ubuntu Telegram Manager
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=$ROOT
ExecStart=$ROOT/venv/bin/python -m manager.manager
Restart=always
RestartSec=5
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
UNIT2
$SUDO cp "$MANAGER_TMP" "/etc/systemd/system/$MANAGER_SERVICE"
$SUDO systemctl daemon-reload
$SUDO systemctl enable "$MANAGER_SERVICE"
$SUDO systemctl restart "$MANAGER_SERVICE"

cat <<EOF2

========================================
HATE_tets установлен.

Запуск:    ./start.sh
Остановка: ./stop.sh
Статус:    ./status.sh

После запуска Web-панель покажет LAN-адрес в:
  data/web.json

Открыть её можно с телефона/ПК в той же сети.
========================================
EOF2
