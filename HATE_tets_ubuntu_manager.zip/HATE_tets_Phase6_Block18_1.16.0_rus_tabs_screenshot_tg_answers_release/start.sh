#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files hate-tets.service >/dev/null 2>&1; then
  if [[ "${EUID}" -eq 0 ]]; then systemctl start hate-tets.service; else sudo systemctl start hate-tets.service; fi
else
  cd "$ROOT"
  exec "$ROOT/venv/bin/python" "$ROOT/src/main.py"
fi
