#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
if [[ "$EUID" -ne 0 ]]; then exec sudo bash "$0" "$@"; fi
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y python3 ca-certificates curl unzip tar
mkdir -p "$ROOT/data/manager" "$ROOT/data/managed_projects"
printf '%s\n' '8522666040:AAHZh3nk1LwtfT917Vi2sudVg_bbetgM2JA' > "$ROOT/data/manager/token"
printf '%s\n' '5554369191' > "$ROOT/data/manager/admin_id"
chmod 600 "$ROOT/data/manager/token" "$ROOT/data/manager/admin_id"
cat > /etc/systemd/system/hate-ubuntu-manager.service <<UNIT
[Unit]
Description=HATE Ubuntu Telegram Manager
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=$ROOT
ExecStart=/usr/bin/python3 -m manager.manager
Restart=always
RestartSec=5
Environment=PYTHONUNBUFFERED=1

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now hate-ubuntu-manager.service
echo "Telegram Manager installed."
