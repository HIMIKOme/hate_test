"""Telegram manager for the Ubuntu deployment."""
