from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import signal
import subprocess
import tarfile
import tempfile
import time
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path
from typing import Optional

from .config import PROJECTS, ROOT, admin_id, ensure_dirs, token

API = "https://api.telegram.org/bot{}/{}"
MAX_LOG = 5000
NAME_RE = re.compile(r"^[A-Za-z0-9._-]{1,48}$")


def run_command(args: list[str], cwd: Path | None = None, timeout: int = 900) -> tuple[int, str]:
    proc = subprocess.run(
        args,
        cwd=str(cwd) if cwd else None,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
        env={**os.environ, "PYTHONUNBUFFERED": "1"},
    )
    return proc.returncode, proc.stdout[-MAX_LOG:]


def github_download_url(url: str) -> str:
    """Accept raw GitHub URLs, /blob/ archive URLs and repository URLs."""
    url = url.strip()
    p = urllib.parse.urlparse(url)
    if p.netloc.lower() in {"github.com", "www.github.com"}:
        parts = [x for x in p.path.split("/") if x]
        if len(parts) >= 5 and parts[2] == "blob":
            return "https://raw.githubusercontent.com/" + "/".join(parts[:2] + parts[3:])
        if len(parts) >= 2:
            return f"https://github.com/{parts[0]}/{parts[1]}/archive/refs/heads/main.zip"
    return url


def download(url: str, destination: Path) -> None:
    req = urllib.request.Request(url, headers={"User-Agent": "HATE-Ubuntu-Manager/1.0"})
    with urllib.request.urlopen(req, timeout=60) as response, destination.open("wb") as out:
        shutil.copyfileobj(response, out)


def extract_archive(archive: Path, destination: Path) -> Path:
    destination.mkdir(parents=True, exist_ok=True)
    if zipfile.is_zipfile(archive):
        with zipfile.ZipFile(archive) as z:
            z.extractall(destination)
    elif tarfile.is_tarfile(archive):
        with tarfile.open(archive) as t:
            base = destination.resolve()
            for member in t.getmembers():
                target = (destination / member.name).resolve()
                if target != base and base not in target.parents:
                    raise ValueError("Опасный путь в TAR-архиве")
                if member.issym() or member.islnk():
                    raise ValueError("Ссылки в TAR-архивах запрещены")
            t.extractall(destination)
    else:
        raise ValueError("Поддерживаются ZIP/TAR-архивы")
    children = list(destination.iterdir())
    if len(children) == 1 and children[0].is_dir():
        wrapper = children[0]
        tmp = destination.parent / (destination.name + ".flatten")
        if tmp.exists(): shutil.rmtree(tmp)
        tmp.mkdir()
        for item in wrapper.iterdir():
            shutil.move(str(item), str(tmp / item.name))
        shutil.rmtree(wrapper)
        for item in tmp.iterdir():
            shutil.move(str(item), str(destination / item.name))
        tmp.rmdir()
    return destination


def validate_name(name: str) -> str:
    name = name.strip()
    if not NAME_RE.fullmatch(name):
        raise ValueError("Недопустимое имя проекта")
    return name


def systemd_service(name: str) -> str:
    return f"{name}.service"


def service_status(name: str) -> str:
    try:
        return project_action(name, "status").strip()[-80:] or "unknown"
    except Exception:
        return "unknown"


def project_dir(name: str) -> Path:
    if name == "hate-tets":
        return ROOT
    return PROJECTS / name


def project_list() -> list[str]:
    ensure_dirs()
    names = ["hate-tets"] if (ROOT / "start.sh").exists() else []
    names.extend(p.name for p in PROJECTS.iterdir() if p.is_dir())
    return sorted(set(names))


def install_project(name: str, url: str) -> str:
    name = validate_name(name)
    project = PROJECTS / name
    if project.exists():
        raise FileExistsError(f"Проект {name} уже существует")
    work = Path(tempfile.mkdtemp(prefix="hate-manager-", dir=str(PROJECTS.parent)))
    archive = work / "project.zip"
    unpack = work / "unpack"
    try:
        download(github_download_url(url), archive)
        extract_archive(archive, unpack)
        candidates = list(unpack.iterdir())
        if len(candidates) == 1 and candidates[0].is_dir():
            source = candidates[0]
        else:
            source = unpack
        shutil.copytree(source, project)
        installer = project / "install.sh"
        if not installer.exists():
            raise FileNotFoundError("В архиве нет install.sh")
        installer.chmod(installer.stat().st_mode | 0o111)
        rc, output = run_command(["bash", str(installer)], cwd=project, timeout=1800)
        if rc != 0:
            shutil.rmtree(project, ignore_errors=True)
            raise RuntimeError(output or "install.sh завершился с ошибкой")
        return output
    finally:
        shutil.rmtree(work, ignore_errors=True)


def update_project(name: str, url: str) -> str:
    name = validate_name(name)
    if name == "hate-tets":
        raise ValueError("Основной HATE_tets обновляйте отдельно, чтобы не потерять серверную конфигурацию")
    project = project_dir(name)
    if not project.is_dir():
        raise FileNotFoundError("Проект не найден")
    backup = PROJECTS / ("." + name + ".backup")
    if backup.exists():
        shutil.rmtree(backup)
    project.rename(backup)
    try:
        output = install_project(name, url)
        old_data = backup / "data"
        new_data = project / "data"
        if old_data.is_dir():
            shutil.copytree(old_data, new_data, dirs_exist_ok=True)
        shutil.rmtree(backup, ignore_errors=True)
        return output
    except Exception:
        shutil.rmtree(project, ignore_errors=True)
        if backup.exists():
            backup.rename(project)
        raise


def delete_project(name: str) -> None:
    name = validate_name(name)
    if name == "hate-tets":
        raise ValueError("Основной HATE_tets удалять через менеджер нельзя")
    project = project_dir(name)
    if not project.is_dir():
        raise FileNotFoundError("Проект не найден")
    try:
        project_action(name, "stop")
    except Exception:
        pass
    shutil.rmtree(project)


def project_action(name: str, action: str) -> str:
    name = validate_name(name)
    project = project_dir(name)
    if not project.is_dir():
        raise FileNotFoundError("Проект не найден")
    scripts = {
        "start": project / "start.sh",
        "stop": project / "stop.sh",
        "restart": project / "restart.sh",
        "status": project / "status.sh",
    }
    if action == "logs":
        log_dir = project / "data" / "logs"
        logs = sorted(log_dir.glob("*.log"), key=lambda p: p.stat().st_mtime, reverse=True) if log_dir.exists() else []
        if not logs:
            rc, out = run_command(["journalctl", "-u", "hate-tets.service", "-n", "80", "--no-pager"], timeout=30)
            return out or "Логи пока отсутствуют."
        return logs[0].read_text(encoding="utf-8", errors="replace")[-MAX_LOG:]
    script = scripts[action]
    if action == "restart" and not script.exists():
        stop = scripts["stop"]
        start = scripts["start"]
        if not stop.exists() or not start.exists():
            raise FileNotFoundError("Для restart нужны start.sh и stop.sh")
        for candidate in (stop, start):
            candidate.chmod(candidate.stat().st_mode | 0o111)
        rc, out = run_command(["bash", str(stop)], cwd=project, timeout=120)
        if rc == 0:
            rc, out2 = run_command(["bash", str(start)], cwd=project, timeout=120)
            out += "\n" + out2
    else:
        if not script.exists():
            raise FileNotFoundError(f"В проекте нет {script.name}")
        script.chmod(script.stat().st_mode | 0o111)
        rc, out = run_command(["bash", str(script)], cwd=project, timeout=120)
    if rc != 0:
        raise RuntimeError(out or f"{action} завершился с ошибкой")
    return out or f"{action}: OK"


def server_status() -> str:
    du = shutil.disk_usage(ROOT)
    try:
        load = os.getloadavg()[0]
    except OSError:
        load = 0.0
    return (
        f"CPU load: {load:.2f}\n"
        f"RAM: {memory_text()}\n"
        f"Disk free: {du.free / 1024**3:.1f} GB / {du.total / 1024**3:.1f} GB"
    )


def memory_text() -> str:
    try:
        data = Path("/proc/meminfo").read_text().splitlines()
        vals = {line.split(":",1)[0]: int(line.split()[1]) for line in data if ":" in line}
        total = vals.get("MemTotal", 0)
        avail = vals.get("MemAvailable", 0)
        return f"{(total-avail)/1024**2:.1f} / {total/1024**2:.1f} GB"
    except Exception:
        return "n/a"


class TelegramManager:
    def __init__(self) -> None:
        ensure_dirs()
        self.offset = 0
        self.pending: dict[int, tuple[str, str]] = {}

    def call(self, method: str, **params):
        data = urllib.parse.urlencode(params).encode()
        req = urllib.request.Request(API.format(token(), method), data=data)
        with urllib.request.urlopen(req, timeout=70) as r:
            return json.loads(r.read().decode())

    def send(self, chat_id: int, text: str, reply_markup: Optional[dict] = None) -> None:
        params = {"chat_id": chat_id, "text": text}
        if reply_markup:
            params["reply_markup"] = json.dumps(reply_markup, ensure_ascii=False)
        self.call("sendMessage", **params)

    def allowed(self, chat_id: int) -> bool:
        return chat_id == admin_id()

    def keyboard(self):
        return {"inline_keyboard": [
            [{"text":"📦 Проекты", "callback_data":"projects"}, {"text":"📊 Сервер", "callback_data":"server"}],
            [{"text":"📥 Установить", "callback_data":"install"}],
        ]}

    def project_keyboard(self, name: str):
        return {"inline_keyboard": [
            [{"text":"▶️ Запустить", "callback_data":f"act:{name}:start"}, {"text":"⏹ Остановить", "callback_data":f"act:{name}:stop"}],
            [{"text":"🔄 Перезапустить", "callback_data":f"act:{name}:restart"}, {"text":"📊 Статус", "callback_data":f"act:{name}:status"}],
            [{"text":"📜 Логи", "callback_data":f"act:{name}:logs"}],
            [{"text":"🔄 Обновить", "callback_data":f"update:{name}"}, {"text":"🗑 Удалить", "callback_data":f"delete:{name}"}],
            [{"text":"◀️ Назад", "callback_data":"projects"}],
        ]}

    def handle_message(self, msg: dict) -> None:
        chat = msg.get("chat", {}).get("id")
        if not isinstance(chat, int) or not self.allowed(chat):
            return
        text = (msg.get("text") or "").strip()
        if chat in self.pending:
            kind, extra = self.pending.pop(chat)
            if kind == "install_name":
                try:
                    name = validate_name(text)
                    self.pending[chat] = ("install_url", name)
                    self.send(chat, "🔗 Теперь отправь GitHub-ссылку на ZIP/репозиторий.")
                except Exception as e:
                    self.send(chat, f"❌ {e}")
                return
            if kind == "update_url":
                self.pending[chat] = ("update_confirm", json.dumps({"name":extra,"url":text}, ensure_ascii=False))
                self.send(chat, f"⚠️ Проект {extra} будет остановлен, обновлён и снова установлен. Продолжить?", {"inline_keyboard":[[{"text":"✅ Обновить", "callback_data":"update_yes"},{"text":"❌ Нет", "callback_data":"update_no"}]]})
                return
            if kind == "install_url":
                self.pending[chat] = ("install_confirm", json.dumps({"name":extra,"url":text}, ensure_ascii=False))
                self.send(chat, f"⚠️ Будет скачан и запущен код из:\n{text}\n\nПроект: {extra}\n\nПодтвердить?", {"inline_keyboard":[[{"text":"✅ Да", "callback_data":"install_yes"},{"text":"❌ Нет", "callback_data":"install_no"}]]})
                return
        if text in {"/start", "/menu"}:
            self.send(chat, "🛠 HATE Ubuntu Manager\n\nВыбери действие:", self.keyboard())
        elif text == "/status":
            self.send(chat, server_status())
        elif text == "/projects":
            self.send_projects(chat)
        else:
            self.send(chat, "Не понял команду. Нажми /menu")

    def send_projects(self, chat: int) -> None:
        names = project_list()
        if not names:
            self.send(chat, "📦 Проектов пока нет.")
            return
        buttons = [[{"text": f"📦 {n} — {service_status(n)}", "callback_data":f"project:{n}"}] for n in names]
        self.send(chat, "Установленные проекты:", {"inline_keyboard": buttons})

    def callback(self, q: dict) -> None:
        chat = q.get("message", {}).get("chat", {}).get("id")
        if not isinstance(chat, int) or not self.allowed(chat): return
        data = q.get("data", "")
        try:
            self.call("answerCallbackQuery", callback_query_id=q.get("id", ""))
        except Exception: pass
        if data == "projects": self.send_projects(chat)
        elif data == "server": self.send(chat, server_status())
        elif data == "install":
            self.pending[chat] = ("install_name", "")
            self.send(chat, "📦 Введи имя проекта (латиница, цифры, _, -):")
        elif data.startswith("project:"):
            name = data.split(":",1)[1]
            self.send(chat, f"📦 {name}\nСтатус: {service_status(name)}", self.project_keyboard(name))
        elif data.startswith("act:"):
            _, name, action = data.split(":",2)
            try:
                out = project_action(name, action)
                self.send(chat, f"{name} / {action}\n\n{out[-MAX_LOG:]}", self.project_keyboard(name))
            except Exception as e: self.send(chat, f"❌ {e}")
        elif data.startswith("update:"):
            name = data.split(":",1)[1]
            self.pending[chat] = ("update_url", name)
            self.send(chat, f"🔗 Отправь новую GitHub-ссылку для обновления {name}:")
        elif data.startswith("delete:"):
            name = data.split(":",1)[1]
            self.pending[chat] = ("delete_confirm", name)
            self.send(chat, f"⚠️ Удалить проект {name} и его файлы?", {"inline_keyboard":[[{"text":"🗑 Да, удалить", "callback_data":"delete_yes"},{"text":"❌ Нет", "callback_data":"delete_no"}]]})
        elif data == "delete_yes":
            kind, name = self.pending.pop(chat, ("", ""))
            if kind != "delete_confirm": self.send(chat, "Сессия удаления истекла."); return
            try:
                delete_project(name)
                self.send(chat, f"🗑 {name} удалён.")
            except Exception as e: self.send(chat, f"❌ {e}")
        elif data == "delete_no":
            self.pending.pop(chat, None)
            self.send(chat, "Удаление отменено.")
        elif data == "update_yes":
            kind, payload = self.pending.pop(chat, ("", ""))
            if kind != "update_confirm": self.send(chat, "Сессия обновления истекла."); return
            spec = json.loads(payload)
            self.send(chat, "⏳ Обновление началось...")
            try:
                out = update_project(spec["name"], spec["url"])
                self.send(chat, f"✅ {spec['name']} обновлён.\n\n{out[-MAX_LOG:]}")
            except Exception as e: self.send(chat, f"❌ Обновление не удалось:\n{e}")
        elif data == "update_no":
            self.pending.pop(chat, None)
            self.send(chat, "Обновление отменено.")
        elif data == "install_yes":
            kind, payload = self.pending.pop(chat, ("", ""))
            if kind != "install_confirm": self.send(chat, "Сессия установки истекла."); return
            spec = json.loads(payload)
            self.send(chat, "⏳ Установка началась. Это может занять несколько минут...")
            try:
                out = install_project(spec["name"], spec["url"])
                self.send(chat, f"✅ {spec['name']} установлен.\n\n{out[-MAX_LOG:]}")
            except Exception as e: self.send(chat, f"❌ Установка не удалась:\n{e}")
        elif data == "install_no":
            self.pending.pop(chat, None)
            self.send(chat, "❌ Установка отменена.")

    def run(self) -> None:
        print("HATE Ubuntu Manager started", flush=True)
        while True:
            try:
                result = self.call("getUpdates", offset=self.offset, timeout=25)
                for update in result.get("result", []):
                    self.offset = update["update_id"] + 1
                    if "callback_query" in update: self.callback(update["callback_query"])
                    elif "message" in update: self.handle_message(update["message"])
            except KeyboardInterrupt:
                return
            except Exception as e:
                print(f"manager polling error: {e}", flush=True)
                time.sleep(3)


if __name__ == "__main__":
    TelegramManager().run()
