from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "manager"
PROJECTS = ROOT / "data" / "managed_projects"
TOKEN_FILE = DATA / "token"
ADMIN_FILE = DATA / "admin_id"

# The values below are defaults requested for this deployment. They are copied
# to local files on first install and can then be changed without editing code.
DEFAULT_MANAGER_TOKEN = "8522666040:AAHZh3nk1LwtfT917Vi2sudVg_bbetgM2JA"
DEFAULT_ADMIN_ID = "5554369191"


def ensure_dirs() -> None:
    DATA.mkdir(parents=True, exist_ok=True)
    PROJECTS.mkdir(parents=True, exist_ok=True)


def _read_or_default(path: Path, default: str) -> str:
    try:
        value = path.read_text(encoding="utf-8").strip()
        if value:
            return value
    except OSError:
        pass
    path.write_text(default + "\n", encoding="utf-8")
    try:
        path.chmod(0o600)
    except OSError:
        pass
    return default


def token() -> str:
    ensure_dirs()
    return os.environ.get("HATE_MANAGER_TOKEN", _read_or_default(TOKEN_FILE, DEFAULT_MANAGER_TOKEN))


def admin_id() -> int:
    ensure_dirs()
    raw = os.environ.get("HATE_MANAGER_ADMIN_ID", _read_or_default(ADMIN_FILE, DEFAULT_ADMIN_ID))
    return int(raw)
