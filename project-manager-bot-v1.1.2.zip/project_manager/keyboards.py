from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup


def menu_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📦 Мои проекты", callback_data="projects")],
        [InlineKeyboardButton(text="➕ Добавить проект", callback_data="add")],
        [InlineKeyboardButton(text="⚙️ Менеджер", callback_data="manager")],
    ])


def manager_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔄 Обновить менеджер", callback_data="manager_update")],
        [InlineKeyboardButton(text="📦 Версии и откат", callback_data="manager_versions")],
        [InlineKeyboardButton(text="⬅️ Меню", callback_data="menu")],
    ])


def manager_versions_kb(versions: list[str], current: str) -> InlineKeyboardMarkup:
    rows = []
    for version in versions:
        icon = "🟢" if version == current else "⚪"
        rows.append([InlineKeyboardButton(text=f"{icon} {version}", callback_data=f"manager_rollback:{version}")])
    rows.append([InlineKeyboardButton(text="⬅️ Менеджер", callback_data="manager")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def manager_rollback_confirm_kb(version: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="↩️ Да, откатить", callback_data=f"manager_rollback_yes:{version}")],
        [InlineKeyboardButton(text="Отмена", callback_data="manager")],
    ])


def source_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📁 ZIP", callback_data="add_zip")],
        [InlineKeyboardButton(text="🐙 GitHub", callback_data="add_github")],
        [InlineKeyboardButton(text="⬅️ Назад", callback_data="menu")],
    ])


def project_list_kb(projects) -> InlineKeyboardMarkup:
    rows = []
    for p in projects:
        rows.append([InlineKeyboardButton(text=f"📦 {p.name}", callback_data=f"project:{p.id}")])
    rows.append([InlineKeyboardButton(text="➕ Добавить", callback_data="add")])
    rows.append([InlineKeyboardButton(text="⬅️ Меню", callback_data="menu")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def project_kb(project_id: int, running: bool, can_edit_command: bool = False) -> InlineKeyboardMarkup:
    first = [
        InlineKeyboardButton(text="⏹ Остановить", callback_data=f"stop:{project_id}"),
        InlineKeyboardButton(text="🔄 Перезапустить", callback_data=f"restart:{project_id}"),
    ] if running else [
        InlineKeyboardButton(text="▶️ Запустить", callback_data=f"start:{project_id}"),
        InlineKeyboardButton(text="🔄 Перезапустить", callback_data=f"restart:{project_id}"),
    ]
    rows = [
        first,
        [InlineKeyboardButton(text="📋 Логи", callback_data=f"logs:{project_id}")],
        [InlineKeyboardButton(text="🔄 Обновить GitHub", callback_data=f"update:{project_id}")],
    ]
    if can_edit_command:
        rows.append([InlineKeyboardButton(text="📝 Команда запуска", callback_data=f"command:{project_id}")])
    rows.extend([
        [InlineKeyboardButton(text="✏️ Переименовать", callback_data=f"rename:{project_id}")],
        [InlineKeyboardButton(text="🗑 Удалить", callback_data=f"delete:{project_id}")],
        [InlineKeyboardButton(text="⬅️ Проекты", callback_data="projects")],
    ])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def delete_confirm_kb(project_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🗑 Да, удалить", callback_data=f"delete_yes:{project_id}")],
        [InlineKeyboardButton(text="Отмена", callback_data=f"project:{project_id}")],
    ])
