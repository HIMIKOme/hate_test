from __future__ import annotations

import json
import os
import re
import shutil
import time
from pathlib import Path
from uuid import uuid4

from .config import MANAGER_RELEASES_META_DIR, ROOT_DIR, UPDATE_QUEUE_DIR, UPDATE_STATUS_DIR

VERSION_RE = re.compile(r"^v?(\d+)\.(\d+)\.(\d+)$")


def _parse_version(value: str) -> tuple[int, int, int]:
    match = VERSION_RE.match(value.strip())
    if not match:
        raise ValueError(f"Некорректная версия: {value}")
    return tuple(int(x) for x in match.groups())


def normalize_version(value: str) -> str:
    major, minor, patch = _parse_version(value)
    return f"v{major}.{minor}.{patch}"


def bump_patch(value: str) -> str:
    major, minor, patch = _parse_version(value)
    return f"v{major}.{minor}.{patch + 1}"


def current_version() -> str:
    # In production the package is loaded through /opt/project-manager/current,
    # and Path.resolve() makes ROOT_DIR point at the concrete release directory.
    # Therefore the release directory name is the authoritative running version.
    if VERSION_RE.match(ROOT_DIR.name):
        return normalize_version(ROOT_DIR.name)

    # Source-tree fallback (development/tests).
    try:
        from . import __version__
        return normalize_version(__version__)
    except Exception:
        return "v1.1.0"


def releases() -> list[str]:
    items: list[str] = []
    if MANAGER_RELEASES_META_DIR.exists():
        for p in MANAGER_RELEASES_META_DIR.iterdir():
            if p.is_dir() and VERSION_RE.match(p.name):
                items.append(normalize_version(p.name))
    if not items:
        items = [current_version()]
    return sorted(set(items), key=_parse_version, reverse=True)


def request_update(archive: Path) -> str:
    request_id = uuid4().hex
    request_zip = UPDATE_QUEUE_DIR / "request.zip"
    request_json = UPDATE_QUEUE_DIR / "request.json"
    tmp_zip = UPDATE_QUEUE_DIR / f".{request_id}.zip.tmp"
    tmp_json = UPDATE_QUEUE_DIR / f".{request_id}.json.tmp"

    if request_json.exists():
        raise RuntimeError("Другое обновление менеджера уже ожидает обработки.")
    shutil.copy2(archive, tmp_zip)
    os.replace(tmp_zip, request_zip)
    archive.unlink(missing_ok=True)
    payload = {
        "id": request_id,
        "type": "update",
        "archive": str(request_zip),
        "created_at": time.time(),
    }
    tmp_json.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp_json, request_json)
    return request_id


def request_rollback(version: str) -> str:
    target = normalize_version(version)
    request_id = uuid4().hex
    request_json = UPDATE_QUEUE_DIR / "request.json"
    if request_json.exists():
        raise RuntimeError("Другой запрос на изменение версии менеджера уже ожидает обработки.")
    payload = {
        "id": request_id,
        "type": "rollback",
        "version": target,
        "created_at": time.time(),
    }
    tmp_json = UPDATE_QUEUE_DIR / f".{request_id}.json.tmp"
    tmp_json.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp_json, request_json)
    return request_id


def pending_result() -> dict | None:
    path = UPDATE_STATUS_DIR / "pending.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def consume_pending_result() -> dict | None:
    path = UPDATE_STATUS_DIR / "pending.json"
    if not path.exists():
        return None
    try:
        result = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    consumed = UPDATE_STATUS_DIR / "last.json"
    try:
        os.replace(path, consumed)
    except OSError:
        return None
    return result
