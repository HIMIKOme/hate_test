from __future__ import annotations

import os
import shutil
import stat
import zipfile
from pathlib import Path

from .utils import safe_relpath


class ArchiveError(ValueError):
    pass


def extract_zip(archive: Path, destination: Path, *, max_unpacked_bytes: int) -> Path:
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as zf:
        infos = zf.infolist()
        if len(infos) > 5000:
            raise ArchiveError("В архиве слишком много файлов (максимум 5000).")

        total_size = 0
        for info in infos:
            if not safe_relpath(info.filename):
                raise ArchiveError(f"Небезопасный путь в архиве: {info.filename}")
            total_size += max(0, info.file_size)
            if total_size > max_unpacked_bytes:
                raise ArchiveError("Распакованный размер архива превышает установленный лимит.")

            mode = (info.external_attr >> 16) & 0o170000
            if mode == stat.S_IFLNK:
                raise ArchiveError(f"Символические ссылки в ZIP запрещены: {info.filename}")

        for info in infos:
            target = destination / info.filename
            target.parent.mkdir(parents=True, exist_ok=True)
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            with zf.open(info, "r") as src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst, length=1024 * 1024)

    entries = [p for p in destination.iterdir() if p.name not in {"__MACOSX"}]
    if len(entries) == 1 and entries[0].is_dir():
        inner = entries[0]
        temp = destination.with_name(destination.name + "_root")
        if temp.exists():
            shutil.rmtree(temp)
        inner.rename(temp)
        for item in temp.iterdir():
            item.rename(destination / item.name)
        temp.rmdir()

    return destination
