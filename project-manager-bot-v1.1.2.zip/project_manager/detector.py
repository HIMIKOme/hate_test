from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Detection:
    mode: str  # container | compose
    runtime: str  # dockerfile | python | node
    start_command: str | None
    dockerfile: Path | None = None
    compose_file: Path | None = None


def detect_project(root: Path) -> Detection:
    for name in ("compose.yml", "compose.yaml", "docker-compose.yml", "docker-compose.yaml"):
        path = root / name
        if path.exists():
            return Detection("compose", "compose", None, compose_file=path)

    dockerfile = root / "Dockerfile"
    if dockerfile.exists():
        return Detection("container", "dockerfile", None, dockerfile=dockerfile)

    package = root / "package.json"
    if package.exists():
        try:
            data = json.loads(package.read_text(encoding="utf-8"))
        except Exception:
            data = {}
        scripts = data.get("scripts") or {}
        command = "npm start" if "start" in scripts else None
        if command:
            return Detection("container", "node", command)

    py_files = ["main.py", "bot.py", "app.py", "run.py"]
    if any((root / f).exists() for f in py_files) or any(
        (root / f).exists() for f in ("requirements.txt", "pyproject.toml", "setup.py")
    ):
        entry = next((f for f in py_files if (root / f).exists()), None)
        return Detection("container", "python", f"python {entry}" if entry else "python main.py")

    # Most user's projects are Python. We intentionally choose a Python base
    # image as the fallback and ask for a command after the first deployment error.
    return Detection("container", "python", "python main.py")
