from __future__ import annotations

import asyncio
import shutil
import tempfile
from pathlib import Path
from uuid import uuid4

from aiogram import Bot, Dispatcher, F, Router
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Document, Message

from .archive import extract_zip
from .config import PROJECTS_DIR, UPDATE_QUEUE_DIR, Settings
from .db import Database, Project
from .detector import detect_project
from .docker_manager import build_and_start, docker_available, logs, remove, restart, start, status, stop
from .github import clone_public_repo, is_github_url, normalize_github_url
from .keyboards import (
    delete_confirm_kb,
    manager_kb,
    manager_rollback_confirm_kb,
    manager_versions_kb,
    menu_kb,
    project_kb,
    project_list_kb,
    source_kb,
)
from .release_manager import consume_pending_result, current_version, pending_result, releases, request_rollback, request_update
from .utils import clamp_text, escape_html, slugify, unique_slug


router = Router()
op_lock = asyncio.Lock()


class AddStates(StatesGroup):
    waiting_zip = State()
    waiting_zip_name = State()
    waiting_github_url = State()
    waiting_github_name = State()
    waiting_rename = State()
    waiting_command = State()
    waiting_manager_zip = State()


class App:
    def __init__(self, db: Database, settings: Settings):
        self.db = db
        self.settings = settings

    def project_text(self, project: Project) -> str:
        state = status(project)
        icon = {"running": "🟢", "starting": "🟡", "stopped": "🔴"}.get(state, "⚪")
        source = "GitHub" if project.source_type == "github" else "ZIP"
        runtime = project.runtime
        return (
            f"📦 <b>{escape_html(project.name)}</b>\n\n"
            f"Статус: {icon} <b>{state}</b>\n"
            f"Источник: {source}\n"
            f"Среда: {runtime}\n"
            f"Путь: <code>{escape_html(project.path)}</code>"
        )

    async def deploy(self, project: Project, detection) -> None:
        await asyncio.to_thread(build_and_start, project, detection, self.settings.operation_timeout)

    async def update_github(self, project: Project) -> Path:
        """Download a new GitHub tree and swap it into place, retaining an old-tree backup.

        The caller is responsible for removing the returned backup only after the new
        project has successfully rebuilt and started.
        """
        tmp = Path(tempfile.mkdtemp(prefix="pm-update-"))
        try:
            clone_target = tmp / "repo"
            await asyncio.to_thread(clone_public_repo, project.source, clone_target, self.settings.operation_timeout)
            live = Path(project.path)
            backup = live.parent / f".{live.name}.backup-{uuid4().hex[:8]}"
            if live.exists():
                live.rename(backup)
            try:
                clone_target.rename(live)
            except Exception:
                if live.exists():
                    shutil.rmtree(live, ignore_errors=True)
                if backup.exists():
                    backup.rename(live)
                raise
            return backup
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


APP: App


def manager_text() -> str:
    current = current_version()
    version_list = releases()
    return (
        "🤖 <b>Менеджер</b>\n\n"
        f"Текущая версия: <b>{escape_html(current)}</b>\n"
        f"Сохранено версий: <b>{len(version_list)}</b>\n\n"
        "Обновление устанавливается отдельно, проверяется перед переключением и при проблеме автоматически откатывается назад."
    )


async def notify_pending_results(bot: Bot, settings: Settings) -> None:
    while True:
        try:
            result = pending_result()
            if result:
                text = str(result.get("message") or "Операция с менеджером завершена.")
                await bot.send_message(settings.admin_id, text, parse_mode="HTML")
                consume_pending_result()
        except Exception:
            pass
        await asyncio.sleep(2)


def configure(app: App, dp: Dispatcher, settings: Settings) -> None:
    global APP
    APP = app
    router.message.filter(F.from_user.id == settings.admin_id)
    router.callback_query.filter(F.from_user.id == settings.admin_id)

    async def safe_edit(callback: CallbackQuery, text: str, markup=None):
        try:
            await callback.message.edit_text(text, reply_markup=markup, parse_mode="HTML")
        except Exception:
            await callback.message.answer(text, reply_markup=markup, parse_mode="HTML")

    @router.message(CommandStart())
    @router.message(Command("menu"))
    async def cmd_start(message: Message):
        if not docker_available():
            await message.answer("⚠️ Docker недоступен. Проверь состояние службы Docker на сервере.")
            return
        await message.answer("🤖 <b>Project Manager</b>\n\nВыбери действие:", reply_markup=menu_kb(), parse_mode="HTML")

    @router.message(Command("version"))
    async def cmd_version(message: Message):
        await message.answer(manager_text(), parse_mode="HTML", reply_markup=manager_kb())

    @router.callback_query(F.data == "menu")
    async def cb_menu(callback: CallbackQuery):
        await callback.answer()
        await safe_edit(callback, "🤖 <b>Project Manager</b>\n\nВыбери действие:", menu_kb())

    @router.callback_query(F.data == "manager")
    async def cb_manager(callback: CallbackQuery):
        await callback.answer()
        await safe_edit(callback, manager_text(), manager_kb())

    @router.callback_query(F.data == "manager_versions")
    async def cb_manager_versions(callback: CallbackQuery):
        await callback.answer()
        versions = releases()
        await safe_edit(
            callback,
            "📦 <b>Версии менеджера</b>\n\n🟢 — текущая версия\n⚪ — доступная для отката",
            manager_versions_kb(versions, current_version()),
        )

    @router.callback_query(F.data.startswith("manager_rollback:"))
    async def cb_manager_rollback(callback: CallbackQuery):
        await callback.answer()
        target = callback.data.split(":", 1)[1]
        if target == current_version():
            await callback.message.answer("ℹ️ Эта версия уже установлена.")
            return
        await safe_edit(
            callback,
            f"⚠️ <b>Откатить менеджер на {escape_html(target)}?</b>\n\nТекущая версия будет остановлена, новая текущая версия удалена из active, а выбранная версия будет восстановлена. Сохранённые проекты Docker не затрагиваются.",
            manager_rollback_confirm_kb(target),
        )

    @router.callback_query(F.data.startswith("manager_rollback_yes:"))
    async def cb_manager_rollback_yes(callback: CallbackQuery):
        await callback.answer("Откат запланирован")
        target = callback.data.split(":", 1)[1]
        try:
            request_rollback(target)
            await safe_edit(
                callback,
                f"⏳ <b>Откат на {escape_html(target)} запланирован.</b>\n\nМенеджер сам остановится, переключится на сохранённую версию, проверит запуск и при необходимости попробует восстановить резервную копию базы.",
                manager_kb(),
            )
        except Exception as exc:
            await safe_edit(callback, f"❌ Не удалось создать запрос на откат:\n<pre>{escape_html(clamp_text(str(exc)))}</pre>", manager_kb())

    @router.callback_query(F.data == "manager_update")
    async def cb_manager_update(callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        await state.set_state(AddStates.waiting_manager_zip)
        await safe_edit(
            callback,
            "🔄 <b>Обновление менеджера</b>\n\nОтправь новый ZIP-архив именно <b>самого Project Manager</b>.\n\nТекущая версия останется нетронутой, пока новый архив не пройдёт проверки.",
        )

    @router.message(AddStates.waiting_manager_zip, F.document)
    async def receive_manager_zip(message: Message, state: FSMContext, bot: Bot):
        document: Document = message.document
        name = (document.file_name or "").lower()
        if not name.endswith(".zip"):
            await message.answer("❌ Нужен именно ZIP-архив.")
            return
        if document.file_size and document.file_size > settings.max_zip_bytes:
            await message.answer(f"❌ Архив слишком большой. Сейчас лимит: {settings.max_zip_mb} МБ.")
            return

        tmp = Path(tempfile.mkdtemp(prefix="pm-manager-update-"))
        archive = tmp / "manager.zip"
        try:
            file = await bot.get_file(document.file_id)
            await bot.download_file(file.file_path, destination=archive)
            request_id = request_update(archive)
            await state.clear()
            await message.answer(
                "✅ <b>Архив получен.</b>\n\n"
                f"Запрос: <code>{request_id[:12]}</code>\n"
                f"Текущая версия: <b>{escape_html(current_version())}</b>\n\n"
                "Менеджер сохранит резервную копию, автоматически определит следующую версию, проверит новый код и только потом переключится на него. При сбое выполнится rollback.",
                parse_mode="HTML",
            )
        except Exception as exc:
            await message.answer(f"❌ Не удалось принять архив:\n<pre>{escape_html(clamp_text(str(exc)))}</pre>", parse_mode="HTML")
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    @router.callback_query(F.data == "projects")
    async def cb_projects(callback: CallbackQuery):
        await callback.answer()
        projects = app.db.list_projects()
        if not projects:
            await safe_edit(callback, "📦 Проектов пока нет.", project_list_kb([]))
            return
        lines = ["📦 <b>Мои проекты</b>"]
        for p in projects:
            icon = "🟢" if status(p) == "running" else "🔴"
            lines.append(f"{icon} {escape_html(p.name)}")
        await safe_edit(callback, "\n".join(lines), project_list_kb(projects))

    @router.callback_query(F.data == "add")
    async def cb_add(callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        await state.clear()
        await safe_edit(callback, "➕ <b>Добавление проекта</b>\n\nВыбери источник:", source_kb())

    @router.callback_query(F.data == "add_zip")
    async def cb_add_zip(callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        await state.set_state(AddStates.waiting_zip)
        await safe_edit(callback, f"📁 Отправь ZIP-архив одним сообщением.\n\nМаксимум через обычный Telegram Bot API: {settings.max_zip_mb} МБ.")

    @router.message(AddStates.waiting_zip, F.document)
    async def receive_zip(message: Message, state: FSMContext, bot: Bot):
        document: Document = message.document
        name = (document.file_name or "").lower()
        if not name.endswith(".zip"):
            await message.answer("❌ Нужен именно ZIP-архив.")
            return
        if document.file_size and document.file_size > settings.max_zip_bytes:
            await message.answer(f"❌ Архив слишком большой. Сейчас лимит: {settings.max_zip_mb} МБ.")
            return

        tmp = Path(tempfile.mkdtemp(prefix="pm-upload-"))
        archive = tmp / "project.zip"
        try:
            file = await bot.get_file(document.file_id)
            await bot.download_file(file.file_path, destination=archive)
        except Exception as exc:
            shutil.rmtree(tmp, ignore_errors=True)
            await message.answer(f"❌ Не удалось скачать файл: <code>{escape_html(clamp_text(str(exc), 1500))}</code>", parse_mode="HTML")
            return

        await state.update_data(upload_tmp=str(tmp), archive=str(archive))
        await state.set_state(AddStates.waiting_zip_name)
        await message.answer("✅ Архив получен.\n\nТеперь отправь <b>название проекта</b> одним сообщением.", parse_mode="HTML")

    @router.message(AddStates.waiting_zip_name, F.text)
    async def zip_name(message: Message, state: FSMContext):
        name = message.text.strip()
        if not 1 <= len(name) <= 80:
            await message.answer("❌ Название должно быть от 1 до 80 символов.")
            return
        data = await state.get_data()
        tmp = Path(data["upload_tmp"])
        archive = Path(data["archive"])
        await state.clear()
        await message.answer("⏳ Создаю проект, распаковываю архив и готовлю Docker...")
        async with op_lock:
            path = None
            placeholder = None
            try:
                existing = {p.slug for p in app.db.list_projects()}
                slug = unique_slug(slugify(name), existing)
                path = PROJECTS_DIR / slug
                extract_zip(archive, path, max_unpacked_bytes=settings.max_unpacked_bytes)
                detection = detect_project(path)
                container_name = f"pm-{slug}"
                image_name = f"pm-{slug}:latest"
                compose_project = f"pm-{slug}"
                placeholder = Project(
                    id=0, name=name, slug=slug, source_type="zip", source="telegram", path=str(path),
                    mode=detection.mode, runtime=detection.runtime, start_command=detection.start_command,
                    container_name=container_name, image_name=image_name if detection.mode == "container" else None,
                    compose_project=compose_project if detection.mode == "compose" else None, created_at="",
                )
                try:
                    await app.deploy(placeholder, detection)
                except Exception:
                    try:
                        await asyncio.to_thread(remove, placeholder, settings.operation_timeout)
                    except Exception:
                        pass
                    raise
                project = app.db.add_project(
                    name=name, slug=slug, source_type="zip", source="telegram", path=str(path),
                    mode=detection.mode, runtime=detection.runtime, start_command=detection.start_command,
                    container_name=container_name, image_name=image_name if detection.mode == "container" else None,
                    compose_project=compose_project if detection.mode == "compose" else None,
                )
                await message.answer(f"✅ <b>{escape_html(project.name)}</b> добавлен и запущен.\n\n{app.project_text(project)}", parse_mode="HTML", reply_markup=project_kb(project.id, True, project.mode == "container" and project.runtime in {"python", "node"}))
            except Exception as exc:
                if path is not None:
                    shutil.rmtree(path, ignore_errors=True)
                await message.answer(f"❌ Не удалось добавить проект.\n\n<pre>{escape_html(clamp_text(str(exc)))}</pre>", parse_mode="HTML")
            finally:
                shutil.rmtree(tmp, ignore_errors=True)

    @router.callback_query(F.data == "add_github")
    async def cb_add_github(callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        await state.set_state(AddStates.waiting_github_url)
        await safe_edit(callback, "🐙 Отправь публичную GitHub-ссылку.\n\nНапример:\n<code>https://github.com/user/project</code>")

    @router.message(AddStates.waiting_github_url, F.text)
    async def github_url(message: Message, state: FSMContext):
        url = message.text.strip()
        if not is_github_url(url):
            await message.answer("❌ Нужна публичная HTTPS-ссылка вида https://github.com/user/repository")
            return
        await state.update_data(github_url=normalize_github_url(url))
        await state.set_state(AddStates.waiting_github_name)
        await message.answer("✅ Ссылка принята.\n\nТеперь отправь <b>название проекта</b>.", parse_mode="HTML")

    @router.message(AddStates.waiting_github_name, F.text)
    async def github_name(message: Message, state: FSMContext):
        name = message.text.strip()
        if not 1 <= len(name) <= 80:
            await message.answer("❌ Название должно быть от 1 до 80 символов.")
            return
        data = await state.get_data()
        await state.clear()
        await message.answer("⏳ Клонирую GitHub и запускаю проект через Docker...")
        async with op_lock:
            path = None
            project = None
            try:
                existing = {p.slug for p in app.db.list_projects()}
                slug = unique_slug(slugify(name), existing)
                path = PROJECTS_DIR / slug
                await asyncio.to_thread(clone_public_repo, data["github_url"], path, settings.operation_timeout)
                detection = detect_project(path)
                container_name = f"pm-{slug}"
                image_name = f"pm-{slug}:latest"
                compose_project = f"pm-{slug}"
                project = app.db.add_project(
                    name=name, slug=slug, source_type="github", source=data["github_url"], path=str(path),
                    mode=detection.mode, runtime=detection.runtime, start_command=detection.start_command,
                    container_name=container_name, image_name=image_name if detection.mode == "container" else None,
                    compose_project=compose_project if detection.mode == "compose" else None,
                )
                try:
                    await app.deploy(project, detection)
                except Exception:
                    try:
                        await asyncio.to_thread(remove, project, settings.operation_timeout)
                    except Exception:
                        pass
                    app.db.delete_project(project.id)
                    shutil.rmtree(path, ignore_errors=True)
                    raise
                await message.answer(f"✅ <b>{escape_html(project.name)}</b> добавлен и запущен.\n\n{app.project_text(project)}", parse_mode="HTML", reply_markup=project_kb(project.id, True, project.mode == "container" and project.runtime in {"python", "node"}))
            except Exception as exc:
                if path is not None:
                    shutil.rmtree(path, ignore_errors=True)
                await message.answer(f"❌ Не удалось добавить проект.\n\n<pre>{escape_html(clamp_text(str(exc)))}</pre>", parse_mode="HTML")

    @router.callback_query(F.data.startswith("project:"))
    async def cb_project(callback: CallbackQuery):
        await callback.answer()
        project_id = int(callback.data.split(":")[1])
        project = app.db.get_project(project_id)
        running = status(project) == "running"
        await safe_edit(callback, app.project_text(project), project_kb(project.id, running, project.mode == "container" and project.runtime in {"python", "node"}))

    @router.callback_query(F.data.startswith("start:"))
    async def cb_start(callback: CallbackQuery):
        await callback.answer("Запускаю...")
        project = app.db.get_project(int(callback.data.split(":")[1]))
        async with op_lock:
            try:
                await asyncio.to_thread(start, project, settings.operation_timeout)
                await safe_edit(callback, app.project_text(project), project_kb(project.id, True, project.mode == "container" and project.runtime in {"python", "node"}))
            except Exception as exc:
                await safe_edit(callback, f"❌ <b>Ошибка запуска</b>\n\n<pre>{escape_html(clamp_text(str(exc)))}</pre>", project_kb(project.id, False, project.mode == "container" and project.runtime in {"python", "node"}))

    @router.callback_query(F.data.startswith("stop:"))
    async def cb_stop(callback: CallbackQuery):
        await callback.answer("Останавливаю...")
        project = app.db.get_project(int(callback.data.split(":")[1]))
        async with op_lock:
            await asyncio.to_thread(stop, project, settings.operation_timeout)
        await safe_edit(callback, app.project_text(project), project_kb(project.id, False, project.mode == "container" and project.runtime in {"python", "node"}))

    @router.callback_query(F.data.startswith("restart:"))
    async def cb_restart(callback: CallbackQuery):
        await callback.answer("Перезапускаю...")
        project = app.db.get_project(int(callback.data.split(":")[1]))
        async with op_lock:
            try:
                detection = detect_project(Path(project.path))
                if detection.mode == "container" and project.runtime == detection.runtime and project.start_command:
                    detection.start_command = project.start_command
                await asyncio.to_thread(restart, project, detection, settings.operation_timeout)
                await safe_edit(callback, app.project_text(project), project_kb(project.id, True, project.mode == "container" and project.runtime in {"python", "node"}))
            except Exception as exc:
                await safe_edit(callback, f"❌ <b>Ошибка перезапуска</b>\n\n<pre>{escape_html(clamp_text(str(exc)))}</pre>", project_kb(project.id, False, project.mode == "container" and project.runtime in {"python", "node"}))

    @router.callback_query(F.data.startswith("logs:"))
    async def cb_logs(callback: CallbackQuery):
        await callback.answer()
        project = app.db.get_project(int(callback.data.split(":")[1]))
        try:
            output = await asyncio.to_thread(logs, project, settings.log_tail_lines)
            await callback.message.answer(f"📋 <b>Логи: {escape_html(project.name)}</b>\n\n<pre>{escape_html(clamp_text(output, 7000))}</pre>", parse_mode="HTML")
        except Exception as exc:
            await callback.message.answer(f"❌ Не удалось получить логи:\n<pre>{escape_html(clamp_text(str(exc)))}</pre>", parse_mode="HTML")

    @router.callback_query(F.data.startswith("command:"))
    async def cb_command(callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        project_id = int(callback.data.split(":")[1])
        project = app.db.get_project(project_id)
        if project.mode != "container" or project.runtime not in {"python", "node"}:
            await callback.message.answer("ℹ️ Для этого проекта команда запуска задаётся внутри Dockerfile.")
            return
        await state.set_state(AddStates.waiting_command)
        await state.update_data(command_project_id=project_id)
        current = escape_html(project.start_command or "не задана")
        await callback.message.answer(f"📝 Текущая команда:\n<code>{current}</code>\n\nОтправь новую команду. Она будет выполнена в контейнере.", parse_mode="HTML")

    @router.message(AddStates.waiting_command, F.text)
    async def command(message: Message, state: FSMContext):
        command_text = message.text.strip()
        if not 1 <= len(command_text) <= 300:
            await message.answer("❌ Команда должна быть от 1 до 300 символов.")
            return
        data = await state.get_data()
        await state.clear()
        project = app.db.get_project(int(data["command_project_id"]))
        app.db.update_start_command(project.id, command_text)
        project = app.db.get_project(project.id)
        await message.answer("⏳ Команда сохранена. Пересобираю и перезапускаю проект...")
        async with op_lock:
            try:
                detection = detect_project(Path(project.path))
                if detection.mode == "container" and project.runtime == detection.runtime:
                    detection.start_command = project.start_command
                await asyncio.to_thread(restart, project, detection, settings.operation_timeout)
                project = app.db.get_project(project.id)
                await message.answer(f"✅ Команда обновлена.\n\n{app.project_text(project)}", parse_mode="HTML", reply_markup=project_kb(project.id, True, True))
            except Exception as exc:
                await message.answer(f"❌ Не удалось применить команду.\n\n<pre>{escape_html(clamp_text(str(exc)))}</pre>", parse_mode="HTML")

    @router.callback_query(F.data.startswith("rename:"))
    async def cb_rename(callback: CallbackQuery, state: FSMContext):
        await callback.answer()
        project_id = int(callback.data.split(":")[1])
        await state.set_state(AddStates.waiting_rename)
        await state.update_data(rename_project_id=project_id)
        await callback.message.answer("✏️ Отправь новое название проекта.")

    @router.message(AddStates.waiting_rename, F.text)
    async def rename(message: Message, state: FSMContext):
        name = message.text.strip()
        if not 1 <= len(name) <= 80:
            await message.answer("❌ Название должно быть от 1 до 80 символов.")
            return
        data = await state.get_data()
        await state.clear()
        project = app.db.get_project(int(data["rename_project_id"]))
        app.db.rename_project(project.id, name)
        project = app.db.get_project(project.id)
        await message.answer(f"✅ Проект переименован.\n\n{app.project_text(project)}", parse_mode="HTML", reply_markup=project_kb(project.id, status(project) == "running", project.mode == "container" and project.runtime in {"python", "node"}))

    @router.callback_query(F.data.startswith("delete:"))
    async def cb_delete(callback: CallbackQuery):
        await callback.answer()
        project = app.db.get_project(int(callback.data.split(":")[1]))
        await safe_edit(callback, f"⚠️ <b>Удалить «{escape_html(project.name)}»?</b>\n\nБудут удалены контейнер и файлы проекта. Для Compose будут удалены тома проекта.", delete_confirm_kb(project.id))

    @router.callback_query(F.data.startswith("delete_yes:"))
    async def cb_delete_yes(callback: CallbackQuery):
        await callback.answer("Удаляю...")
        project = app.db.get_project(int(callback.data.split(":")[1]))
        async with op_lock:
            try:
                await asyncio.to_thread(remove, project, settings.operation_timeout)
                shutil.rmtree(project.path, ignore_errors=True)
                app.db.delete_project(project.id)
                await safe_edit(callback, f"✅ Проект <b>{escape_html(project.name)}</b> удалён.", project_list_kb(app.db.list_projects()))
            except Exception as exc:
                await safe_edit(callback, f"❌ Не удалось полностью удалить проект.\n\n<pre>{escape_html(clamp_text(str(exc)))}</pre>", project_kb(project.id, status(project) == "running", project.mode == "container" and project.runtime in {"python", "node"}))

    @router.callback_query(F.data.startswith("update:"))
    async def cb_update(callback: CallbackQuery):
        await callback.answer("Обновляю...")
        project = app.db.get_project(int(callback.data.split(":")[1]))
        if project.source_type != "github":
            await callback.message.answer("ℹ️ Для ZIP-проектов обновление через GitHub недоступно.")
            return
        async with op_lock:
            backup = None
            old_runtime = {
                "mode": project.mode,
                "runtime": project.runtime,
                "start_command": project.start_command,
                "image_name": project.image_name,
                "compose_project": project.compose_project,
                "source": project.source,
            }
            try:
                await asyncio.to_thread(stop, project, settings.operation_timeout)
                backup = await app.update_github(project)
                detection = detect_project(Path(project.path))
                if detection.mode == "container" and project.runtime == detection.runtime and project.start_command:
                    detection.start_command = project.start_command
                image_name = project.image_name if detection.mode == "container" else None
                compose_project = project.compose_project if detection.mode == "compose" else None
                app.db.update_runtime(
                    project.id, mode=detection.mode, runtime=detection.runtime, start_command=detection.start_command,
                    image_name=image_name, compose_project=compose_project, source=project.source,
                )
                project = app.db.get_project(project.id)
                await asyncio.to_thread(restart, project, detection, settings.operation_timeout)
                if backup and backup.exists():
                    shutil.rmtree(backup, ignore_errors=True)
                    backup = None
                project = app.db.get_project(project.id)
                await safe_edit(callback, f"✅ <b>{escape_html(project.name)}</b> обновлён и запущен.\n\n{app.project_text(project)}", project_kb(project.id, True, project.mode == "container" and project.runtime in {"python", "node"}))
            except Exception as exc:
                restore_error = None
                if backup and backup.exists():
                    try:
                        failed_project = app.db.get_project(project.id)
                        await asyncio.to_thread(stop, failed_project, settings.operation_timeout)
                        live = Path(failed_project.path)
                        if live.exists():
                            shutil.rmtree(live, ignore_errors=True)
                        backup.rename(live)
                        app.db.update_runtime(project.id, **old_runtime)
                        restored_project = app.db.get_project(project.id)
                        restored_detection = detect_project(live)
                        if restored_detection.mode == "container" and restored_project.start_command:
                            restored_detection.start_command = restored_project.start_command
                        await asyncio.to_thread(restart, restored_project, restored_detection, settings.operation_timeout)
                        restore_error = "Старая версия проекта восстановлена и запущена."
                    except Exception as restore_exc:
                        restore_error = f"НЕ УДАЛОСЬ восстановить старую версию: {restore_exc}"
                if restore_error:
                    message_text = f"❌ <b>Ошибка обновления</b>\n\n<pre>{escape_html(clamp_text(str(exc)))}</pre>\n\n⚠️ {escape_html(restore_error)}"
                else:
                    message_text = f"❌ <b>Ошибка обновления</b>\n\n<pre>{escape_html(clamp_text(str(exc)))}</pre>"
                try:
                    restored = app.db.get_project(project.id)
                    running = status(restored) == "running"
                    markup = project_kb(restored.id, running, restored.mode == "container" and restored.runtime in {"python", "node"})
                except Exception:
                    markup = None
                await safe_edit(callback, message_text, markup)

    dp.include_router(router)
