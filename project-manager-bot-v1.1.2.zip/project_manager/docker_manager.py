from __future__ import annotations

import re
import shlex
import subprocess
import time
from pathlib import Path

from .db import Project
from .detector import Detection
from .utils import clamp_text


class DockerError(RuntimeError):
    pass


def _run(cmd: list[str], *, cwd: Path | None = None, timeout: int = 1800) -> str:
    result = subprocess.run(
        cmd,
        cwd=str(cwd) if cwd else None,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    output = (result.stdout or "") + ("\n" + result.stderr if result.stderr else "")
    output = output.strip()
    if result.returncode != 0:
        raise DockerError(clamp_text(output or f"Команда завершилась с кодом {result.returncode}"))
    return output


def docker_available() -> bool:
    try:
        _run(["docker", "info"], timeout=20)
        return True
    except Exception:
        return False


def write_generated_dockerfile(root: Path, runtime: str, command: str | None) -> Path:
    path = root / "Dockerfile.manager"
    if runtime == "node":
        lines = [
            "FROM node:24-bookworm-slim",
            "WORKDIR /app",
            "ENV NODE_ENV=production",
            "COPY package*.json ./",
            "RUN if [ -f package-lock.json ]; then npm ci --omit=dev; else npm install --omit=dev; fi",
            "COPY . .",
            f'CMD [{json_quote_command(command or "npm start")}]',
        ]
    else:
        lines = [
            "FROM python:3.13-slim",
            "WORKDIR /app",
            "ENV PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1 PIP_DISABLE_PIP_VERSION_CHECK=1",
            "COPY . .",
            "RUN if [ -f requirements.txt ]; then pip install --no-cache-dir -r requirements.txt; fi",
            "RUN if [ -f pyproject.toml ] || [ -f setup.py ]; then pip install --no-cache-dir .; fi",
            f'CMD [{json_quote_command(command or "python main.py")}]',
        ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def json_quote_command(command: str) -> str:
    parts = shlex.split(command)
    if not parts:
        parts = ["python", "main.py"]
    escaped = ", ".join('"' + p.replace('\\', '\\\\').replace('"', '\\"') + '"' for p in parts)
    return escaped


def build_and_start(project: Project, detection: Detection, timeout: int) -> None:
    root = Path(project.path)
    if project.mode == "compose":
        _run(["docker", "compose", "-p", project.compose_project or project.slug, "up", "-d", "--build"], cwd=root, timeout=timeout)
        wait_until_running(project)
        return

    dockerfile = detection.dockerfile
    if dockerfile is None or dockerfile.name == "Dockerfile.manager":
        dockerfile = write_generated_dockerfile(root, detection.runtime, project.start_command)

    _run(
        ["docker", "build", "-f", dockerfile.name, "-t", project.image_name or f"pm-{project.slug}:latest", "."],
        cwd=root,
        timeout=timeout,
    )
    try:
        _run(["docker", "rm", "-f", project.container_name], timeout=60)
    except Exception:
        pass
    _run(
        [
            "docker", "run", "-d",
            "--name", project.container_name,
            "--restart", "no",
            "--label", f"project-manager.project={project.slug}",
            project.image_name or f"pm-{project.slug}:latest",
        ],
        cwd=root,
        timeout=120,
    )
    wait_until_running(project)


def wait_until_running(project: Project, seconds: int = 2) -> None:
    time.sleep(seconds)
    if status(project) == "running":
        return
    try:
        tail = logs(project, 80)
    except Exception:
        tail = "(не удалось получить логи)"
    raise DockerError("Контейнер запустился и сразу завершился.\n\n" + tail)


def start(project: Project, timeout: int) -> None:
    if project.mode == "compose":
        _run(["docker", "compose", "-p", project.compose_project or project.slug, "up", "-d"], cwd=Path(project.path), timeout=timeout)
        wait_until_running(project)
        return
    try:
        _run(["docker", "start", project.container_name], timeout=120)
    except DockerError:
        raise DockerError("Контейнер ещё не существует. Выполни «🔄 Перезапустить» для повторной сборки проекта.")
    wait_until_running(project)


def stop(project: Project, timeout: int) -> None:
    if project.mode == "compose":
        _run(["docker", "compose", "-p", project.compose_project or project.slug, "stop"], cwd=Path(project.path), timeout=timeout)
        return
    try:
        _run(["docker", "stop", project.container_name], timeout=120)
    except DockerError:
        pass


def restart(project: Project, detection: Detection, timeout: int) -> None:
    if project.mode == "compose":
        _run(["docker", "compose", "-p", project.compose_project or project.slug, "down"], cwd=Path(project.path), timeout=timeout)
        build_and_start(project, detection, timeout)
        return

    try:
        _run(["docker", "rm", "-f", project.container_name], timeout=120)
    except DockerError:
        pass
    build_and_start(project, detection, timeout)


def status(project: Project) -> str:
    if project.mode == "compose":
        try:
            out = _run(["docker", "compose", "-p", project.compose_project or project.slug, "ps", "-q"], cwd=Path(project.path), timeout=60)
            ids = [x.strip() for x in out.splitlines() if x.strip()]
            if not ids:
                return "stopped"
            inspect = _run(["docker", "inspect", "--format", "{{.State.Status}}"] + ids, timeout=60)
            states = {x.strip() for x in inspect.splitlines()}
            if "running" in states:
                return "running"
            if states & {"created", "restarting", "paused"}:
                return "starting"
            return "stopped"
        except Exception:
            return "stopped"

    try:
        out = _run(["docker", "inspect", "--format", "{{.State.Status}}", project.container_name], timeout=30)
        state = out.strip()
        if state == "running":
            return "running"
        if state in {"created", "restarting", "paused"}:
            return "starting"
        return "stopped"
    except Exception:
        return "stopped"


def logs(project: Project, tail_lines: int) -> str:
    if project.mode == "compose":
        out = _run(
            ["docker", "compose", "-p", project.compose_project or project.slug, "logs", "--no-color", "--tail", str(tail_lines)],
            cwd=Path(project.path),
            timeout=60,
        )
    else:
        out = _run(["docker", "logs", "--tail", str(tail_lines), project.container_name], timeout=60)
    return clamp_text(out or "(логи пустые)")


def remove(project: Project, timeout: int) -> None:
    if project.mode == "compose":
        _run(
            ["docker", "compose", "-p", project.compose_project or project.slug, "down", "--volumes", "--remove-orphans"],
            cwd=Path(project.path),
            timeout=timeout,
        )
        return
    try:
        _run(["docker", "rm", "-f", project.container_name], timeout=120)
    except Exception:
        pass
    if project.image_name:
        try:
            _run(["docker", "image", "rm", "-f", project.image_name], timeout=120)
        except Exception:
            pass
