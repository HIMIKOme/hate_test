from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path


@dataclass
class Project:
    id: int
    name: str
    slug: str
    source_type: str
    source: str
    path: str
    mode: str
    runtime: str
    start_command: str | None
    container_name: str
    image_name: str | None
    compose_project: str | None
    created_at: str


class Database:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS projects (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    slug TEXT NOT NULL UNIQUE,
                    source_type TEXT NOT NULL,
                    source TEXT NOT NULL,
                    path TEXT NOT NULL,
                    mode TEXT NOT NULL,
                    runtime TEXT NOT NULL,
                    start_command TEXT,
                    container_name TEXT NOT NULL,
                    image_name TEXT,
                    compose_project TEXT,
                    created_at TEXT NOT NULL
                )
                """
            )
            conn.commit()

    @staticmethod
    def _to_project(row: sqlite3.Row) -> Project:
        return Project(**dict(row))

    def add_project(
        self,
        *,
        name: str,
        slug: str,
        source_type: str,
        source: str,
        path: str,
        mode: str,
        runtime: str,
        start_command: str | None,
        container_name: str,
        image_name: str | None,
        compose_project: str | None,
    ) -> Project:
        now = datetime.now(timezone.utc).isoformat()
        with self._connect() as conn:
            cur = conn.execute(
                """
                INSERT INTO projects
                (name, slug, source_type, source, path, mode, runtime,
                 start_command, container_name, image_name, compose_project, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    name,
                    slug,
                    source_type,
                    source,
                    path,
                    mode,
                    runtime,
                    start_command,
                    container_name,
                    image_name,
                    compose_project,
                    now,
                ),
            )
            project_id = int(cur.lastrowid)
            conn.commit()
        return self.get_project(project_id)

    def get_project(self, project_id: int) -> Project:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM projects WHERE id = ?", (project_id,)).fetchone()
        if not row:
            raise KeyError(project_id)
        return self._to_project(row)

    def list_projects(self) -> list[Project]:
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM projects ORDER BY id ASC").fetchall()
        return [self._to_project(r) for r in rows]

    def update_start_command(self, project_id: int, command: str) -> None:
        with self._connect() as conn:
            conn.execute("UPDATE projects SET start_command = ? WHERE id = ?", (command, project_id))
            conn.commit()

    def rename_project(self, project_id: int, new_name: str) -> None:
        with self._connect() as conn:
            conn.execute("UPDATE projects SET name = ? WHERE id = ?", (new_name, project_id))
            conn.commit()

    def update_runtime(
        self, project_id: int, *, mode: str, runtime: str, start_command: str | None,
        image_name: str | None, compose_project: str | None, source: str | None = None
    ) -> None:
        with self._connect() as conn:
            if source is None:
                conn.execute(
                    "UPDATE projects SET mode=?, runtime=?, start_command=?, image_name=?, compose_project=? WHERE id=?",
                    (mode, runtime, start_command, image_name, compose_project, project_id),
                )
            else:
                conn.execute(
                    "UPDATE projects SET mode=?, runtime=?, start_command=?, image_name=?, compose_project=?, source=? WHERE id=?",
                    (mode, runtime, start_command, image_name, compose_project, source, project_id),
                )
            conn.commit()

    def delete_project(self, project_id: int) -> None:
        with self._connect() as conn:
            conn.execute("DELETE FROM projects WHERE id = ?", (project_id,))
            conn.commit()
