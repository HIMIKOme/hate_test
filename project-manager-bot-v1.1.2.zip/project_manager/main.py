from __future__ import annotations

import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from .bot import App, configure, notify_pending_results
from .config import DB_PATH, Settings, load_settings
from .db import Database
from .manager_health import clear_ready, mark_ready


async def main() -> None:
    settings: Settings = load_settings()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")

    db = Database(DB_PATH)
    app = App(db, settings)
    dp = Dispatcher()
    configure(app, dp, settings)

    bot = Bot(token=settings.bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    watcher = asyncio.create_task(notify_pending_results(bot, settings))
    try:
        await bot.delete_webhook(drop_pending_updates=True)
        await bot.get_me()
        mark_ready()
        await dp.start_polling(bot)
    finally:
        watcher.cancel()
        clear_ready()
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
