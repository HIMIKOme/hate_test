from __future__ import annotations

import html
import re
from pathlib import Path


RU_TRANSLIT = {
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "e",
    "ж": "zh", "з": "z", "и": "i", "й": "y", "к": "k", "л": "l", "м": "m",
    "н": "n", "о": "o", "п": "p", "р": "r", "с": "s", "т": "t", "у": "u",
    "ф": "f", "х": "h", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "sch", "ъ": "",
    "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya",
}


def slugify(value: str) -> str:
    text = value.strip().lower()
    text = "".join(RU_TRANSLIT.get(ch, ch) for ch in text)
    text = re.sub(r"[^a-z0-9]+", "-", text).strip("-")
    return text[:45] or "project"


def unique_slug(base: str, existing: set[str]) -> str:
    candidate = base
    i = 2
    while candidate in existing:
        candidate = f"{base}-{i}"
        i += 1
    return candidate


def safe_relpath(path: str) -> bool:
    p = Path(path)
    return not p.is_absolute() and ".." not in p.parts


def escape_html(text: str) -> str:
    return html.escape(text, quote=False)


def clamp_text(text: str, max_chars: int = 7000) -> str:
    if len(text) <= max_chars:
        return text
    return "…" + text[-max_chars:]
