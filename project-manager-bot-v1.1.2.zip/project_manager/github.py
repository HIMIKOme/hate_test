from __future__ import annotations

import re
import subprocess
from pathlib import Path


GITHUB_RE = re.compile(r"^https://github\.com/([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+?)(?:\.git)?/?$")


def normalize_github_url(url: str) -> str:
    url = url.strip()
    match = GITHUB_RE.match(url)
    if not match:
        raise ValueError("Нужна публичная HTTPS-ссылка вида https://github.com/user/repository")
    user, repo = match.groups()
    return f"https://github.com/{user}/{repo}.git"


def clone_public_repo(url: str, destination: Path, timeout: int) -> None:
    normalized = normalize_github_url(url)
    destination.parent.mkdir(parents=True, exist_ok=True)
    result = subprocess.run(
        ["git", "clone", "--depth", "1", normalized, str(destination)],
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    if result.returncode != 0:
        raise RuntimeError((result.stderr or result.stdout or "git clone failed").strip())


def is_github_url(url: str) -> bool:
    return GITHUB_RE.match(url.strip()) is not None
