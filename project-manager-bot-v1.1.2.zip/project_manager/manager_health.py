from __future__ import annotations

import json
import os
import time
from pathlib import Path

from .config import READY_FILE
from .release_manager import current_version


def mark_ready() -> None:
    READY_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = READY_FILE.with_suffix(".tmp")
    payload = {
        "version": current_version(),
        "pid": os.getpid(),
        "timestamp": time.time(),
    }
    tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, READY_FILE)


def clear_ready() -> None:
    try:
        READY_FILE.unlink()
    except FileNotFoundError:
        pass
