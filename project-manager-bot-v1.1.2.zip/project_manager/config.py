from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


ROOT_DIR = Path(__file__).resolve().parent.parent
DATA_ROOT = Path(os.environ.get("PROJECT_MANAGER_DATA_ROOT", "/var/lib/project-manager"))
DATA_DIR = DATA_ROOT / "data"
PROJECTS_DIR = DATA_ROOT / "projects"
UPDATE_QUEUE_DIR = DATA_ROOT / "update-queue"
UPDATE_STATUS_DIR = DATA_ROOT / "update-status"
MANAGER_RELEASES_META_DIR = DATA_ROOT / "manager-releases"
READY_FILE = DATA_ROOT / "manager-status" / "ready.json"

for _path in (DATA_DIR, PROJECTS_DIR, UPDATE_QUEUE_DIR, UPDATE_STATUS_DIR, MANAGER_RELEASES_META_DIR, READY_FILE.parent):
    _path.mkdir(parents=True, exist_ok=True)

DB_PATH = DATA_DIR / "projects.sqlite3"


@dataclass(frozen=True)
class Settings:
    bot_token: str
    admin_id: int
    max_zip_mb: int = 20
    max_unpacked_mb: int = 1000
    operation_timeout: int = 1800
    log_tail_lines: int = 150
    manager_health_timeout: int = 20

    @property
    def max_zip_bytes(self) -> int:
        return self.max_zip_mb * 1024 * 1024

    @property
    def max_unpacked_bytes(self) -> int:
        return self.max_unpacked_mb * 1024 * 1024


def load_settings() -> Settings:
    token = os.environ.get("BOT_TOKEN", "").strip()
    admin_id_raw = os.environ.get("ADMIN_ID", "").strip()
    if not token:
        raise RuntimeError("BOT_TOKEN is not set")
    if not admin_id_raw or not admin_id_raw.lstrip("-").isdigit():
        raise RuntimeError("ADMIN_ID must be a numeric Telegram user ID")

    return Settings(
        bot_token=token,
        admin_id=int(admin_id_raw),
        max_zip_mb=int(os.environ.get("MAX_ZIP_MB", "20")),
        max_unpacked_mb=int(os.environ.get("MAX_UNPACKED_MB", "1000")),
        operation_timeout=int(os.environ.get("OPERATION_TIMEOUT", "1800")),
        log_tail_lines=int(os.environ.get("LOG_TAIL_LINES", "150")),
        manager_health_timeout=int(os.environ.get("MANAGER_HEALTH_TIMEOUT", "20")),
    )
