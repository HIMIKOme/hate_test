from pathlib import Path

from project_manager.utils import safe_relpath, slugify, unique_slug


def test_slugify():
    assert slugify("Мой Telegram бот") == "moy-telegram-bot"
    assert slugify("hello world!") == "hello-world"


def test_unique_slug():
    assert unique_slug("bot", {"bot", "bot-2"}) == "bot-3"


def test_safe_relpath():
    assert safe_relpath("main.py")
    assert safe_relpath("foo/bar.py")
    assert not safe_relpath("../evil")
    assert not safe_relpath("/absolute/path")


def test_compose_remove_propagates_errors(monkeypatch, tmp_path):
    import project_manager.docker_manager as dm
    from project_manager.db import Project
    def fail(*args, **kwargs):
        raise dm.DockerError("compose failed")
    monkeypatch.setattr(dm, "_run", fail)
    project = Project(0, "x", "x", "zip", "telegram", str(tmp_path), "compose", "compose", None, "pm-x", None, "pm-x", "")
    import pytest
    with pytest.raises(dm.DockerError, match="compose failed"):
        dm.remove(project, 10)
