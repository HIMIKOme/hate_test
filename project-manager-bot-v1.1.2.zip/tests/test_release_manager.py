from pathlib import Path

from project_manager.release_manager import bump_patch, normalize_version


def test_bump_patch():
    assert bump_patch("v1.0.0") == "v1.0.1"
    assert bump_patch("1.2.9") == "v1.2.10"


def test_normalize_version():
    assert normalize_version("1.3.4") == "v1.3.4"


def test_current_version_from_release_directory(monkeypatch):
    import project_manager.release_manager as rm
    monkeypatch.setattr(rm, "ROOT_DIR", Path("/opt/project-manager/releases/v9.8.7"))
    assert rm.current_version() == "v9.8.7"
