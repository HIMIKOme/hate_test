from pathlib import Path
from zipfile import ZipFile

import pytest

from project_manager.archive import ArchiveError, extract_zip


def test_zip_extract(tmp_path: Path):
    archive = tmp_path / "ok.zip"
    dest = tmp_path / "dest"
    with ZipFile(archive, "w") as zf:
        zf.writestr("folder/main.py", "print('ok')")
        zf.writestr("folder/requirements.txt", "")
    out = extract_zip(archive, dest, max_unpacked_bytes=1024 * 1024)
    assert (out / "main.py").exists()


def test_zip_path_traversal(tmp_path: Path):
    archive = tmp_path / "bad.zip"
    dest = tmp_path / "dest"
    with ZipFile(archive, "w") as zf:
        zf.writestr("../evil.txt", "bad")
    with pytest.raises(ArchiveError):
        extract_zip(archive, dest, max_unpacked_bytes=1024 * 1024)
