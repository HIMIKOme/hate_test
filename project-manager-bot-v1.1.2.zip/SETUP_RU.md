# Установка Project Manager на Ubuntu Server

После публикации репозитория на GitHub на сервере нужен только этот набор действий:

```bash
git clone https://github.com/ВАШ_ЛОГИН/project-manager-bot.git
cd project-manager-bot
sudo bash install.sh
```

Во время установки скрипт попросит:

1. токен Telegram-бота;
2. твой Telegram user ID.

После этого открой бота и отправь:

```text
/start
```

или:

```text
/version
```

## Самое важное после первой установки

Для изменения **самого Project Manager** командная строка больше не нужна.

В Telegram:

`⚙️ Менеджер` → `🔄 Обновить менеджер` → отправить новый ZIP.

Менеджер автоматически:

- назначит следующую patch-версию;
- сохранит предыдущую версию;
- сохранит исходный ZIP нового релиза;
- сохранит backup базы;
- проверит новый код до установки;
- переключится на новый release;
- проверит, что бот реально запустился;
- при проблеме вернёт предыдущую версию автоматически.

## Ручной rollback

В Telegram:

`⚙️ Менеджер` → `📦 Версии и откат` → выбрать сохранённую версию → `↩️ Да, откатить`.

При необходимости система дополнительно попробует восстановить совместимую backup-копию базы данных.

## Где что хранится

```text
/opt/project-manager/releases/          # код релизов менеджера
/opt/project-manager/current            # текущая версия (symlink)
/usr/local/lib/project-manager/         # стабильный bootstrap updater
/var/lib/project-manager/.env           # секреты
/var/lib/project-manager/data/          # база менеджера
/var/lib/project-manager/projects/     # проекты пользователя
/var/lib/project-manager/manager-releases/ # ZIP архивы релизов и metadata
```

Токен не нужно помещать в GitHub.


### Токен Telegram

Не добавляй токен в GitHub и не прописывай его в исходниках. При первой установке `install.sh` попросит токен скрытым вводом и сохранит его в защищённом файле `/var/lib/project-manager/.env`. При обновлении менеджера через Telegram токен и остальные настройки сохраняются.
