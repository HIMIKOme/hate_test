#!/usr/bin/env bash
set -euo pipefail

CURRENT="/opt/project-manager/current"

if [[ ! -L "$CURRENT" ]]; then
  echo "Текущая версия менеджера не найдена: $CURRENT" >&2
  exit 1
fi

RELEASE="$(readlink -f "$CURRENT")"
PYTHON="$RELEASE/venv/bin/python"

if [[ ! -x "$PYTHON" ]]; then
  echo "Python окружение текущей версии не найдено: $PYTHON" >&2
  exit 1
fi

cd "$CURRENT"
exec "$PYTHON" -m project_manager.main
