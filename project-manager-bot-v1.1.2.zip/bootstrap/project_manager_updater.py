#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import html
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

APP_ROOT = Path("/opt/project-manager")
RELEASES_DIR = APP_ROOT / "releases"
CURRENT = APP_ROOT / "current"
DATA_ROOT = Path("/var/lib/project-manager")
DB_PATH = DATA_ROOT / "data" / "projects.sqlite3"
QUEUE_DIR = DATA_ROOT / "update-queue"
STATUS_DIR = DATA_ROOT / "update-status"
META_DIR = DATA_ROOT / "manager-releases"
READY_FILE = DATA_ROOT / "manager-status" / "ready.json"
LOCK_FILE = DATA_ROOT / "manager-update.lock"
SERVICE = "project-manager.service"
KEEP_RELEASES = 5
HEALTH_TIMEOUT = 20
MAX_FILES = 5000
MAX_UNPACKED_BYTES = 1000 * 1024 * 1024
VERSION_RE = re.compile(r"^v(\d+)\.(\d+)\.(\d+)$")


def run(cmd: list[str], timeout: int = 1800, *, cwd: Path | None = None, env: dict[str, str] | None = None) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, cwd=str(cwd) if cwd else None, env=env, capture_output=True, text=True, timeout=timeout)


def run_checked(cmd: list[str], timeout: int = 1800, *, cwd: Path | None = None, env: dict[str, str] | None = None) -> str:
    result = run(cmd, timeout, cwd=cwd, env=env)
    output = ((result.stdout or "") + ("\n" + result.stderr if result.stderr else "")).strip()
    if result.returncode != 0:
        raise RuntimeError(output or f"Команда завершилась с кодом {result.returncode}: {' '.join(cmd)}")
    return output


def version_tuple(value: str) -> tuple[int, int, int]:
    match = VERSION_RE.match(value)
    if not match:
        raise ValueError(f"Некорректная версия: {value}")
    return tuple(map(int, match.groups()))


def current_version() -> str:
    if not CURRENT.exists():
        raise RuntimeError("Символическая ссылка current отсутствует.")
    target = CURRENT.resolve()
    if target.parent != RELEASES_DIR:
        raise RuntimeError(f"current указывает вне releases: {target}")
    if not VERSION_RE.match(target.name):
        raise RuntimeError(f"Некорректное имя текущего релиза: {target.name}")
    return target.name


def next_version(current: str) -> str:
    major, minor, patch = version_tuple(current)
    return f"v{major}.{minor}.{patch + 1}"


def list_versions() -> list[str]:
    result = []
    if RELEASES_DIR.exists():
        result.extend(p.name for p in RELEASES_DIR.iterdir() if p.is_dir() and VERSION_RE.match(p.name))
    return sorted(set(result), key=version_tuple, reverse=True)


def safe_extract(zip_path: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path) as zf:
        infos = zf.infolist()
        if len(infos) > MAX_FILES:
            raise RuntimeError(f"В архиве слишком много файлов (максимум {MAX_FILES}).")
        total = 0
        for info in infos:
            p = Path(info.filename)
            if p.is_absolute() or ".." in p.parts:
                raise RuntimeError(f"Небезопасный путь в архиве: {info.filename}")
            if not info.filename or info.filename.endswith("/"):
                continue
            total += max(0, info.file_size)
            if total > MAX_UNPACKED_BYTES:
                raise RuntimeError("Распакованный размер архива превышает 1000 МБ.")
            mode = (info.external_attr >> 16) & 0o170000
            if mode == 0o120000:
                raise RuntimeError(f"Символические ссылки в ZIP запрещены: {info.filename}")

        for info in infos:
            target = destination / info.filename
            target.parent.mkdir(parents=True, exist_ok=True)
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            with zf.open(info, "r") as src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst, 1024 * 1024)

    # Remove a single wrapping folder, like the normal project ZIP importer.
    entries = [p for p in destination.iterdir() if p.name != "__MACOSX"]
    if len(entries) == 1 and entries[0].is_dir():
        inner = entries[0]
        for item in list(inner.iterdir()):
            item.rename(destination / item.name)
        inner.rmdir()


def validate_release(root: Path) -> None:
    required = [root / "project_manager" / "main.py", root / "project_manager" / "bot.py"]
    missing = [str(p.relative_to(root)) for p in required if not p.is_file()]
    if missing:
        raise RuntimeError("Это не похоже на Project Manager. Не хватает: " + ", ".join(missing))
    requirements = root / "requirements.txt"
    if not requirements.is_file() and not (root / "pyproject.toml").is_file():
        raise RuntimeError("В новом менеджере нет requirements.txt или pyproject.toml.")


def install_environment(root: Path) -> Path:
    venv = root / "venv"
    run_checked(["/usr/bin/python3", "-m", "venv", str(venv)], timeout=180)
    pip = venv / "bin" / "pip"
    run_checked([str(pip), "install", "--no-input", "--disable-pip-version-check", "--upgrade", "pip"], timeout=600)
    requirements = root / "requirements.txt"
    if requirements.is_file():
        run_checked([str(pip), "install", "--no-input", "--disable-pip-version-check", "-r", str(requirements)], timeout=1200)
    elif (root / "pyproject.toml").is_file():
        run_checked([str(pip), "install", "--no-input", "--disable-pip-version-check", str(root)], timeout=1200)
    return venv / "bin" / "python"


def smoke_test(root: Path, python_bin: Path) -> None:
    temp_data = Path(tempfile.mkdtemp(prefix="pm-smoke-"))
    env = os.environ.copy()
    env["PROJECT_MANAGER_DATA_ROOT"] = str(temp_data)
    code = (
        "import project_manager.main; "
        "import project_manager.bot; "
        "import project_manager.db; "
        "import project_manager.config; "
        "from project_manager.db import Database; "
        "from project_manager.config import DB_PATH; "
        "Database(DB_PATH); print('PROJECT_MANAGER_SMOKE_OK')"
    )
    try:
        run_checked([str(python_bin), "-m", "compileall", "-q", "project_manager"], timeout=180, cwd=root, env=env)
        result = run([str(python_bin), "-c", code], timeout=180, cwd=root, env=env)
        output = ((result.stdout or "") + ("\n" + result.stderr if result.stderr else "")).strip()
        if result.returncode != 0 or "PROJECT_MANAGER_SMOKE_OK" not in output:
            raise RuntimeError(output or "Smoke-test не прошёл.")
    finally:
        shutil.rmtree(temp_data, ignore_errors=True)


def atomic_switch(version: str) -> None:
    target = RELEASES_DIR / version
    if not target.is_dir():
        raise RuntimeError(f"Релиз {version} не найден.")
    temp_link = APP_ROOT / ".current.next"
    try:
        if temp_link.exists() or temp_link.is_symlink():
            temp_link.unlink()
        temp_link.symlink_to(target)
        os.replace(temp_link, CURRENT)
    finally:
        if temp_link.exists() or temp_link.is_symlink():
            temp_link.unlink()


def clear_ready() -> None:
    try:
        READY_FILE.unlink()
    except FileNotFoundError:
        pass


def service_active() -> bool:
    return run(["/bin/systemctl", "is-active", "--quiet", SERVICE], timeout=10).returncode == 0


def service_main_pid() -> int:
    out = run_checked(["/bin/systemctl", "show", "-p", "MainPID", "--value", SERVICE], timeout=10).strip()
    try:
        return int(out)
    except ValueError:
        return 0


def health_check(expected_version: str, timeout: int = HEALTH_TIMEOUT) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if service_active() and READY_FILE.exists():
            try:
                payload = json.loads(READY_FILE.read_text(encoding="utf-8"))
                pid = int(payload.get("pid", 0))
                timestamp = float(payload.get("timestamp", 0))
                version = str(payload.get("version", ""))
                if version == expected_version and pid == service_main_pid() and pid > 0 and timestamp > 0:
                    return
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                pass
        time.sleep(1)
    raise RuntimeError(f"Менеджер не прошёл health-check за {timeout} секунд.")


def backup_database(destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if DB_PATH.exists():
        shutil.copy2(DB_PATH, destination)
    else:
        destination.write_bytes(b"")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def save_meta(version: str, payload: dict) -> None:
    path = META_DIR / version
    path.mkdir(parents=True, exist_ok=True)
    tmp = path / "meta.json.tmp"
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, path / "meta.json")


def write_result(request_id: str, ok: bool, message: str) -> None:
    STATUS_DIR.mkdir(parents=True, exist_ok=True)
    payload = {"id": request_id, "ok": ok, "message": message, "timestamp": time.time()}
    tmp = STATUS_DIR / "pending.json.tmp"
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, STATUS_DIR / "pending.json")


def find_db_backup_for_target(target: str) -> Path | None:
    versions = [v for v in list_versions() if version_tuple(v) > version_tuple(target)]
    for version in sorted(versions, key=version_tuple):
        candidate = META_DIR / version / "db_before.sqlite3"
        if candidate.is_file():
            return candidate
    return None


def restart_and_check(version: str) -> None:
    clear_ready()
    run_checked(["/bin/systemctl", "start", SERVICE], timeout=30)
    health_check(version)


def stop_manager() -> None:
    run_checked(["/bin/systemctl", "stop", SERVICE], timeout=60)


def delete_release(version: str) -> None:
    path = RELEASES_DIR / version
    if path.exists() or path.is_symlink():
        shutil.rmtree(path, ignore_errors=True)
    meta = META_DIR / version
    shutil.rmtree(meta, ignore_errors=True)


def prune_releases() -> None:
    versions = list_versions()
    keep = set(versions[:KEEP_RELEASES])
    current = current_version()
    keep.add(current)
    for version in versions:
        if version in keep:
            continue
        delete_release(version)


def restore_version(version: str, db_backup: Path | None = None) -> tuple[bool, str]:
    """Try to restore a version, first with the current DB, then with an optional DB backup."""
    last_error = ""
    try:
        try:
            stop_manager()
        except Exception:
            pass
        atomic_switch(version)
        clear_ready()
        restart_and_check(version)
        return True, ""
    except Exception as exc:
        last_error = str(exc)

    if db_backup and db_backup.is_file():
        try:
            try:
                stop_manager()
            except Exception:
                pass
            if DB_PATH.exists():
                emergency = DATA_ROOT / "database-emergency-before-db-restore.sqlite3"
                shutil.copy2(DB_PATH, emergency)
            shutil.copy2(db_backup, DB_PATH)
            atomic_switch(version)
            clear_ready()
            restart_and_check(version)
            return True, last_error
        except Exception as exc:
            last_error = f"{last_error}; после восстановления БД: {exc}"

    return False, last_error


def update_from_zip(request_id: str, archive: Path) -> None:
    old = current_version()
    new = next_version(old)
    if new in list_versions():
        delete_release(new)
    stage = RELEASES_DIR / f".staging-{new}-{request_id[:8]}"
    final = RELEASES_DIR / new
    meta = META_DIR / new
    db_backup: Path | None = None
    switched = False

    try:
        if stage.exists():
            shutil.rmtree(stage)
        stage.mkdir(parents=True, exist_ok=True)
        safe_extract(archive, stage)
        validate_release(stage)
        python_bin = install_environment(stage)
        smoke_test(stage, python_bin)

        if final.exists():
            shutil.rmtree(final)
        stage.rename(final)
        meta.mkdir(parents=True, exist_ok=True)
        shutil.copy2(archive, meta / "source.zip")

        stop_manager()
        db_backup = meta / "db_before.sqlite3"
        backup_database(db_backup)
        metadata = {
            "version": new,
            "previous_version": old,
            "created_at": time.time(),
            "sha256": sha256(archive),
            "status": "pending",
        }
        save_meta(new, metadata)
        atomic_switch(new)
        switched = True

        try:
            restart_and_check(new)
        except Exception as health_error:
            restored, restore_error = restore_version(old, db_backup=None)
            if restored:
                delete_release(new)
                write_result(
                    request_id,
                    False,
                    "❌ <b>Обновление менеджера отклонено автоматически.</b>\n\n"
                    f"Новая версия <b>{html.escape(new)}</b> не прошла health-check.\n"
                    f"Причина: <code>{html.escape(str(health_error))}</code>\n\n"
                    f"✅ Предыдущая версия <b>{html.escape(old)}</b> восстановлена. Пользовательские Docker-проекты не затрагивались.\n\n"
                    "Новый релиз удалён из установленных версий."
                )
                return

            restored_with_db, restore_db_error = restore_version(old, db_backup=db_backup)
            if restored_with_db:
                delete_release(new)
                write_result(
                    request_id,
                    False,
                    "❌ <b>Новая версия менеджера сломалась.</b>\n\n"
                    f"После health-check новая версия <b>{html.escape(new)}</b> была автоматически отключена.\n"
                    f"✅ Версия <b>{html.escape(old)}</b> восстановлена с резервной копией базы данных.\n\n"
                    f"Ошибка новой версии: <code>{html.escape(str(health_error))}</code>\n"
                    f"Проверка старой версии с текущей БД: <code>{html.escape(restore_error)}</code>\n"
                    f"Проверка после восстановления БД: <code>{html.escape(str(restore_db_error))}</code>"
                )
                return
            raise RuntimeError(
                f"Новая версия не прошла health-check: {health_error}; "
                f"не удалось вернуть старую версию: {restore_db_error}"
            )

        save_meta(new, {**metadata, "status": "active", "activated_at": time.time()})
        prune_releases()
        write_result(
            request_id,
            True,
            "✅ <b>Менеджер обновлён.</b>\n\n"
            f"Было: <b>{html.escape(old)}</b>\n"
            f"Стало: <b>{html.escape(new)}</b>\n\n"
            "✅ Новый код прошёл предварительный smoke-test.\n"
            "✅ Создан backup базы данных.\n"
            "✅ Выполнен health-check после перезапуска.\n"
            "✅ Предыдущие версии сохранены."
        )
    except Exception as exc:
        # No matter where the failure happened, make a best effort to leave the old release working.
        try:
            current = current_version()
        except Exception:
            current = old
        if current != old or not service_active():
            restored, restore_error = restore_version(old, db_backup=db_backup)
            if not restored:
                write_result(
                    request_id,
                    False,
                    "❌ <b>Критическая ошибка обновления менеджера.</b>\n\n"
                    f"Причина: <code>{html.escape(str(exc))}</code>\n"
                    f"Дополнительная ошибка восстановления: <code>{html.escape(restore_error)}</code>\n\n"
                    "⚠️ Требуется ручная проверка службы менеджера на сервере."
                )
                return
        if final.exists() and current_version() == old:
            delete_release(new)
        write_result(
            request_id,
            False,
            "❌ <b>Обновление менеджера не выполнено.</b>\n\n"
            f"Текущая версия <b>{html.escape(old)}</b> продолжает работать.\n"
            f"Причина: <code>{html.escape(str(exc))}</code>"
        )
    finally:
        try:
            archive.unlink()
        except FileNotFoundError:
            pass
        if stage.exists():
            shutil.rmtree(stage, ignore_errors=True)


def rollback_to(request_id: str, target: str) -> None:
    old = current_version()
    if target == old:
        write_result(request_id, True, f"ℹ️ <b>{html.escape(target)}</b> уже является текущей версией.")
        return
    if target not in list_versions() or not (RELEASES_DIR / target).is_dir():
        raise RuntimeError(f"Сохранённая версия {target} не найдена.")

    current_db_before = DATA_ROOT / f"db-before-rollback-{int(time.time())}.sqlite3"
    try:
        if DB_PATH.exists():
            shutil.copy2(DB_PATH, current_db_before)
        try:
            stop_manager()
        except Exception:
            pass
        atomic_switch(target)
        switched = True
        try:
            restart_and_check(target)
        except Exception as health_error:
            # Put the old version back first. Only try the target DB snapshot if needed.
            restored_old, old_error = restore_version(old, db_backup=None)
            if not restored_old:
                restored_old_with_db, old_db_error = restore_version(old, db_backup=find_db_backup_for_target(old))
                if not restored_old_with_db:
                    raise RuntimeError(f"Не удалось сохранить рабочую версию {old}: {old_db_error}")
            db_backup = find_db_backup_for_target(target)
            if db_backup:
                restored_target, target_error = restore_version(target, db_backup=db_backup)
                if restored_target:
                    write_result(
                        request_id,
                        True,
                        "↩️ <b>Откат менеджера выполнен.</b>\n\n"
                        f"Было: <b>{html.escape(old)}</b>\n"
                        f"Стало: <b>{html.escape(target)}</b>\n\n"
                        "✅ Версия не запустилась с текущей базой, поэтому был использован резервный snapshot БД."
                    )
                    return
            raise RuntimeError(f"Версия {target} не прошла health-check: {health_error}; восстановление старой версии: {old_error}")

        write_result(
            request_id,
            True,
            "↩️ <b>Откат менеджера выполнен.</b>\n\n"
            f"Было: <b>{html.escape(old)}</b>\n"
            f"Стало: <b>{html.escape(target)}</b>\n\n"
            "✅ Проверка запуска пройдена.\n"
            "✅ Docker-проекты пользователей не перезапускались."
        )
    except Exception as exc:
        try:
            current = current_version()
        except Exception:
            current = target
        if current != old or not service_active():
            restore_version(old, db_backup=find_db_backup_for_target(old))
        write_result(
            request_id,
            False,
            "❌ <b>Откат менеджера не выполнен.</b>\n\n"
            f"Текущая рабочая версия: <b>{html.escape(current_version())}</b>\n"
            f"Причина: <code>{html.escape(str(exc))}</code>"
        )
    finally:
        try:
            current_db_before.unlink()
        except FileNotFoundError:
            pass

def handle_request(payload: dict) -> None:
    request_id = str(payload.get("id") or "unknown")
    kind = str(payload.get("type") or "")
    if kind == "update":
        update_from_zip(request_id, Path(str(payload.get("archive") or QUEUE_DIR / "request.zip")))
    elif kind == "rollback":
        rollback_to(request_id, str(payload.get("version") or ""))
    else:
        raise RuntimeError("Неизвестный тип запроса.")


def main() -> int:
    DATA_ROOT.mkdir(parents=True, exist_ok=True)
    QUEUE_DIR.mkdir(parents=True, exist_ok=True)
    STATUS_DIR.mkdir(parents=True, exist_ok=True)
    META_DIR.mkdir(parents=True, exist_ok=True)
    RELEASES_DIR.mkdir(parents=True, exist_ok=True)

    request_json = QUEUE_DIR / "request.json"
    if not request_json.exists():
        return 0

    lock = None
    try:
        lock = open(LOCK_FILE, "a+")
        import fcntl
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except (BlockingIOError, OSError):
        if lock:
            lock.close()
        return 0

    try:
        payload = json.loads(request_json.read_text(encoding="utf-8"))
        request_json.unlink(missing_ok=True)
        handle_request(payload)
        return 0
    except Exception as exc:
        request_id = str(locals().get("payload", {}).get("id") or "unknown")
        write_result(
            request_id,
            False,
            "❌ <b>Операция с менеджером не выполнена.</b>\n\n"
            f"Ошибка: <code>{html.escape(str(exc))}</code>"
        )
        return 1
    finally:
        if lock:
            try:
                import fcntl
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
            except Exception:
                pass
            lock.close()


if __name__ == "__main__":
    raise SystemExit(main())
