#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/opt/project-manager"
RELEASES_DIR="$APP_DIR/releases"
CURRENT_LINK="$APP_DIR/current"
BOOTSTRAP_DIR="/usr/local/lib/project-manager"
DATA_ROOT="/var/lib/project-manager"
SERVICE="project-manager.service"
UPDATER_SERVICE="project-manager-updater.service"
UPDATER_PATH="project-manager-updater.path"
INITIAL_VERSION="v1.1.2"
SCRIPT_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"

if [[ "$(id -u)" -ne 0 ]]; then
  echo "Запусти так: sudo bash install.sh"
  exit 1
fi

if [[ -e "$CURRENT_LINK" || -L "$CURRENT_LINK" ]]; then
  echo "Project Manager уже установлен в $APP_DIR/current"
  echo "Для дальнейших обновлений используй Telegram → ⚙️ Менеджер → 🔄 Обновить менеджер."
  exit 0
fi

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y ca-certificates curl git python3 python3-venv python3-pip zip

if ! command -v docker >/dev/null 2>&1 || ! docker compose version >/dev/null 2>&1; then
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
  chmod a+r /etc/apt/keyrings/docker.asc
  cat >/etc/apt/sources.list.d/docker.sources <<SRC
Types: deb
URIs: https://download.docker.com/linux/ubuntu
Suites: $(. /etc/os-release && echo "${UBUNTU_CODENAME:-$VERSION_CODENAME}")
Components: stable
Architectures: $(dpkg --print-architecture)
Signed-By: /etc/apt/keyrings/docker.asc
SRC
  apt-get update
  apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
fi

systemctl enable --now docker

if ! id project-manager >/dev/null 2>&1; then
  useradd --system --home "$APP_DIR" --create-home --shell /usr/sbin/nologin project-manager
fi
usermod -aG docker project-manager

mkdir -p "$RELEASES_DIR" "$BOOTSTRAP_DIR" \
  "$DATA_ROOT/data" "$DATA_ROOT/projects" "$DATA_ROOT/update-queue" \
  "$DATA_ROOT/update-status" "$DATA_ROOT/manager-releases" "$DATA_ROOT/manager-status"

RELEASE_DIR="$RELEASES_DIR/$INITIAL_VERSION"
META_DIR="$DATA_ROOT/manager-releases/$INITIAL_VERSION"
mkdir -p "$RELEASE_DIR" "$META_DIR"

cp -a "$SCRIPT_DIR"/. "$RELEASE_DIR"/
rm -rf "$RELEASE_DIR/.git" "$RELEASE_DIR/.venv" "$RELEASE_DIR/venv" "$RELEASE_DIR/data" "$RELEASE_DIR/projects" "$RELEASE_DIR/__pycache__" "$RELEASE_DIR/project_manager/__pycache__" "$RELEASE_DIR/tests/__pycache__" 2>/dev/null || true

cp -f "$SCRIPT_DIR/bootstrap/manager_launcher.sh" "$BOOTSTRAP_DIR/manager_launcher.sh"
cp -f "$SCRIPT_DIR/bootstrap/project_manager_updater.py" "$BOOTSTRAP_DIR/project_manager_updater.py"
chmod 0755 "$BOOTSTRAP_DIR/manager_launcher.sh" "$BOOTSTRAP_DIR/project_manager_updater.py"

python3 -m venv "$RELEASE_DIR/venv"
"$RELEASE_DIR/venv/bin/pip" install --no-input --disable-pip-version-check --upgrade pip
"$RELEASE_DIR/venv/bin/pip" install --no-input --disable-pip-version-check -r "$RELEASE_DIR/requirements.txt"

cd "$SCRIPT_DIR"
zip -qr "$META_DIR/source.zip" . \
  -x '.git/*' '.venv/*' 'venv/*' '__pycache__/*' '*/__pycache__/*' 'data/*' 'projects/*' '.pytest_cache/*'

ln -s "$RELEASE_DIR" "$CURRENT_LINK"

cat >"$DATA_ROOT/.env" <<ENV
BOT_TOKEN=
ADMIN_ID=
MAX_ZIP_MB=20
MAX_UNPACKED_MB=1000
OPERATION_TIMEOUT=1800
LOG_TAIL_LINES=150
MANAGER_HEALTH_TIMEOUT=20
PROJECT_MANAGER_DATA_ROOT=$DATA_ROOT
ENV

cat >"$META_DIR/meta.json" <<META
{
  "version": "$INITIAL_VERSION",
  "previous_version": null,
  "status": "active",
  "installed_at": $(date +%s)
}
META

cat >"/etc/systemd/system/$SERVICE" <<'UNIT'
[Unit]
Description=Telegram Project Manager Bot
After=docker.service network-online.target
Requires=docker.service
Wants=network-online.target

[Service]
Type=simple
User=project-manager
Group=project-manager
SupplementaryGroups=docker
WorkingDirectory=/opt/project-manager/current
EnvironmentFile=/var/lib/project-manager/.env
ExecStart=/usr/local/lib/project-manager/manager_launcher.sh
Restart=on-failure
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
ProtectHome=true
ReadWritePaths=/var/lib/project-manager

[Install]
WantedBy=multi-user.target
UNIT

cp -f "$SCRIPT_DIR/systemd/project-manager-updater.service" "/etc/systemd/system/$UPDATER_SERVICE"
cp -f "$SCRIPT_DIR/systemd/project-manager-updater.path" "/etc/systemd/system/$UPDATER_PATH"

chown -R project-manager:project-manager "$DATA_ROOT" "$RELEASES_DIR"
chmod 700 "$DATA_ROOT/.env"
chmod 755 "$APP_DIR" "$RELEASES_DIR" "$RELEASE_DIR" "$BOOTSTRAP_DIR"
chmod 700 "$DATA_ROOT/projects" "$DATA_ROOT/data" "$DATA_ROOT/update-queue" "$DATA_ROOT/update-status" "$DATA_ROOT/manager-releases" "$DATA_ROOT/manager-status"

echo
echo "Настройка Telegram-бота"
echo "Токен не хранится в GitHub и не входит в ZIP релиза."
echo "При будущих обновлениях этот файл сохраняется."
echo

if [[ -z "${BOT_TOKEN:-}" ]]; then
  read -r -s -p "Вставь токен Telegram-бота: " BOT_TOKEN
  echo
fi
BOT_TOKEN="${BOT_TOKEN:-}"

if [[ -z "${ADMIN_ID:-}" ]]; then
  read -r -p "Вставь Telegram user ID администратора: " ADMIN_ID
fi
ADMIN_ID="${ADMIN_ID:-}"

python3 - "$DATA_ROOT/.env" "$BOT_TOKEN" "$ADMIN_ID" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
token = sys.argv[2].replace("\n", "").strip()
admin_id = sys.argv[3].replace("\n", "").strip()

if not token:
    raise SystemExit("BOT_TOKEN не указан.")
if not admin_id.lstrip("-").isdigit():
    raise SystemExit("ADMIN_ID должен быть числовым Telegram user ID.")

text = path.read_text()
text = text.replace("BOT_TOKEN=\n", f"BOT_TOKEN={token}\n")
text = text.replace("ADMIN_ID=\n", f"ADMIN_ID={admin_id}\n")
path.write_text(text)
PY

chown project-manager:project-manager "$DATA_ROOT/.env"
chmod 600 "$DATA_ROOT/.env"

systemctl daemon-reload
systemctl enable --now "$UPDATER_PATH"
systemctl enable --now "$SERVICE"

sleep 3
if systemctl is-active --quiet "$SERVICE"; then
  echo
  echo "✅ Project Manager установлен и запущен."
  echo "Открой Telegram-бота и отправь /start"
  echo
  echo "Версия: $INITIAL_VERSION"
  echo "Обновление менеджера после этого выполняется только из Telegram."
else
  echo
  echo "❌ Служба менеджера не запустилась."
  echo "Проверка: sudo journalctl -u $SERVICE -n 100 --no-pager"
  exit 1
fi
