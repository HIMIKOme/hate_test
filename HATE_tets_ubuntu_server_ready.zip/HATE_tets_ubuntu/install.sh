#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT/phase6work"

if [[ $EUID -ne 0 ]]; then
  echo "Запусти: sudo ./install.sh"
  exit 1
fi

apt-get update
apt-get install -y python3 python3-venv python3-pip chromium-browser || true
apt-get install -y chromium || true

python3 -m venv "$ROOT/venv"
"$ROOT/venv/bin/python" -m pip install --upgrade pip wheel
"$ROOT/venv/bin/pip" install -r requirements.txt

mkdir -p data/logs data/heartbeats data/answers
chown -R "${SUDO_USER:-root}:${SUDO_USER:-root}" "$ROOT" || true

SERVICE_USER="${SUDO_USER:-$USER}"
SERVICE_FILE="/etc/systemd/system/hate-tets.service"
cat > "$SERVICE_FILE" <<EOF
[Unit]
Description=HATE_tets Web Test Server
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$SERVICE_USER
WorkingDirectory=$ROOT/phase6work
Environment=PYTHONUNBUFFERED=1
ExecStart=$ROOT/venv/bin/python $ROOT/phase6work/main.py
Restart=always
RestartSec=5
TimeoutStopSec=30

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
if command -v ufw >/dev/null 2>&1; then
  ufw allow 8765/tcp || true
fi
systemctl enable --now hate-tets.service

echo
echo "HATE_tets установлен и запущен."
echo "Проверь: systemctl status hate-tets"
echo "Логи:   journalctl -u hate-tets -f"
