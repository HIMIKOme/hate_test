"""Логика автоматизации Selenium."""
from .base import TestAutomationError
from .runner import TestRunner

__all__ = ["TestRunner", "TestAutomationError"]