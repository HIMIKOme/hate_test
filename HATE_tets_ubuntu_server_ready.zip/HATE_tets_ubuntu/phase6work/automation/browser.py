"""Запуск Chrome с изолированной копией профиля.

Схема (v3):
  - В рамках процесса ровно ОДНО окно Chrome.
  - Окно НЕ сворачивается и НЕ закрывается между тестами.
  - close_all_browsers() вызывается при выходе из проекта или из
    веб-панели (кнопка «Стоп всё»).
"""
from __future__ import annotations

import os
import shutil
import tempfile
import threading
import time
from pathlib import Path
from typing import Optional

from selenium.webdriver.chrome.webdriver import WebDriver as ChromeWebDriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service


def _detect_chrome_user_data_dir() -> str:
    """Определяет папку Chrome автоматически под Windows / macOS / Linux.

    Возвращает путь-строку. Если папки нет ни в одном типовом месте —
    возвращает путь по умолчанию для текущей ОС (Chrome сам его создаст).
    """
    home = Path.home()

    if os.name == "nt":
        # Windows: %LOCALAPPDATA%\Google\Chrome\User Data
        local_app = os.environ.get("LOCALAPPDATA") or str(home / "AppData" / "Local")
        return str(Path(local_app) / "Google" / "Chrome" / "User Data")

    if sys.platform == "darwin":
        # macOS: ~/Library/Application Support/Google/Chrome
        return str(home / "Library" / "Application Support" / "Google" / "Chrome")

    # Linux: ~/.config/google-chrome
    return str(home / ".config" / "google-chrome")


import sys  # noqa: E402  (нужен для проверки sys.platform выше)

SOURCE_USER_DATA_DIR = _detect_chrome_user_data_dir()
SOURCE_PROFILE_DIR = "Default"

PROFILE_PREFIX = "HATE_tets_profile_"
MASTER_DIRNAME = "HATE_tets_profile_master"

MASTER_FILES = ("Preferences", "Secure Preferences", "Local State")


_lock = threading.Lock()
_driver: Optional[ChromeWebDriver] = None
_current_profile_dir: Optional[Path] = None
_last_use_time: float = 0.0


# ---------------------------------------------------------------------------
# Мастер-профиль
# ---------------------------------------------------------------------------

def _master_dir() -> Path:
    return Path(tempfile.gettempdir()) / MASTER_DIRNAME


def _ensure_master(logger) -> Path:
    master = _master_dir()
    source_user_data = Path(SOURCE_USER_DATA_DIR)
    source_default = source_user_data / SOURCE_PROFILE_DIR
    source_ext = source_default / "Extensions"

    if not source_ext.exists():
        raise RuntimeError(f"Папка расширений Chrome не найдена: {source_ext}")

    master_ext = master / SOURCE_PROFILE_DIR / "Extensions"

    need_update = True
    if master_ext.exists():
        try:
            if master_ext.stat().st_mtime >= source_ext.stat().st_mtime:
                need_update = False
        except OSError:
            pass

    if not need_update:
        return master

    logger.info("Обновляю мастер-профиль (расширения)...")
    if master.exists():
        shutil.rmtree(master, ignore_errors=True)
    (master / SOURCE_PROFILE_DIR).mkdir(parents=True, exist_ok=True)

    try:
        shutil.copytree(source_ext, master_ext, dirs_exist_ok=True)
    except (OSError, shutil.Error) as exc:
        logger.warning(f"Не удалось скопировать Extensions: {exc}")

    for name in MASTER_FILES:
        if name == "Local State":
            src = source_user_data / name
            dst = master / name
        else:
            src = source_default / name
            dst = master / SOURCE_PROFILE_DIR / name
        if src.exists():
            try:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
            except (OSError, shutil.Error) as exc:
                logger.debug(f"Пропускаю {name}: {exc}")

    local_state = master / "Local State"
    if local_state.exists():
        try:
            import json
            data = json.loads(local_state.read_text(encoding="utf-8"))
            data.pop("sync", None)
            data.pop("signin", None)
            data.pop("account_info", None)
            local_state.write_text(json.dumps(data), encoding="utf-8")
        except Exception:
            pass

    logger.info("Мастер-профиль готов.")
    return master


# ---------------------------------------------------------------------------
# Рабочая копия
# ---------------------------------------------------------------------------

def _cleanup_old_profiles(logger) -> None:
    """Удаляет только явно старые профили, не трогая активные Worker.

    Активность определяется lock-файлом, который создаёт BrowserSession.
    """
    temp_dir = Path(tempfile.gettempdir())
    now = time.time()
    removed = 0
    for path in temp_dir.glob(f"{PROFILE_PREFIX}*"):
        if not path.is_dir():
            continue
        lock_file = path / ".hate_worker_active"
        try:
            if lock_file.exists():
                age = now - lock_file.stat().st_mtime
                if age < 3600:
                    continue
            shutil.rmtree(path)
            removed += 1
        except (OSError, PermissionError) as exc:
            logger.debug(f"Не удалось удалить {path.name}: {exc}")
    if removed:
        logger.info(f"Очистка старых рабочих профилей: удалено {removed}.")


def _prepare_worker_profile(logger) -> Path:
    _cleanup_old_profiles(logger)
    master = _ensure_master(logger)

    temp_dir = Path(tempfile.gettempdir())
    target = temp_dir / f"{PROFILE_PREFIX}{time.time_ns()}"

    logger.info(f"Готовлю рабочую копию профиля: {target.name}")
    try:
        shutil.copytree(master, target, dirs_exist_ok=True)
    except (OSError, shutil.Error) as exc:
        logger.error(f"Ошибка при копировании профиля: {exc}")
        shutil.rmtree(target, ignore_errors=True)
        raise
    logger.info("Рабочая копия профиля создана.")
    return target


# ---------------------------------------------------------------------------
# Открытие
# ---------------------------------------------------------------------------

def _open_new_browser(logger) -> ChromeWebDriver:
    global _current_profile_dir

    logger.info("Подготовка драйвера Chrome...")
    options = Options()

    try:
        user_data_dir = _prepare_worker_profile(logger)
        _current_profile_dir = user_data_dir
        options.add_argument(f"--user-data-dir={user_data_dir}")
        options.add_argument(f"--profile-directory={SOURCE_PROFILE_DIR}")
        logger.info(f"Использую копию профиля: {user_data_dir}")
    except Exception as exc:
        logger.warning(
            f"Не удалось использовать копию профиля ({exc}). "
            "Запускаю с временным профилем без расширений."
        )
        _current_profile_dir = None
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option("useAutomationExtension", False)

    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    if not os.environ.get("DISPLAY") and not os.environ.get("WAYLAND_DISPLAY"):
        options.add_argument("--headless=new")
        options.add_argument("--disable-gpu")
    else:
        options.add_argument("--start-maximized")
    for binary in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser"):
        found = shutil.which(binary)
        if found:
            options.binary_location = found
            break
    options.add_argument("--no-first-run")
    options.add_argument("--no-default-browser-check")
    options.add_argument("--disable-sync")
    options.add_argument("--disable-background-networking")
    options.add_argument("--disable-component-update")
    options.add_argument("--disable-default-apps")
    options.add_argument(
        "--disable-features=AccountConsistency,SigninAllowed,ChromeSignin,"
        "OptimizationHints,MediaRouter,AutofillServerCommunication"
    )

    service = Service()
    driver = ChromeWebDriver(service=service, options=options)

    try:
        driver.execute_script(
            "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});"
        )
    except Exception:
        pass

    logger.info("Браузер запущен.")
    return driver


def _is_driver_alive(driver: ChromeWebDriver) -> bool:
    try:
        _ = driver.current_url
        return True
    except Exception:
        return False



class BrowserSession:
    """Изолированный Chrome, принадлежащий одному Worker.

    Сессия живёт между Job одного Worker и закрывается только при остановке Worker.
    """
    def __init__(self, logger, worker_id: str):
        self.logger = logger
        self.worker_id = worker_id
        self.driver: Optional[ChromeWebDriver] = None
        self._profile_dir: Optional[Path] = None
        self._lock_file: Optional[Path] = None

    def get(self) -> ChromeWebDriver:
        if self.driver is not None and _is_driver_alive(self.driver):
            return self.driver
        self.close()
        self.driver = self._open()
        return self.driver

    def _open(self) -> ChromeWebDriver:
        # Здесь профиль и driver являются локальными переменными Worker,
        # поэтому параллельные Worker не перетирают глобальное состояние друг друга.
        profile_dir = _prepare_worker_profile(self.logger)
        options = Options()
        options.add_argument(f"--user-data-dir={profile_dir}")
        options.add_argument(f"--profile-directory={SOURCE_PROFILE_DIR}")
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        if not os.environ.get("DISPLAY") and not os.environ.get("WAYLAND_DISPLAY"):
            options.add_argument("--headless=new")
            options.add_argument("--disable-gpu")
        else:
            options.add_argument("--start-maximized")
        for binary in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser"):
            found = shutil.which(binary)
            if found:
                options.binary_location = found
                break
        options.add_argument("--no-first-run")
        options.add_argument("--no-default-browser-check")
        options.add_argument("--disable-sync")
        options.add_argument("--disable-background-networking")
        options.add_argument("--disable-component-update")
        options.add_argument("--disable-default-apps")
        options.add_argument(
            "--disable-features=AccountConsistency,SigninAllowed,ChromeSignin,"
            "OptimizationHints,MediaRouter,AutofillServerCommunication"
        )
        service = Service()
        try:
            driver = ChromeWebDriver(service=service, options=options)
            try:
                driver.execute_script(
                    "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});"
                )
            except Exception:
                pass
        except Exception:
            shutil.rmtree(profile_dir, ignore_errors=True)
            raise
        self._profile_dir = profile_dir
        self._lock_file = profile_dir / ".hate_worker_active"
        try:
            self._lock_file.write_text(self.worker_id, encoding="utf-8")
        except OSError:
            pass
        self.logger.info(f"Worker {self.worker_id}: Chrome запущен с профилем {profile_dir.name}.")
        return driver

    def close(self) -> None:
        driver = self.driver
        self.driver = None
        if driver is not None:
            try:
                driver.quit()
            except Exception:
                pass
        if self._lock_file is not None:
            try:
                self._lock_file.unlink(missing_ok=True)
            except OSError:
                pass
        if self._profile_dir is not None:
            try:
                shutil.rmtree(self._profile_dir, ignore_errors=True)
            except Exception:
                pass
        self._profile_dir = None
        self._lock_file = None


def _get_or_create(logger) -> ChromeWebDriver:
    global _driver, _last_use_time

    with _lock:
        if _driver is not None and _is_driver_alive(_driver):
            logger.info("Использую уже открытый Chrome.")
            _last_use_time = time.time()
            return _driver

        if _driver is not None:
            logger.warning("Предыдущий Chrome не отвечает — закрываю его.")
            try:
                _driver.quit()
            except Exception:
                pass
            _driver = None

        _driver = _open_new_browser(logger)
        _last_use_time = time.time()
        return _driver


def open_browser(logger) -> ChromeWebDriver:
    return _get_or_create(logger)


def get_or_open_browser(logger) -> ChromeWebDriver:
    return _get_or_create(logger)


def bring_to_front(driver=None, logger=None) -> None:
    # Поддерживает старый вызов bring_to_front(logger) для совместимости.
    if driver is not None and not hasattr(driver, "execute_cdp_cmd") and logger is None:
        logger = driver
        driver = _driver
    if driver is None:
        return
    try:
        driver.execute_cdp_cmd("Page.bringToFront", {})
    except Exception as exc:
        if logger:
            logger.debug(f"Page.bringToFront не сработал: {exc}")
    try:
        driver.execute_script("window.focus();")
    except Exception:
        pass


def minimize_browser(logger) -> None:
    global _last_use_time
    _last_use_time = time.time()


def _do_close(driver, logger) -> None:
    global _current_profile_dir

    if driver is not None:
        try:
            driver.quit()
        except Exception:
            pass

    if _current_profile_dir is not None:
        try:
            if _current_profile_dir.exists():
                shutil.rmtree(_current_profile_dir, ignore_errors=True)
                if logger:
                    logger.debug(f"Папка профиля удалена: {_current_profile_dir.name}")
        except Exception as exc:
            if logger:
                logger.debug(f"Не удалось удалить папку профиля: {exc}")
        _current_profile_dir = None


def close_and_cleanup(driver, logger) -> None:
    global _driver
    with _lock:
        _do_close(driver, logger)
        if _driver is driver:
            _driver = None


def close_all_browsers(logger) -> None:
    """Закрывает Chrome и удаляет профиль.

    Вызывается при выходе из проекта и из веб-панели (кнопка «Стоп всё»).
    """
    global _driver
    with _lock:
        if _driver is not None:
            _do_close(_driver, logger)
            _driver = None
            if logger:
                logger.info("Chrome закрыт.")
        else:
            _do_close(None, logger)


def is_browser_open() -> bool:
    global _driver
    with _lock:
        return _driver is not None and _is_driver_alive(_driver)