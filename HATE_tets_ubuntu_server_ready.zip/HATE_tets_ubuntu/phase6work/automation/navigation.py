"""Кнопка «Далее», подтверждение «Да», определение страницы результата,
извлечение процентов/баллов/оценки."""
from __future__ import annotations

import re
import time

from selenium.common.exceptions import (
    StaleElementReferenceException,
    WebDriverException,
)
from selenium.webdriver.common.by import By

import page_selectors as sel
from .base import check_stop, find_first, safe_click


def go_to_next(runner) -> bool:
    button = find_first(runner, sel.NEXT_BUTTON_XPATHS, timeout=3)
    if button is not None:
        safe_click(runner, button)
        return True

    runner.driver.switch_to.default_content()
    found = find_next_in_frames(runner, 0, 6)
    if found is None:
        return False
    safe_click(runner, found)
    return True


def find_next_in_frames(runner, depth: int, max_depth: int):
    button = find_first(runner, sel.NEXT_BUTTON_XPATHS, timeout=1.5)
    if button is not None:
        return button
    if depth >= max_depth:
        return None

    try:
        frames = runner.driver.find_elements(By.CSS_SELECTOR, "iframe, frame")
    except WebDriverException:
        return None

    for frame in frames:
        try:
            runner.driver.switch_to.frame(frame)
        except (WebDriverException, StaleElementReferenceException):
            continue
        button = find_next_in_frames(runner, depth + 1, max_depth)
        if button is not None:
            return button
        try:
            runner.driver.switch_to.parent_frame()
        except WebDriverException:
            runner.driver.switch_to.default_content()
            return None
    return None


# ---------------------------------------------------------------------------
# Модалка "Завершить прохождение теста?"
# ---------------------------------------------------------------------------

def has_confirm_finish_modal(runner) -> bool:
    try:
        runner.driver.switch_to.default_content()
    except WebDriverException:
        return False

    for xp in sel.CONFIRM_FINISH_MODAL_XPATHS:
        try:
            els = runner.driver.find_elements(By.XPATH, xp)
        except WebDriverException:
            continue
        for el in els:
            try:
                if el.is_displayed():
                    return True
            except (WebDriverException, StaleElementReferenceException):
                continue
    return False


def click_confirm_yes(runner) -> bool:
    for xp in sel.CONFIRM_FINISH_YES_BUTTON_XPATHS:
        try:
            els = runner.driver.find_elements(By.XPATH, xp)
        except WebDriverException:
            continue
        for el in els:
            try:
                if not el.is_displayed() or not el.is_enabled():
                    continue
                safe_click(runner, el)
                runner.logger.info(
                    "Нажата кнопка 'Да' — подтверждение завершения теста."
                )
                return True
            except (WebDriverException, StaleElementReferenceException):
                continue
    return False


# ---------------------------------------------------------------------------
# Определение страницы результата
# ---------------------------------------------------------------------------

def is_result_page(runner) -> bool:
    """Страница результата на onlinetestpad.

    Всегда /ru/testresult/... — проверяем только URL и (на всякий случай)
    характерный CSS-контейнер. Текстовые маркеры НЕ используем: они ловят
    фразы из описания теста («несколько правильных ответов») и ломают
    логику на стартовой странице.
    """
    try:
        url = (runner.driver.current_url or "").lower()
    except WebDriverException:
        return False

    if "testresult" in url:
        return True

    # На всякий случай — устойчивый признак страницы результата.
    js_check = """
    if (document.querySelector('.otp-item-res-container')) return true;
    if (document.querySelector('.otp-item-res-number')) return true;
    return false;
    """
    try:
        if runner.driver.execute_script(js_check):
            return True
    except WebDriverException:
        return False

    return False


def log_result_summary(runner) -> None:
    try:
        title = runner.driver.title
    except WebDriverException:
        title = "(не удалось получить заголовок страницы)"
    runner.logger.info(f"Заголовок страницы результата: {title}")
    runner.logger.info("Результат виден в открытом окне браузера.")


# ---------------------------------------------------------------------------
# Извлечение процентов / баллов / оценки со страницы результата
# ---------------------------------------------------------------------------

_PERCENT_RE = re.compile(r"(\d+(?:[.,]\d+)?)\s*%")

# Якорные фразы, которые onlinetestpad показывает в блоке статистики.
_BODY_CORRECT_RE = re.compile(
    r"Количество\s+баллов\s*\(правильных\s+ответов\)\s*:?\s*(\d+)",
    re.IGNORECASE,
)
_BODY_MAX_POINTS_RE = re.compile(
    r"Максимально\s+возможное\s+количество\s+баллов\s*:?\s*(\d+)",
    re.IGNORECASE,
)
_BODY_PERCENT_RE = re.compile(
    r"Процент\s*:?\s*(\d+(?:[.,]\d+)?)",
    re.IGNORECASE,
)
_BODY_GRADE_RE = re.compile(
    r"Ваша\s+оценка\s*:?\s*(\d+)",
    re.IGNORECASE,
)


def _first_x_of_y_in_text(text: str):
    m = re.search(r"(\d+)\s*(?:из|/)\s*(\d+)", text)
    if not m:
        return None, None
    try:
        return int(m.group(1)), int(m.group(2))
    except ValueError:
        return None, None


def extract_result_score(runner) -> dict:
    """Возвращает словарь с полями:

        percent      — целое (0..100+) или None
        correct      — сколько правильных ответов
        total        — сколько всего вопросов (максимум баллов)
        points       — баллы (число)
        max_points   — максимум баллов
        grade        — «4» / «отлично» / …
        raw          — первые 3000 символов innerText (для отладки)
    """
    result = {
        "percent": None,
        "correct": None,
        "total": None,
        "points": None,
        "max_points": None,
        "grade": None,
        "raw": "",
    }

    try:
        driver = runner.driver
    except Exception:
        return result

    # 1. Полный текст страницы.
    try:
        body = driver.execute_script(
            "return document.body ? (document.body.innerText || '') : '';"
        ) or ""
    except WebDriverException:
        body = ""

    result["raw"] = body[:3000]

    # 2. Якорные фразы — самые надёжные (используются на странице
    #    результата onlinetestpad в блоке статистики).
    m = _BODY_CORRECT_RE.search(body)
    if m:
        try:
            result["correct"] = int(m.group(1))
        except ValueError:
            pass

    m = _BODY_MAX_POINTS_RE.search(body)
    if m:
        try:
            result["max_points"] = int(m.group(1))
            result["total"] = result["max_points"]
        except ValueError:
            pass

    m = _BODY_PERCENT_RE.search(body)
    if m:
        try:
            result["percent"] = int(float(m.group(1).replace(",", ".")))
        except ValueError:
            pass

    m = _BODY_GRADE_RE.search(body)
    if m:
        result["grade"] = m.group(1)

    # 3. Fallback: если проценты не нашли через «Процент», ищем `N%`.
    if result["percent"] is None:
        m = _PERCENT_RE.search(body)
        if m:
            try:
                result["percent"] = int(float(m.group(1).replace(",", ".")))
            except ValueError:
                pass

    # 4. Fallback: total/points через «N из M», но ТОЛЬКО если ещё не нашли
    #    через якорные фразы — и берём не первое совпадение, а одно из
    #    последних (обычно на странице сначала идут баллы за отдельный
    #    вопрос, а потом уже итоговая строка).
    if result["total"] is None or result["correct"] is None:
        matches = re.findall(r"(\d+)\s*(?:из|/)\s*(\d+)", body)
        if matches:
            # Итоговая строка обычно — последняя (с наибольшим знаменателем).
            best = None
            best_total = -1
            for a, b in matches:
                try:
                    ai, bi = int(a), int(b)
                except ValueError:
                    continue
                if bi > best_total:
                    best_total = bi
                    best = (ai, bi)
            if best is not None:
                if result["correct"] is None:
                    result["correct"] = best[0]
                if result["total"] is None:
                    result["total"] = best[1]

    # 5. Если percent не нашли, но есть correct и total — считаем.
    if (
        result["percent"] is None
        and result["correct"] is not None
        and result["total"] and result["total"] > 0
    ):
        result["percent"] = round(100 * result["correct"] / result["total"])

    # 6. Характерные CSS-селекторы как последний резерв.
    if result["percent"] is None:
        for css in sel.RESULT_SCORE_CSS_SELECTORS:
            try:
                els = driver.find_elements(By.CSS_SELECTOR, css)
            except WebDriverException:
                continue
            for el in els:
                try:
                    if not el.is_displayed():
                        continue
                    text = (el.text or "").strip()
                except (WebDriverException, StaleElementReferenceException):
                    continue
                if not text:
                    continue
                m = _PERCENT_RE.search(text)
                if m:
                    try:
                        result["percent"] = int(float(m.group(1).replace(",", ".")))
                        break
                    except ValueError:
                        pass
            if result["percent"] is not None:
                break

    return result