"""
page_selectors.py — XPath-селекторы для onlinetestpad.com.

Файл специально НЕ назван selectors.py, чтобы не конфликтовать со
встроенным модулем стандартной библиотеки Python.
"""

# ---------------------------------------------------------------------------
# Прохождение теста
# ---------------------------------------------------------------------------

START_BUTTON_XPATHS = [
    # Кнопка «Принять» (диалог перед тестом).
    "//button[contains(normalize-space(text()),'Принять')]",
    "//input[@type='button' and contains(@value,'Принять')]",
    "//input[@type='submit' and contains(@value,'Принять')]",
    "//button[contains(translate(text(),'НАЧАТЬДАЛЕЕПРОЙТИСТАРТ','начатьдалеепройтистарт'),'начать')]",
    "//button[contains(translate(text(),'НАЧАТЬДАЛЕЕПРОЙТИСТАРТ','начатьдалеепройтистарт'),'далее')]",
    "//button[contains(translate(text(),'НАЧАТЬДАЛЕЕПРОЙТИСТАРТ','начатьдалеепройтистарт'),'пройти')]",
    "//button[contains(translate(text(),'НАЧАТЬДАЛЕЕПРОЙТИСТАРТ','начатьдалеепройтистарт'),'старт')]",
    "//a[contains(translate(text(),'НАЧАТЬДАЛЕЕПРОЙТИСТАРТ','начатьдалеепройтистарт'),'начать')]",
    "//a[contains(translate(text(),'НАЧАТЬДАЛЕЕПРОЙТИСТАРТ','начатьдалеепройтистарт'),'далее')]",
    "//a[contains(normalize-space(text()),'Принять')]",
    "//input[@type='submit' and (contains(@value,'ачать') or contains(@value,'алее'))]",
    "//div[contains(@class,'start') and (contains(@class,'btn') or contains(@class,'button'))]",
    "//*[@id='start_btn' or @id='startBtn' or @id='btnStart']",
    "//*[@id='btnAccept']",
    "//button[contains(translate(text(),'STARTNEXTBEGIN','startnextbegin'),'start')]",
    "//button[contains(translate(text(),'STARTNEXTBEGIN','startnextbegin'),'next')]",
]

NEXT_BUTTON_XPATHS = [
    # onlinetestpad: основная кнопка «Далее» — input#btnNext без value.
    "//input[@id='btnNext']",
    "//input[@id='btnFinish']",
    # Текстовые варианты.
    "//button[contains(translate(text(),'ДАЛЕЕСЛЕДУЮЩИЙОТВЕТИТЬ','далееследующийответить'),'далее')]",
    "//button[contains(translate(text(),'ДАЛЕЕСЛЕДУЮЩИЙОТВЕТИТЬ','далееследующийответить'),'следующ')]",
    "//button[contains(translate(text(),'ДАЛЕЕСЛЕДУЮЩИЙОТВЕТИТЬ','далееследующийответить'),'ответить')]",
    "//a[contains(translate(text(),'ДАЛЕЕСЛЕДУЮЩИЙОТВЕТИТЬ','далееследующийответить'),'далее')]",
    "//input[@type='submit' and contains(@value,'алее')]",
    "//button[@type='submit']",
    "//*[@id='next_btn' or @id='nextBtn' or @id='btnNext']",
    "//div[contains(@class,'next') and (contains(@class,'btn') or contains(@class,'button'))]",
    "//button[contains(translate(text(),'NEXTSUBMIT','nextsubmit'),'next')]",
]

RADIO_OPTION_XPATHS = [
    "//input[@type='radio']",
    "//div[contains(@class,'radio')]//input",
    "//label[contains(@class,'answer') or contains(@class,'option')]//input[@type='radio']",
]

CHECKBOX_OPTION_XPATHS = [
    "//input[@type='checkbox']",
    "//div[contains(@class,'checkbox')]//input",
]

CLICKABLE_OPTION_WRAPPER_XPATHS = [
    "//div[contains(@class,'answer-item')]",
    "//div[contains(@class,'answer_item')]",
    "//div[contains(@class,'option') and not(contains(@class,'options'))]",
    "//li[contains(@class,'answer')]",
]

TEXT_INPUT_XPATHS = [
    "//input[@type='text']",
    "//textarea",
]

RESULT_PAGE_MARKERS = [
    "результат #",
    "результат онлайн теста",
    "показать мои ответы",
    "показать мой результат",
    "результат теста",
    "результаты теста",
    "ваш результат",
    "правильных ответов",
    "количество баллов",
    "тест завершен",
    "тест завершён",
    "тестирование завершено",
    "test result",
    "your result",
    "score:",
]

START_PAGE_MARKERS = [
    "инструкция",
    "начать тест",
    "пройти тест",
    "начать тестирование",
]


# ---------------------------------------------------------------------------
# Подтверждение завершения теста ("Да")
# ---------------------------------------------------------------------------
# Модальное окно "Завершить прохождение теста?" появляется на некоторых
# тестах после последнего вопроса. Кликаем ТОЛЬКО кнопку "Да" и сразу
# останавливаемся — иначе модалки начнут наслаиваться друг на друга.

CONFIRM_FINISH_MODAL_XPATHS = [
    "//p[contains(normalize-space(text()),'Завершить прохождение теста')]",
    "//div[contains(@class,'modal-body') and contains(.,'Завершить прохождение теста')]",
    "//*[contains(normalize-space(text()),'Завершить прохождение теста')]",
]

CONFIRM_FINISH_YES_BUTTON_XPATHS = [
    "//div[contains(@class,'modal-footer')]//button[normalize-space(text())='Да']",
    "//button[normalize-space(text())='Да']",
    "//button[contains(@class,'btn-primary') and normalize-space(text())='Да']",
    "//input[@type='button' and @value='Да']",
    "//input[@type='submit' and @value='Да']",
]


# ---------------------------------------------------------------------------
# Сбор правильных ответов со страницы "Показать мои ответы"
# ---------------------------------------------------------------------------

SHOW_ANSWERS_BUTTON_XPATHS = [
    "//a[contains(@onclick,'showQuestions')]",
    "//*[contains(@onclick,'showQuestions')]",
    "//a[.//i[contains(@class,'icon-questions')]]",
    "//i[contains(@class,'icon-questions')]/parent::a",
    "//button[contains(translate(normalize-space(.),'ПОКАЗАТЬМОИОТВЕТЫ','показатьмоиответы'),'показать')"
    " and contains(translate(normalize-space(.),'ПОКАЗАТЬМОИОТВЕТЫ','показатьмоиответы'),'ответ')]",
    "//a[contains(translate(normalize-space(.),'ПОКАЗАТЬМОИОТВЕТЫ','показатьмоиответы'),'показать')"
    " and contains(translate(normalize-space(.),'ПОКАЗАТЬМОИОТВЕТЫ','показатьмоиответы'),'ответ')]",
    "//div[contains(translate(normalize-space(.),'ПОКАЗАТЬМОИОТВЕТЫ','показатьмоиответы'),'показать')"
    " and contains(translate(normalize-space(.),'ПОКАЗАТЬМОИОТВЕТЫ','показатьмоиответы'),'ответ')]",
    "//span[contains(translate(normalize-space(.),'ПОКАЗАТЬМОИОТВЕТЫ','показатьмоиответы'),'показать')"
    " and contains(translate(normalize-space(.),'ПОКАЗАТЬМОИОТВЕТЫ','показатьмоиответы'),'ответ')]",
    "//button[contains(translate(normalize-space(.),'SHOWANSWERSMY','showanswersmy'),'show')"
    " and contains(translate(normalize-space(.),'SHOWANSWERSMY','showanswersmy'),'answer')]",
    "//a[contains(translate(normalize-space(.),'SHOWANSWERSMY','showanswersmy'),'show')"
    " and contains(translate(normalize-space(.),'SHOWANSWERSMY','showanswersmy'),'answer')]",
    "//*[contains(@class,'show-answers') or contains(@class,'show_answers')"
    " or contains(@class,'showAnswers') or contains(@class,'answers-btn')]",
    "//*[@id='show_answers' or @id='showAnswers' or @id='btnShowAnswers'"
    " or @id='show-my-answers' or @id='showMyAnswers']",
]

QUESTION_BLOCK_XPATHS = [
    "//div[contains(@class,'question-item')]",
    "//div[contains(@class,'question_item')]",
    "//div[contains(@class,'questionItem')]",
    "//div[contains(@class,'question') and contains(@class,'item')]",
    "//li[contains(@class,'question')]",
    "//tr[contains(@class,'question')]",
    "//div[contains(@class,'result-item')]",
    "//div[contains(@class,'result_item')]",
    "//div[contains(@class,'answer-item') and contains(@class,'question')]",
]

CORRECT_OPTION_XPATHS = [
    ".//*[contains(@class,'otp-item-ans-correct')]",
    ".//*[contains(@class,'answer') and contains(@class,'correct')]",
    ".//*[contains(@class,'answer') and contains(@class,'right')]",
    ".//*[contains(@class,'option') and contains(@class,'correct')]",
    ".//*[contains(@class,'option') and contains(@class,'right')]",
    ".//*[contains(@class,'correct-answer')]",
    ".//*[contains(@class,'right-answer')]",
    ".//*[contains(@class,'answer-right')]",
    ".//*[contains(@class,'is-correct')]",
    ".//*[contains(@class,'is_correct')]",
    ".//*[contains(@class,'is_right')]",
    ".//*[contains(@class,'success')]",
    ".//*[contains(@class,'valid')]",
    ".//*[contains(@class,'pravil')]",
    ".//*[@data-correct='true' or @data-correct='1' or @data-correct='yes']",
    ".//*[@data-right='true' or @data-right='1']",
    ".//*[@data-is-correct='true' or @data-is-correct='1']",
]

SELECTED_OPTION_XPATHS = [
    ".//*[contains(@class,'answer') and contains(@class,'selected')]",
    ".//*[contains(@class,'option') and contains(@class,'selected')]",
    ".//*[contains(@class,'answer') and contains(@class,'chosen')]",
    ".//*[contains(@class,'option') and contains(@class,'chosen')]",
    ".//*[contains(@class,'answer') and contains(@class,'checked')]",
    ".//*[contains(@class,'option') and contains(@class,'checked')]",
    ".//*[contains(@class,'user-answer')]",
    ".//*[contains(@class,'user_answer')]",
    ".//*[contains(@class,'my-answer')]",
    ".//*[contains(@class,'my_answer')]",
    ".//*[contains(@class,'active') and (contains(@class,'answer') or contains(@class,'option'))]",
    ".//input[@checked]",
    ".//*[@aria-checked='true']",
]

CORRECT_STATUS_MARKERS = [
    "правильный ответ",
    "верный ответ",
    "answered correctly",
    "correct answer",
]

INCORRECT_STATUS_MARKERS = [
    "неправильный ответ",
    "неверный ответ",
    "вы ответили неправильно",
    "incorrect",
    "wrong answer",
    "you answered",
]


# ---------------------------------------------------------------------------
# Точные селекторы onlinetestpad (по разметке страницы ответов)
# ---------------------------------------------------------------------------
# Значок правильного ответа: <i class="indicator ... otp-item-ans-correct"></i>
# Рядом (в следующем <span>) — текст правильного варианта.
OTP_CORRECT_ICON_SELECTOR = "i.otp-item-ans-correct"

# XPath для извлечения текста правильного варианта из блока.
OTP_CORRECT_TEXT_XPATHS = [
    ".//*[contains(@class,'otp-item-ans-correct')]/following-sibling::span[1]",
    ".//*[contains(@class,'otp-item-ans-correct')]/following-sibling::*[1]",
    ".//label[.//*[contains(@class,'otp-item-ans-correct')]]//span[1]",
    ".//p[.//*[contains(@class,'otp-item-ans-correct')]]//span",
]

# XPath для текста вопроса: <strong> внутри <span class="qtext">.
QUESTION_TEXT_XPATHS = [
    "//span[contains(@class,'qtext')]//p[1]//strong",
    "//span[contains(@class,'qtext')]//strong[1]",
    "//span[contains(@class,'qtext')]/p[1]",
    "//div[contains(@class,'qcontainer')]//p[1]",
]

# XPath для номера вопроса — на странице ответов он в сером квадрате.
QUESTION_NUMBER_XPATHS = [
    ".//*[contains(@class,'otp-q-number')]",
    ".//*[contains(@class,'q-number')]",
    ".//*[contains(@class,'question-number')]",
]


# ---------------------------------------------------------------------------
# Чтение процентов / баллов / оценки со страницы результата
# ---------------------------------------------------------------------------
# Нужно, чтобы отличать «100%» от «81%». Раньше бот считал успехом просто
# «все вопросы совпали с кэшем», независимо от того, что показал сайт.

RESULT_SCORE_CSS_SELECTORS = [
    ".otp-item-res-number",
    ".otp-item-res-percent",
    ".otp-item-res-score",
    "[class*='res-number']",
    "[class*='res-percent']",
    "[class*='res-score']",
    "[class*='result-number']",
    "[class*='result-percent']",
    "[class*='result-score']",
    "[class*='test-result']",
    ".otp-item-res-container",
]

RESULT_SCORE_LABEL_XPATHS = [
    "//*[contains(text(),'правильных ответов')]",
    "//*[contains(text(),'Правильных ответов')]",
    "//*[contains(text(),'баллов')]",
    "//*[contains(text(),'Баллов')]",
    "//*[contains(text(),'процент')]",
    "//*[contains(text(),'Процент')]",
    "//*[contains(text(),'оценка')]",
    "//*[contains(text(),'Оценка')]",
]