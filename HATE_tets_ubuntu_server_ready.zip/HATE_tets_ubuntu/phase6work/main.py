"""Server entry point for HATE_tets on Ubuntu/Linux."""
from __future__ import annotations

import signal
import threading

from services.hub import ApplicationHub
from services.logging_setup import setup_logger


def main() -> int:
    logger = setup_logger(log_queue=None, log_name="server")
    hub = ApplicationHub(logger)
    stop = threading.Event()

    def _shutdown(signum, frame):
        if not stop.is_set():
            logger.info("Получен сигнал остановки (%s).", signum)
            stop.set()
            hub.stop()

    signal.signal(signal.SIGTERM, _shutdown)
    signal.signal(signal.SIGINT, _shutdown)

    hub.start()
    logger.info("HATE_tets Server запущен. Web: %s", hub.web_url)

    try:
        while not stop.wait(1.0):
            pass
    finally:
        hub.stop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
