"""Глобальный флаг остановки для всех активных тестов.

Веб-панель выставляет флаг → все TestRunner'ы, включая текущий,
видят его через check_stop() и корректно завершаются.
"""
from __future__ import annotations

import threading

_stop_event = threading.Event()


def request_stop() -> None:
    """Выставить флаг «остановить всё»."""
    _stop_event.set()


def clear_stop() -> None:
    """Сбросить флаг (вызывается при старте нового задания)."""
    _stop_event.clear()


def is_stop_requested() -> bool:
    return _stop_event.is_set()