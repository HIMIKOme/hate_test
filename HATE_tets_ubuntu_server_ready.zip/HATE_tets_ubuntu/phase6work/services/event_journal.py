"""Персистентный журнал событий для связи основного процесса и Web."""
from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path
from typing import Any, Dict, Iterator

from .config import _base_dir

_LOCK = threading.Lock()
_MAX_BYTES = 2 * 1024 * 1024


def event_path() -> Path:
    path = _base_dir() / "data" / "events.jsonl"
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def append_event(event: Dict[str, Any]) -> None:
    payload = dict(event)
    payload.setdefault("timestamp", time.time())
    line = json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n"
    path = event_path()
    with _LOCK:
        try:
            if path.exists() and path.stat().st_size + len(line.encode("utf-8")) > _MAX_BYTES:
                backup = path.with_suffix(".old")
                try:
                    if backup.exists():
                        backup.unlink()
                except OSError:
                    pass
                try:
                    path.replace(backup)
                except OSError:
                    pass
            with path.open("a", encoding="utf-8") as fh:
                fh.write(line)
                fh.flush()
                os.fsync(fh.fileno())
        except OSError:
            pass


def read_events_from(path: Path, offset: int) -> tuple[list[dict], int]:
    events: list[dict] = []
    try:
        with path.open("r", encoding="utf-8") as fh:
            fh.seek(offset)
            while True:
                line = fh.readline()
                if not line:
                    break
                try:
                    events.append(json.loads(line))
                except (ValueError, TypeError):
                    continue
            return events, fh.tell()
    except (OSError, ValueError):
        return [], offset
