"""Настройки приложения: settings.json + необязательный config.txt.

config.txt (ключ = значение):

    токен бота = ...
    чат 1 = ...
    чат 2 = ...
    чат 3 = ...
    юзернейм = @...
    дней хранения = 15
    белый список = @HATE_death_ME

Белый список — через запятую. Хранится нормализованно (lowercase, без @).
"""
from __future__ import annotations

import json
import re
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

# По умолчанию — уже в нормализованном виде (lowercase, без @).
DEFAULT_WHITELIST = ["hate_death_me"]

DEFAULT_SETTINGS: Dict[str, Any] = {
    "telegram_token": "",
    "telegram_chats": ["", "", ""],
    "error_contact": "",
    "cleanup_days": 15,
    "whitelist": DEFAULT_WHITELIST.copy(),
    "worker_count": 4,
}

CONFIG_TXT_NAME = "config.txt"


# ---------------------------------------------------------------------------
# Пути
# ---------------------------------------------------------------------------

def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def get_data_dir() -> Path:
    d = _base_dir() / "data"
    d.mkdir(parents=True, exist_ok=True)
    return d


def get_settings_path() -> Path:
    return get_data_dir() / "settings.json"


def _config_candidates() -> List[Path]:
    candidates: List[Path] = []
    base = _base_dir()
    candidates.append(base / CONFIG_TXT_NAME)
    if base.name.lower() == "dist":
        candidates.append(base.parent / CONFIG_TXT_NAME)
    try:
        cwd = Path.cwd().resolve()
        p = cwd / CONFIG_TXT_NAME
        if p not in candidates:
            candidates.append(p)
    except Exception:
        pass
    return candidates


def get_config_txt_path() -> Path:
    for p in _config_candidates():
        if p.exists():
            return p
    return _config_candidates()[0]


# ---------------------------------------------------------------------------
# Хелперы
# ---------------------------------------------------------------------------

def _normalize_chats(chats) -> List[str]:
    if not isinstance(chats, list):
        chats = []
    result = [str(c).strip() if c else "" for c in chats]
    while len(result) < 3:
        result.append("")
    return result[:3]


def _normalize_whitelist(value) -> List[str]:
    """Принимает строку с @user,@user2 или список. Возвращает нормализованный список."""
    if isinstance(value, str):
        items = [x.strip() for x in value.split(",")]
    elif isinstance(value, list):
        items = [str(x).strip() for x in value]
    else:
        items = []

    result: List[str] = []
    for it in items:
        if not it:
            continue
        norm = it.lstrip("@").strip().lower()
        if norm and norm not in result:
            result.append(norm)
    return result


def is_user_allowed(username: Optional[str]) -> bool:
    """Проверяет, входит ли username (любой регистр, с @ или без) в белый список."""
    if not username:
        return False
    norm = username.lstrip("@").strip().lower()
    try:
        wl = load_settings().get("whitelist", [])
    except Exception:
        wl = DEFAULT_WHITELIST
    # Гарантируем нормализацию — на случай, если откуда-то пришёл необработанный список.
    wl = _normalize_whitelist(wl)
    return norm in wl


def _empty() -> Dict[str, Any]:
    return {
        "telegram_token": "",
        "telegram_chats": ["", "", ""],
        "error_contact": "",
        "cleanup_days": 15,
        "whitelist": DEFAULT_WHITELIST.copy(),
        "worker_count": 4,
    }


# ---------------------------------------------------------------------------
# Ключи
# ---------------------------------------------------------------------------

_KEY_TOKEN = {"токенбота", "токен", "token", "bottoken"}
_KEY_CHAT_1 = {"чат1", "группа1", "chat1", "chatid1", "chat_id1", "ссылканагруппу1"}
_KEY_CHAT_2 = {"чат2", "группа2", "chat2", "chatid2", "chat_id2", "ссылканагруппу2"}
_KEY_CHAT_3 = {"чат3", "группа3", "chat3", "chatid3", "chat_id3", "ссылканагруппу3"}
_KEY_USERNAME = {"юзернейм", "username", "контакт", "contact", "тг", "telegram"}
_KEY_GROUP_GENERIC = {"ссылканагруппу", "группа", "чат"}
_KEY_CLEANUP = {"днейхранения", "хранение", "дней", "cleanupdays", "cleanup_days", "cleanup"}
_KEY_WHITELIST = {"белыйсписок", "whitelist", "whitelisted", "вайтлист"}
_KEY_WORKERS = {"worker", "workers", "воркеры", "воркеров", "количествоworker", "количествоworkers"}


def _norm_key(key: str) -> str:
    return re.sub(r"[\s\-_]+", "", key.lower())


def _classify_key(key: str) -> Optional[str]:
    k = _norm_key(key)
    if k in _KEY_TOKEN:
        return "token"
    if k in _KEY_CHAT_1:
        return "chat1"
    if k in _KEY_CHAT_2:
        return "chat2"
    if k in _KEY_CHAT_3:
        return "chat3"
    if k in _KEY_USERNAME:
        return "username"
    if k in _KEY_GROUP_GENERIC:
        return "chat1"
    if k in _KEY_CLEANUP:
        return "cleanup"
    if k in _KEY_WHITELIST:
        return "whitelist"
    if k in _KEY_WORKERS:
        return "worker_count"
    return None


def _parse_key_value(lines: List[str]) -> Optional[Dict[str, Any]]:
    found_any = False
    result = _empty()

    for raw in lines:
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, _, value = line.partition("=")
        kind = _classify_key(key)
        if kind is None:
            continue
        found_any = True
        value = value.strip()

        if kind == "token":
            result["telegram_token"] = value
        elif kind == "chat1":
            result["telegram_chats"][0] = value
        elif kind == "chat2":
            result["telegram_chats"][1] = value
        elif kind == "chat3":
            result["telegram_chats"][2] = value
        elif kind == "username":
            result["error_contact"] = value
        elif kind == "cleanup":
            try:
                result["cleanup_days"] = int(value)
            except (ValueError, TypeError):
                pass
        elif kind == "whitelist":
            parsed = _normalize_whitelist(value)
            # Пустая строка = оставить DEFAULT_WHITELIST.
            result["whitelist"] = parsed if parsed else DEFAULT_WHITELIST.copy()
        elif kind == "worker_count":
            try:
                result["worker_count"] = max(1, min(16, int(value)))
            except (ValueError, TypeError):
                pass

    return result if found_any else None


def _parse_positional(lines: List[str]) -> Dict[str, Any]:
    values = [line.strip() for line in lines[:5]]
    while len(values) < 5:
        values.append("")
    return {
        "telegram_token": values[0],
        "telegram_chats": [values[1], values[2], values[3]],
        "error_contact": values[4],
        "cleanup_days": 15,
        "whitelist": DEFAULT_WHITELIST.copy(),
        "worker_count": 4,
    }


# ---------------------------------------------------------------------------
# Загрузка
# ---------------------------------------------------------------------------

def _load_from_json() -> Dict[str, Any]:
    path = get_settings_path()
    if not path.exists():
        return _empty()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return _empty()
    try:
        cleanup_days = int(data.get("cleanup_days", 15))
    except (ValueError, TypeError):
        cleanup_days = 15

    wl = _normalize_whitelist(data.get("whitelist"))

    return {
        "telegram_token": str(data.get("telegram_token") or "").strip(),
        "telegram_chats": _normalize_chats(data.get("telegram_chats")),
        "error_contact": str(data.get("error_contact") or "").strip(),
        "cleanup_days": cleanup_days,
        "whitelist": wl or DEFAULT_WHITELIST.copy(),
        "worker_count": max(1, min(16, int(data.get("worker_count", 4) or 4))),
    }


def _load_from_config_txt() -> Dict[str, Any]:
    path = get_config_txt_path()
    if not path.exists():
        return _empty()
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return _empty()

    kv = _parse_key_value(lines)
    if kv is not None:
        return kv
    return _parse_positional(lines)


def load_settings() -> Dict[str, Any]:
    json_data = _load_from_json()
    txt_data = _load_from_config_txt()

    wl_raw = txt_data["whitelist"] or json_data["whitelist"]
    # На всякий случай — нормализуем ещё раз.
    wl = _normalize_whitelist(wl_raw) or DEFAULT_WHITELIST.copy()

    return {
        "telegram_token": txt_data["telegram_token"] or json_data["telegram_token"],
        "telegram_chats": [
            txt_data["telegram_chats"][i] or json_data["telegram_chats"][i]
            for i in range(3)
        ],
        "error_contact": txt_data["error_contact"] or json_data["error_contact"],
        "cleanup_days": txt_data["cleanup_days"] or json_data["cleanup_days"],
        "whitelist": wl,
        "worker_count": txt_data.get("worker_count") or json_data.get("worker_count", 4),
    }


# ---------------------------------------------------------------------------
# Сохранение
# ---------------------------------------------------------------------------

def _write_settings_json(token, chats, contact, cleanup, whitelist) -> None:
    try:
        get_settings_path().write_text(
            json.dumps(
                {
                    "telegram_token": token,
                    "telegram_chats": chats,
                    "error_contact": contact,
                    "cleanup_days": cleanup,
                    "whitelist": whitelist,
                },
                ensure_ascii=False, indent=2,
            ),
            encoding="utf-8",
        )
    except OSError:
        pass


def _write_config_txt(token, chats, contact, cleanup, whitelist, path) -> None:
    wl_str = ", ".join(f"@{u}" for u in whitelist)
    text = (
        "# HATE_tets — настройки\n"
        "# Формат: ключ = значение. Пустые строки / строки с # игнорируются.\n"
        "\n"
        f"токен бота = {token}\n"
        f"чат 1 = {chats[0]}\n"
        f"чат 2 = {chats[1]}\n"
        f"чат 3 = {chats[2]}\n"
        f"юзернейм = {contact}\n"
        f"дней хранения = {cleanup}\n"
        f"белый список = {wl_str}\n"
    )
    try:
        path.write_text(text, encoding="utf-8")
    except OSError:
        pass


def save_settings(settings: Dict[str, Any]) -> None:
    token = str(settings.get("telegram_token") or "").strip()
    chats = _normalize_chats(settings.get("telegram_chats"))
    contact = str(settings.get("error_contact") or "").strip()
    try:
        cleanup = int(settings.get("cleanup_days", 15))
    except (ValueError, TypeError):
        cleanup = 15
    if cleanup < 1:
        cleanup = 1
    whitelist = _normalize_whitelist(settings.get("whitelist")) or DEFAULT_WHITELIST.copy()

    _write_settings_json(token, chats, contact, cleanup, whitelist)

    target = None
    for p in _config_candidates():
        if p.exists():
            target = p
            break
    if target is None:
        target = _config_candidates()[0]
    _write_config_txt(token, chats, contact, cleanup, whitelist, target)

    request_reload()


# ---------------------------------------------------------------------------
# Флаг перезагрузки
# ---------------------------------------------------------------------------

def get_reload_flag_path() -> Path:
    return get_data_dir() / "reload.flag"


def request_reload() -> None:
    try:
        get_reload_flag_path().write_text(str(time.time()), encoding="utf-8")
    except OSError:
        pass


def consume_reload_request() -> bool:
    p = get_reload_flag_path()
    if not p.exists():
        return False
    try:
        p.unlink()
    except OSError:
        pass
    return True