"""Логирование: очередь для GUI (опционально) + файл с ротацией."""
from __future__ import annotations

import logging
import queue
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path
from typing import Optional

from .config import get_data_dir


class QueueLogHandler(logging.Handler):
    def __init__(self, log_queue: "queue.Queue"):
        super().__init__()
        self.log_queue = log_queue

    def emit(self, record: logging.LogRecord) -> None:
        try:
            self.log_queue.put((record.levelname, self.format(record)))
        except Exception:
            pass


def get_logs_dir() -> Path:
    d = get_data_dir() / "logs"
    d.mkdir(parents=True, exist_ok=True)
    return d


def setup_logger(
    log_queue: Optional["queue.Queue"] = None,
    log_name: str = "app",
) -> logging.Logger:
    """Если log_queue is None — только файл (режим трея).

    Файлы ротируются ежедневно в полночь, храним последние 7 дней.
    """
    logger = logging.getLogger(f"hate_tets_{log_name}")
    logger.setLevel(logging.DEBUG)
    logger.handlers.clear()
    logger.propagate = False

    if log_queue is not None:
        qh = QueueLogHandler(log_queue)
        qh.setLevel(logging.INFO)
        qh.setFormatter(logging.Formatter("%(asctime)s  %(message)s", datefmt="%H:%M:%S"))
        logger.addHandler(qh)

    try:
        # Один файл на процесс — ротация сама добавит суффиксы по дате.
        log_file = get_logs_dir() / f"{log_name}.log"
        fh = TimedRotatingFileHandler(
            log_file,
            when="midnight",
            interval=1,
            backupCount=7,
            encoding="utf-8",
            delay=False,
        )
        fh.setLevel(logging.DEBUG)
        fh.setFormatter(logging.Formatter(
            "%(asctime)s [%(levelname)s] %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        ))
        logger.addHandler(fh)
        logger.info(f"Логи сохраняются в файл: {log_file}")
    except Exception as exc:
        logger.warning(f"Не удалось создать файловый лог: {exc}")

    return logger