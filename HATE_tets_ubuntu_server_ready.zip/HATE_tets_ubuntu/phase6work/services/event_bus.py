"""Внутренняя шина событий HATE_tets."""
from __future__ import annotations

import threading
from collections import defaultdict
from typing import Any, Callable, Dict, List


class EventBus:
    def __init__(self, logger=None):
        self.logger = logger
        self._subs: Dict[str, List[Callable[[dict], None]]] = defaultdict(list)
        self._lock = threading.RLock()

    def subscribe(self, event_type: str, callback: Callable[[dict], None]) -> None:
        with self._lock:
            self._subs[event_type].append(callback)

    def subscribe_all(self, callback: Callable[[dict], None]) -> None:
        self.subscribe("*", callback)

    def publish(self, event_type: str, **data: Any) -> None:
        event = {"type": event_type, **data}
        with self._lock:
            callbacks = list(self._subs.get(event_type, ())) + list(self._subs.get("*", ()))
        for callback in callbacks:
            try:
                callback(event)
            except Exception as exc:
                if self.logger:
                    self.logger.warning(f"EventBus {event_type}: {exc}")
