"""Контекст отдельного Worker: ресурсы Worker и heartbeat."""
from __future__ import annotations

import threading
import time
from typing import Any, Dict, Optional
from pathlib import Path
import json
import os


class WorkerContext:
    def __init__(self, worker_id: str, event_bus=None, logger=None, heartbeat_interval: float = 5.0):
        self.worker_id = worker_id
        self.event_bus = event_bus
        self.logger = logger
        self.heartbeat_interval = max(1.0, float(heartbeat_interval))
        self.resources: Dict[str, Any] = {}
        self.current_job_id: Optional[str] = None
        self.started_at = time.time()
        self.last_heartbeat = time.time()
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._heartbeat_path = self._get_heartbeat_path()

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._heartbeat_loop,
            name=f"{self.worker_id}-heartbeat",
            daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2)
        self._thread = None
        try:
            self._heartbeat_path.unlink(missing_ok=True)
        except OSError:
            pass

    def set_job(self, job_id: Optional[str]) -> None:
        self.current_job_id = job_id
        self.heartbeat()

    def _get_heartbeat_path(self) -> Path:
        base = Path(__file__).resolve().parent.parent / "data" / "heartbeats"
        base.mkdir(parents=True, exist_ok=True)
        return base / f"{self.worker_id}.json"

    def _write_heartbeat_file(self) -> None:
        payload = {"worker_id": self.worker_id, "timestamp": self.last_heartbeat, "job_id": self.current_job_id, "pid": os.getpid()}
        try:
            tmp = self._heartbeat_path.with_suffix(".tmp")
            tmp.write_text(json.dumps(payload), encoding="utf-8")
            tmp.replace(self._heartbeat_path)
        except OSError:
            pass

    def heartbeat(self) -> None:
        self.last_heartbeat = time.time()
        self._write_heartbeat_file()
        if self.event_bus:
            self.event_bus.publish(
                "WorkerHeartbeat",
                worker_id=self.worker_id,
                job_id=self.current_job_id,
                timestamp=self.last_heartbeat,
            )

    def get_resource(self, name: str, factory):
        if name not in self.resources or self.resources[name] is None:
            self.resources[name] = factory()
        return self.resources[name]

    def close_resource(self, name: str) -> None:
        resource = self.resources.pop(name, None)
        if resource is None:
            return
        close = getattr(resource, "close", None)
        if callable(close):
            try:
                close()
            except Exception as exc:
                if self.logger:
                    self.logger.warning(f"{self.worker_id}: ошибка закрытия {name}: {exc}")

    def close_all(self) -> None:
        for name in list(self.resources):
            self.close_resource(name)

    def _heartbeat_loop(self) -> None:
        while not self._stop.wait(self.heartbeat_interval):
            self.heartbeat()
