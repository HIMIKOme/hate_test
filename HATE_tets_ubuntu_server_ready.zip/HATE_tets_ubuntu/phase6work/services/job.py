"""Модель задания и формальные состояния Job."""
from __future__ import annotations

import threading
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Optional


class JobState(str, Enum):
    QUEUED = "QUEUED"
    STARTING = "STARTING"
    BROWSER_STARTING = "BROWSER_STARTING"
    OPENING = "OPENING"
    TESTING = "TESTING"
    COLLECTING = "COLLECTING"
    SAVING = "SAVING"
    NOTIFYING = "NOTIFYING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLING = "CANCELLING"
    CANCELLED = "CANCELLED"


class JobPriority(int, Enum):
    LOW = 10
    NORMAL = 20
    HIGH = 30
    VERY_HIGH = 40


TERMINAL_STATES = {JobState.COMPLETED, JobState.FAILED, JobState.CANCELLED}

_ALLOWED = {
    JobState.QUEUED: {JobState.STARTING, JobState.CANCELLING, JobState.CANCELLED},
    JobState.STARTING: {JobState.BROWSER_STARTING, JobState.OPENING, JobState.TESTING, JobState.COLLECTING, JobState.NOTIFYING, JobState.COMPLETED, JobState.CANCELLING, JobState.FAILED},
    JobState.BROWSER_STARTING: {JobState.OPENING, JobState.TESTING, JobState.CANCELLING, JobState.FAILED},
    JobState.OPENING: {JobState.TESTING, JobState.COLLECTING, JobState.CANCELLING, JobState.FAILED},
    JobState.TESTING: {JobState.COLLECTING, JobState.SAVING, JobState.NOTIFYING, JobState.COMPLETED, JobState.CANCELLING, JobState.FAILED},
    JobState.COLLECTING: {JobState.SAVING, JobState.NOTIFYING, JobState.COMPLETED, JobState.CANCELLING, JobState.FAILED},
    JobState.SAVING: {JobState.NOTIFYING, JobState.COMPLETED, JobState.FAILED},
    JobState.NOTIFYING: {JobState.COMPLETED, JobState.FAILED},
    JobState.CANCELLING: {JobState.CANCELLED, JobState.FAILED},
    JobState.COMPLETED: set(),
    JobState.FAILED: set(),
    JobState.CANCELLED: set(),
}


@dataclass
class Job:
    url: str
    mode: str = "collect"
    user_name: str = ""
    telegram_chat_id: Optional[str] = None
    priority: JobPriority = JobPriority.NORMAL
    id: str = field(default_factory=lambda: f"job-{uuid.uuid4().hex[:12]}")
    created_at: float = field(default_factory=time.time)
    started_at: Optional[float] = None
    finished_at: Optional[float] = None
    state: JobState = JobState.QUEUED
    stage: str = "queued"
    progress: float = 0.0
    current_question: int = 0
    total_questions: int = 0
    attempts: int = 0
    worker_id: Optional[str] = None
    error: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    cancel_event: threading.Event = field(default_factory=threading.Event, repr=False)

    def transition(self, state: JobState, *, stage: Optional[str] = None, error: str = "") -> None:
        if state != self.state and state not in _ALLOWED.get(self.state, set()):
            raise ValueError(f"Недопустимый переход Job {self.id}: {self.state} -> {state}")
        self.state = state
        if stage is not None:
            self.stage = stage
        if error:
            self.error = error
        now = time.time()
        if state == JobState.STARTING and self.started_at is None:
            self.started_at = now
        if state in TERMINAL_STATES:
            self.finished_at = now
            if state == JobState.COMPLETED:
                self.progress = 100.0

    @property
    def waiting_seconds(self) -> float:
        return max(0.0, time.time() - self.created_at)

    def effective_priority(self) -> float:
        # Каждые 5 минут ожидания добавляют один уровень, но не меняют исходный priority.
        return float(self.priority.value) + self.waiting_seconds / 300.0

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "url": self.url,
            "mode": self.mode,
            "user_name": self.user_name,
            "telegram_chat_id": self.telegram_chat_id,
            "priority": self.priority.name,
            "priority_value": self.priority.value,
            "effective_priority": round(self.effective_priority(), 2),
            "created_at": self.created_at,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "state": self.state.value,
            "stage": self.stage,
            "progress": round(self.progress, 1),
            "current_question": self.current_question,
            "total_questions": self.total_questions,
            "attempts": self.attempts,
            "worker_id": self.worker_id,
            "error": self.error,
            "metadata": dict(self.metadata),
            "waiting_seconds": round(self.waiting_seconds, 1),
        }
