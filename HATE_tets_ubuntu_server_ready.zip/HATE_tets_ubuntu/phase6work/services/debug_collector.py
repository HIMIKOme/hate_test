"""Сбор отладочной информации о тесте для команды /test.

Особенности:
  - Сбрасывает глобальный флаг «Стоп всё» в начале.
  - Умеет ПРОХОДИТЬ matching через select-ы (заглушка).
  - Умеет ПРОХОДИТЬ открытые ответы (input.otp-textbox) — заглушка.
  - Точный fingerprint по id вопроса (dq_XXXX).
  - Сохраняет отчёт ВСЕГДА, даже при «Стоп всё».
"""
from __future__ import annotations

import threading
import time
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Tuple

from selenium.common.exceptions import (
    StaleElementReferenceException,
    WebDriverException,
)
from selenium.webdriver.common.by import By

import page_selectors as sel
from services.config import get_data_dir
from services.global_state import clear_stop, is_stop_requested

MAX_QUESTIONS = 100
WAIT_FIRST_QUESTION = 25.0
WAIT_AFTER_CLICK = 1.2

MAX_SECTION_LEN = 15000
MAX_TOTAL_LEN = 8_000_000

WAIT_RESULT_RENDER = 3.0

STUCK_THRESHOLD = 3
MAX_SAME_CLICKS = 4
MAX_NEXT_NO_MOVE = 2
MATCHING_STUB_RETRIES = 2

MAX_MAIN_ITERATIONS = 300
MAX_TOTAL_SECONDS = 240.0

STUCK_PAGE_LIMIT = 300_000

# Текст-заглушка для открытых ответов.
STUB_OPEN_TEXT = "Debug Test"


class _RunnerWrap:
    def __init__(self, driver, logger):
        self.driver = driver
        self.logger = logger or _DummyLogger()
        self.stop_event = threading.Event()
        self.url = ""


class _DummyLogger:
    def info(self, *args, **kwargs): pass
    def warning(self, *args, **kwargs): pass
    def error(self, *args, **kwargs): pass
    def debug(self, *args, **kwargs): pass


def _debug_dir() -> Path:
    d = get_data_dir() / "debug"
    d.mkdir(parents=True, exist_ok=True)
    return d


# ---------------------------------------------------------------------------
# Проверки живости браузера / остановки
# ---------------------------------------------------------------------------

def _browser_alive(driver) -> bool:
    try:
        _ = driver.current_url
        return True
    except Exception:
        return False


def _stop_requested() -> bool:
    try:
        return is_stop_requested()
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Определение, что мы на вопросе
# ---------------------------------------------------------------------------

def _has_answer_elements(driver) -> bool:
    js = """
    var labels = document.querySelectorAll('label.otp-input, label.otp-checkbox');
    for (var i = 0; i < labels.length; i++) {
        if (labels[i].offsetParent !== null) return true;
    }
    var inputs = document.querySelectorAll('input[type=radio], input[type=checkbox]');
    for (var i = 0; i < inputs.length; i++) {
        if (inputs[i].offsetParent !== null) return true;
    }
    return false;
    """
    try:
        return bool(driver.execute_script(js))
    except WebDriverException:
        return False


def _has_matching_block(driver) -> bool:
    try:
        els = driver.find_elements(By.CSS_SELECTOR, "div.matching-div")
    except WebDriverException:
        return False
    for el in els:
        try:
            if el.is_displayed():
                return True
        except (WebDriverException, StaleElementReferenceException):
            continue
    return False


def _has_open_text_input(driver) -> bool:
    """Открытый ответ: input.otp-textbox (без radio/checkbox рядом)."""
    try:
        els = driver.find_elements(By.CSS_SELECTOR, "input.otp-textbox")
    except WebDriverException:
        return False
    for el in els:
        try:
            if not el.is_displayed() or not el.is_enabled():
                continue
            typ = (el.get_attribute("type") or "").lower()
            if typ in ("text", ""):
                return True
        except (WebDriverException, StaleElementReferenceException):
            continue
    return False


def _has_question_block(driver) -> bool:
    js = """
    var sels = [
        '.otp-item-view-question',
        '#d-q-ans-container',
        'div[id^="dq_"]',
        '.qcontainer',
        '.qtext',
        'div.matching-div',
        'table.simpletext-tbl'
    ];
    for (var i = 0; i < sels.length; i++) {
        var els = document.querySelectorAll(sels[i]);
        for (var j = 0; j < els.length; j++) {
            if (els[j].offsetParent !== null) return true;
        }
    }
    var spans = document.querySelectorAll('span, div, p');
    for (var k = 0; k < spans.length; k++) {
        var t = (spans[k].textContent || '').trim();
        if (!t) continue;
        if (t.indexOf('Ответьте, пожалуйста') >= 0 && spans[k].offsetParent !== null) {
            return true;
        }
    }
    return false;
    """
    try:
        return bool(driver.execute_script(js))
    except WebDriverException:
        return False


def _try_click_xpath(driver, xpaths) -> Optional[str]:
    for xp in xpaths:
        try:
            els = driver.find_elements(By.XPATH, xp)
        except WebDriverException:
            continue
        for el in els:
            try:
                driver.execute_script("arguments[0].click();", el)
                return xp
            except (WebDriverException, StaleElementReferenceException):
                try:
                    el.click()
                    return xp
                except (WebDriverException, StaleElementReferenceException):
                    continue
    return None


def _js_click_by_id(driver, element_id: str) -> bool:
    js = f"""
    var el = document.getElementById('{element_id}');
    if (el && el.offsetParent !== null) {{
        el.click();
        return true;
    }}
    return false;
    """
    try:
        return bool(driver.execute_script(js))
    except WebDriverException:
        return False


# ---------------------------------------------------------------------------
# Заглушка для matching
# ---------------------------------------------------------------------------

def _fill_matching_stub(driver, logger=None) -> bool:
    try:
        container = None
        for el in driver.find_elements(By.CSS_SELECTOR, "div.matching-div"):
            try:
                if el.is_displayed():
                    container = el
                    break
            except (WebDriverException, StaleElementReferenceException):
                continue
        if container is None:
            if logger:
                logger.warning("/test stub: matching-div не найден.")
            return False

        selects = container.find_elements(By.CSS_SELECTOR, "select.otp-select")
        if not selects:
            if logger:
                logger.warning("/test stub: в matching нет select-ов.")
            return False

        options_per_select: List[List[str]] = []
        for s in selects:
            try:
                opts = s.find_elements(By.TAG_NAME, "option")
            except WebDriverException:
                opts = []
            values: List[str] = []
            for o in opts:
                try:
                    v = o.get_attribute("value") or ""
                except (WebDriverException, StaleElementReferenceException):
                    continue
                if v and v != "0":
                    values.append(v)
            options_per_select.append(values)

        if logger:
            logger.info(
                f"/test stub: found {len(selects)} select(s); "
                f"options per select: {[len(x) for x in options_per_select]}"
            )

        any_filled = False
        for i, s in enumerate(selects):
            vals = options_per_select[i] if i < len(options_per_select) else []
            if not vals:
                continue
            value = vals[i % len(vals)]
            try:
                from selenium.webdriver.support.ui import Select
                try:
                    Select(s).select_by_value(value)
                except WebDriverException:
                    driver.execute_script(
                        """
                        var s = arguments[0], v = arguments[1];
                        s.value = v;
                        s.dispatchEvent(new Event('input', {bubbles: true}));
                        s.dispatchEvent(new Event('change', {bubbles: true}));
                        if (window.jQuery) {
                            try { jQuery(s).trigger('change'); } catch(e) {}
                            try { jQuery(s).trigger('input'); } catch(e) {}
                        }
                        """,
                        s, value,
                    )
                any_filled = True
            except WebDriverException as exc:
                if logger:
                    logger.debug(f"/test stub: select#{i}: {exc}")

        time.sleep(0.8)
        return any_filled

    except Exception as exc:
        if logger:
            logger.warning(f"/test stub: matching failed: {exc}")
        return False


# ---------------------------------------------------------------------------
# Заглушка для открытого ответа
# ---------------------------------------------------------------------------

def _fill_open_text_stub(driver, logger=None) -> bool:
    """Заполнить первое видимое input.otp-textbox текстом-заглушкой."""
    try:
        els = driver.find_elements(By.CSS_SELECTOR, "input.otp-textbox")
    except WebDriverException:
        return False

    for el in els:
        try:
            if not el.is_displayed() or not el.is_enabled():
                continue
            typ = (el.get_attribute("type") or "").lower()
            if typ not in ("text", ""):
                continue
        except (WebDriverException, StaleElementReferenceException):
            continue

        # Пробуем нативно через send_keys.
        try:
            el.clear()
        except WebDriverException:
            pass
        try:
            el.send_keys(STUB_OPEN_TEXT)
            if logger:
                logger.info(
                    f"/test stub: заполнено открытое поле {STUB_OPEN_TEXT!r}."
                )
            time.sleep(0.4)
            return True
        except WebDriverException:
            pass

        # Fallback: JS.
        try:
            driver.execute_script(
                """
                var el = arguments[0], v = arguments[1];
                el.value = v;
                el.dispatchEvent(new Event('input', {bubbles: true}));
                el.dispatchEvent(new Event('change', {bubbles: true}));
                if (window.jQuery) {
                    try { jQuery(el).trigger('input'); } catch(e) {}
                    try { jQuery(el).trigger('change'); } catch(e) {}
                }
                """,
                el, STUB_OPEN_TEXT,
            )
            if logger:
                logger.info(
                    f"/test stub: заполнено открытое поле (JS) {STUB_OPEN_TEXT!r}."
                )
            time.sleep(0.4)
            return True
        except WebDriverException as exc:
            if logger:
                logger.debug(f"/test stub: open-text JS failed: {exc}")

    return False


def _try_click_finish_button(driver) -> bool:
    try:
        els = driver.find_elements(By.ID, "btnFinish")
    except WebDriverException:
        els = []
    for el in els:
        try:
            if el.is_displayed() and el.is_enabled():
                try:
                    driver.execute_script("arguments[0].click();", el)
                except WebDriverException:
                    el.click()
                return True
        except (WebDriverException, StaleElementReferenceException):
            continue
    for xp in (
        "//input[@value='Завершить']",
        "//button[contains(normalize-space(text()),'Завершить')]",
    ):
        try:
            els = driver.find_elements(By.XPATH, xp)
        except WebDriverException:
            continue
        for el in els:
            try:
                if el.is_displayed() and el.is_enabled():
                    driver.execute_script("arguments[0].click();", el)
                    return True
            except (WebDriverException, StaleElementReferenceException):
                continue
    return False


# ---------------------------------------------------------------------------
# JS-хелперы
# ---------------------------------------------------------------------------

def _js_all_buttons(driver) -> List[dict]:
    js = """
    var out = [];
    var els = document.querySelectorAll('button, a.btn, input[type=submit], input[type=button], [role=button]');
    for (var i = 0; i < els.length; i++) {
        var e = els[i];
        if (e.offsetParent === null) continue;
        out.push({
            tag: e.tagName,
            cls: e.className || '',
            id: e.id || '',
            type: e.getAttribute('type') || '',
            value: e.getAttribute('value') || '',
            text: (e.textContent || '').trim().substring(0, 80),
            onclick: (e.getAttribute('onclick') || '').substring(0, 120),
            displayed: e.offsetParent !== null
        });
    }
    return out;
    """
    try:
        return driver.execute_script(js) or []
    except WebDriverException:
        return []


def _js_all_labels(driver) -> List[dict]:
    js = """
    var out = [];
    var labels = document.querySelectorAll('label');
    for (var i = 0; i < labels.length; i++) {
        var l = labels[i];
        out.push({
            i: i,
            cls: l.className || '',
            text: (l.textContent || '').trim().substring(0, 120),
            id: l.id || '',
            forAttr: l.getAttribute('for') || '',
            displayed: l.offsetParent !== null,
            html: (l.outerHTML || '').substring(0, 400)
        });
    }
    return out;
    """
    try:
        return driver.execute_script(js) or []
    except WebDriverException:
        return []


def _js_all_inputs(driver) -> List[dict]:
    js = """
    var out = [];
    var els = document.querySelectorAll('input[type=radio], input[type=checkbox], input[type=text], textarea');
    for (var i = 0; i < els.length; i++) {
        var e = els[i];
        out.push({
            i: i,
            tag: e.tagName,
            type: e.type || '',
            name: e.name || '',
            id: e.id || '',
            value: (e.value || '').substring(0, 80),
            displayed: e.offsetParent !== null,
            checked: !!e.checked
        });
    }
    return out;
    """
    try:
        return driver.execute_script(js) or []
    except WebDriverException:
        return []


def _js_all_form_fields(driver) -> List[dict]:
    js = """
    var out = [];
    var els = document.querySelectorAll('input, textarea, select');
    for (var i = 0; i < els.length; i++) {
        var e = els[i];
        out.push({
            tag: e.tagName,
            type: e.type || '',
            name: e.name || '',
            id: e.id || '',
            placeholder: e.getAttribute('placeholder') || '',
            value: (e.value || '').substring(0, 160),
            cls: (e.className || '').substring(0, 120),
            displayed: e.offsetParent !== null,
            required: !!e.required,
            readonly: !!e.readOnly,
            disabled: !!e.disabled,
            ariaLabel: e.getAttribute('aria-label') || '',
            maxlength: e.getAttribute('maxlength') || ''
        });
    }
    return out;
    """
    try:
        return driver.execute_script(js) or []
    except WebDriverException:
        return []


def _safe_outer(el, max_len: int = MAX_SECTION_LEN) -> str:
    try:
        html = el.get_attribute("outerHTML") or ""
    except (WebDriverException, StaleElementReferenceException):
        return "(не удалось получить outerHTML)"
    if len(html) > max_len:
        html = html[:max_len] + f"\n... [обрезано, всего {len(html)} символов]"
    return html


# ---------------------------------------------------------------------------
# Fingerprint
# ---------------------------------------------------------------------------

def _page_fingerprint(driver) -> str:
    try:
        url = driver.current_url or ""
    except Exception:
        return "DEAD_DRIVER"

    try:
        txt = driver.execute_script("""
            var q = document.querySelector('.otp-item-view-question[id^="dq_"]');
            if (q && q.id) return 'DQ:' + q.id;
            if (location.href.indexOf('testresult') >= 0) return 'RESULT:' + location.href;
            var md = document.querySelector('div.matching-div');
            if (md && md.offsetParent !== null) {
                var t = document.querySelector('.qtext');
                var qt = t ? (t.textContent || '').trim().substring(0, 60) : '';
                return 'M:' + md.id + ':' + qt;
            }
            var num = document.querySelector('.otp-item-view-question .qnumber .num');
            if (num) return 'Q:' + (num.textContent || '').trim();
            var spans = document.querySelectorAll('span, div, p');
            for (var k = 0; k < spans.length; k++) {
                var tx = (spans[k].textContent || '').trim();
                if (tx && tx.indexOf('Ответьте, пожалуйста') >= 0) {
                    return 'ALERT:' + tx.substring(0, 60);
                }
            }
            var body = document.body ? (document.body.innerText || '') : '';
            return 'B:' + body.substring(0, 120);
        """) or ""
    except Exception:
        txt = "JS_FAIL"

    return f"{url}:::{txt}"


# ---------------------------------------------------------------------------
# Снимки
# ---------------------------------------------------------------------------

def _snapshot_question(driver, qnum: int) -> str:
    parts: List[str] = []
    parts.append(f"\n{'=' * 72}")
    parts.append(f"QUESTION #{qnum}")
    parts.append(f"{'=' * 72}")

    try:
        parts.append(f"URL: {driver.current_url}")
    except WebDriverException:
        parts.append("URL: (недоступен)")

    try:
        els = driver.find_elements(By.CSS_SELECTOR, "span.qtext")
        parts.append(f"\n--- span.qtext ({len(els)} шт.) ---")
        if els:
            parts.append(_safe_outer(els[0]))
        else:
            parts.append("(не найден)")
    except WebDriverException as exc:
        parts.append(f"(ошибка span.qtext: {exc})")

    cont_found = False
    for sel_css in (
        "#d-q-ans-container",
        "div[id='d-q-ans-container']",
        "[id*='ans-container']",
        "div.matching-div",
    ):
        try:
            els = driver.find_elements(By.CSS_SELECTOR, sel_css)
        except WebDriverException:
            continue
        if els:
            parts.append(f"\n--- {sel_css} ---")
            parts.append(_safe_outer(els[0], 25000))
            cont_found = True
            break
    if not cont_found:
        parts.append("\n--- Контейнер вариантов ответа ---")
        parts.append("(не найден)")

    parts.append("\n--- JS: видимые кнопки ---")
    for b in _js_all_buttons(driver):
        parts.append(
            f"  <{b['tag']}> id={b['id']!r} class={b['cls']!r} "
            f"type={b['type']!r} value={b['value']!r} text={b['text']!r} "
            f"onclick={b['onclick']!r}"
        )

    parts.append("\n--- JS: input/textarea ---")
    for inp in _js_all_inputs(driver):
        parts.append(
            f"  [{inp['i']}] <{inp['tag']}> type={inp['type']!r} "
            f"name={inp['name']!r} id={inp['id']!r} value={inp['value']!r} "
            f"displayed={inp['displayed']} checked={inp['checked']}"
        )

    return "\n".join(parts)


def _snapshot_modal(driver, label: str) -> str:
    parts: List[str] = []
    parts.append(f"\n{'=' * 72}")
    parts.append(f"{label}")
    parts.append(f"{'=' * 72}")
    try:
        parts.append(f"URL: {driver.current_url}")
    except WebDriverException:
        pass

    try:
        els = driver.find_elements(By.CSS_SELECTOR, ".modal, .modal-content, .modal-dialog")
        if els:
            parts.append("\n--- .modal ---")
            parts.append(_safe_outer(els[0], 8000))
    except WebDriverException:
        pass

    parts.append("\n--- JS: видимые кнопки ---")
    for b in _js_all_buttons(driver):
        parts.append(
            f"  <{b['tag']}> id={b['id']!r} class={b['cls']!r} "
            f"type={b['type']!r} value={b['value']!r} text={b['text']!r}"
        )
    return "\n".join(parts)


def _snapshot_result_page(driver, label: str, body_limit: int = MAX_SECTION_LEN) -> str:
    parts: List[str] = []
    parts.append(f"\n{'=' * 72}")
    parts.append(f"{label}")
    parts.append(f"{'=' * 72}")

    try:
        driver.switch_to.default_content()
    except WebDriverException:
        pass

    try:
        parts.append(f"URL: {driver.current_url}")
        parts.append(f"TITLE: {driver.title}")
    except WebDriverException:
        pass

    parts.append("\n--- JS: видимые кнопки ---")
    for b in _js_all_buttons(driver):
        parts.append(
            f"  <{b['tag']}> id={b['id']!r} class={b['cls']!r} "
            f"text={b['text']!r} onclick={b['onclick']!r}"
        )

    all_fields = _js_all_form_fields(driver)
    parts.append(f"\n--- JS: все поля ввода (input/textarea/select), "
                 f"всего {len(all_fields)} ---")
    for idx, f in enumerate(all_fields):
        parts.append(
            f"  [{idx}] <{f['tag']}> type={f['type']!r} "
            f"name={f['name']!r} id={f['id']!r} "
            f"placeholder={f['placeholder']!r} "
            f"value={f['value']!r} "
            f"cls={f['cls']!r} "
            f"displayed={f['displayed']} required={f['required']} "
            f"readonly={f['readonly']} disabled={f['disabled']} "
            f"maxlength={f['maxlength']!r} aria-label={f['ariaLabel']!r}"
        )

    try:
        html = driver.execute_script(
            "return document.body ? document.body.outerHTML : '';"
        ) or ""
    except WebDriverException:
        html = ""

    if html:
        parts.append("\n--- Поиск по HTML (ключевые слова) ---")
        low = html.lower()
        for needle in (
            "соответств", "соотнести", "установите соответствие",
            "перетащи", "drag", "drop", "sortable",
            "sequence", "порядок", "match",
            "фамил", "фио", "введите", "surname", "lastname",
            "firstname", "отчество", "имя",
            "ответьте, пожалуйста",
        ):
            pos = low.find(needle)
            if pos < 0:
                continue
            start = max(0, pos - 200)
            end = min(len(html), pos + 500)
            snippet = html[start:end].replace("\n", " ")
            parts.append(f"  [{needle}] @{pos}: ...{snippet}...")

    parts.append("\n--- body (обрезано) ---")
    if len(html) > body_limit:
        parts.append(html[:body_limit]
                     + f"\n... [обрезано, всего {len(html)} символов]")
    else:
        parts.append(html or "(пусто)")

    return "\n".join(parts)


def _snapshot_score(driver, label: str) -> str:
    parts: List[str] = []
    parts.append(f"\n{'=' * 72}")
    parts.append(f"{label}")
    parts.append(f"{'=' * 72}")

    try:
        from automation.navigation import extract_result_score
    except Exception as exc:
        parts.append(f"(не удалось импортировать extract_result_score: {exc})")
        return "\n".join(parts)

    wrapper = _RunnerWrap(driver, None)
    try:
        score = extract_result_score(wrapper)
    except Exception as exc:
        parts.append(f"(ошибка при извлечении результата: {exc})")
        return "\n".join(parts)

    parts.append(f"percent:      {score.get('percent')}")
    parts.append(f"correct:      {score.get('correct')}")
    parts.append(f"total:        {score.get('total')}")
    parts.append(f"points:       {score.get('points')}")
    parts.append(f"max_points:   {score.get('max_points')}")
    parts.append(f"grade:        {score.get('grade')}")

    raw = (score.get("raw") or "").strip()
    if raw:
        parts.append("")
        parts.append("--- raw (первые 3000 символов innerText) ---")
        parts.append(raw)

    return "\n".join(parts)


# ---------------------------------------------------------------------------
# Довести до первого вопроса
# ---------------------------------------------------------------------------

_START_BUTTON_XPATHS = [
    "//button[contains(normalize-space(text()),'Принять')]",
    "//button[contains(normalize-space(text()),'Согласен')]",
    "//button[contains(normalize-space(text()),'Продолжить')]",
    "//input[@id='btnNext']",
    "//input[@id='btnFinish']",
    "//button[contains(normalize-space(text()),'Начать')]",
    "//button[contains(normalize-space(text()),'Пройти')]",
    "//button[contains(normalize-space(text()),'Старт')]",
    "//a[contains(normalize-space(text()),'Начать')]",
    "//a[contains(normalize-space(text()),'Пройти')]",
    "//a[contains(normalize-space(text()),'Старт')]",
    "//button[contains(normalize-space(text()),'Далее')]",
]


def _ensure_first_question(
    driver, logger, timeout: float = WAIT_FIRST_QUESTION,
) -> Tuple[bool, List[str], str]:
    log_lines: List[str] = []

    if _has_answer_elements(driver):
        log_lines.append("Уже на первом вопросе (radio/checkbox видны).")
        return True, log_lines, ""
    if _has_matching_block(driver):
        log_lines.append("Уже на первом вопросе (matching через select).")
        return True, log_lines, ""
    if _has_open_text_input(driver):
        log_lines.append("Уже на первом вопросе (открытый ответ).")
        return True, log_lines, ""
    if _has_question_block(driver):
        log_lines.append(
            "Уже на первом вопросе (неизвестный тип)."
        )
        return True, log_lines, ""

    end = time.time() + timeout
    iteration = 0
    max_iterations = 20
    last_clicked: Optional[str] = None
    same_clicks = 0

    while time.time() < end and iteration < max_iterations:
        iteration += 1

        if not _browser_alive(driver):
            log_lines.append("Браузер перестал отвечать — прерываю.")
            return False, log_lines, "Chrome не отвечает"

        if _has_answer_elements(driver):
            log_lines.append(f"Первый вопрос (radio) на итерации {iteration}.")
            return True, log_lines, ""
        if _has_matching_block(driver):
            log_lines.append(f"Первый вопрос (matching) на итерации {iteration}.")
            return True, log_lines, ""
        if _has_open_text_input(driver):
            log_lines.append(f"Первый вопрос (открытый ответ) на итерации {iteration}.")
            return True, log_lines, ""
        if _has_question_block(driver):
            log_lines.append(
                f"Первый вопрос (неизвестный тип) на итерации {iteration}."
            )
            return True, log_lines, ""

        used = _try_click_xpath(driver, _START_BUTTON_XPATHS)
        if used:
            log_lines.append(f"[{iteration}] клик: {used}")

            if used == last_clicked:
                same_clicks += 1
            else:
                same_clicks = 1
                last_clicked = used

            if same_clicks >= MAX_SAME_CLICKS:
                reason = (
                    f"Кнопка '{used}' нажата {same_clicks} раз подряд — "
                    "страница не меняется."
                )
                log_lines.append(reason)
                if logger:
                    logger.warning(f"/test: {reason}")
                return False, log_lines, reason

            time.sleep(WAIT_AFTER_CLICK)
            continue

        if _js_click_by_id(driver, "btnNext"):
            log_lines.append(f"[{iteration}] JS-клик по #btnNext")
            time.sleep(WAIT_AFTER_CLICK)
            continue

        log_lines.append(f"[{iteration}] ни одна кнопка не найдена")
        time.sleep(0.5)

    if (_has_answer_elements(driver) or _has_matching_block(driver)
            or _has_open_text_input(driver) or _has_question_block(driver)):
        return True, log_lines, ""

    reason = (
        f"За {timeout} сек ({iteration} итераций) первый вопрос не появился."
    )
    log_lines.append(reason)
    if logger:
        logger.warning(f"/test: {reason}")
    return False, log_lines, reason


# ---------------------------------------------------------------------------
# Основная функция
# ---------------------------------------------------------------------------

def collect_debug(url: str, logger=None) -> Optional[Path]:
    def _log(msg):
        if logger:
            try:
                logger.info(msg)
            except Exception:
                pass

    try:
        if _stop_requested():
            _log("/test: сбрасываю глобальный флаг «Стоп всё» перед сбором.")
        clear_stop()
    except Exception as exc:
        _log(f"/test: не удалось сбросить глобальный флаг: {exc}")

    from automation.browser import open_browser, close_and_cleanup

    _log(f"/test: старт сбора отчёта по {url}")

    reports: List[str] = []
    reports.append("=" * 72)
    reports.append(f"DEBUG REPORT от {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    reports.append(f"URL: {url}")
    reports.append("=" * 72)

    try:
        reports.append(f"Глобальный флаг остановки: {is_stop_requested()}")
    except Exception:
        pass

    driver = None
    started_at = time.time()
    aborted_reason = ""
    saved_path: Optional[Path] = None

    try:
        driver = open_browser(logger)
        driver.get(url)
        time.sleep(1.5)
        _log("/test: страница загружена.")

        wrap = _RunnerWrap(driver, logger)
        reports.append(f"stop_event.is_set(): {wrap.stop_event.is_set()}")

        reports.append(_snapshot_result_page(driver, "START PAGE (до нажатия)"))

        ok, ensure_log, ensure_reason = _ensure_first_question(
            driver, logger, timeout=WAIT_FIRST_QUESTION,
        )
        reports.append(f"\n{'=' * 72}")
        reports.append("ENSURE FIRST QUESTION (журнал)")
        reports.append(f"{'=' * 72}")
        reports.append(f"Успех: {ok}")
        for line in ensure_log:
            reports.append(f"  {line}")

        if not ok:
            aborted_reason = f"Не дошли до вопроса: {ensure_reason}"
            reports.append(f"\n!!! {aborted_reason}")
            if _browser_alive(driver):
                reports.append(_snapshot_result_page(
                    driver,
                    "STUCK AT START — ПОЛНЫЙ HTML ДЛЯ РАЗБОРА",
                    body_limit=STUCK_PAGE_LIMIT,
                ))
        else:
            from automation.navigation import (
                click_confirm_yes,
                go_to_next,
                has_confirm_finish_modal,
                is_result_page,
            )
            from automation.questions import answer_current_question

            attempts = 0
            questions_done = 0
            last_fp = ""
            stuck_count = 0
            same_next_clicks = 0
            matching_retries = 0

            while attempts < MAX_MAIN_ITERATIONS:
                attempts += 1

                if time.time() - started_at > MAX_TOTAL_SECONDS:
                    aborted_reason = (
                        f"Превышен лимит времени {MAX_TOTAL_SECONDS:.0f} сек."
                    )
                    reports.append(f"\n!!! {aborted_reason}")
                    break

                if not _browser_alive(driver):
                    aborted_reason = (
                        "Chrome не отвечает (вероятно, «Стоп всё»)."
                    )
                    _log(f"/test: {aborted_reason}")
                    reports.append(f"\n!!! {aborted_reason}")
                    break

                try:
                    if is_result_page(wrap):
                        reports.append(
                            f"\n\n>>> СТРАНИЦА РЕЗУЛЬТАТА (шаг {attempts})\n"
                        )
                        _log("/test: достигли страницы результата.")
                        break
                except Exception:
                    pass

                try:
                    if has_confirm_finish_modal(wrap):
                        reports.append(
                            _snapshot_modal(driver, f"MODAL (шаг {attempts})")
                        )
                        click_confirm_yes(wrap)
                        time.sleep(1.0)
                        continue
                except Exception:
                    pass

                fp = _page_fingerprint(driver)
                if fp == last_fp:
                    stuck_count += 1
                else:
                    stuck_count = 0
                    last_fp = fp
                    matching_retries = 0

                if stuck_count >= STUCK_THRESHOLD:
                    aborted_reason = (
                        f"Страница не меняется {stuck_count} итераций подряд."
                    )
                    _log(f"/test: {aborted_reason}")
                    reports.append(f"\n\n!!! {aborted_reason}")
                    reports.append(_snapshot_result_page(
                        driver,
                        "STUCK PAGE — ПОЛНЫЙ HTML ДЛЯ РАЗБОРА",
                        body_limit=STUCK_PAGE_LIMIT,
                    ))
                    break

                # --- Matching через select --- #
                if _has_matching_block(driver):
                    questions_done += 1
                    reports.append(_snapshot_question(driver, questions_done))
                    reports.append(
                        "\n[STUB] matching detected — заполняю select-ы."
                    )
                    _log("/test: matching stub — заполняю select-ы.")

                    filled = _fill_matching_stub(driver, logger)
                    reports.append(f"[STUB] matching filled: {filled}")
                    matching_retries += 1

                    fp_before = _page_fingerprint(driver)

                    if matching_retries >= MATCHING_STUB_RETRIES + 1:
                        _log(
                            "/test: matching stub не сработал несколько раз — "
                            "пробую нажать «Завершить»."
                        )
                        reports.append(
                            "\n[STUB] matching не проходит — жму «Завершить»."
                        )
                        if _try_click_finish_button(driver):
                            time.sleep(1.5)
                            try:
                                if has_confirm_finish_modal(wrap):
                                    click_confirm_yes(wrap)
                                    time.sleep(1.5)
                            except Exception:
                                pass
                            continue

                    try:
                        if not go_to_next(wrap):
                            reports.append(
                                "\n!!! 'Далее' не найдена после matching stub."
                            )
                            aborted_reason = "Не найдена 'Далее' после matching stub."
                            break
                    except Exception as exc:
                        reports.append(
                            f"\n!!! Ошибка перехода после matching stub: {exc}"
                        )
                        aborted_reason = f"Ошибка перехода: {exc}"
                        break

                    time.sleep(0.8)
                    fp_after = _page_fingerprint(driver)
                    if fp_after == fp_before:
                        same_next_clicks += 1
                        reports.append(
                            f"\n[!] После matching stub страница не "
                            f"изменилась (повтор {same_next_clicks}/"
                            f"{MAX_NEXT_NO_MOVE})"
                        )
                        if same_next_clicks >= MAX_NEXT_NO_MOVE:
                            _log(
                                "/test: matching stub застрял — "
                                "пробую нажать «Завершить»."
                            )
                            if _try_click_finish_button(driver):
                                time.sleep(1.5)
                                try:
                                    if has_confirm_finish_modal(wrap):
                                        click_confirm_yes(wrap)
                                        time.sleep(1.5)
                                except Exception:
                                    pass
                                same_next_clicks = 0
                                continue
                    else:
                        same_next_clicks = 0
                    continue

                # --- Обычный вопрос с radio/checkbox --- #
                if _has_answer_elements(driver):
                    questions_done += 1
                    try:
                        reports.append(_snapshot_question(driver, questions_done))
                    except Exception as exc:
                        reports.append(
                            f"\n!!! Ошибка снапшота #{questions_done}: {exc}"
                        )

                    try:
                        if not answer_current_question(wrap):
                            reports.append(
                                f"\n!!! Не удалось кликнуть ответ #{questions_done}."
                            )
                            aborted_reason = "Не удалось кликнуть ответ."
                            break
                    except Exception as exc:
                        reports.append(
                            f"\n!!! Ошибка клика #{questions_done}: {exc}"
                        )
                        aborted_reason = f"Ошибка клика: {exc}"
                        break

                    fp_before = _page_fingerprint(driver)
                    try:
                        if not go_to_next(wrap):
                            reports.append(
                                f"\n!!! 'Далее' не найдена после #{questions_done}."
                            )
                            aborted_reason = "Не найдена кнопка 'Далее'."
                            break
                    except Exception as exc:
                        reports.append(
                            f"\n!!! Ошибка перехода #{questions_done}: {exc}"
                        )
                        aborted_reason = f"Ошибка перехода: {exc}"
                        break

                    time.sleep(0.5)
                    fp_after = _page_fingerprint(driver)
                    if fp_after == fp_before:
                        same_next_clicks += 1
                        reports.append(
                            f"\n[!] После #{questions_done} страница не "
                            f"изменилась (повтор {same_next_clicks}/"
                            f"{MAX_NEXT_NO_MOVE})"
                        )
                        if same_next_clicks >= MAX_NEXT_NO_MOVE:
                            aborted_reason = (
                                f"Кнопка 'Далее' {MAX_NEXT_NO_MOVE} раза "
                                "не сдвинула страницу."
                            )
                            reports.append(f"\n!!! {aborted_reason}")
                            reports.append(_snapshot_result_page(
                                driver,
                                "STUCK AFTER 'ДАЛЕЕ' — ПОЛНЫЙ HTML",
                                body_limit=STUCK_PAGE_LIMIT,
                            ))
                            break
                    else:
                        same_next_clicks = 0

                    time.sleep(0.3)
                    continue

                # --- Открытый ответ (input.otp-textbox) --- #
                if _has_open_text_input(driver):
                    questions_done += 1
                    try:
                        reports.append(_snapshot_question(driver, questions_done))
                    except Exception as exc:
                        reports.append(
                            f"\n!!! Ошибка снапшота #{questions_done}: {exc}"
                        )

                    reports.append(
                        f"\n[STUB] открытый ответ — заполняю "
                        f"{STUB_OPEN_TEXT!r}."
                    )
                    _log("/test: open-text stub — заполняю поле.")

                    filled = _fill_open_text_stub(driver, logger)
                    reports.append(f"[STUB] open-text filled: {filled}")

                    fp_before = _page_fingerprint(driver)
                    try:
                        if not go_to_next(wrap):
                            reports.append(
                                f"\n!!! 'Далее' не найдена после open-text."
                            )
                            aborted_reason = "Не найдена 'Далее' после open-text."
                            break
                    except Exception as exc:
                        reports.append(
                            f"\n!!! Ошибка перехода после open-text: {exc}"
                        )
                        aborted_reason = f"Ошибка перехода: {exc}"
                        break

                    time.sleep(0.6)
                    fp_after = _page_fingerprint(driver)
                    if fp_after == fp_before:
                        same_next_clicks += 1
                        reports.append(
                            f"\n[!] После open-text страница не изменилась "
                            f"(повтор {same_next_clicks}/{MAX_NEXT_NO_MOVE})"
                        )
                        if same_next_clicks >= MAX_NEXT_NO_MOVE:
                            aborted_reason = (
                                "open-text stub не сдвинул страницу."
                            )
                            reports.append(f"\n!!! {aborted_reason}")
                            reports.append(_snapshot_result_page(
                                driver,
                                "STUCK AFTER OPEN-TEXT — ПОЛНЫЙ HTML",
                                body_limit=STUCK_PAGE_LIMIT,
                            ))
                            break
                    else:
                        same_next_clicks = 0
                    continue

                # --- Неизвестный тип --- #
                if _has_question_block(driver):
                    aborted_reason = (
                        "Найден блок вопроса неизвестного типа "
                        "(не matching, не open-text, не radio/checkbox)."
                    )
                    _log(f"/test: {aborted_reason}")
                    reports.append(f"\n\n!!! {aborted_reason}")
                    reports.append(_snapshot_result_page(
                        driver,
                        "UNKNOWN QUESTION TYPE — ПОЛНЫЙ HTML ДЛЯ РАЗБОРА",
                        body_limit=STUCK_PAGE_LIMIT,
                    ))
                    break

                # --- Не поняли что на странице --- #
                used = _try_click_xpath(driver, _START_BUTTON_XPATHS)
                if used:
                    if logger:
                        logger.info(
                            f"/test: до вопроса нажата кнопка {used[:60]}."
                        )
                    time.sleep(WAIT_AFTER_CLICK)
                    continue

                reports.append(
                    "\n!!! Не удалось найти ни вариант ответа, ни кнопку."
                )
                aborted_reason = "Нет ни ответов, ни кнопок."
                reports.append(_snapshot_result_page(
                    driver,
                    "NO-ACTION PAGE — ПОЛНЫЙ HTML",
                    body_limit=STUCK_PAGE_LIMIT,
                ))
                break

            # --- Финальные снимки --- #
            try:
                _log(
                    f"/test: жду отрисовки страницы результата "
                    f"({WAIT_RESULT_RENDER} сек)..."
                )
                time.sleep(WAIT_RESULT_RENDER)

                if _browser_alive(driver):
                    reports.append(_snapshot_result_page(
                        driver,
                        "RESULT PAGE (до 'Показать мои ответы')",
                        body_limit=90000,
                    ))
                    reports.append(_snapshot_score(
                        driver, "SCORE (до 'Показать мои ответы')"
                    ))

                    try:
                        for xp in sel.SHOW_ANSWERS_BUTTON_XPATHS:
                            els = driver.find_elements(By.XPATH, xp)
                            clicked_show = False
                            for el in els:
                                try:
                                    if el.is_displayed() and el.is_enabled():
                                        try:
                                            el.click()
                                        except WebDriverException:
                                            driver.execute_script(
                                                "arguments[0].click();", el
                                            )
                                        clicked_show = True
                                        _log(
                                            "/test: нажата 'Показать мои "
                                            f"ответы' ({xp[:60]})."
                                        )
                                        break
                                except (
                                    WebDriverException,
                                    StaleElementReferenceException,
                                ):
                                    continue
                            if clicked_show:
                                break
                    except WebDriverException:
                        pass

                    time.sleep(2.5)

                    reports.append(_snapshot_result_page(
                        driver,
                        "ANSWERS PAGE (после 'Показать мои ответы')",
                        body_limit=120000,
                    ))
                    reports.append(_snapshot_score(
                        driver, "SCORE (после 'Показать мои ответы')"
                    ))
                else:
                    reports.append(
                        "\n!!! Chrome умер — финальные снимки недоступны, "
                        "сохраняю то, что успели собрать."
                    )
            except Exception as exc:
                reports.append(
                    f"\n!!! Ошибка при снятии финальных снимков: {exc}"
                )

    except Exception as exc:
        _log(f"/test: исключение при сборе: {exc}")
        reports.append(f"\n\n!!! Исключение при сборе: {exc}")

    # ------------------------------------------------------------------ #
    # ВСЕГДА сохраняем файл.
    # ------------------------------------------------------------------ #

    if aborted_reason:
        reports.append(f"\n{'=' * 72}")
        reports.append(f"ИТОГ: сбор прерван — {aborted_reason}")
        reports.append(f"{'=' * 72}")

    text = "\n".join(reports)
    if len(text) > MAX_TOTAL_LEN:
        text = text[:MAX_TOTAL_LEN] + "\n\n... [ОБРЕЗАНО по общему лимиту]"

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    try:
        path = _debug_dir() / f"debug_{ts}.txt"
        path.write_text(text, encoding="utf-8")
        saved_path = path
        _log(
            f"/test: отчёт сохранён в {path} (размер {len(text)} символов)."
        )
    except Exception as exc:
        _log(f"/test: не удалось сохранить отчёт: {exc}")
        saved_path = None

    if driver is not None:
        try:
            close_and_cleanup(driver, logger)
            _log("/test: браузер закрыт.")
        except Exception:
            pass

    return saved_path