"""Центральный менеджер Job и приоритетная очередь."""
from __future__ import annotations

import threading
import time
from typing import Callable, Dict, List, Optional

from .event_bus import EventBus
from .job import Job, JobPriority, JobState, TERMINAL_STATES
from .worker_context import WorkerContext


class JobManager:
    def __init__(self, logger, event_bus: Optional[EventBus] = None, worker_count: int = 1):
        self.logger = logger
        self.events = event_bus or EventBus(logger)
        self.worker_count = max(1, int(worker_count))
        self._jobs: Dict[str, Job] = {}
        self._pending: List[Job] = []
        self._callbacks: Dict[str, Callable[[Job], None]] = {}
        self._lock = threading.RLock()
        self._wake = threading.Condition(self._lock)
        self._stop = False
        self._threads: List[threading.Thread] = []
        self._active: Dict[str, Job] = {}
        self._worker_seq = 0
        self._contexts: Dict[str, WorkerContext] = {}

    def start(self) -> None:
        with self._lock:
            if self._threads:
                return
            self._stop = False
            for _ in range(self.worker_count):
                self._worker_seq += 1
                worker_id = f"worker-{self._worker_seq}"
                context = WorkerContext(worker_id, self.events, self.logger)
                self._contexts[worker_id] = context
                context.start()
                t = threading.Thread(target=self._worker_loop, args=(worker_id,), name=worker_id, daemon=True)
                self._threads.append(t)
                t.start()
        self.events.publish("WorkerPoolStarted", worker_count=self.worker_count)

    def stop(self, cancel_pending: bool = True) -> None:
        with self._lock:
            self._stop = True
            if cancel_pending:
                for job in self._pending:
                    job.cancel_event.set()
                    if job.state == JobState.QUEUED:
                        job.transition(JobState.CANCELLED, stage="cancelled")
                        self.events.publish("JobCancelled", job=job.to_dict())
                self._pending.clear()
            self._wake.notify_all()
        for t in list(self._threads):
            if t.is_alive():
                t.join(timeout=3)
        with self._lock:
            self._threads.clear()
        with self._lock:
            contexts = list(self._contexts.values())
            self._contexts.clear()
        for context in contexts:
            context.close_all()
            context.stop()
        self.events.publish("WorkerPoolStopped")

    def submit(self, job: Job, callback: Callable[[Job], None]) -> str:
        with self._lock:
            if job.id in self._jobs:
                raise ValueError(f"Job ID уже существует: {job.id}")
            self._jobs[job.id] = job
            self._callbacks[job.id] = callback
            self._pending.append(job)
            self._wake.notify()
        self.events.publish("JobCreated", job=job.to_dict())
        return job.id

    def get(self, job_id: str) -> Optional[Job]:
        with self._lock:
            return self._jobs.get(job_id)

    def update(self, job: Job, state: Optional[JobState] = None, **fields) -> None:
        with self._lock:
            if state is not None:
                job.transition(state, stage=fields.pop("stage", None), error=fields.pop("error", ""))
            for key, value in fields.items():
                if hasattr(job, key):
                    setattr(job, key, value)
            snapshot = job.to_dict()
        event = "JobStateChanged" if state is not None else "JobProgress"
        self.events.publish(event, job=snapshot)

    def set_progress(self, job: Job, progress: float, *, stage: Optional[str] = None, current_question: Optional[int] = None, total_questions: Optional[int] = None) -> None:
        with self._lock:
            job.progress = max(0.0, min(100.0, float(progress)))
            if stage is not None:
                job.stage = stage
            if current_question is not None:
                job.current_question = int(current_question)
            if total_questions is not None:
                job.total_questions = int(total_questions)
            snapshot = job.to_dict()
        self.events.publish("JobProgress", job=snapshot)

    def cancel(self, job_id: str) -> bool:
        with self._lock:
            job = self._jobs.get(job_id)
            if not job or job.state in TERMINAL_STATES:
                return False
            job.cancel_event.set()
            if job.state == JobState.QUEUED:
                job.transition(JobState.CANCELLED, stage="cancelled")
                self._pending = [j for j in self._pending if j.id != job_id]
                self.events.publish("JobCancelled", job=job.to_dict())
            elif job.state not in (JobState.CANCELLING, JobState.CANCELLED):
                job.transition(JobState.CANCELLING, stage="cancelling")
                self.events.publish("JobStateChanged", job=job.to_dict())
            self._wake.notify_all()
            return True

    def clear_pending(self) -> int:
        with self._lock:
            jobs = list(self._pending)
            self._pending.clear()
            count = 0
            for job in jobs:
                if job.state == JobState.QUEUED:
                    job.cancel_event.set()
                    job.transition(JobState.CANCELLED, stage="cancelled")
                    count += 1
                    self.events.publish("JobCancelled", job=job.to_dict())
            return count

    def cancel_all(self) -> int:
        with self._lock:
            jobs = [j for j in self._jobs.values() if j.state not in TERMINAL_STATES]
        count = 0
        for job in jobs:
            if self.cancel(job.id):
                count += 1
        return count

    def snapshot(self, include_history: bool = True) -> dict:
        with self._lock:
            jobs = list(self._jobs.values())
            pending = sorted((j for j in self._pending if j.state == JobState.QUEUED), key=lambda j: (-j.effective_priority(), j.created_at, j.id))
            active = [j for j in jobs if j.state not in TERMINAL_STATES and j.id not in {x.id for x in pending}]
            history = [j for j in jobs if j.state in TERMINAL_STATES]
            result = {
                "queued": [j.to_dict() for j in pending],
                "active": [j.to_dict() for j in active],
                "queue_size": len(pending),
                "running": len(active),
            }
            if include_history:
                result["history"] = [j.to_dict() for j in sorted(history, key=lambda x: x.finished_at or 0, reverse=True)[:50]]
            return result

    def _next_job(self) -> Optional[Job]:
        if not self._pending:
            return None
        self._pending.sort(key=lambda j: (-j.effective_priority(), j.created_at, j.id))
        return self._pending.pop(0)

    def _worker_loop(self, worker_id: str) -> None:
        self.events.publish("WorkerStarted", worker_id=worker_id)
        while True:
            with self._lock:
                while not self._stop and not self._pending:
                    self._wake.wait(timeout=1.0)
                if self._stop:
                    break
                job = self._next_job()
                if job is None:
                    continue
                job.worker_id = worker_id
                self._active[job.id] = job
                callback = self._callbacks.get(job.id)
                context = self._contexts.get(worker_id)
                if context:
                    context.set_job(job.id)
                if job.cancel_event.is_set():
                    job.transition(JobState.CANCELLED, stage="cancelled")
                    self._active.pop(job.id, None)
                    self.events.publish("JobCancelled", job=job.to_dict())
                    continue
                job.transition(JobState.STARTING, stage="starting")
                self.events.publish("JobStarted", job=job.to_dict())
            try:
                if callback is None:
                    raise RuntimeError("Для Job не назначен callback")
                callback(job, context)
                with self._lock:
                    if job.state not in TERMINAL_STATES:
                        if job.cancel_event.is_set():
                            job.transition(JobState.CANCELLED, stage="cancelled")
                        else:
                            job.transition(JobState.COMPLETED, stage="completed")
                    snapshot = job.to_dict()
            except Exception as exc:
                with self._lock:
                    if job.state not in TERMINAL_STATES:
                        job.transition(JobState.FAILED, stage="failed", error=str(exc))
                    snapshot = job.to_dict()
                if self.logger:
                    self.logger.error(f"Job {job.id} завершилась ошибкой: {exc}")
                self.events.publish("JobFailed", job=snapshot)
            else:
                self.events.publish("JobCompleted" if job.state == JobState.COMPLETED else "JobCancelled", job=snapshot)
            finally:
                with self._lock:
                    self._active.pop(job.id, None)
                    if context:
                        context.set_job(None)
                    self._wake.notify_all()
        self.events.publish("WorkerStopped", worker_id=worker_id)
