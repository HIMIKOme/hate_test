"""Определение локального IP-адреса машины в локальной сети.

Нужен, чтобы показать/отправить пользователю рабочий адрес веб-панели:
сервер слушает 0.0.0.0, но в браузере по 0.0.0.0 зайти нельзя — нужен
конкретный LAN-адрес вида 192.168.x.x.
"""
from __future__ import annotations

import socket
from typing import List


def _is_lan_ip(ip: str) -> bool:
    if not ip or ip.startswith("127.") or ip == "0.0.0.0":
        return False
    parts = ip.split(".")
    if len(parts) != 4:
        return False
    try:
        a, b = int(parts[0]), int(parts[1])
    except ValueError:
        return False
    # 10.0.0.0/8
    if a == 10:
        return True
    # 172.16.0.0/12
    if a == 172 and 16 <= b <= 31:
        return True
    # 192.168.0.0/16
    if a == 192 and b == 168:
        return True
    return False


def _rank(ip: str) -> int:
    # Домашние/офисные 192.168.* — самые частые, ставим их первыми.
    if ip.startswith("192.168."):
        return 0
    if ip.startswith("10."):
        return 1
    return 2


def get_all_lan_ips() -> List[str]:
    """Все LAN IPv4-адреса машины, отсортированные по 'типичности'."""
    found: List[str] = []
    seen = set()

    # Способ 1: UDP-сокет к внешнему адресу (пакеты реально не уходят).
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            if _is_lan_ip(ip) and ip not in seen:
                seen.add(ip)
                found.append(ip)
        finally:
            s.close()
    except OSError:
        pass

    # Способ 2: перебор имён хоста (ловит случаи с несколькими адаптерами).
    try:
        hostname = socket.gethostname()
        for info in socket.getaddrinfo(hostname, None, socket.AF_INET):
            ip = info[4][0]
            if _is_lan_ip(ip) and ip not in seen:
                seen.add(ip)
                found.append(ip)
    except OSError:
        pass

    found.sort(key=_rank)
    return found


def get_lan_ip() -> str:
    """Основной LAN IPv4. Если не нашли — возвращает '127.0.0.1'."""
    ips = get_all_lan_ips()
    if ips:
        return ips[0]
    return "127.0.0.1"