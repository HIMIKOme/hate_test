"""Быстрая проверка ссылок.

Использует HEAD-запрос (без тела ответа) — в разы быстрее, чем GET
на страницу с большим HTML. Если сервер не поддерживает HEAD (редко),
сработает fallback.
"""
from __future__ import annotations

import urllib.error
import urllib.request

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/120.0.0.0 Safari/537.36"
)

# HEAD-запрос обычно отвечает за 0.1–0.5 сек.
DEFAULT_TIMEOUT = 4.0


def _request(url: str, method: str, timeout: float) -> bool:
    req = urllib.request.Request(url, method=method)
    req.add_header("User-Agent", USER_AGENT)
    req.add_header("Accept", "text/html,*/*")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            code = getattr(resp, "status", None) or resp.getcode()
            return 200 <= int(code) < 400
    except urllib.error.HTTPError as e:
        # 405 Method Not Allowed — сервер не поддерживает HEAD.
        if e.code == 405 and method == "HEAD":
            return _request(url, "GET", timeout)
        return 200 <= e.code < 400
    except Exception:
        return False


def is_url_alive(url: str, timeout: float = DEFAULT_TIMEOUT) -> bool:
    """True — сервер отвечает 2xx/3xx; False — 4xx/5xx или сеть недоступна."""
    if not url:
        return False
    return _request(url, "HEAD", timeout)