"""Центральный Hub/Application Manager HATE_tets.

Hub — единственная точка оркестрации компонентов приложения.
Web/GUI/Telegram отправляют команды в Hub, Hub управляет JobManager,
EventBus и жизненным циклом компонентов. Компоненты не должны напрямую
управлять внутренним состоянием друг друга.
"""
from __future__ import annotations

import json
import os
import sys
import threading
import time
from typing import Any, Dict, Optional

from .event_bus import EventBus
from .event_journal import append_event
from .job import Job, JobPriority, JobState
from .job_manager import JobManager
from .cleanup import cleanup_old_files
from .config import consume_reload_request, load_settings
from .logging_setup import setup_logger
from .telegram_bot import TelegramBot
from .answers import get_answers_dir
from .web_panel import WebPanel
from automation.browser import close_all_browsers

APP_VERSION = "1.0.0"


class ApplicationHub:
    """Центральный фасад приложения и владелец его компонентов."""

    def __init__(self, logger=None):
        self.logger = logger or setup_logger(log_queue=None, log_name="hub")
        self.event_bus = EventBus(self.logger)
        self.event_bus.subscribe_all(append_event)

        settings = load_settings()
        worker_count = max(1, min(int(settings.get("worker_count", 4) or 4), 16))

        self.job_manager = JobManager(
            self.logger,
            event_bus=self.event_bus,
            worker_count=worker_count,
        )
        self.telegram = TelegramBot(
            (settings.get("telegram_token") or "").strip(),
            self.logger,
            hub=self,
        )

        self._lock = threading.RLock()
        self._running = False
        self._stop = threading.Event()
        self._threads: list[threading.Thread] = []
        self._app_started_at = time.time()
        self._bot_running = False
        self.web = WebPanel(logger=self.logger, hub=self)

        self.event_bus.publish(
            "HubCreated",
            version=APP_VERSION,
            worker_count=worker_count,
        )

    # ------------------------------------------------------------------
    # Public command surface — this is the API used by clients.
    # ------------------------------------------------------------------

    def submit_job(
        self,
        url: str,
        *,
        mode: str = "collect",
        user_name: str = "",
        telegram_chat_id: Optional[str] = None,
        priority: JobPriority = JobPriority.NORMAL,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Создать и поставить Job в центральную очередь."""
        job = Job(
            url=url,
            mode=mode,
            user_name=user_name,
            telegram_chat_id=telegram_chat_id,
            priority=priority,
            metadata=dict(metadata or {}),
        )
        self.job_manager.submit(job, self._execute_job)
        self.event_bus.publish("HubJobSubmitted", job=job.to_dict())
        return job.id

    def cancel_job(self, job_id: str) -> bool:
        return self.job_manager.cancel(job_id)

    def stop_all(self) -> int:
        self._set_global_stop()
        count = self.job_manager.cancel_all()
        try:
            close_all_browsers(self.logger)
        except Exception as exc:
            self.logger.debug(f"Ошибка закрытия Chrome: {exc}")
        self.event_bus.publish("HubStopAll", cancelled=count)
        return count

    def restart_telegram(self) -> bool:
        self._stop_telegram()
        settings = load_settings()
        token = (settings.get("telegram_token") or "").strip()
        if not token:
            self.logger.warning("Токен Telegram пуст — бот не запущен.")
            return False
        return self._start_telegram(token)

    def open_answers(self) -> None:
        path = get_answers_dir()
        self.logger.info("Каталог ответов на сервере: %s", path)

    @property
    def web_url(self) -> str:
        return self.web.url

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        with self._lock:
            if self._running:
                return
            self._running = True
            self._stop.clear()

        self.logger.info(f"=== HATE_tets Hub {APP_VERSION} стартует ===")
        self._start_heartbeat()
        self.web.start()

        try:
            cleanup_old_files(self.logger)
        except Exception as exc:
            self.logger.warning(f"Ошибка автоочистки: {exc}")

        self.job_manager.start()

        settings = load_settings()
        token = (settings.get("telegram_token") or "").strip()
        if token:
            self._start_telegram(token)
        else:
            self.logger.warning(
                "Токен Telegram не задан — бот запустится автоматически "
                "после появления токена в config.txt."
            )

        self._start_thread(self._reload_loop, "hub-config-reloader")

        self.event_bus.publish("HubStarted", version=APP_VERSION)

    def stop(self) -> None:
        with self._lock:
            if not self._running:
                return
            self._running = False
            self._stop.set()

        self.event_bus.publish("HubStopping")
        try:
            self._stop_telegram()
        except Exception:
            pass
        try:
            self.job_manager.stop(cancel_pending=True)
        except Exception as exc:
            self.logger.warning(f"Ошибка остановки JobManager: {exc}")
        try:
            self.web.stop()
        except Exception:
            pass
        try:
            close_all_browsers(self.logger)
        except Exception:
            pass
        self._remove_heartbeat()
        self.event_bus.publish("HubStopped")

    # ------------------------------------------------------------------
    # Job execution — JobManager owns the queue, Hub owns orchestration.
    # ------------------------------------------------------------------

    def _execute_job(self, job: Job, worker_context=None) -> None:
        """Единая точка исполнения Job для любого клиента."""
        if job.telegram_chat_id:
            self.telegram.process_job(job, worker_context)
            return

        # GUI/Web Job без Telegram-получателя.
        self._execute_non_telegram_job(job, worker_context)

    def _execute_non_telegram_job(self, job: Job, worker_context=None) -> None:
        from automation import TestRunner

        if job.cancel_event.is_set():
            return

        self.job_manager.update(job, state=JobState.OPENING, stage="opening")
        browser = None
        if worker_context is not None:
            from automation.browser import BrowserSession
            browser = worker_context.get_resource(
                "chrome",
                lambda: BrowserSession(self.logger, worker_context.worker_id),
            ).get()
            self.job_manager.update(
                job,
                state=JobState.TESTING,
                stage="browser_ready",
            )
        else:
            self.job_manager.update(job, state=JobState.TESTING, stage="testing")

        runner = TestRunner(
            url=job.url,
            logger=self.logger,
            stop_event=job.cancel_event,
            max_attempts=int(job.metadata.get("max_attempts", 1) or 1),
            mode=job.mode,
            user_name=job.user_name,
            driver=browser,
        )
        self.job_manager.update(job, state=None, stage="testing")
        runner.run()

    # ------------------------------------------------------------------
    # Telegram lifecycle
    # ------------------------------------------------------------------

    def _start_telegram(self, token: str) -> bool:
        with self._lock:
            if self._bot_running:
                return True
            self.telegram.token = token

        try:
            self.telegram.start()
        except Exception as exc:
            self.logger.error(f"Не удалось запустить Telegram: {exc}")
            self.event_bus.publish("TelegramFailed", error=str(exc))
            return False

        with self._lock:
            self._bot_running = True
        self.event_bus.publish("TelegramStarted")
        return True

    def _stop_telegram(self) -> None:
        try:
            self.telegram.stop()
        except Exception:
            pass
        with self._lock:
            was_running = self._bot_running
            self._bot_running = False
        if was_running:
            self.event_bus.publish("TelegramStopped")

    # ------------------------------------------------------------------
    # State and heartbeat
    # ------------------------------------------------------------------

    def _start_heartbeat(self) -> None:
        self._write_heartbeat()
        self._start_thread(self._heartbeat_loop, "hub-heartbeat")

    def _heartbeat_loop(self) -> None:
        while not self._stop.wait(3):
            self._write_heartbeat()

    def _write_heartbeat(self) -> None:
        path = base_dir() / "data" / "heartbeats" / "app.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "component": "hub",
            "timestamp": time.time(),
            "pid": os.getpid(),
            "version": APP_VERSION,
        }
        try:
            tmp = path.with_suffix(".tmp")
            tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
            tmp.replace(path)
        except OSError:
            pass

    def _remove_heartbeat(self) -> None:
        try:
            (base_dir() / "data" / "heartbeats" / "app.json").unlink(missing_ok=True)
        except OSError:
            pass

    def _reload_loop(self) -> None:
        while not self._stop.wait(2):
            try:
                if consume_reload_request():
                    settings = load_settings()
                    token = (settings.get("telegram_token") or "").strip()
                    if token:
                        self.telegram.token = token
                        if not self._bot_running:
                            self._start_telegram(token)
            except Exception as exc:
                self.logger.debug(f"Hub config reload: {exc}")

    def _set_global_stop(self) -> None:
        try:
            from .global_state import request_stop
            request_stop()
        except Exception:
            pass

    def _start_thread(self, target, name: str) -> None:
        t = threading.Thread(target=target, name=name, daemon=True)
        self._threads.append(t)
        t.start()

    # ------------------------------------------------------------------
    # Tray adapter. Tray is UI only; it does not own application state.
    # ------------------------------------------------------------------

    def run_tray(self) -> None:
        def on_quit():
            self.stop()

        run_tray(on_quit, logger=self.logger, state=self._tray_state)
