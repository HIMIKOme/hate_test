"""Telegram-бот HATE_tets."""
from __future__ import annotations

import json
import re
import threading
import time
from pathlib import Path
import json
import os
from typing import Dict, List, Optional, Set, Tuple

from .job import Job, JobPriority, JobState

from .cache import Cache
from .config import get_data_dir, is_user_allowed, load_settings
from .global_state import clear_stop, is_stop_requested
from .link_checker import is_url_alive
from .telegram import delete_message, get_updates, send_document, send_text

URL_RE = re.compile(r"https?://(?:www\.)?onlinetestpad\.com/[^\s]+", re.IGNORECASE)

FLOOD_WINDOW_SEC = 60
FLOOD_MAX_LINKS = 10
FLOOD_BLOCK_SEC = 600

# Сколько секунд ждём ответ на /config.
CONFIG_WAIT_SEC = 600

BUSY_MESSAGE = "Бот решает другой тест, подождите немного..."
ACCEPT_MESSAGE = "Принял, прохожу тест..."
ACCEPT_100_MESSAGE = "Принял, решаю тест на 100%..."
COLLECT_THEN_100_MESSAGE = (
    "В кэше нет ответов для этой ссылки. Сначала соберу ответы, "
    "затем пройду тест на 100%."
)
RETRY_100_MESSAGE = (
    "Первый проход не дал 100% — обновляю ответы и пробую снова."
)
NO_100_MESSAGE = (
    "Не удалось решить на 100%: даже после повторного сбора остались "
    "несовпадающие вопросы. Ответы собраны и отправлены."
)
RESULT_100_MESSAGE = "✅ Готово! Тест пройден на 100%."
RESULT_UNKNOWN_MESSAGE = (
    "✅ Тест завершён. Все ответы совпали с сохранёнными, "
    "но сайт не показал процент или баллы.\n"
    "Проверьте вручную: {url}"
)
STOPPED_MESSAGE = "⛔ Прохождение теста остановлено."

NO_CONFIG_WARNING = (
    "⚠️ У вас не заполнено ФИО для страницы результатов.\n"
    "Тест всё равно будет пройден, но результат может быть без имени.\n\n"
    "Заполнить: /config"
)

BAD_LINK_MESSAGE = (
    "Ссылка не работает или недоступна.\n"
    "Проверьте, что она открывается в браузере.\n\n"
    "По вопросам: {author}"
)

FLOOD_MESSAGE = (
    "Спам-защита: слишком много ссылок за минуту.\n"
    "Таймаут: 10 минут.\n\n"
    "Если это были не вы — обратитесь к {author}."
)

NO_WHITELIST_MESSAGE = (
    "Команда доступна только пользователям из белого списка."
)

USAGE_R_MESSAGE = (
    "Использование:\n"
    "/r <ссылка> — решить тест на 100%\n"
    "или ответьте (reply) на сообщение со ссылкой и напишите /r"
)

TEST_ACCEPT_MESSAGE = "Запускаю сбор HTML для отладки..."
TEST_DONE_MESSAGE = "Отчёт готов. Файл с HTML всех вопросов:"
TEST_FAIL_MESSAGE = "Не удалось собрать отчёт. Смотри лог."

ERROR_TEXT_WITH_CONTACT = (
    "Не удалось пройти тест по ссылке.\n"
    "Проверьте, что ссылка работает и открывается в браузере.\n\n"
    "По вопросам ошибок: напишите {contact}"
)

ERROR_TEXT_NO_CONTACT = (
    "Не удалось пройти тест по ссылке.\n"
    "Проверьте, что ссылка работает и открывается в браузере."
)

DEV_WARNING = (
    "⚠️ Проект находится в активной разработке.\n"
    "Возможны временные сбои. О найденных проблемах сообщайте "
    "владельцу бота."
)


def _build_help_message() -> str:
    try:
        author = (load_settings().get("error_contact") or "").strip()
    except Exception:
        author = ""

    tail = f"\n\nПо всем вопросам: {author}" if author else ""

    return (
        "Привет! Я бот HATE_tets.\n\n"
        "Что я умею:\n"
        "• Отправь мне ссылку на тест onlinetestpad.com — "
        "я пройду его и пришлю правильные ответы.\n"
        "• Пришлю два сообщения: короткий список ответов (буквы) "
        "и файл со всеми ответами.\n"
        "• Работаю в личных сообщениях и в группах.\n\n"
        "Команды:\n"
        "/help — показать это сообщение.\n"
        "/config — задать своё ФИО (вводится на странице результатов).\n"
        "/myconfig — посмотреть сохранённое ФИО.\n"
        "/cancel — отменить ввод.\n"
        "/r <ссылка> — решить тест на 100% (только для белого списка).\n"
        "/test <ссылка> — собрать HTML теста для отладки "
        "(только для белого списка).\n\n"
        f"{DEV_WARNING}"
        f"{tail}"
    )


def _author_placeholder() -> str:
    try:
        return (load_settings().get("error_contact") or "").strip() or "владельцу бота"
    except Exception:
        return "владельцу бота"


def _format_result_block(score: dict) -> str:
    if not score:
        return ""

    lines: List[str] = []
    percent = score.get("percent")
    correct = score.get("correct")
    total = score.get("total")
    points = score.get("points")
    max_points = score.get("max_points")
    grade = score.get("grade")

    if correct is not None and total is not None:
        lines.append(f"• Правильных ответов: {correct} из {total}")
    if percent is not None:
        lines.append(f"• Результат: {percent}%")
    if points is not None:
        if max_points is not None:
            lines.append(f"• Баллов: {points} из {max_points}")
        else:
            lines.append(f"• Баллов: {points}")
    if grade:
        lines.append(f"• Оценка: {grade}")

    if not lines:
        return ""
    return "\n".join(lines)


def _user_chats_path() -> Path:
    return get_data_dir() / "user_chats.json"


def _user_configs_path() -> Path:
    return get_data_dir() / "user_configs.json"


class TelegramBot:
    def __init__(self, token: str, logger, hub=None):
        self.token = token
        self.logger = logger
        self.cache = Cache(logger)
        self.hub = hub

        self._stop = threading.Event()
        self._offset = 0
        self._poll_thread: Optional[threading.Thread] = None

        self._active: Set[str] = set()
        self._subscribers: Dict[str, Set[str]] = {}
        self._pending_messages: Dict[str, List[Tuple[str, int]]] = {}
        self._link_check_results: Dict[str, Optional[bool]] = {}
        self._lock = threading.Lock()

        self._flood: Dict[str, List[float]] = {}
        self._blocked_until: Dict[str, float] = {}
        # Отдельные счётчики на пользователя (для групп, где несколько человек).
        self._flood_users: Dict[str, List[float]] = {}
        self._blocked_users: Dict[str, float] = {}
        self._flood_lock = threading.Lock()

        # username (lowercase, без @) -> chat_id (строка)
        self._user_chat_ids: Dict[str, str] = {}
        self._load_user_chats()

        # user_id (строка) -> введённое пользователем ФИО
        self._user_configs: Dict[str, str] = {}
        self._load_user_configs()

        # user_id (int) -> timestamp начала ожидания ввода ФИО
        self._awaiting_config: Dict[int, float] = {}
        self._config_lock = threading.Lock()
        self._job_ids_by_url: Dict[str, str] = {}

    # ------------------------------------------------------------------ #
    # Хранилище chat_id пользователей (для отправки ссылки в ЛС)
    # ------------------------------------------------------------------ #

    def _load_user_chats(self) -> None:
        path = _user_chats_path()
        if not path.exists():
            return
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            if self.logger:
                self.logger.debug(f"Не удалось прочитать user_chats.json: {exc}")
            return
        if not isinstance(data, dict):
            return
        clean: Dict[str, str] = {}
        for k, v in data.items():
            if not k or v is None:
                continue
            key = str(k).lstrip("@").strip().lower()
            if not key:
                continue
            clean[key] = str(v)
        self._user_chat_ids = clean

    def _save_user_chats(self) -> None:
        try:
            _user_chats_path().write_text(
                json.dumps(self._user_chat_ids, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception as exc:
            if self.logger:
                self.logger.debug(f"Не удалось сохранить user_chats.json: {exc}")

    def _remember_user_chat(self, username: str, chat_id: str) -> None:
        if not username or not chat_id:
            return
        key = username.lstrip("@").strip().lower()
        if not key:
            return
        if self._user_chat_ids.get(key) == chat_id:
            return
        self._user_chat_ids[key] = chat_id
        self._save_user_chats()
        if self.logger:
            self.logger.info(f"Запомнил chat_id для @{key}: {chat_id}")

    def send_to_username(self, username: str, text: str) -> bool:
        """Отправить текст в ЛС пользователю по @username."""
        if not username or not text:
            return False
        key = username.lstrip("@").strip().lower()
        if not key:
            return False
        chat_id = self._user_chat_ids.get(key)
        if not chat_id:
            if self.logger:
                self.logger.info(
                    f"Не знаю chat_id для @{key} — пользователь ещё не писал боту."
                )
            return False
        try:
            result = send_text(self.token, chat_id, text)
        except Exception as exc:
            if self.logger:
                self.logger.warning(f"send_to_username(@{key}): {exc}")
            return False
        if result is None:
            if self.logger:
                self.logger.warning(
                    f"send_to_username(@{key}): Telegram вернул ошибку."
                )
            return False
        return True

    # ------------------------------------------------------------------ #
    # Хранилище ФИО (user_configs.json)
    # ------------------------------------------------------------------ #

    def _load_user_configs(self) -> None:
        path = _user_configs_path()
        if not path.exists():
            return
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            if self.logger:
                self.logger.debug(f"Не удалось прочитать user_configs.json: {exc}")
            return
        if not isinstance(data, dict):
            return
        clean: Dict[str, str] = {}
        for k, v in data.items():
            if k is None or v is None:
                continue
            key = str(k).strip()
            val = str(v).strip()
            if not key or not val:
                continue
            clean[key] = val
        self._user_configs = clean

    def _save_user_configs(self) -> None:
        try:
            _user_configs_path().write_text(
                json.dumps(self._user_configs, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception as exc:
            if self.logger:
                self.logger.debug(f"Не удалось сохранить user_configs.json: {exc}")

    def _get_user_name(self, user_id: Optional[int]) -> str:
        if user_id is None:
            return ""
        return self._user_configs.get(str(user_id), "") or ""

    # ---- ожидание ввода ФИО ----------------------------------------- #

    def _set_awaiting_config(self, user_id: int) -> None:
        with self._config_lock:
            self._awaiting_config[user_id] = time.time()

    def _clear_awaiting_config(self, user_id: int) -> None:
        with self._config_lock:
            self._awaiting_config.pop(user_id, None)

    def _is_awaiting_config(self, user_id: Optional[int]) -> bool:
        if user_id is None:
            return False
        with self._config_lock:
            ts = self._awaiting_config.get(user_id)
            if ts is None:
                return False
            if time.time() - ts > CONFIG_WAIT_SEC:
                # истекло
                self._awaiting_config.pop(user_id, None)
                return False
            return True

    # ------------------------------------------------------------------ #
    def start(self) -> None:
        if not self.token:
            self.logger.warning("Токен не задан — бот не запущен.")
            return
        self.logger.info("Запускаю Telegram-бота (long polling)...")
        self._stop.clear()
        self._heartbeat_path = get_data_dir() / "heartbeats" / "telegram.json"
        self._heartbeat_path.parent.mkdir(parents=True, exist_ok=True)
        self._poll_thread = threading.Thread(target=self._poll_loop, name="tg-poll", daemon=True)
        self._poll_thread.start()
        self.logger.info("Telegram-бот запущен.")

    def stop(self) -> None:
        self.logger.info("Останавливаю Telegram-бота...")
        self._stop.set()
        try:
            self._heartbeat_path.unlink(missing_ok=True)
        except OSError:
            pass
        for t in (self._poll_thread,):
            if t and t.is_alive():
                t.join(timeout=3)
    def clear_queue(self) -> int:
        """Удаляет все ожидающие задания через центральный JobManager."""
        if self.hub is None:
            return 0
        return self.hub.job_manager.clear_pending() if self.hub is not None else 0

    def stop_all_work(self) -> int:
        """Отменяет все Job через центральный JobManager."""
        try:
            from .global_state import request_stop
            request_stop()
        except Exception as exc:
            if self.logger:
                self.logger.warning(f"stop_all_work: request_stop: {exc}")

        removed = self.hub.job_manager.cancel_all() if self.hub is not None else 0

        with self._lock:
            active_before = len(self._active)
            pending_snapshot = dict(self._pending_messages)
            self._active.clear()
            self._subscribers.clear()
            self._link_check_results.clear()
            self._pending_messages.clear()
            self._job_ids_by_url.clear()

        if pending_snapshot:
            threading.Thread(target=self._delete_pending_snapshot, args=(pending_snapshot,), daemon=True).start()

        if self.logger:
            self.logger.info(f"«Стоп всё»: отменено Job — {removed}, активных URL было — {active_before}.")
        return removed

    def _delete_pending_snapshot(self, snapshot: Dict[str, List]) -> None:
        for _url, items in snapshot.items():
            for chat_id, msg_id in items:
                try:
                    delete_message(self.token, chat_id, msg_id)
                except Exception:
                    pass

    # ------------------------------------------------------------------ #
    def _write_heartbeat(self) -> None:
        try:
            path = getattr(self, "_heartbeat_path", get_data_dir() / "heartbeats" / "telegram.json")
            payload = {"timestamp": time.time(), "pid": os.getpid(), "running": not self._stop.is_set()}
            tmp = path.with_suffix(".tmp")
            tmp.write_text(json.dumps(payload), encoding="utf-8")
            tmp.replace(path)
        except OSError:
            pass

    def _poll_loop(self) -> None:
        while not self._stop.is_set():
            self._write_heartbeat()
            try:
                updates = get_updates(self.token, self._offset, timeout=20)
            except Exception as exc:
                self.logger.warning(f"Ошибка getUpdates: {exc}")
                time.sleep(3)
                continue
            if updates is None:
                time.sleep(0.5)
                continue
            for upd in updates:
                try:
                    self._offset = upd["update_id"] + 1
                    self._handle_update(upd)
                except Exception as exc:
                    self.logger.warning(f"Ошибка обработки update: {exc}")

    def _handle_update(self, upd: dict) -> None:
        message = upd.get("message") or upd.get("channel_post")
        if not message:
            return

        chat = message.get("chat") or {}
        chat_id = chat.get("id")
        chat_type = (chat.get("type") or "").lower()
        text = (message.get("text") or "").strip()
        if not chat_id or not text:
            return

        chat_id_str = str(chat_id)
        is_private = chat_type == "private"

        from_user = message.get("from") or {}
        username = from_user.get("username") or ""
        user_id_raw = from_user.get("id")
        user_id: Optional[int]
        try:
            user_id = int(user_id_raw) if user_id_raw is not None else None
        except (TypeError, ValueError):
            user_id = None

        # Запоминаем chat_id пользователя, пишущего в ЛС,
        # чтобы потом можно было отправить ему ссылку на веб-панель.
        if is_private and username:
            self._remember_user_chat(username, chat_id_str)

        # --- Ожидаем ответ на /config ------------------------------- #
        if user_id is not None and self._is_awaiting_config(user_id):
            if text.startswith("/cancel"):
                self._clear_awaiting_config(user_id)
                send_text(self.token, chat_id_str, "Ввод ФИО отменён.")
                return
            if text.startswith("/"):
                # другая команда — не считаем ответом, обрабатываем обычно
                pass
            elif URL_RE.search(text):
                # это ссылка, не ФИО
                pass
            else:
                # это ответ на /config
                name = text.strip()
                self._user_configs[str(user_id)] = name
                self._save_user_configs()
                self._clear_awaiting_config(user_id)
                send_text(
                    self.token, chat_id_str,
                    f"✅ Сохранил ФИО: {name}\n\n"
                    "Теперь при /r это значение будет подставлено "
                    "на странице результатов.",
                )
                if self.logger:
                    self.logger.info(
                        f"Пользователь {user_id} сохранил ФИО: {name!r}"
                    )
                return

        # --- Команды ------------------------------------------------- #
        if text.startswith("/config"):
            self._handle_config_command(chat_id_str, user_id)
            return

        if text.startswith("/myconfig"):
            self._handle_myconfig_command(chat_id_str, user_id)
            return

        if text.startswith("/r") and (len(text) == 2 or text[2] in " \t\n"):
            self._handle_r_command(
                message=message, chat_id=chat_id_str, text=text,
                username=username, user_id=user_id,
            )
            return

        if text.startswith("/test") and (len(text) == 5 or text[5] in " \t\n"):
            self._handle_test_command(
                message=message, chat_id=chat_id_str, text=text, username=username,
            )
            return

        if text.startswith("/help") or text.startswith("/start"):
            send_text(self.token, chat_id_str, _build_help_message())
            return

        url_match = URL_RE.search(text)
        if url_match:
            if not self._flood_ok(chat_id_str, user_id):
                threading.Thread(
                    target=self._send_tracked,
                    args=(chat_id_str, chat_id_str,
                          FLOOD_MESSAGE.format(author=_author_placeholder())),
                    daemon=True,
                ).start()
                return
            url = url_match.group(0).rstrip(".,;:!?")
            self._enqueue_url(url, chat_id_str, mode="collect", user_name="")
            return

        if is_private:
            send_text(self.token, chat_id_str, _build_help_message())

    # ------------------------------------------------------------------ #
    # /config и /myconfig
    # ------------------------------------------------------------------ #

    def _handle_config_command(self, chat_id: str, user_id: Optional[int]) -> None:
        if user_id is None:
            send_text(
                self.token, chat_id,
                "Не удалось определить ваш Telegram ID. "
                "Попробуйте позже или напишите владельцу бота.",
            )
            return
        current = self._get_user_name(user_id)
        self._set_awaiting_config(user_id)
        lines = []
        if current:
            lines.append(f"Сейчас сохранено: {current}")
            lines.append("")
        lines.append(
            "Отправьте одной строкой ФИО (или любой текст), "
            "который нужно ввести на странице результатов теста."
        )
        lines.append("")
        lines.append("Пример: Иванов Иван Иванович")
        lines.append("Для отмены — /cancel.")
        send_text(self.token, chat_id, "\n".join(lines))

    def _handle_myconfig_command(self, chat_id: str, user_id: Optional[int]) -> None:
        current = self._get_user_name(user_id)
        if current:
            send_text(
                self.token, chat_id,
                f"Ваше сохранённое ФИО:\n{current}\n\n"
                "Изменить: /config",
            )
        else:
            send_text(
                self.token, chat_id,
                "ФИО пока не заполнено.\nЗаполнить: /config",
            )

    # ------------------------------------------------------------------ #
    def _handle_r_command(
        self,
        message: dict,
        chat_id: str,
        text: str,
        username: str,
        user_id: Optional[int],
    ) -> None:
        try:
            wl = load_settings().get("whitelist", [])
        except Exception:
            wl = []

        allowed = is_user_allowed(username)
        self.logger.info(
            f"/r от username={username!r} id={user_id} "
            f"(norm={username.lstrip('@').lower()!r}): "
            f"{'разрешено' if allowed else 'НЕ в белом списке'}. "
            f"whitelist={wl}"
        )

        if not allowed:
            send_text(self.token, chat_id, NO_WHITELIST_MESSAGE)
            return

        url: Optional[str] = None

        arg = text[2:].strip()
        if arg:
            m = URL_RE.search(arg)
            if m:
                url = m.group(0).rstrip(".,;:!?")

        if url is None:
            reply = message.get("reply_to_message") or {}
            reply_text = (reply.get("text") or "").strip()
            if reply_text:
                m = URL_RE.search(reply_text)
                if m:
                    url = m.group(0).rstrip(".,;:!?")

        if url is None:
            send_text(self.token, chat_id, USAGE_R_MESSAGE)
            return

        if not self._flood_ok(chat_id, user_id):
            threading.Thread(
                target=self._send_tracked,
                args=(chat_id, chat_id,
                      FLOOD_MESSAGE.format(author=_author_placeholder())),
                daemon=True,
            ).start()
            return

        user_name = self._get_user_name(user_id)
        if not user_name:
            send_text(self.token, chat_id, NO_CONFIG_WARNING)

        self._enqueue_url(url, chat_id, mode="100", user_name=user_name)

    # ------------------------------------------------------------------ #
    def _handle_test_command(self, message: dict, chat_id: str, text: str, username: str) -> None:
        if not is_user_allowed(username):
            send_text(self.token, chat_id, NO_WHITELIST_MESSAGE)
            self.logger.info(f"/test от {username} — не в белом списке.")
            return

        url: Optional[str] = None

        arg = text[5:].strip()
        if arg:
            m = URL_RE.search(arg)
            if m:
                url = m.group(0).rstrip(".,;:!?")

        if url is None:
            reply = message.get("reply_to_message") or {}
            reply_text = (reply.get("text") or "").strip()
            if reply_text:
                m = URL_RE.search(reply_text)
                if m:
                    url = m.group(0).rstrip(".,;:!?")

        if url is None:
            send_text(self.token, chat_id, "Использование: /test <ссылка>")
            return

        send_text(self.token, chat_id, TEST_ACCEPT_MESSAGE)

        def _run():
            from .debug_collector import collect_debug
            try:
                path = collect_debug(url, self.logger)
            except Exception as exc:
                self.logger.error(f"/test: {exc}")
                send_text(self.token, chat_id, TEST_FAIL_MESSAGE)
                return

            if path is None or not path.exists():
                send_text(self.token, chat_id, TEST_FAIL_MESSAGE)
                return

            try:
                send_text(self.token, chat_id, TEST_DONE_MESSAGE)
                send_document(self.token, chat_id, path)
                self.logger.info(f"/test: файл отправлен ({path.name}).")
            except Exception as exc:
                self.logger.warning(f"/test: не удалось отправить файл: {exc}")

        threading.Thread(target=_run, daemon=True).start()

    # ------------------------------------------------------------------ #
    def _flood_ok(self, chat_id: str, user_id: Optional[int] = None) -> bool:
        """Проверка антифлуда.

        Считаем ОТДЕЛЬНО по чату и по пользователю. Если у пользователя
        переполнен лимит — блокируется только он (в группе остальные не
        страдают). Если переполнен лимит чата — блокируется чат целиком.
        """
        now = time.time()
        user_key = str(user_id) if user_id is not None else ""

        with self._flood_lock:
            # 1. Блокировка чата.
            if self._blocked_until.get(chat_id, 0) > now:
                return False
            # 2. Блокировка пользователя.
            if user_key and self._blocked_users.get(user_key, 0) > now:
                return False

            # 3. Счётчик чата.
            chat_ts = [
                t for t in self._flood.get(chat_id, [])
                if now - t < FLOOD_WINDOW_SEC
            ]
            chat_ts.append(now)
            self._flood[chat_id] = chat_ts

            # 4. Счётчик пользователя.
            user_ts: List[float] = []
            if user_key:
                user_ts = [
                    t for t in self._flood_users.get(user_key, [])
                    if now - t < FLOOD_WINDOW_SEC
                ]
                user_ts.append(now)
                self._flood_users[user_key] = user_ts

            # 5. Проверка лимитов.
            chat_blocked = len(chat_ts) > FLOOD_MAX_LINKS
            user_blocked = bool(user_key) and len(user_ts) > FLOOD_MAX_LINKS

            if chat_blocked:
                self._blocked_until[chat_id] = now + FLOOD_BLOCK_SEC
                self.logger.warning(
                    f"Антифлуд: чат {chat_id} заблокирован "
                    f"на {FLOOD_BLOCK_SEC // 60} минут."
                )

            if user_blocked:
                self._blocked_users[user_key] = now + FLOOD_BLOCK_SEC
                self.logger.warning(
                    f"Антифлуд: пользователь {user_key} заблокирован "
                    f"на {FLOOD_BLOCK_SEC // 60} минут."
                )

            return not (chat_blocked or user_blocked)

    # ------------------------------------------------------------------ #
    def _enqueue_url(self, url: str, chat_id: str, mode: str, user_name: str = "") -> None:
        if mode == "collect":
            cached = self.cache.get(url)
            if cached:
                self.logger.info(f"URL в кэше — отправляю сохранённые ответы: {url}")
                threading.Thread(
                    target=self._send_cached, args=(chat_id, cached), daemon=True,
                ).start()
                return

        with self._lock:
            already_active = url in self._active
            if already_active:
                self._subscribers[url].add(chat_id)
            else:
                self._active.add(url)
                self._subscribers[url] = {chat_id}

        if already_active:
            threading.Thread(
                target=self._send_tracked,
                args=(url, chat_id, BUSY_MESSAGE), daemon=True,
            ).start()
            return

        with self._lock:
            self._link_check_results[url] = None

        threading.Thread(target=self._precheck_link, args=(url,), daemon=True).start()

        if self.hub is None:
            raise RuntimeError("TelegramBot: ApplicationHub не подключён")
        priority = JobPriority.HIGH if mode == "100" else JobPriority.NORMAL
        job_id = self.hub.submit_job(
            url,
            mode=mode,
            user_name=user_name,
            telegram_chat_id=str(chat_id),
            priority=priority,
            metadata={"source": "telegram"},
        )
        with self._lock:
            self._job_ids_by_url[url] = job_id

        if mode == "100":
            cached = self.cache.get(url)
            accept = ACCEPT_100_MESSAGE if (cached and cached.get("answers")) else COLLECT_THEN_100_MESSAGE
        else:
            accept = ACCEPT_MESSAGE

        threading.Thread(
            target=self._send_tracked,
            args=(url, chat_id, accept), daemon=True,
        ).start()

    def _precheck_link(self, url: str) -> None:
        try:
            ok = is_url_alive(url, timeout=4.0)
        except Exception:
            ok = None
        with self._lock:
            if url in self._link_check_results:
                self._link_check_results[url] = ok

    def _send_tracked(self, url: str, chat_id: str, text: str) -> None:
        try:
            msg_id = send_text(self.token, chat_id, text)
            if msg_id is None:
                return
            with self._lock:
                self._pending_messages.setdefault(url, []).append((chat_id, msg_id))
        except Exception as exc:
            self.logger.warning(f"Не удалось отправить '{text[:30]}...': {exc}")

    def _cleanup_pending(self, url: str) -> None:
        with self._lock:
            items = self._pending_messages.pop(url, [])
        if not items:
            return
        removed = 0
        for chat_id, msg_id in items:
            try:
                if delete_message(self.token, chat_id, msg_id):
                    removed += 1
            except Exception as exc:
                self.logger.debug(f"Не удалось удалить сообщение: {exc}")
        if removed:
            self.logger.info(f"Удалено служебных сообщений: {removed}.")

    def _send_cached(self, chat_id: str, cached: dict) -> None:
        text = cached.get("telegram_text") or ""
        if text:
            for chunk in _split(text):
                send_text(self.token, chat_id, chunk)
        cheat = cached.get("cheatsheet_path")
        if cheat:
            p = Path(cheat)
            if p.exists():
                send_document(self.token, chat_id, p)

    # ------------------------------------------------------------------ #
    def process_job(self, job: Job, worker_context=None) -> None:
        """Callback JobManager. Telegram остаётся клиентом JobManager."""
        try:
            self._process_url(job.url, job.mode, job.user_name, job, worker_context)
        finally:
            self._cleanup_pending(job.url)
            with self._lock:
                self._active.discard(job.url)
                self._subscribers.pop(job.url, None)
                self._link_check_results.pop(job.url, None)
                self._job_ids_by_url.pop(job.url, None)

    def _process_url(self, url: str, mode: str, user_name: str = "", job: Optional[Job] = None, worker_context=None) -> None:
        self.logger.info(f"Обрабатываю URL (mode={mode}, job={job.id if job else 'n/a'}): {url}")

        clear_stop()

        if job is not None:
            self.hub.job_manager.update(job, JobState.OPENING, stage="checking_link")

        with self._lock:
            subscribers = list(self._subscribers.get(url, set()))
            link_ok = self._link_check_results.get(url)

        if not subscribers:
            self.logger.warning("Нет подписчиков для URL — пропускаю.")
            return

        if link_ok is False:
            if job is not None:
                self.hub.job_manager.update(job, JobState.FAILED, stage="link_check", error="Ссылка недоступна")
            self.logger.warning(f"Ссылка не отвечает: {url}")
            text = BAD_LINK_MESSAGE.format(author=_author_placeholder())
            for cid in subscribers:
                send_text(self.token, cid, text)
            return

        if job is not None:
            self.hub.job_manager.update(job, JobState.TESTING, stage="testing")

        if mode == "100":
            self._process_100(url, subscribers, user_name, job, worker_context)
        else:
            self._process_collect(url, subscribers, job, worker_context)

    def _process_collect(self, url: str, subscribers: List[str], job: Optional[Job] = None, worker_context=None):
        from automation import TestRunner

        if is_stop_requested():
            self.logger.info("Сбор пропущен — запрошен «Стоп всё».")
            return None

        def on_complete(completed_url: str, result: dict) -> None:
            try:
                self.cache.put(
                    completed_url,
                    result["cheatsheet_path"],
                    result["short_path"],
                    result["telegram_text"],
                    result.get("answer_pairs"),
                )
            except Exception as exc:
                self.logger.warning(f"Не удалось обновить кэш: {exc}")

        stop_event = job.cancel_event if job is not None else threading.Event()
        browser = None
        if worker_context is not None:
            from automation.browser import BrowserSession
            browser = worker_context.get_resource(
                "chrome", lambda: BrowserSession(self.logger, worker_context.worker_id)
            ).get()
            if job is not None:
                self.hub.job_manager.update(job, state=None, stage="browser_ready")
        runner = TestRunner(
            url=url,
            logger=self.logger,
            stop_event=stop_event,
            max_attempts=1,
            telegram_chat_ids=subscribers,
            on_complete=on_complete,
            mode="collect",
            driver=browser,
        )
        try:
            runner.run()
        except Exception as exc:
            self.logger.error(f"Collect упал: {exc}")
            if not is_stop_requested():
                self._notify_error(subscribers)
        return runner

    # ------------------------------------------------------------------ #
    def _restart_browser(self, worker_context=None) -> None:
        try:
            if worker_context is not None:
                worker_context.close_resource("chrome")
                return
            from automation.browser import close_all_browsers
            close_all_browsers(self.logger)
        except Exception as exc:
            self.logger.debug(f"Ошибка при закрытии Chrome: {exc}")

    def _attempt_100(self, url: str, saved_answers: List[dict], user_name: str, job: Optional[Job] = None, worker_context=None) -> Tuple[str, dict]:
        from automation import TestRunner

        if is_stop_requested():
            return "error", {}

        stop_event = job.cancel_event if job is not None else threading.Event()
        browser = None
        if worker_context is not None:
            from automation.browser import BrowserSession
            browser = worker_context.get_resource(
                "chrome", lambda: BrowserSession(self.logger, worker_context.worker_id)
            ).get()
            if job is not None:
                self.hub.job_manager.update(job, state=None, stage="browser_ready")
        runner = TestRunner(
            url=url,
            logger=self.logger,
            stop_event=stop_event,
            max_attempts=1,
            telegram_chat_ids=[],
            on_complete=None,
            mode="100",
            saved_answers=saved_answers,
            reset_cookies=True,
            user_name=user_name or "",
            driver=browser,
        )
        try:
            runner.run()
        except Exception as exc:
            self.logger.error(f"100% упал: {exc}")
            return "error", {}

        status = getattr(runner, "result_status", "") or ""
        score = getattr(runner, "result_score", {}) or {}
        if status in ("success", "partial", "unknown"):
            return status, score
        return "error", score

    def _report_100_result(self, chat_ids: List[str], url: str, status: str, score: dict) -> None:
        extra = _format_result_block(score)
        for cid in chat_ids:
            try:
                if status == "success":
                    text = RESULT_100_MESSAGE + ("\n\n" + extra if extra else "")
                    send_text(self.token, cid, text)
                elif status == "unknown":
                    if extra:
                        text = "✅ Тест завершён. Все ответы совпали с сохранёнными.\n\n" + extra
                        send_text(self.token, cid, text)
                    else:
                        send_text(
                            self.token, cid,
                            RESULT_UNKNOWN_MESSAGE.format(url=url),
                        )
            except Exception as exc:
                self.logger.warning(
                    f"Не удалось отправить результат ({status}) в {cid}: {exc}"
                )

    def _process_100(self, url: str, subscribers: List[str], user_name: str = "", job: Optional[Job] = None, worker_context=None) -> None:
        cached = self.cache.get(url)
        saved_answers = (cached.get("answers") if cached else None) or []

        if not saved_answers:
            self.logger.info(f"/r: в кэше нет ответов для {url} — сначала collect.")
            self._process_collect(url, subscribers, job, worker_context)
            if is_stop_requested() or (job is not None and job.cancel_event.is_set()):
                return
            cached = self.cache.get(url)
            saved_answers = (cached.get("answers") if cached else None) or []
            if not saved_answers:
                self.logger.warning("После сбора ответы не найдены — 100% прохождение отменено.")
                if not is_stop_requested():
                    self._notify_error(subscribers)
                return

        # --- Попытка 1 ---
        status, score = self._attempt_100(url, saved_answers, user_name, job, worker_context)
        if is_stop_requested():
            for cid in subscribers:
                try:
                    send_text(self.token, cid, STOPPED_MESSAGE)
                except Exception:
                    pass
            return
        if status in ("success", "unknown"):
            self._report_100_result(subscribers, url, status, score)
            return

        # --- Пересбор + Попытка 2 ---
        self.logger.info("Первый проход не дал 100% — пересобираю ответы.")
        for cid in subscribers:
            try:
                send_text(self.token, cid, RETRY_100_MESSAGE)
            except Exception:
                pass

        self._restart_browser(worker_context)
        self._process_collect(url, subscribers, job, worker_context)
        if is_stop_requested() or (job is not None and job.cancel_event.is_set()):
            return

        cached = self.cache.get(url)
        saved_answers = (cached.get("answers") if cached else None) or []
        if not saved_answers:
            self.logger.warning("После повторного сбора ответы не найдены — 100% отменено.")
            if not is_stop_requested():
                self._notify_error(subscribers)
            return

        status, score = self._attempt_100(url, saved_answers, user_name, job, worker_context)
        if is_stop_requested():
            for cid in subscribers:
                try:
                    send_text(self.token, cid, STOPPED_MESSAGE)
                except Exception:
                    pass
            return
        if status in ("success", "unknown"):
            self._report_100_result(subscribers, url, status, score)
            return

        for cid in subscribers:
            try:
                send_text(self.token, cid, NO_100_MESSAGE)
            except Exception:
                pass

    # ------------------------------------------------------------------ #
    def _notify_error(self, chat_ids: List[str]) -> None:
        try:
            contact = (load_settings().get("error_contact") or "").strip()
        except Exception:
            contact = ""
        text = ERROR_TEXT_WITH_CONTACT.format(contact=contact) if contact else ERROR_TEXT_NO_CONTACT
        for cid in chat_ids:
            try:
                send_text(self.token, cid, text)
            except Exception as exc:
                self.logger.warning(f"Не удалось отправить сообщение {cid}: {exc}")


def _split(text: str, limit: int = 4000) -> List[str]:
    if len(text) <= limit:
        return [text]
    chunks, current = [], ""
    for line in text.split("\n"):
        cand = current + ("\n" if current else "") + line
        if len(cand) > limit:
            if current:
                chunks.append(current)
            current = line
        else:
            current = cand
    if current:
        chunks.append(current)
    return chunks