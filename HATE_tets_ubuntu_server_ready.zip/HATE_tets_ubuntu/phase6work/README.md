# HATE_tets — Ubuntu Server

Серверная версия HATE_tets. Локального GUI, Tray, EXE и Windows-скриптов нет.

## Доступ

После запуска открой с телефона/ПК в той же LAN:

`http://IP_СЕРВЕРА:8765/`

Весь интерфейс находится в браузере.

## Архитектура

```text
Телефон / ПК / планшет
          │
       Browser
          │ HTTP
          ▼
   ApplicationHub
     ┌────┼─────┐
     ▼    ▼     ▼
    Web  Jobs Telegram
          │
       Workers
          │
       Selenium
          │
 Chromium/Chrome
```

Web больше не является отдельным процессом и не использует файловый IPC для команд. Все команды проходят через `ApplicationHub`.

## Установка

Из корня проекта:

```bash
sudo ./install.sh
```

Установка создаёт Python venv, ставит зависимости и регистрирует `systemd`-службу `hate-tets`.

## Управление

```bash
sudo systemctl status hate-tets
sudo systemctl restart hate-tets
sudo systemctl stop hate-tets
journalctl -u hate-tets -f
```

## Конфигурация

`config.txt` можно редактировать из Web-панели. Данные приложения находятся в `data/`.

На Ubuntu Server браузер запускается headless, если нет `DISPLAY`/Wayland.
