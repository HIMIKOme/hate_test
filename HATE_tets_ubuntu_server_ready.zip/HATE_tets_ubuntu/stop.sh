#!/usr/bin/env bash
set -euo pipefail
systemctl stop hate-tets.service
