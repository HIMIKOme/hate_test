# HATE_tets — Ubuntu Server Edition

Это серверная версия проекта. Windows GUI, Tray и EXE полностью удалены.

## Как запустить

Распакуй архив на Ubuntu Server и выполни:

```bash
cd HATE_tets
sudo ./install.sh
```

Скрипт устанавливает Python, Chromium, зависимости, создаёт виртуальное окружение и регистрирует `systemd`-службу.

После запуска открой на телефоне/ПК в той же локальной сети:

```text
http://IP_UBUNTU:8765/
```

IP сервера можно узнать командой:

```bash
hostname -I
```

## Управление

```bash
sudo systemctl status hate-tets
sudo systemctl restart hate-tets
sudo systemctl stop hate-tets
journalctl -u hate-tets -f
```

## Архитектура

```text
Телефон / ПК / планшет
        │
        ▼
   Web Browser
        │ HTTP
        ▼
 ApplicationHub
   ┌────┼───────────┐
   ▼    ▼           ▼
 Web  JobManager  Telegram
        │
        ▼
     Workers
        │
        ▼
 Chromium/Selenium
```

Web работает внутри того же процесса, что и Hub. Файловый IPC между Web и приложением больше не используется.

## Headless Chrome

Ubuntu Server может работать без графического рабочего стола. В таком режиме Chromium запускается автоматически с `--headless=new`.

## Конфигурация

Основные настройки находятся в `phase6work/config.txt` и `phase6work/data/settings.json`.

Токен Telegram и остальные параметры можно менять через Web-панель.
